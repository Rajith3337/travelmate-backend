import { useState, useEffect } from "react";
import { tripsApi, expensesApi } from "../api/client";
import { DARK, LIGHT } from "../styles/theme";
import { Spinner } from "./UI";

const T = d => d === false ? LIGHT : DARK;

function genNotifications(trips, expenses, { includeTips = false } = {}) {
  const notes = [];
  const now = new Date();
  const today = now.toISOString().slice(0, 10);

  trips.forEach(t => {
    if (t.budget > 0 && t.progress >= 90 && t.status !== "completed") {
      notes.push({
        id: `budget-${t.id}`,
        type: "warning",
        icon: "⚠️",
        title: "Budget Alert",
        body: `${t.name} is at ${t.progress}% of budget`,
      });
    }

    if (t.start_date && t.status !== "completed") {
      const diff = Math.ceil((new Date(t.start_date) - now) / 86400000);
      if (diff > 0 && diff <= 7) {
        notes.push({
          id: `start-${t.id}`,
          type: "info",
          icon: "✈️",
          title: "Trip Starting Soon",
          body: `${t.name} starts in ${diff} day${diff !== 1 ? "s" : ""}`,
          time: `${diff}d`,
        });
      }
      if (diff === 0) {
        notes.push({
          id: `today-${t.id}`,
          type: "success",
          icon: "🎉",
          title: "Trip Day!",
          body: `Have a great trip to ${t.destination}!`,
          time: "today",
        });
      }
    }

    if (t.end_date && t.status === "active") {
      const diff = Math.ceil((new Date(t.end_date) - now) / 86400000);
      if (diff >= 0 && diff <= 2) {
        notes.push({
          id: `end-${t.id}`,
          type: "warning",
          icon: "🏁",
          title: "Trip Ending Soon",
          body: `${t.name} ends ${diff === 0 ? "today" : `in ${diff} day(s)`}`,
        });
      }
    }
  });

  if (includeTips) {
    trips.forEach(t => {
      if (!["upcoming", "active"].includes(String(t.status))) return;
      notes.push({
        id: `daily-${t.id}-${today}`,
        type: "tip",
        icon: "REM",
        title: "Daily Reminder",
        body: `Review budget, packing list, and itinerary for ${t.name}.`,
        time: today,
      });
    });
  }

  expenses
    .filter(e => (now - new Date(e.created_at)) / 3600000 < 24 && e.amount > 2000)
    .forEach(e => {
      notes.push({
        id: `exp-${e.id}`,
        type: "info",
        icon: "💳",
        title: "Large Expense",
        body: `₹${e.amount.toLocaleString("en-IN")} for "${e.title}" logged`,
        time: "today",
      });
    });

  return notes;
}

async function loadNotifications({ includeTips = false } = {}) {
  if (!localStorage.getItem("tm_token")) return [];
  const trips = await tripsApi.list();
  const allExp = await Promise.all(trips.map(tr => expensesApi.list(tr.id).catch(() => [])));
  return genNotifications(trips, allExp.flat(), { includeTips });
}

export function useNotifCount() {
  const [count, setCount] = useState(0);

  useEffect(() => {
    let dead = false;

    const refresh = () => {
      loadNotifications({ includeTips: false }).then(notes => {
        if (dead) return;
        const unseen = notes.filter(n => !n.id || !localStorage.getItem("tm_seen_" + n.id));
        setCount(unseen.length);
      }).catch(() => {
        if (!dead) setCount(0);
      });
    };

    refresh();
    window.addEventListener("tm_data_updated", refresh);
    window.addEventListener("tm_notifications_updated", refresh);
    window.addEventListener("focus", refresh);
    window.addEventListener("storage", refresh);

    return () => {
      dead = true;
      window.removeEventListener("tm_data_updated", refresh);
      window.removeEventListener("tm_notifications_updated", refresh);
      window.removeEventListener("focus", refresh);
      window.removeEventListener("storage", refresh);
    };
  }, []);

  return count;
}

export function markNotifsRead(notes) {
  notes.forEach(n => { if (n.id) localStorage.setItem("tm_seen_" + n.id, "1"); });
  try { window.dispatchEvent(new Event("tm_notifications_updated")); } catch {}
}

const getTypeColors = t => ({ warning: t.amber, info: t.accent, success: t.green, tip: t.violetLight });

export default function Notifications({ onClose, dark }) {
  const t = T(dark);
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [dismissed, setDismissed] = useState(new Set());

  useEffect(() => {
    if (!localStorage.getItem("tm_token")) {
      setLoading(false);
      return;
    }
    loadNotifications({ includeTips: true }).then(generated => {
      setNotes(generated);
      generated.forEach(n => { if (n.id) localStorage.setItem("tm_seen_" + n.id, "1"); });
      try { window.dispatchEvent(new Event("tm_notifications_updated")); } catch {}
    }).catch(console.error).finally(() => setLoading(false));
  }, []);

  const visible = notes.filter(n => !dismissed.has(n.id));

  return (
    <div className="page-enter" style={{ maxWidth: 660 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900 }}>Notifications</h1>
          <div style={{ fontSize: 13, color: t.textDim, marginTop: 4 }}>
            {!loading && (visible.length === 0 ? "✅ All clear — no alerts right now" : `${visible.length} alert${visible.length !== 1 ? "s" : ""} need attention`)}
          </div>
        </div>
        <button
          onClick={onClose}
          style={{ width: 36, height: 36, borderRadius: 11, background: t.card, border: `1px solid ${t.border}`, color: t.textDim, fontSize: 16, cursor: "pointer", display: "flex", alignItems: "center", justifyContent: "center", transition: "all .18s" }}
          onMouseEnter={e => { e.currentTarget.style.background = `${t.red}15`; e.currentTarget.style.color = t.red; e.currentTarget.style.borderColor = `${t.red}44`; }}
          onMouseLeave={e => { e.currentTarget.style.background = t.card; e.currentTarget.style.color = t.textDim; e.currentTarget.style.borderColor = t.border; }}>
          ✕
        </button>
      </div>

      {loading ? (
        <div style={{ display: "flex", justifyContent: "center", padding: 60 }}><Spinner size={36} /></div>
      ) : visible.length === 0 ? (
        <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 22, padding: "60px 40px", textAlign: "center" }}>
          <div className="float" style={{ fontSize: 60, marginBottom: 18, display: "inline-block" }}>🎉</div>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 22, fontWeight: 800, marginBottom: 8 }}>All Clear!</div>
          <div style={{ color: t.textDim, fontSize: 14, lineHeight: 1.75 }}>No budget overruns, no upcoming trip deadlines.<br />Everything is perfectly on track.</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {visible.map((n, i) => {
            const col = getTypeColors(t)[n.type] || t.accent;
            return (
              <div
                key={n.id}
                className="fade-up"
                style={{
                  background: t.card,
                  borderRadius: 16,
                  padding: "15px 18px",
                  border: `1px solid ${col}30`,
                  borderLeft: `3px solid ${col}`,
                  boxShadow: `0 4px 24px ${col}10`,
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "flex-start",
                  transition: "all .2s",
                  animationDelay: `${i * 40}ms`,
                }}
                onMouseEnter={e => { e.currentTarget.style.transform = "translateX(5px)"; e.currentTarget.style.boxShadow = `0 8px 32px ${col}20`; }}
                onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = `0 4px 24px ${col}10`; }}>
                <div style={{ display: "flex", gap: 12, flex: 1 }}>
                  <span style={{ fontSize: 24, flexShrink: 0, marginTop: 1 }}>{n.icon}</span>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: col, marginBottom: 4 }}>{n.title}</div>
                    <div style={{ fontSize: 13, color: t.textDim, lineHeight: 1.65 }}>{n.body}</div>
                    {n.time && <div style={{ fontSize: 11, color: t.muted, marginTop: 5 }}>⏰ {n.time}</div>}
                  </div>
                </div>
                <button
                  onClick={() => setDismissed(d => new Set([...d, n.id]))}
                  style={{ background: "none", border: "none", color: t.muted, cursor: "pointer", fontSize: 16, flexShrink: 0, marginLeft: 10, padding: 4, borderRadius: 6, transition: "all .15s" }}
                  onMouseEnter={e => { e.currentTarget.style.background = `${t.red}15`; e.currentTarget.style.color = t.red; }}
                  onMouseLeave={e => { e.currentTarget.style.background = "none"; e.currentTarget.style.color = t.muted; }}>
                  ✕
                </button>
              </div>
            );
          })}
          {visible.length > 1 && (
            <button
              onClick={() => setDismissed(new Set(notes.map(n => n.id)))}
              style={{ padding: 12, borderRadius: 12, background: "none", border: `1px solid ${t.border}`, color: t.textDim, cursor: "pointer", fontSize: 13, fontFamily: "inherit", marginTop: 4, transition: "all .2s" }}
              onMouseEnter={e => { e.currentTarget.style.borderColor = `${t.red}55`; e.currentTarget.style.color = t.red; }}
              onMouseLeave={e => { e.currentTarget.style.borderColor = t.border; e.currentTarget.style.color = t.textDim; }}>
              Clear All Notifications
            </button>
          )}
        </div>
      )}
    </div>
  );
}