import { useEffect, useRef } from "react";
import { tripsApi, aiApi } from "../api/client";
import { useOfflineDownload } from "../hooks/useOfflineDownload";
import { useOfflineSync } from "../hooks/useOfflineSync";
import { isNativePlatform } from "../utils/offline";

const TRIPS_KEY = "tm_auto_trip_ids";
const OFFLINE_KEY = "tm_auto_offline_done";
const PRECOMPUTE_KEY = "tm_auto_precompute_last";

function readIdSet(key) {
  try {
    const raw = JSON.parse(localStorage.getItem(key) || "[]");
    return new Set(Array.isArray(raw) ? raw.map(String) : []);
  } catch {
    return new Set();
  }
}

function writeIdSet(key, set) {
  localStorage.setItem(key, JSON.stringify(Array.from(set)));
}

function wifiAllowed() {
  const raw = localStorage.getItem("offline_wifi_only_downloads");
  const wifiOnly = raw == null ? true : ["1", "true", "yes", "on"].includes(String(raw).toLowerCase());
  if (!wifiOnly) return true;
  const conn = navigator.connection || navigator.mozConnection || navigator.webkitConnection;
  if (!conn) return true;
  const type = (conn.type || conn.effectiveType || "").toLowerCase();
  return type === "wifi" || type === "ethernet";
}

export default function AutomationRunner({ user }) {
  const { downloadTripBundle } = useOfflineDownload();
  const { online, sync } = useOfflineSync();
  const runningRef = useRef(false);
  const lastRunRef = useRef(0);

  // Auto-sync queued changes when user is available and online.
  useEffect(() => {
    if (!user || !online) return;
    sync();
  }, [user, online, sync]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    const runAutomation = async () => {
      if (runningRef.current) return;
      runningRef.current = true;
      try {
        const trips = await tripsApi.list().catch(() => []);
        if (cancelled) return;

        // Auto-generate AI roadmap when a new trip is created.
        const known = readIdSet(TRIPS_KEY);
        const newTrips = trips.filter(t => !known.has(String(t.id)));
        if (newTrips.length > 0) {
          const last = parseInt(localStorage.getItem(PRECOMPUTE_KEY) || "0", 10);
          const now = Date.now();
          if (now - last > 60 * 1000) {
            aiApi.precomputeRoadmaps().catch(() => {});
            localStorage.setItem(PRECOMPUTE_KEY, String(now));
          }
        }
        trips.forEach(t => known.add(String(t.id)));
        writeIdSet(TRIPS_KEY, known);

        // Auto-download offline data for upcoming trips (native only).
        if (isNativePlatform() && online && wifiAllowed()) {
          const done = readIdSet(OFFLINE_KEY);
          const candidates = trips.filter(t => ["upcoming", "active"].includes(String(t.status)));
          for (const trip of candidates) {
            const tid = String(trip.id);
            if (done.has(tid)) continue;
            const ok = await downloadTripBundle(trip, { silent: true });
            if (ok) {
              done.add(tid);
              writeIdSet(OFFLINE_KEY, done);
            }
          }
        }
      } finally {
        runningRef.current = false;
        lastRunRef.current = Date.now();
      }
    };

    runAutomation();
    const handler = () => runAutomation();
    window.addEventListener("tm_trips_updated", handler);
    const intervalId = setInterval(() => {
      // Light periodic check (every 10 min) while app is open.
      if (Date.now() - lastRunRef.current > 9 * 60 * 1000) runAutomation();
    }, 2 * 60 * 1000);

    return () => {
      cancelled = true;
      window.removeEventListener("tm_trips_updated", handler);
      clearInterval(intervalId);
    };
  }, [user, online, downloadTripBundle]);

  return null;
}
