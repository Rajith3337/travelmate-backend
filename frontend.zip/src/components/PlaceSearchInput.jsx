/**
 * PlaceSearchInput — verified place search backed by Nominatim
 *
 * Props:
 *   value        string        current display value
 *   onSelect     fn(place)     called with { name, address, lat, lng, type, displayName }
 *   onChange     fn(string)    called when text changes (for controlled input)
 *   placeholder  string
 *   contextCity  string        optional — biases search toward a city
 *   dark         bool
 *   required     bool
 *   style        object
 */
import { useState, useRef, useEffect, useCallback } from "react";
import { DARK, LIGHT } from "../styles/theme";
import { aiApi } from "../api/client";

// Map OSM tags → friendly place type
function inferType(result) {
  const cls = result.class || "";
  const type = result.type || "";
  const tags = result.extratags || {};
  if (cls === "tourism" || type === "attraction" || type === "museum" || type === "monument" || type === "viewpoint") return "Attraction";
  if (cls === "amenity" && (type === "restaurant" || type === "cafe" || type === "fast_food" || type === "food_court")) return "Restaurant";
  if (cls === "tourism" && (type === "hotel" || type === "hostel" || type === "guest_house" || type === "motel")) return "Hotel";
  if (cls === "amenity" && (type === "hospital" || type === "clinic" || type === "pharmacy")) return "Hospital";
  if (cls === "railway" || cls === "highway" || type === "bus_stop" || type === "station" || type === "airport") return "Transport";
  if (cls === "natural" || cls === "leisure" || type === "park" || type === "beach" || type === "forest") return "Nature";
  if (cls === "shop" || type === "mall" || type === "supermarket" || type === "marketplace") return "Shopping";
  return "Attraction";
}

// Pick a good short display name from OSM result
function pickName(result) {
  const a = result.address || {};
  // Prefer specific names over generic city/country
  return (
    result.namedetails?.name ||
    result.name ||
    a.attraction || a.tourism || a.amenity ||
    a.building || a.road ||
    result.display_name.split(",")[0]
  );
}

// Build a clean short address line
function buildAddress(result) {
  const a = result.address || {};
  const parts = [
    a.road || a.pedestrian || a.footway,
    a.suburb || a.neighbourhood || a.quarter,
    a.city || a.town || a.village || a.municipality,
    a.state,
    a.country,
  ].filter(Boolean);
  return parts.slice(0, 4).join(", ");
}

// Category icons
const TYPE_ICON = {
  Attraction: "🏛️", Restaurant: "🍽️", Hotel: "🏨",
  Hospital: "🏥", Transport: "🚉", Nature: "🌿",
  Shopping: "🛍️", Other: "📍",
};

export default function PlaceSearchInput({
  value,
  onSelect,
  onChange,
  placeholder = "Search for a place…",
  contextCity = "",
  dark = true,
  required = false,
  style = {},
  tripId = null,
}) {
  const t = dark ? DARK : LIGHT;
  const [query,       setQuery]       = useState(value || "");
  const [suggestions, setSuggestions] = useState([]);
  const [loading,     setLoading]     = useState(false);
  const [aiLoading,   setAiLoading]   = useState(false);
  const [open,        setOpen]        = useState(false);
  const [verified,    setVerified]    = useState(false);  // true after user picks from list
  const [selected,    setSelected]    = useState(null);
  const debounceRef = useRef(null);
  const wrapRef     = useRef(null);
  const abortRef    = useRef(null);

  // Sync external value changes
  useEffect(() => {
    if (value !== undefined && value !== query) {
      setQuery(value);
      if (!value) { setVerified(false); setSelected(null); setSuggestions([]); }
    }
  }, [value]);

  // Close dropdown on outside click
  useEffect(() => {
    const h = e => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  const search = useCallback(async (q) => {
    if (q.length < 2) { setSuggestions([]); setOpen(false); return; }
    abortRef.current?.abort();
    abortRef.current = new AbortController();
    setLoading(true);
    try {
      const bias = contextCity ? ` ${contextCity}` : "";
      const url = [
        `https://nominatim.openstreetmap.org/search`,
        `?q=${encodeURIComponent(q + bias)}`,
        `&format=json&limit=10&addressdetails=1&namedetails=1&extratags=1&email=app@travelmate.local`,
      ].join("");
      const r = await fetch(url, {
        headers: { "Accept-Language": "en" },
        signal: abortRef.current.signal,
      });
      const data = await r.json();
      console.log('Search results for', q, ':', data);
      setSuggestions(data);
      setOpen(data.length > 0);
    } catch (e) {
      if (e.name !== "AbortError") {
        console.error('Search error:', e);
        setSuggestions([]);
      }
    } finally {
      setLoading(false);
    }
  }, [contextCity]);

  const askAI = async () => {
    if (!tripId) { alert("Please select a trip first to use AI Vibe Search"); return; }
    setAiLoading(true); setSuggestions([]); setOpen(true);
    try {
      const prompt = `Recommend 3 places corresponding to this vibe or query: "${query}" ${contextCity ? 'in ' + contextCity : ''}. You MUST return ONLY a raw JSON array (no markdown code blocks, no text before or after). Format: [{"name": "Place Name", "lat": 28.6, "lon": 77.2, "type": "Attraction", "display_name": "Full address string"}]`;
      const res = await aiApi.recommend(tripId, prompt);
      
      // Clean up markdown markers if any
      let jsonStr = res.response.replace(/```(json)?|```/gi, "").trim();
      const stIdx = jsonStr.indexOf("[");
      const enIdx = jsonStr.lastIndexOf("]");
      if (stIdx !== -1 && enIdx !== -1) {
        jsonStr = jsonStr.substring(stIdx, enIdx + 1);
      }
      
      const items = JSON.parse(jsonStr);
      setSuggestions(items.map((i, idx) => ({
        place_id: "ai_" + idx,
        name: i.name,
        lat: String(i.lat),
        lon: String(i.lon),
        type: i.type?.toLowerCase() || "attraction",
        display_name: i.display_name || i.name,
        address: { building: i.name, city: contextCity }
      })));
    } catch (e) {
      console.error(e);
      setSuggestions([{ place_id: "error", name: "AI Search Failed", display_name: "Try again later", type: "error" }]);
    } finally {
      setAiLoading(false);
    }
  };

  const handleChange = e => {
    const v = e.target.value;
    setQuery(v);
    setVerified(false);
    setSelected(null);
    onChange?.(v);
    clearTimeout(debounceRef.current);
    // Use an 750ms debounce to strictly comply with Nominatim's ToS and prevent dropped/hung connections
    debounceRef.current = setTimeout(() => search(v), 750);
  };

  const handleSelect = result => {
    const name    = pickName(result);
    const address = buildAddress(result);
    const lat     = parseFloat(result.lat);
    const lng     = parseFloat(result.lon);
    const type    = inferType(result);

    setQuery(name);
    setVerified(true);
    setSelected({ name, address, lat, lng, type, displayName: result.display_name });
    setSuggestions([]);
    setOpen(false);

    onChange?.(name);
    onSelect?.({ name, address, lat, lng, type, displayName: result.display_name });
  };

  const handleClear = () => {
    setQuery("");
    setVerified(false);
    setSelected(null);
    setSuggestions([]);
    setOpen(false);
    onChange?.("");
    onSelect?.(null);
  };

  const borderColor = query && !verified
    ? `${t.amber}88`
    : verified
      ? `${t.green}88`
      : t.border;

  const bgColor = query && !verified
    ? `${t.amber}06`
    : verified
      ? `${t.green}06`
      : t.surface;

  return (
    <div ref={wrapRef} style={{ position: "relative", ...style }}>
      {/* Input */}
      <div style={{
        display: "flex", alignItems: "center", gap: 8,
        background: bgColor,
        border: `1px solid ${borderColor}`,
        borderRadius: 10,
        padding: "9px 12px",
        transition: "border-color .2s, background .2s",
      }}>
        <span style={{ fontSize: 15, flexShrink: 0, opacity: .7 }}>
          {verified ? TYPE_ICON[selected?.type] || "📍" : "🔍"}
        </span>
        <input
          value={query}
          onChange={handleChange}
          onFocus={() => { if (suggestions.length > 0) setOpen(true); }}
          placeholder={placeholder}
          required={required}
          autoComplete="off"
          style={{
            flex: 1, background: "transparent", border: "none", outline: "none",
            color: t.text, fontSize: 13, fontFamily: "inherit",
          }}
        />
        {loading && (
          <span style={{ fontSize: 11, color: t.textSub, flexShrink: 0 }}>…</span>
        )}
        {verified && (
          <span style={{ fontSize: 11, color: t.green, fontWeight: 700, flexShrink: 0 }}>✓</span>
        )}
        {query && (
          <button type="button" onClick={handleClear}
            style={{ background: "none", border: "none", color: t.textSub, cursor: "pointer", fontSize: 14, lineHeight: 1, flexShrink: 0, padding: 0 }}>
            ✕
          </button>
        )}
      </div>

      {/* Unverified warning - only show if user has typed something but hasn't selected */}
      {query.length > 1 && !verified && !loading && !open && (
        <div style={{ marginTop: 4, fontSize: 11, color: t.amber, display: "flex", alignItems: "center", gap: 5 }}>
          <span>⚠️</span>
          <span>Select a result from the list or continue with custom name</span>
        </div>
      )}

      {/* Verified address pill */}
      {verified && selected?.address && (
        <div style={{ marginTop: 4, fontSize: 11, color: t.green, display: "flex", alignItems: "center", gap: 5 }}>
          <span>✓</span>
          <span style={{ color: t.textSub }}>{selected.address}</span>
          {selected.lat && (
            <span style={{ color: t.textDim, fontFamily: "monospace" }}>
              ({selected.lat.toFixed(4)}, {selected.lng.toFixed(4)})
            </span>
          )}
        </div>
      )}

      {/* Suggestions dropdown */}
      {open && suggestions.length > 0 && (
        <div style={{
          position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0,
          background: t.card, border: `1px solid ${t.border}`, borderRadius: 12,
          zIndex: 9999, boxShadow: dark ? "0 12px 40px rgba(0,0,0,.5)" : "0 8px 24px rgba(0,0,0,.15)",
          overflow: "hidden", maxHeight: 320, overflowY: "auto",
        }}>
          <div style={{ padding: "7px 12px 5px", fontSize: 10, color: t.textDim, fontWeight: 600, textTransform: "uppercase", letterSpacing: ".07em", borderBottom: `1px solid ${t.border}` }}>
            Verified results from OpenStreetMap
          </div>
          {suggestions.map((r, i) => {
            const name    = pickName(r);
            const address = buildAddress(r);
            const type    = inferType(r);
            return (
              <div key={r.place_id || i}
                onClick={() => handleSelect(r)}
                style={{
                  padding: "10px 14px", cursor: "pointer",
                  borderBottom: i < suggestions.length - 1 ? `1px solid ${t.border}` : "none",
                  display: "flex", alignItems: "flex-start", gap: 10,
                  transition: "background .12s",
                }}
                onMouseEnter={e => e.currentTarget.style.background = t.cardHover}
                onMouseLeave={e => e.currentTarget.style.background = ""}>
                <span style={{ fontSize: 18, flexShrink: 0, marginTop: 1 }}>{TYPE_ICON[type] || "📍"}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 600, color: t.text, marginBottom: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {name}
                  </div>
                  <div style={{ fontSize: 11, color: t.textSub, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                    {address}
                  </div>
                </div>
                <div style={{ flexShrink: 0, textAlign: "right" }}>
                  <span style={{ fontSize: 10, padding: "2px 7px", borderRadius: 20, background: `${t.accent}14`, color: t.accent, fontWeight: 600 }}>
                    {type}
                  </span>
                </div>
              </div>
            );
          })}
          <div style={{ padding: "6px 12px", fontSize: 10, color: t.textDim, borderTop: `1px solid ${t.border}`, textAlign: "right" }}>
            Powered by OpenStreetMap · Nominatim
          </div>
        </div>
      )}

      {/* No results */}
      {open && suggestions.length === 0 && !loading && query.length > 2 && (
        <div style={{
          position: "absolute", top: "calc(100% + 6px)", left: 0, right: 0,
          background: t.card, border: `1px solid ${t.border}`, borderRadius: 12,
          zIndex: 9999, padding: "14px 16px",
          boxShadow: dark ? "0 12px 40px rgba(0,0,0,.5)" : "0 8px 24px rgba(0,0,0,.15)",
        }}>
          <div style={{ fontSize: 13, color: t.textSub, textAlign: "center", marginBottom: 12 }}>
            🔍 No results for "<strong>{query}</strong>"
          </div>
          
          <button onClick={askAI} disabled={aiLoading} style={{ width: "100%", padding: "10px", borderRadius: 10, background: "linear-gradient(135deg,#A855F7,#7E22CE)", color: "#fff", border: "none", fontWeight: 700, cursor: aiLoading ? "not-allowed" : "pointer", display: "flex", justifyContent: "center", gap: 8, fontSize: 12, fontFamily: "inherit" }}>
            {aiLoading ? <span className="lm-spin" style={{ width: 14, height: 14, border: "2px solid #fff4", borderTopColor: "#fff", borderRadius: "50%" }} /> : "🧠 Ask AI (Vibe Search)"}
          </button>
        </div>
      )}
    </div>
  );
}
