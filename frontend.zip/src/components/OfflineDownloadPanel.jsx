﻿// OfflineDownloadPanel - shown in map/offline pages
// Allows downloading map tiles and phrase packs for offline use
import { useState } from "react";
import { useOfflineDownload } from "../hooks/useOfflineDownload";
import { isNativePlatform } from "../utils/offline";

function ProgressBar({ done, total, color = "#3B82F6" }) {
  const pct = total > 0 ? Math.round((done / total) * 100) : 0;
  return (
    <div style={{ marginTop: 6 }}>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, marginBottom: 4, color: "var(--tm-textSub, #94A3B8)" }}>
        <span>{done} / {total} saved</span>
        <span>{pct}%</span>
      </div>
      <div style={{ height: 5, borderRadius: 99, background: "rgba(255,255,255,0.08)", overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${pct}%`, borderRadius: 99, background: color, transition: "width .3s" }} />
      </div>
    </div>
  );
}

const LANGS = [
  { code: "hi", name: "Hindi" },
  { code: "ta", name: "Tamil" },
  { code: "te", name: "Telugu" },
  { code: "kn", name: "Kannada" },
  { code: "bn", name: "Bengali" },
  { code: "mr", name: "Marathi" },
  { code: "fr", name: "French" },
  { code: "es", name: "Spanish" },
];

const PHRASES = [
  "Hello", "Thank you", "Please", "Where is the station?",
  "How much does this cost?", "I need help", "Call a taxi",
  "I am allergic to peanuts", "Where is the hospital?",
  "I need vegetarian food", "Can you show me on the map?",
  "I do not understand", "Do you speak English?",
  "Can I pay by card?", "I need internet",
];

export default function OfflineDownloadPanel({ t, trips = [] }) {
  const {
    tileProgress,
    transProgress,
    tripProgress,
    bundleProgress,
    cachedRoutes,
    cachedLangs,
    cachedTrips,
    downloadRouteTiles,
    downloadTranslations,
    downloadTripData,
    downloadTripBundle,
    clearTileCache,
    clearTranslationCache,
    clearTripCache,
    clearAllOfflineCaches,
  } = useOfflineDownload();

  const [selTrip, setSelTrip] = useState("");
  const [selLang, setSelLang] = useState("hi");
  const isNative = isNativePlatform();

  const handleDownloadRoute = async () => {
    const trip = trips.find(tr => String(tr.id) === selTrip);
    if (!trip || !trip.destination) return;
    try {
      const r = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(trip.destination)}&format=json&limit=1`);
      const d = await r.json();
      if (!d[0]) return;
      const lat = parseFloat(d[0].lat);
      const lng = parseFloat(d[0].lon);
      const delta = 1.5;
      await downloadRouteTiles({
        label: trip.destination,
        minLat: lat - delta,
        maxLat: lat + delta,
        minLng: lng - delta,
        maxLng: lng + delta,
        minZoom: 8,
        maxZoom: 12,
      });
    } catch (e) {
      console.error("Download tiles:", e);
    }
  };

  const cardSt = {
    background: t.card,
    border: `1px solid ${t.border}`,
    borderRadius: 14,
    padding: "16px 18px",
    marginBottom: 0,
  };

  const selSt = {
    background: t.surface,
    border: `1px solid ${t.border}`,
    borderRadius: 9,
    padding: "8px 12px",
    color: t.text,
    fontSize: 12,
    fontFamily: "inherit",
    outline: "none",
    cursor: "pointer",
  };

  const btnSt = (enabled, color = t.accent) => ({
    background: enabled ? color : t.textDim + "22",
    color: enabled ? "#fff" : t.textDim,
    border: "none",
    borderRadius: 9,
    padding: "8px 14px",
    fontSize: 12,
    fontWeight: 700,
    cursor: enabled ? "pointer" : "not-allowed",
    fontFamily: "inherit",
    transition: "all .2s",
  });

  if (!isNative) {
    return (
      <div style={cardSt}>
        <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 6, color: t.text }}>Offline Downloads</div>
        <div style={{ fontSize: 13, color: t.textSub }}>
          Offline downloads are available only in the Android/iOS app and are saved to the device folder.
        </div>
      </div>
    );
  }

  return (
    <div style={cardSt}>
      <div style={{ fontWeight: 700, fontSize: 15, marginBottom: 4, color: t.text }}>Offline Downloads</div>
      <div style={{ fontSize: 12, color: t.textSub, marginBottom: 14 }}>
        Download maps and phrase packs for use without internet.
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ fontSize: 12, color: t.textSub, lineHeight: 1.6 }}>
          Save your trip route + places route with map tiles to view fully offline.
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <select value={selTrip} onChange={e => setSelTrip(e.target.value)} style={selSt}>
            <option value="">Select trip...</option>
            {trips.map(tr => <option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name}</option>)}
          </select>
          <button
            onClick={() => {
              const trip = trips.find(tr => String(tr.id) === String(selTrip));
              if (trip) downloadTripBundle(trip);
            }}
            disabled={!selTrip || bundleProgress?.active}
            style={btnSt(!(!selTrip || bundleProgress?.active), "#0EA5E9")}
          >
            {bundleProgress?.active ? "Saving..." : "Save Trip + Routes"}
          </button>
        </div>

        {bundleProgress && (
          <div style={{ background: t.surface, borderRadius: 9, padding: "10px 13px", border: `1px solid ${t.border}` }}>
            <div style={{ fontSize: 12, color: "#0EA5E9", fontWeight: 600, marginBottom: 3 }}>
              {bundleProgress.active ? "Saving trip routes for offline..." : "Trip saved for offline use"}
            </div>
            <ProgressBar done={bundleProgress.done} total={bundleProgress.total} color="#0EA5E9" />
          </div>
        )}

        <div style={{ height: 1, background: t.border, margin: "6px 0" }} />

        <div style={{ fontSize: 12, color: t.textSub, lineHeight: 1.6 }}>
          Downloads map tiles for a 150km area around your trip destination (zoom 8 to 12).
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <select value={selTrip} onChange={e => setSelTrip(e.target.value)} style={selSt}>
            <option value="">Select trip destination...</option>
            {trips.filter(tr => tr.destination).map(tr => (
              <option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name} {"->"} {tr.destination}</option>
            ))}
          </select>
          <button onClick={handleDownloadRoute} disabled={!selTrip || tileProgress?.active} style={btnSt(!!selTrip && !tileProgress?.active)}>
            {tileProgress?.active ? "Downloading..." : "Download Map"}
          </button>
        </div>

        {tileProgress && (
          <div style={{ background: t.surface, borderRadius: 9, padding: "10px 13px", border: `1px solid ${t.border}` }}>
            <div style={{ fontSize: 12, color: t.accent, fontWeight: 600, marginBottom: 3 }}>
              {tileProgress.active ? "Downloading map tiles..." : "Download complete"}
            </div>
            <ProgressBar done={tileProgress.done} total={tileProgress.total} color={t.accent} />
          </div>
        )}

        {cachedRoutes.length > 0 && (
          <div style={{ background: t.surface, borderRadius: 9, padding: "10px 13px", border: `1px solid ${t.border}` }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textDim, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 7 }}>
              Saved map areas
            </div>
            {cachedRoutes.map((r, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: t.textSub, padding: "3px 0" }}>
                <span>{r.label}</span>
                <span style={{ color: t.accent }}>{r.tiles} tiles</span>
              </div>
            ))}
            <button onClick={clearTileCache}
              style={{ marginTop: 8, fontSize: 11, color: t.red, background: "none", border: `1px solid ${t.red}33`, borderRadius: 7, padding: "4px 10px", cursor: "pointer", fontFamily: "inherit" }}>
              Clear saved maps
            </button>
          </div>
        )}
      </div>

      <div style={{ height: 1, background: t.border, margin: "16px 0" }} />

      {/* OFFLINE TRIP DATA */}
      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ fontSize: 12, color: t.textSub, lineHeight: 1.6 }}>
          Download complete trip data for offline access including places, itinerary, and expenses.
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <select value={selTrip} onChange={e => setSelTrip(e.target.value)} style={selSt}>
            <option value="">Select trip...</option>
            {trips.map(tr => <option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name}</option>)}
          </select>
          <button
            onClick={() => {
              if (selTrip) {
                const trip = trips.find(tr => tr.id === selTrip);
                if (trip) downloadTripData(trip);
              }
            }}
            disabled={!selTrip || tripProgress?.active}
            style={btnSt(!(!selTrip || tripProgress?.active), "#10B981")}
          >
            {tripProgress?.active ? "Downloading..." : "Download Trip Data"}
          </button>
        </div>

        {tripProgress && (
          <div style={{ background: t.surface, borderRadius: 9, padding: "10px 13px", border: `1px solid ${t.border}` }}>
            <div style={{ fontSize: 12, color: "#10B981", fontWeight: 600, marginBottom: 3 }}>
              {tripProgress.active ? "Downloading trip data..." : "Download complete"}
            </div>
            <ProgressBar done={tripProgress.done} total={tripProgress.total} color="#10B981" />
          </div>
        )}

        {cachedTrips.length > 0 && (
          <div style={{ background: t.surface, borderRadius: 9, padding: "10px 13px", border: `1px solid ${t.border}` }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textDim, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 7 }}>
              Saved trip data
            </div>
            {cachedTrips.map((trip, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: t.textSub, padding: "3px 0" }}>
                <span>{trip.emoji} {trip.name}</span>
                <span style={{ color: "#10B981" }}>{trip.places} places</span>
              </div>
            ))}
            <button onClick={clearTripCache}
              style={{ marginTop: 8, fontSize: 11, color: t.red, background: "none", border: `1px solid ${t.red}33`, borderRadius: 7, padding: "4px 10px", cursor: "pointer", fontFamily: "inherit" }}>
              Clear saved trip data
            </button>
          </div>
        )}
      </div>

      <div style={{ height: 1, background: t.border, margin: "16px 0" }} />

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        <div style={{ fontSize: 12, color: t.textSub, lineHeight: 1.6 }}>
          Download travel phrase packs for offline translation assistance.
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <select value={selLang} onChange={e => setSelLang(e.target.value)} style={selSt}>
            {LANGS.map(l => <option key={l.code} value={l.code}>{l.name}</option>)}
          </select>
          <button
            onClick={() => {
              const lang = LANGS.find(l => l.code === selLang);
              if (lang) downloadTranslations(lang.code, lang.name, PHRASES);
            }}
            disabled={transProgress?.active}
            style={btnSt(!transProgress?.active, "#A855F7")}
          >
            {transProgress?.active ? "Downloading..." : "Download Phrases"}
          </button>
        </div>

        {transProgress && (
          <div style={{ background: t.surface, borderRadius: 9, padding: "10px 13px", border: `1px solid ${t.border}` }}>
            <div style={{ fontSize: 12, color: "#A855F7", fontWeight: 600, marginBottom: 3 }}>
              {transProgress.active ? `Downloading ${transProgress.lang} pack...` : "Phrase pack ready"}
            </div>
            <ProgressBar done={transProgress.done} total={transProgress.total} color="#A855F7" />
          </div>
        )}

        {cachedLangs.length > 0 && (
          <div style={{ background: t.surface, borderRadius: 9, padding: "10px 13px", border: `1px solid ${t.border}` }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textDim, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 7 }}>
              Saved phrase packs
            </div>
            {cachedLangs.map((l, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: t.textSub, padding: "3px 0" }}>
                <span>{l.name}</span>
                <span style={{ color: "#A855F7" }}>{l.phrases} phrases</span>
              </div>
            ))}
            <div style={{ display: "flex", gap: 8, marginTop: 8, flexWrap: "wrap" }}>
              <button onClick={clearTranslationCache}
                style={{ fontSize: 11, color: "#A855F7", background: "none", border: "1px solid #A855F733", borderRadius: 7, padding: "4px 10px", cursor: "pointer", fontFamily: "inherit" }}>
                Clear saved phrases
              </button>
              <button onClick={clearAllOfflineCaches}
                style={{ fontSize: 11, color: t.red, background: "none", border: `1px solid ${t.red}33`, borderRadius: 7, padding: "4px 10px", cursor: "pointer", fontFamily: "inherit" }}>
                Clear all offline files
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

