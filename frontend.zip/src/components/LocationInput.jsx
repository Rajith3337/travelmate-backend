// LocationInput — shared autocomplete component using Nominatim (free, no key)
// Drop-in replacement for any raw <input> that takes a city/location value.
//
// Props:
//   value       – controlled string value
//   onChange    – (stringValue) => void
//   onSelect    – ({ label, lat, lng }) => void  (optional, fires on pick)
//   placeholder – string
//   label       – optional label text above input
//   icon        – optional emoji prefix inside the input
//   dark        – boolean
//   style       – override wrapper div style
//   inputStyle  – override input element style
//   required    – boolean
//   autoFocus   – boolean
//   disabled    – boolean
//   zIndex      – dropdown z-index (default 3000)

import { useState, useEffect, useRef } from "react";
import { DARK, LIGHT } from "../styles/theme";

async function nominatimSearch(q) {
  const url = `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&limit=6&addressdetails=1`;
  const r = await fetch(url, {
    headers: { "Accept-Language": "en" },
    signal: AbortSignal.timeout(6000),
  });
  if (!r.ok) return [];
  const data = await r.json();
  return data.map(x => ({
    label: [
      x.address?.city || x.address?.town || x.address?.village || x.address?.county || x.name,
      x.address?.state,
      x.address?.country,
    ].filter(Boolean).join(", "),
    lat: parseFloat(x.lat),
    lng: parseFloat(x.lon),
  })).filter(x => x.label);
}

export default function LocationInput({
  value = "",
  onChange,
  onSelect,
  placeholder = "Search location…",
  label,
  icon,
  dark = true,
  style = {},
  inputStyle = {},
  required = false,
  autoFocus = false,
  disabled = false,
  zIndex = 3000,
}) {
  const t = dark ? DARK : LIGHT;
  const [suggestions, setSuggestions] = useState([]);
  const [open,        setOpen]        = useState(false);
  const [busy,        setBusy]        = useState(false);
  const [activeIdx,   setActiveIdx]   = useState(-1);
  const debRef   = useRef(null);
  const wrapRef  = useRef(null);
  const inputRef = useRef(null);

  // Close dropdown on outside click
  useEffect(() => {
    const handler = e => {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const handleChange = e => {
    const v = e.target.value;
    onChange?.(v);
    setActiveIdx(-1);
    clearTimeout(debRef.current);
    if (v.length < 2) { setSuggestions([]); setOpen(false); return; }
    debRef.current = setTimeout(async () => {
      setBusy(true);
      try {
        const res = await nominatimSearch(v);
        setSuggestions(res);
        setOpen(res.length > 0);
      } catch {}
      setBusy(false);
    }, 380);
  };

  const pick = (s) => {
    onChange?.(s.label.split(",")[0].trim());
    onSelect?.(s);
    setSuggestions([]);
    setOpen(false);
    setActiveIdx(-1);
  };

  const handleKeyDown = e => {
    if (!open || !suggestions.length) return;
    if (e.key === "ArrowDown") { e.preventDefault(); setActiveIdx(i => Math.min(i + 1, suggestions.length - 1)); }
    if (e.key === "ArrowUp")   { e.preventDefault(); setActiveIdx(i => Math.max(i - 1, 0)); }
    if (e.key === "Enter" && activeIdx >= 0) { e.preventDefault(); pick(suggestions[activeIdx]); }
    if (e.key === "Escape") { setOpen(false); setActiveIdx(-1); }
  };

  const baseInputSt = {
    background: "transparent",
    border: "none",
    outline: "none",
    color: t.text,
    fontSize: 13,
    fontFamily: "inherit",
    width: "100%",
    minWidth: 0,
    ...inputStyle,
  };

  const wrapSt = {
    position: "relative",
    ...style,
  };

  const boxSt = {
    display: "flex",
    alignItems: "center",
    gap: 6,
    background: t.surface,
    border: `1px solid ${t.border}`,
    borderRadius: 9,
    padding: "8px 11px",
    transition: "border-color .15s",
  };

  return (
    <div ref={wrapRef} style={wrapSt}>
      {label && (
        <div style={{ fontSize: 10, fontWeight: 700, color: t.textDim, textTransform: "uppercase", letterSpacing: ".07em", marginBottom: 5 }}>
          {label}{required && <span style={{ color: t.red, marginLeft: 2 }}>*</span>}
        </div>
      )}
      <div style={boxSt}
        onFocus={() => { boxSt.borderColor = t.accent; }}
        onBlur={() => { boxSt.borderColor = t.border; }}>
        {icon && <span style={{ fontSize: 14, flexShrink: 0, opacity: 0.7 }}>{icon}</span>}
        <input
          ref={inputRef}
          value={value}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          onFocus={() => suggestions.length && setOpen(true)}
          placeholder={placeholder}
          required={required}
          autoFocus={autoFocus}
          disabled={disabled}
          autoComplete="off"
          style={baseInputSt}
        />
        {busy && (
          <span style={{ width: 10, height: 10, border: `2px solid ${t.border}`, borderTopColor: t.accent, borderRadius: "50%", display: "inline-block", animation: "locSpin .6s linear infinite", flexShrink: 0 }} />
        )}
      </div>

      {/* Dropdown */}
      {open && suggestions.length > 0 && (
        <div style={{
          position: "absolute",
          top: "calc(100% + 4px)",
          left: 0, right: 0,
          background: t.card,
          border: `1px solid ${t.border}`,
          borderRadius: 10,
          zIndex,
          boxShadow: "0 8px 28px rgba(0,0,0,.35)",
          overflow: "hidden",
        }}>
          {suggestions.map((s, i) => (
            <div
              key={i}
              onMouseDown={e => { e.preventDefault(); pick(s); }}
              onMouseEnter={() => setActiveIdx(i)}
              style={{
                padding: "9px 13px",
                cursor: "pointer",
                fontSize: 12,
                color: t.text,
                background: i === activeIdx ? t.accentSoft : "transparent",
                borderBottom: i < suggestions.length - 1 ? `1px solid ${t.border}` : "none",
                display: "flex",
                alignItems: "center",
                gap: 7,
                transition: "background .1s",
              }}>
              <span style={{ opacity: 0.5, fontSize: 11 }}>📍</span>
              <div>
                <div style={{ fontWeight: 500 }}>{s.label.split(",")[0].trim()}</div>
                <div style={{ fontSize: 10, color: t.textDim, marginTop: 1 }}>{s.label.split(",").slice(1).join(",").trim()}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      <style>{`@keyframes locSpin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}
