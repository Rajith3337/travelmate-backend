import { Component } from "react";

export default class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { error: null, info: null };
  }

  static getDerivedStateFromError(error) {
    return { error };
  }

  componentDidCatch(error, info) {
    this.setState({ info });
    console.error("Page error caught by ErrorBoundary:", error, info);
  }

  reset() {
    this.setState({ error: null, info: null });
  }

  render() {
    if (this.state.error) {
      const t = this.props.dark
        ? { bg:"#161D2E", border:"#1E2D45", text:"#E2E8F0", sub:"#94A3B8", accent:"#3B82F6", red:"#EF4444" }
        : { bg:"#FFFFFF", border:"#C8D4E8", text:"#0F172A", sub:"#475569", accent:"#2563EB", red:"#DC2626" };

      return (
        <div style={{
          display:"flex", alignItems:"center", justifyContent:"center",
          minHeight:"60vh", padding:32, flexDirection:"column", gap:16, textAlign:"center",
        }}>
          <div style={{ width:56, height:56, borderRadius:14, background:`${t.red}12`, border:`1.5px solid ${t.red}33`, display:"flex", alignItems:"center", justifyContent:"center" }}>
            <div style={{ width:22, height:22, borderRadius:"50%", border:`2px solid ${t.red}`, position:"relative" }}>
              <div style={{ position:"absolute", top:"50%", left:"50%", transform:"translate(-50%,-60%)", width:2, height:8, background:t.red, borderRadius:1 }}/>
              <div style={{ position:"absolute", bottom:3, left:"50%", transform:"translateX(-50%)", width:2, height:2, background:t.red, borderRadius:"50%" }}/>
            </div>
          </div>
          <div style={{ fontSize:18, fontWeight:700, color:t.text }}>Something went wrong</div>
          <div style={{ fontSize:13, color:t.sub, maxWidth:380, lineHeight:1.6 }}>
            This page encountered an unexpected error. Your data is safe — this only affects the current view.
          </div>
          <div style={{ fontSize:11, fontFamily:"monospace", color:t.sub, background:`${t.red}08`, border:`1px solid ${t.red}22`, borderRadius:8, padding:"8px 14px", maxWidth:480, wordBreak:"break-all" }}>
            {this.state.error?.message || "Unknown error"}
          </div>
          <div style={{ display:"flex", gap:10 }}>
            <button
              onClick={() => this.reset()}
              style={{ padding:"9px 20px", borderRadius:9, border:`1.5px solid ${t.border}`, background:"transparent", color:t.sub, cursor:"pointer", fontSize:13, fontFamily:"inherit" }}>
              Try again
            </button>
            <button
              onClick={() => window.location.reload()}
              style={{ padding:"9px 20px", borderRadius:9, border:"none", background:t.accent, color:"#fff", cursor:"pointer", fontSize:13, fontFamily:"inherit", fontWeight:600 }}>
              Reload app
            </button>
          </div>
        </div>
      );
    }
    return this.props.children;
  }
}
