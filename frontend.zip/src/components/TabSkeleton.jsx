import { DARK, LIGHT } from "../styles/theme";

export default function TabSkeleton({ dark = true }) {
  const t = dark ? DARK : LIGHT;
  const bar = (w = "100%") => ({
    width: w,
    height: 10,
    borderRadius: 999,
    background: dark ? "rgba(255,255,255,0.08)" : "rgba(0,0,0,0.08)",
  });
  const card = {
    background: t.card,
    border: `1px solid ${t.border}`,
    borderRadius: 14,
    padding: 16,
    display: "flex",
    flexDirection: "column",
    gap: 10,
  };

  return (
    <div style={{ padding: "18px 18px 120px" }}>
      <div style={{ marginBottom: 20 }}>
        <div style={{ ...bar("48%"), height: 16 }} />
        <div style={{ height: 8 }} />
        <div style={{ ...bar("32%") }} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(140px,1fr))", gap: 12, marginBottom: 18 }}>
        {Array.from({ length: 6 }).map((_, i) => (
          <div key={i} style={card}>
            <div style={{ ...bar("40%"), height: 12 }} />
            <div style={{ ...bar("70%"), height: 16 }} />
            <div style={{ ...bar("55%") }} />
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(220px,1fr))", gap: 12 }}>
        {Array.from({ length: 2 }).map((_, i) => (
          <div key={i} style={card}>
            <div style={{ ...bar("35%"), height: 12 }} />
            <div style={{ ...bar("100%"), height: 120, borderRadius: 12 }} />
          </div>
        ))}
      </div>
    </div>
  );
}
