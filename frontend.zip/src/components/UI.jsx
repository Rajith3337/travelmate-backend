import { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { DARK, LIGHT } from "../styles/theme";

const T = d => d===false ? LIGHT : DARK;

// ── Ripple ────────────────────────────────────────────────────────────────────
function ripple(e, col) {
  const el=e.currentTarget, r=el.getBoundingClientRect();
  const sz=Math.max(r.width,r.height)*2.5;
  const sp=document.createElement("span");
  sp.style.cssText=`position:absolute;border-radius:50%;pointer-events:none;z-index:0;
    width:${sz}px;height:${sz}px;
    left:${e.clientX-r.left-sz/2}px;top:${e.clientY-r.top-sz/2}px;
    background:${col||"rgba(255,255,255,.1)"};animation:ripple .55s cubic-bezier(.22,.68,0,1.2)`;
  el.appendChild(sp);
  setTimeout(()=>sp.remove(),560);
}

// ── Card ──────────────────────────────────────────────────────────────────────
export function Card({ children, style={}, onClick, dark, glow=false }) {
  const [hov, setHov] = useState(false);
  const t = T(dark);
  const clickable = !!onClick;
  const isDark = dark !== false;
  return (
    <div
      onClick={e=>{if(onClick){ripple(e,`${t.accent}18`);onClick(e);}}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        background:t.card,
        borderRadius:14,padding:20,position:"relative",overflow:"hidden",
        cursor:clickable?"pointer":"default",
        transition:"all .22s cubic-bezier(.22,.68,0,1.2)",
        transform:hov&&clickable?"translateY(-3px)":"none",
        border:`1px solid ${hov&&clickable?`${t.accent}40`:t.border}`,
        boxShadow: hov&&clickable
          ? isDark ? `0 16px 40px rgba(0,0,0,.5),0 0 0 1px ${t.accent}20,0 0 30px ${t.accent}10`
                   : `0 16px 40px rgba(0,0,0,.08),0 0 0 1px ${t.accent}20`
          : isDark ? "0 2px 12px rgba(0,0,0,.4)"
                   : "0 1px 6px rgba(0,0,0,.06)",
        ...style,
      }}>
      {/* Top shimmer line */}
      <div style={{position:"absolute",top:0,left:0,right:0,height:1,
        background:`linear-gradient(90deg,transparent,${t.accent}${hov&&clickable?"66":"20"},transparent)`,
        pointerEvents:"none"}}/>
      {glow&&<div style={{position:"absolute",top:-30,right:-30,width:80,height:80,borderRadius:"50%",background:`radial-gradient(circle,${t.accent}15,transparent 65%)`,pointerEvents:"none"}}/>}
      {children}
    </div>
  );
}

// ── Badge ─────────────────────────────────────────────────────────────────────
export function Badge({ children, color, dark }) {
  const t=T(dark), c=color||t.accent;
  return (
    <span style={{
      background:`${c}14`,color:c,border:`1px solid ${c}30`,
      fontSize:9,fontWeight:800,padding:"3px 9px",
      borderRadius:999,letterSpacing:".1em",textTransform:"uppercase",
      whiteSpace:"nowrap",
    }}>{children}</span>
  );
}

// ── Progress bar ──────────────────────────────────────────────────────────────
export function ProgressBar({ value=0, color, height=5, dark }) {
  const t=T(dark), [v,setV]=useState(0);
  useEffect(()=>{const id=setTimeout(()=>setV(Math.min(Math.max(value,0),100)),80);return()=>clearTimeout(id);},[value]);
  const c=color||t.accent;
  return (
    <div style={{background:t.border,borderRadius:999,height,overflow:"hidden"}}>
      <div style={{
        width:`${v}%`,height:"100%",borderRadius:999,
        background:`linear-gradient(90deg,${c}CC,${c},${c}CC)`,
        backgroundSize:"200% 100%",
        transition:"width 1s cubic-bezier(.22,.68,0,1.2)",
        position:"relative",animation:"shimmer 2.5s infinite",
      }}>
        <div style={{position:"absolute",right:0,top:"10%",bottom:"10%",width:3,borderRadius:99,background:c,boxShadow:`0 0 8px ${c}`,opacity:v>2?1:0}}/>
      </div>
    </div>
  );
}

// ── Aurora Button ─────────────────────────────────────────────────────────────
export function Btn({ children, onClick, variant="primary", size="md", style={}, disabled=false, type="button", loading=false, dark }) {
  const t=T(dark);
  const [hov,setHov]=useState(false);
  const [press,setPress]=useState(false);
  const isDark = dark!==false;

  const variants = {
    primary: { bg: isDark ? `linear-gradient(135deg,${t.accent}CC,${t.accentDeep})` : `linear-gradient(135deg,${t.accent},${t.accentDeep})`, fg:"#fff", glow:t.accent },
    success: { bg:`linear-gradient(135deg,${t.green}CC,${t.teal})`, fg:"#fff", glow:t.green },
    danger:  { bg:`linear-gradient(135deg,${t.red}CC,${t.rose})`, fg:"#fff", glow:t.red },
    violet:  { bg:`linear-gradient(135deg,${t.violet}CC,${t.violetLight})`, fg:"#fff", glow:t.violet },
    ghost:   { bg:"transparent", fg:hov?t.text:t.textSub, glow:t.accent },
    subtle:  { bg:t.surface, fg:hov?t.text:t.textSub, glow:t.accent },
  };
  const cfg=variants[variant]||variants.primary;
  const pads={xs:"3px 9px",sm:"6px 13px",md:"9px 18px",lg:"11px 22px"};
  const fns={xs:9,sm:11,md:13,lg:14};
  const brd=variant==="ghost"?`1px solid ${hov?`${t.accent}55`:t.border}`:variant==="subtle"?`1px solid ${t.border}`:"none";
  const isAurora = variant==="primary" && !disabled && isDark;

  const inner = (
    <button type={type} disabled={disabled||loading}
      onClick={e=>{ripple(e,variant==="ghost"?`${t.accent}15`:"rgba(255,255,255,.15)");onClick&&onClick(e);}}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>{setHov(false);setPress(false);}}
      onMouseDown={()=>setPress(true)} onMouseUp={()=>setPress(false)}
      style={{
        fontFamily:"inherit",fontWeight:800,cursor:disabled||loading?"not-allowed":"pointer",
        border:brd,borderRadius:10,opacity:disabled?.4:1,
        background:cfg.bg,color:cfg.fg,padding:pads[size]||pads.md,fontSize:fns[size]||fns.md,
        display:"flex",alignItems:"center",gap:7,whiteSpace:"nowrap",
        position:"relative",overflow:"hidden",
        transform:press?"scale(.96)":hov?"translateY(-1px)":"none",
        transition:"all .15s cubic-bezier(.22,.68,0,1.2)",
        letterSpacing:".04em",textTransform:"uppercase",
        boxShadow: hov&&!disabled&&variant!=="ghost"&&variant!=="subtle"
          ? isDark ? `0 6px 24px ${cfg.glow}50,0 2px 8px rgba(0,0,0,.3)` : `0 6px 20px ${cfg.glow}30`
          : "none",
        ...style,
      }}>
      {/* Top shine */}
      <div style={{position:"absolute",top:0,left:0,right:0,height:1,background:"linear-gradient(90deg,transparent,rgba(255,255,255,.2),transparent)",pointerEvents:"none"}}/>
      {loading&&<span className="spin" style={{width:12,height:12,flexShrink:0,border:`2px solid rgba(255,255,255,.2)`,borderTopColor:"rgba(255,255,255,.9)",borderRadius:"50%",display:"inline-block"}}/>}
      {children}
    </button>
  );

  if(isAurora) return (
    <div className="ab-wrap" style={{display:"inline-flex",borderRadius:10,...style}}>
      <div className="ab-spin ab-blur" style={{borderRadius:10}}/>
      <div className="ab-spin ab-glow" style={{borderRadius:10}}/>
      {inner}
    </div>
  );
  return inner;
}

// ── Input ─────────────────────────────────────────────────────────────────────
export function Input({ label, value, onChange, type="text", placeholder, required, style={}, hint, autoComplete, onKeyDown, dark }) {
  const [foc,setFoc]=useState(false);
  const t=T(dark);
  const isDark=dark!==false;
  return (
    <div style={{display:"flex",flexDirection:"column",gap:5}}>
      {label&&<label style={{fontSize:10,fontWeight:800,textTransform:"uppercase",letterSpacing:".1em",color:foc?t.accent:t.textSub,transition:"color .18s"}}>{label}</label>}
      <input type={type} value={value} onChange={onChange} placeholder={placeholder}
        required={required} autoComplete={autoComplete} onKeyDown={onKeyDown}
        onFocus={()=>setFoc(true)} onBlur={()=>setFoc(false)}
        style={{
          background:foc?`${t.accent}08`:isDark?"rgba(255,255,255,0.03)":t.surface,
          border:`1px solid ${foc?`${t.accent}66`:t.border}`,
          borderRadius:9,padding:"10px 13px",color:t.text,fontSize:14,outline:"none",
          boxShadow:foc?`0 0 0 3px ${t.accent}14,0 0 16px ${t.accent}08`:"none",
          transition:"all .2s",letterSpacing:".01em",
          ...style,
        }}/>
      {hint&&<span style={{fontSize:10,color:t.textDim}}>{hint}</span>}
    </div>
  );
}

// ── Select ────────────────────────────────────────────────────────────────────
export function Select({ label, value, onChange, options, style={}, dark }) {
  const [foc,setFoc]=useState(false);
  const t=T(dark);
  return (
    <div style={{display:"flex",flexDirection:"column",gap:5}}>
      {label&&<label style={{fontSize:10,fontWeight:800,textTransform:"uppercase",letterSpacing:".1em",color:t.textSub}}>{label}</label>}
      <select value={value} onChange={onChange} onFocus={()=>setFoc(true)} onBlur={()=>setFoc(false)}
        style={{
          background:foc?`${t.accent}08`:dark!==false?"rgba(255,255,255,0.03)":t.surface,
          border:`1px solid ${foc?`${t.accent}66`:t.border}`,
          borderRadius:9,padding:"10px 13px",color:t.text,fontSize:14,outline:"none",
          fontFamily:"inherit",cursor:"pointer",
          boxShadow:foc?`0 0 0 3px ${t.accent}14`:"none",
          transition:"all .2s",...style,
        }}>
        {options?.map(o=>typeof o==="string"
          ?<option key={o} value={o}>{o}</option>
          :<option key={o.value} value={o.value}>{o.label}</option>
        )}
      </select>
    </div>
  );
}

// ── Tabs ──────────────────────────────────────────────────────────────────────
export function Tabs({ tabs, active, onChange, dark }) {
  const t = T(dark);
  return (
    <div style={{
      display: "inline-flex",
      background: dark !== false ? "rgba(10, 11, 16, 0.6)" : t.surface,
      backdropFilter: "blur(12px)",
      WebkitBackdropFilter: "blur(12px)",
      borderRadius: 12,
      padding: 4,
      border: `1px solid ${dark !== false ? "rgba(255,255,255,0.08)" : t.border}`,
      boxShadow: "inset 0 2px 4px rgba(0,0,0,0.1)",
      gap: 4
    }}>
      {tabs.map(tab => {
        const isActive = active === (tab.value || tab);
        const label = tab.label || tab;
        const val = tab.value || tab;
        return (
          <button
            key={val}
            onClick={() => onChange(val)}
            style={{
              position: "relative",
              padding: "8px 16px",
              borderRadius: 8,
              fontSize: 12,
              fontWeight: isActive ? 700 : 500,
              cursor: "pointer",
              fontFamily: "inherit",
              border: "none",
              letterSpacing: ".02em",
              background: isActive ? t.accent : "transparent",
              color: isActive ? "#fff" : t.textSub,
              boxShadow: isActive ? `0 4px 12px ${t.accent}40, inset 0 1px 1px rgba(255,255,255,0.2)` : "none",
              transition: "all 0.25s cubic-bezier(0.22, 1, 0.36, 1)",
              textShadow: isActive ? "0 1px 2px rgba(0,0,0,0.2)" : "none",
            }}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}

// ── Modal ─────────────────────────────────────────────────────────────────────
export function Modal({ title, onClose, children, dark, width=520 }) {
  const t=T(dark);
  useEffect(()=>{
    const h=e=>{if(e.key==="Escape")onClose();};
    document.addEventListener("keydown",h);
    return()=>document.removeEventListener("keydown",h);
  },[onClose]);
  return createPortal(
    <div onClick={onClose} style={{position:"fixed",inset:0,background:"rgba(0,0,0,.75)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999,backdropFilter:"blur(8px)",padding:"20px 16px",overflowY:"auto"}}>
      <div onClick={e=>e.stopPropagation()} className="pop"
        style={{
          width:`min(${width}px,94vw)`,maxHeight:"calc(100dvh - 40px)",
          display:"flex",flexDirection:"column",
          background:t.card,borderRadius:16,
          border:`1px solid ${t.accent}20`,
          boxShadow:dark!==false?`0 32px 80px rgba(0,0,0,.6),0 0 0 1px ${t.accent}15,0 0 40px ${t.accent}06`:"0 32px 80px rgba(0,0,0,.15)",
        }}>
        {/* Top accent line */}
        <div style={{height:1.5,borderRadius:"16px 16px 0 0",background:`linear-gradient(90deg,transparent,${t.accent},${t.cyan||t.teal},transparent)`,flexShrink:0}}/>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",padding:"14px 18px",borderBottom:`1px solid ${t.border}`,flexShrink:0}}>
          <div style={{fontWeight:800,fontSize:14,color:t.text,letterSpacing:".04em",textTransform:"uppercase"}}>{title}</div>
          <button onClick={onClose} style={{width:28,height:28,borderRadius:8,border:`1px solid ${t.border}`,background:dark!==false?`${t.accent}08`:"transparent",color:t.textSub,cursor:"pointer",fontSize:15,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .15s"}}
            onMouseEnter={e=>{e.currentTarget.style.background=`${t.red}15`;e.currentTarget.style.color=t.red;}}
            onMouseLeave={e=>{e.currentTarget.style.background=dark!==false?`${t.accent}08`:"transparent";e.currentTarget.style.color=t.textSub;}}>×</button>
        </div>
        <div style={{padding:"18px 20px",overflowY:"auto",flex:1}}>{children}</div>
      </div>
    </div>,
    document.body
  );
}

// ── Confirm Dialog ────────────────────────────────────────────────────────────
export function ConfirmDialog({ title, message, onConfirm, onCancel, confirmLabel="Confirm", danger=false, dark }) {
  const t=T(dark);
  return createPortal(
    <div onClick={onCancel} style={{position:"fixed",inset:0,background:"rgba(0,0,0,.7)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:9999,backdropFilter:"blur(6px)"}}>
      <div onClick={e=>e.stopPropagation()} className="pop"
        style={{width:"min(380px,90vw)",background:t.card,border:`1px solid ${danger?`${t.red}30`:t.border}`,borderRadius:15,padding:"24px",boxShadow:"0 24px 60px rgba(0,0,0,.5)"}}>
        <div style={{fontWeight:800,fontSize:15,marginBottom:10,color:t.text,letterSpacing:".02em"}}>{title}</div>
        <div style={{color:t.textSub,fontSize:13,marginBottom:22,lineHeight:1.65}}>{message}</div>
        <div style={{display:"flex",gap:10,justifyContent:"flex-end"}}>
          <Btn variant="ghost" onClick={onCancel} dark={dark}>Cancel</Btn>
          <Btn variant={danger?"danger":"primary"} onClick={onConfirm} dark={dark}>{confirmLabel}</Btn>
        </div>
      </div>
    </div>,
    document.body
  );
}

// ── Spinner ───────────────────────────────────────────────────────────────────
export function Spinner({ size=28, color, dark }) {
  const t=T(dark), c=color||t.accent;
  return (
    <div style={{position:"relative",width:size,height:size,display:"inline-flex",alignItems:"center",justifyContent:"center"}}>
      <div className="spin" style={{width:size,height:size,border:`2px solid ${c}18`,borderTopColor:c,borderRadius:"50%",position:"absolute"}}/>
      <div style={{width:size*.35,height:size*.35,borderRadius:"50%",background:`${c}30`,boxShadow:`0 0 ${size*.3}px ${c}60`}}/>
    </div>
  );
}

// ── Empty ─────────────────────────────────────────────────────────────────────
export function Empty({ icon="📭", text, sub, dark }) {
  const t=T(dark);
  return (
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"52px 20px",gap:12}}>
      <div style={{
        width:68,height:68,borderRadius:20,
        background:dark!==false?"rgba(255,255,255,0.03)":t.surface,
        border:`1px dashed ${t.border}`,
        display:"flex",alignItems:"center",justifyContent:"center",fontSize:30,
      }}>{icon}</div>
      <div style={{fontWeight:700,fontSize:14,color:t.textSub,letterSpacing:".02em"}}>{text}</div>
      {sub&&<div style={{fontSize:12,color:t.textDim,textAlign:"center",maxWidth:240,lineHeight:1.6}}>{sub}</div>}
    </div>
  );
}

// ── ErrorMsg ──────────────────────────────────────────────────────────────────
export function ErrorMsg({ msg, dark }) {
  const t=T(dark);
  if(!msg)return null;
  return (
    <div style={{background:`${t.red}08`,border:`1px solid ${t.red}25`,color:t.red,borderRadius:9,padding:"10px 13px",fontSize:12,fontWeight:500,display:"flex",gap:8,alignItems:"flex-start",letterSpacing:".01em"}}>
      <span>⚠</span><span>{msg}</span>
    </div>
  );
}

// ── SuccessMsg ────────────────────────────────────────────────────────────────
export function SuccessMsg({ msg, dark }) {
  const t=T(dark);
  if(!msg)return null;
  return (
    <div style={{background:`${t.green}08`,border:`1px solid ${t.green}25`,color:t.green,borderRadius:9,padding:"10px 13px",fontSize:12,fontWeight:500,display:"flex",gap:8,alignItems:"flex-start"}}>
      <span>✓</span><span>{msg}</span>
    </div>
  );
}

// ── StatCard ──────────────────────────────────────────────────────────────────
export function StatCard({ icon, label, value, color, delay=0, dark }) {
  const t=T(dark), [hov,setHov]=useState(false), [count,setCount]=useState(0);
  const isDark=dark!==false;
  useEffect(()=>{
    const target=parseFloat(String(value).replace(/[^0-9.]/g,""))||0;
    if(!target)return;
    let start=0;const inc=target/32;let raf;
    const run=()=>{start+=inc;if(start>=target){setCount(target);return;}setCount(Math.floor(start));raf=requestAnimationFrame(run);};
    raf=requestAnimationFrame(run);
    return()=>cancelAnimationFrame(raf);
  },[value]);
  const displayVal=typeof value==="number"?count:value;
  return (
    <div onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{
        background:t.card,borderRadius:14,padding:"18px 20px",
        position:"relative",overflow:"hidden",
        animation:`fadeUp .44s cubic-bezier(.16,.84,.44,1) ${delay}ms both`,
        transform:hov?"translateY(-4px)":"none",
        border:`1px solid ${hov?`${color}30`:t.border}`,
        boxShadow:hov
          ?isDark?`0 16px 40px rgba(0,0,0,.5),0 0 30px ${color}18`:`0 16px 36px rgba(0,0,0,.08)`
          :isDark?"0 2px 10px rgba(0,0,0,.4)":"0 1px 6px rgba(0,0,0,.05)",
        transition:"all .22s cubic-bezier(.22,.68,0,1.2)",
      }}>
      {/* Glow corner */}
      <div style={{position:"absolute",top:-20,right:-20,width:80,height:80,borderRadius:"50%",background:`radial-gradient(circle,${color}20,transparent 65%)`,pointerEvents:"none",opacity:hov?1:.4,transition:"opacity .3s"}}/>
      {/* Bottom line */}
      <div style={{position:"absolute",bottom:0,left:0,right:0,height:1.5,background:`linear-gradient(90deg,transparent,${color}${hov?"88":"33"},transparent)`,transition:"opacity .3s"}}/>
      <div style={{fontSize:22,marginBottom:8}}>{icon}</div>
      <div className="count-up" style={{fontSize:26,fontWeight:800,color,lineHeight:1,letterSpacing:"-.02em"}}>{displayVal}</div>
      <div style={{fontSize:10,color:t.textSub,marginTop:5,fontWeight:700,textTransform:"uppercase",letterSpacing:".1em"}}>{label}</div>
    </div>
  );
}

// ── PageHeader ────────────────────────────────────────────────────────────────
export function PageHeader({ title, sub, icon, right, dark }) {
  const t = T(dark);
  return (
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20, flexWrap: "wrap", gap: 10 }}>
      <div>
        <h1 style={{ fontFamily: "'Syne','DM Sans',sans-serif", fontSize: 26, fontWeight: 900, margin: 0, color: t.text, lineHeight: 1.2, display: "flex", alignItems: "center", letterSpacing: "-.02em" }}>
          {icon && <span style={{ marginRight: 8 }}>{icon}</span>}
          {title}
        </h1>
        {sub && <div style={{ color: t.textSub, fontSize: 13, marginTop: 4, letterSpacing: ".01em" }}>{sub}</div>}
      </div>
      {right && (
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          {right}
        </div>
      )}
    </div>
  );
}
