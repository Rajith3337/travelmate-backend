import { useState, useRef } from "react";
import { Spinner } from "./UI";

export default function PullToRefresh({ children, onRefresh, dark, style, className, disabled }) {
  const [startY, setStartY] = useState(0);
  const [pullDist, setPullDist] = useState(0);
  const [refreshing, setRefreshing] = useState(false);
  const scrollRef = useRef(null);

  const THRESHOLD = 65;

  const onTouchStart = e => {
    // Never pull-to-refresh when the user's finger starts inside the Leaflet map
    const touchTarget = e.touches[0]?.target;
    if (touchTarget && touchTarget.closest(".leaflet-container")) return;
    if (disabled) return;
    if (scrollRef.current && scrollRef.current.scrollTop === 0) {
      setStartY(e.touches[0].clientY);
    } else {
      setStartY(0);
    }
  };

  const onTouchMove = e => {
    if (startY === 0 || refreshing) return;
    const y = e.touches[0].clientY;
    const dist = y - startY;
    // Only register pull down if at absolute top
    if (dist > 0 && scrollRef.current && scrollRef.current.scrollTop <= 0) {
      // Don't prevent default, Capacitor often handles scroll blocks, but we capture the distance
      setPullDist(dist * 0.4);
    }
  };

  const onTouchEnd = () => {
    if (startY === 0 || refreshing) return;
    if (pullDist > THRESHOLD) {
      setRefreshing(true);
      if (onRefresh) {
        onRefresh().finally(() => setRefreshing(false));
      } else {
        window.location.reload();
      }
    } else {
      setPullDist(0);
    }
    setStartY(0);
  };

  return (
    <div 
      style={{ display: "flex", flexDirection: "column", height: "100%", width: "100%" }}
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      <div style={{
        height: Math.min(pullDist, 100),
        overflow: "hidden",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "transparent",
        transition: startY === 0 ? "height 0.3s ease" : "none",
        flexShrink: 0
      }}>
        {refreshing ? <Spinner size={24} dark={dark}/> : (
           pullDist > 10 && (
             <div style={{ 
               opacity: pullDist/THRESHOLD, 
               transform: `rotate(${pullDist*4}deg)`, 
               fontSize:24, 
               color: dark ? "#EDF0F7" : "#1C2030" 
             }}>
               ↻
             </div>
           )
        )}
      </div>
      <div ref={scrollRef} style={style} className={className}>
        {children}
      </div>
    </div>
  );
}
