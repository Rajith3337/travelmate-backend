import { useState, useContext, useEffect, useRef } from "react";
import { AuthContext } from "../context/AuthContext";
import { DARK, LIGHT } from "../styles/theme";
import { ConfirmDialog } from "./UI";
import { useOfflineSync } from "../hooks/useOfflineSync";

const NAV = [
  { id:"dashboard", icon:"\u{1F3E0}", label:"Home" },
  { id:"trips",     icon:"\u2708\uFE0F", label:"Trips" },
  { id:"map",       icon:"\u{1F5FA}\uFE0F", label:"Map" },
  { id:"planner",   icon:"\u{1F5D3}\uFE0F", label:"Planner" },
  { id:"budget",    icon:"\u{1F4B3}", label:"Budget" },
  { id:"packing",   icon:"\u{1F9F3}", label:"Packing" },
  { id:"notes",     icon:"\u{1F4DD}", label:"Notes" },
  { id:"weather",   icon:"\u{1F324}\uFE0F", label:"Weather" },
  { id:"currency",  icon:"\u{1F4B1}", label:"Currency" },
  { id:"flights",   icon:"\u{1F6EB}", label:"Bookings" },
  { id:"ai",        icon:"\u{1F916}", label:"AI",      badge:"AI" },
  { id:"translate", icon:"\u{1F310}", label:"Translate" },
  { id:"offline",   icon:"\u{1F4F6}", label:"Offline" },
  { id:"stats",     icon:"\u{1F4CA}", label:"Analytics", badge:"NEW" },
];

const PRIMARY = ["dashboard","trips","map","budget","ai"];

// ── Compass logo mark ─────────────────────────────────────────────────────────
function CompassMark({ size=30 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <defs>
        <linearGradient id="cg1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#9060F0"/>
          <stop offset="100%" stopColor="#C8A0FF"/>
        </linearGradient>
      </defs>
      <circle cx="50" cy="50" r="46" fill="none" stroke="url(#cg1)" strokeWidth="3" opacity="0.35"/>
      <g>
        <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="8s" repeatCount="indefinite"/>
        <circle cx="50" cy="50" r="36" fill="none" stroke="url(#cg1)" strokeWidth="1.5" strokeDasharray="5 7" opacity="0.4"/>
        <polygon points="50,14 44,38 50,32 56,38" fill="url(#cg1)"/>
        <polygon points="50,86 44,62 50,68 56,62" fill="url(#cg1)" opacity="0.35"/>
        <circle cx="84" cy="50" r="4" fill="url(#cg1)" opacity="0.45"/>
        <circle cx="16" cy="50" r="4" fill="url(#cg1)" opacity="0.45"/>
      </g>
      <circle cx="50" cy="50" r="8" fill="url(#cg1)"/>
      <circle cx="50" cy="50" r="4" fill="#080510"/>
    </svg>
  );
}

function UserAvatar({ url, initials, size = 26, borderColor, bgGradient }) {
  const [err, setErr] = useState(false);
  const showImg = !!url && !err;
  return (
    <div style={{
      width: size,
      height: size,
      borderRadius: "50%",
      flexShrink: 0,
      background: bgGradient || "linear-gradient(135deg,#9060F0,#6A3EC8)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: Math.max(9, Math.round(size * 0.4)),
      fontWeight: 800,
      color: "#080C14",
      overflow: "hidden",
      border: borderColor ? `1px solid ${borderColor}` : "none",
    }}>
      {showImg ? (
        <img
          src={url}
          alt=""
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
          onError={() => setErr(true)}
        />
      ) : (
        initials
      )}
    </div>
  );
}

// ── Mobile bottom nav ─────────────────────────────────────────────────────────
function MobileNav({ page, setPage, notifCount, dark, toggleTheme }) {
  const t = dark ? DARK : LIGHT;
  const [showMore, setShowMore] = useState(false);
  const { user, logout } = useContext(AuthContext);
  const [showLogout, setShowLogout] = useState(false);
  const primaryTabs = NAV.filter(n => PRIMARY.includes(n.id));
  const moreTabs    = NAV.filter(n => !PRIMARY.includes(n.id));
  const go = id => { setPage(id); setShowMore(false); };

  useEffect(() => {
    if (typeof document !== "undefined") {
      document.body.classList.toggle("tm-more-open", showMore);
    }
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("tm-more-toggle", { detail: showMore }));
    }
  }, [showMore]);

  const goldAccent = dark ? "#9060F0" : "#6A3EC8";
  const initials = (user?.full_name || user?.username || "?").split(" ").map(w => w[0]).join("").toUpperCase().slice(0, 2);

  return (
    <>
      {/* Bottom bar */}
      <div style={{
        position:"fixed",bottom:0,left:0,right:0,zIndex:300,
        background: dark ? "rgba(8,12,20,0.97)" : "rgba(253,250,244,0.97)",
        borderTop:`1px solid ${dark?"rgba(144,96,240,0.15)":t.border}`,
        backdropFilter:"blur(24px)", WebkitBackdropFilter:"blur(24px)",
        display:"flex",
        paddingBottom:"env(safe-area-inset-bottom, 0px)",
        boxShadow: dark ? `0 -1px 0 rgba(144,96,240,0.1), 0 -12px 40px rgba(0,0,0,.3)` : `0 -1px 0 ${t.border}`,
      }}>
        {primaryTabs.map(item => {
          const active = page === item.id;
          return (
            <button key={item.id} onClick={() => go(item.id)} style={{
              flex:1,display:"flex",flexDirection:"column",
              alignItems:"center",justifyContent:"center",
              gap:4,padding:"10px 4px 8px",
              border:"none",background: active ? "radial-gradient(ellipse at top, rgba(144,96,240,0.15) 0%, transparent 70%)" : "transparent",
              color: active ? goldAccent : t.textSub,
              cursor:"pointer",minHeight:54,position:"relative",
              WebkitTapHighlightColor:"transparent",touchAction:"manipulation",
              transition:"all .25s cubic-bezier(0.22, 1, 0.36, 1)",
            }}>
              {active && (
                <div style={{
                  position:"absolute",top:-1,left:"50%",transform:"translateX(-50%)",
                  width:32,height:3,borderRadius:"0 0 4px 4px",
                  background:`linear-gradient(90deg,#9060F0,#00E5FF)`,
                  boxShadow:"0 0 12px rgba(144,96,240,0.6)",
                }}/>
              )}
              <span style={{
                fontSize:21,
                transform:active?"scale(1.12)":"scale(1)",
                transition:"transform .2s cubic-bezier(.16,.84,.44,1)",
                display:"inline-block",
              }}>{item.icon}</span>
              <span style={{fontSize:9,fontWeight:active?700:500,letterSpacing:".04em",textTransform:"uppercase"}}>
                {item.label}
              </span>
            </button>
          );
        })}
        {/* More */}
        <button onClick={() => setShowMore(s=>!s)} style={{
          flex:1,display:"flex",flexDirection:"column",
          alignItems:"center",justifyContent:"center",
          gap:3,padding:"10px 4px 8px",
          border:"none",background:"transparent",
          color: showMore ? goldAccent : t.textSub,
          cursor:"pointer",minHeight:54,position:"relative",
          WebkitTapHighlightColor:"transparent",touchAction:"manipulation",
        }}>
          {notifCount>0&&<span style={{position:"absolute",top:8,right:"calc(50% - 14px)",width:7,height:7,background:t.rose,borderRadius:"50%",border:`2px solid ${dark?"#080C14":"#fff"}`}}/>}
          <span style={{fontSize:21,transform:showMore?"rotate(45deg)":"none",transition:"transform .2s",display:"inline-block"}}>
            {showMore?"\u2715":"\u2630"}
          </span>
          <span style={{fontSize:9,fontWeight:500,letterSpacing:".04em",textTransform:"uppercase"}}>More</span>
        </button>
      </div>

      {/* More sheet */}
      {showMore && (<>
        <div onClick={()=>setShowMore(false)} style={{position:"fixed",inset:0,zIndex:290,background:"rgba(0,0,0,.6)",backdropFilter:"blur(4px)"}}/>
        <div style={{
          position:"fixed",
          bottom:`calc(54px + env(safe-area-inset-bottom,0px))`,
          left:0,right:0,zIndex:295,
          background: dark ? "#0D0A1C" : "#FDFAF4",
          borderTop:`1px solid ${dark?"rgba(144,96,240,0.2)":t.border}`,
          borderRadius:"20px 20px 0 0",
          padding:"14px 14px 8px",
          boxShadow:"0 -16px 60px rgba(0,0,0,.35)",
          animation:"sheetUp .25s cubic-bezier(.16,.84,.44,1) both",
        }}>
          {/* Handle */}
          <div style={{width:32,height:3,borderRadius:99,background:`rgba(144,96,240,0.3)`,margin:"0 auto 14px"}}/>

          {/* User strip */}
          <div style={{display:"flex",alignItems:"center",gap:12,padding:"12px 14px",background:dark?"rgba(144,96,240,0.05)":"rgba(106,62,200,0.05)",borderRadius:13,marginBottom:14,border:`1px solid ${dark?"rgba(144,96,240,0.15)":t.border}`}}>
            <UserAvatar
              url={user?.avatar_url}
              initials={initials}
              size={40}
              borderColor={dark ? "rgba(144,96,240,0.3)" : t.border}
            />
            <div style={{flex:1,minWidth:0}}>
              <div style={{fontSize:13,fontWeight:700,color:t.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user?.full_name||user?.username}</div>
              <div style={{fontSize:11,color:t.textSub}}>@{user?.username}</div>
            </div>
            <button onClick={()=>go("profile")} style={{padding:"5px 12px",borderRadius:8,background:dark?"rgba(144,96,240,0.1)":"rgba(106,62,200,0.08)",border:`1px solid ${dark?"rgba(144,96,240,0.25)":t.border}`,color:goldAccent,fontSize:11,fontWeight:700,cursor:"pointer",fontFamily:"inherit",letterSpacing:".04em"}}>
              Profile
            </button>
          </div>

          {/* Grid */}
          <div className="sidebar-more-grid">
            {moreTabs.map(item=>(
              <button key={item.id} onClick={()=>go(item.id)} style={{
                display:"flex",flexDirection:"column",alignItems:"center",
                gap:5,padding:"12px 6px",borderRadius:13,
                border:`1.5px solid ${page===item.id?dark?"rgba(144,96,240,0.4)":t.accent:t.border}`,
                background: page===item.id ? dark?"rgba(144,96,240,0.08)":t.accentSoft : t.surface,
                color: page===item.id ? goldAccent : t.textSub,
                cursor:"pointer",position:"relative",
                WebkitTapHighlightColor:"transparent",
              }}>
                {item.badge&&<span style={{position:"absolute",top:3,right:3,fontSize:6,background:goldAccent,color:"#080C14",padding:"1px 4px",borderRadius:99,fontWeight:800,letterSpacing:".04em"}}>{item.badge}</span>}
                <span style={{fontSize:21}}>{item.icon}</span>
                <span style={{fontSize:9,fontWeight:600,textAlign:"center",lineHeight:1.2,letterSpacing:".03em"}}>{item.label}</span>
              </button>
            ))}
            <button onClick={()=>go("notifications")} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:5,padding:"12px 6px",borderRadius:13,border:`1.5px solid ${t.border}`,background:t.surface,color:t.textSub,cursor:"pointer",position:"relative",WebkitTapHighlightColor:"transparent"}}>
              {notifCount>0&&<span style={{position:"absolute",top:3,right:3,width:7,height:7,background:t.rose,borderRadius:"50%"}}/>}
              <span style={{fontSize:21}}>{"\u{1F514}"}</span>
              <span style={{fontSize:9,fontWeight:600,letterSpacing:".03em"}}>Alerts</span>
            </button>
            <button onClick={toggleTheme} style={{display:"flex",flexDirection:"column",alignItems:"center",gap:5,padding:"12px 6px",borderRadius:13,border:`1.5px solid ${t.border}`,background:t.surface,color:t.textSub,cursor:"pointer",WebkitTapHighlightColor:"transparent"}}>
              <span style={{fontSize:21}}>{dark?"\u2600\uFE0F":"\u{1F319}"}</span>
              <span style={{fontSize:9,fontWeight:600,letterSpacing:".03em"}}>{dark?"Light":"Dark"}</span>
            </button>
          </div>

          <button onClick={()=>{setShowMore(false);setShowLogout(true);}} style={{width:"100%",padding:"13px",borderRadius:12,border:`1.5px solid rgba(239,68,68,0.2)`,background:"rgba(239,68,68,0.06)",color:t.red,fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"inherit",WebkitTapHighlightColor:"transparent",letterSpacing:".04em",textTransform:"uppercase"}}>
            Sign Out
          </button>
        </div>
      </>)}

      {showLogout&&<ConfirmDialog title="Sign Out?" message="Are you sure you want to sign out of TravelMate?" confirmLabel="Sign Out" danger dark={dark} onConfirm={()=>{logout();setShowLogout(false);}} onCancel={()=>setShowLogout(false)}/>}
    </>
  );
}

// ── Desktop NavItem ───────────────────────────────────────────────────────────
function NavItem({ item, active, onClick, collapsed, t, dark }) {
  const [hov, setHov] = useState(false);
  const ref = useRef(null);
  const goldAccent = dark ? "#9060F0" : "#6A3EC8";

  const handleClick = e => {
    const el = ref.current;
    const r = el.getBoundingClientRect();
    const sp = document.createElement("span");
    const sz = Math.max(r.width, r.height) * 2.2;
    sp.style.cssText = `position:absolute;border-radius:50%;pointer-events:none;z-index:0;width:${sz}px;height:${sz}px;left:${e.clientX-r.left-sz/2}px;top:${e.clientY-r.top-sz/2}px;background:rgba(144,96,240,0.1);animation:ripple .55s ease`;
    el.appendChild(sp);
    setTimeout(()=>sp.remove(),560);
    onClick();
  };

  return (
    <button ref={ref} onClick={handleClick}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      title={collapsed?item.label:undefined}
      style={{
        display:"flex",alignItems:"center",gap:collapsed?0:9,
        padding:collapsed?"9px 0":"8px 11px",
        borderRadius:10,border:"none",
        background: active ? dark?"rgba(144,96,240,0.1)":"rgba(106,62,200,0.08)" : hov ? dark?"rgba(144,96,240,0.06)":"rgba(106,62,200,0.04)" : "transparent",
        color: active?goldAccent:hov?t.text:t.textSub,
        cursor:"pointer",fontWeight:active?600:400,
        position:"relative",overflow:"hidden",flexShrink:0,
        width:"100%",justifyContent:collapsed?"center":"flex-start",
        transition:"all .15s ease",fontSize:12,
        boxShadow: active ? dark?`inset 0 0 0 1px rgba(144,96,240,0.2)`:`inset 0 0 0 1px ${t.accentSoft}` : "none",
        letterSpacing:".01em",
      }}>
      {active&&<div style={{position:"absolute",left:0,top:"20%",bottom:"20%",width:2.5,borderRadius:"0 3px 3px 0",background:"linear-gradient(180deg,#F0D080,#C9A84C,#A07828)"}}/>}
      <span style={{fontSize:14,flexShrink:0,zIndex:1,display:"inline-block",
        transform:hov?"scale(1.18) rotate(-5deg)":active?"scale(1.1)":"scale(1)",
        transition:"transform .15s cubic-bezier(.22,.68,0,1.2)"}}>{item.icon}</span>
      {!collapsed&&<>
        <span style={{flex:1,textAlign:"left",zIndex:1,whiteSpace:"nowrap"}}>{item.label}</span>
        {item.badge&&<span style={{background:`linear-gradient(135deg,#C9A84C,#F0D080)`,color:"#080C14",fontSize:7,fontWeight:800,padding:"2px 6px",borderRadius:999,zIndex:1,letterSpacing:".08em"}}>{item.badge}</span>}
      </>}
    </button>
  );
}

// ── Main export ───────────────────────────────────────────────────────────────
export default function Sidebar({ page, setPage, notifCount=0, dark, toggleTheme }) {
  const { user, logout } = useContext(AuthContext);
  const [showLogout, setShowLogout] = useState(false);
  const [collapsed, setCollapsed]   = useState(false);
  const [isMobile, setIsMobile]     = useState(window.innerWidth < 768);
  const [time, setTime]             = useState(new Date());
  const [hovId, setHovId]           = useState(null);
  const { online, syncing, pendingCount } = useOfflineSync();
  const t = dark ? DARK : LIGHT;
  const goldAccent = dark ? "#9060F0" : "#6A3EC8";

  useEffect(()=>{const ti=setInterval(()=>setTime(new Date()),30000);return()=>clearInterval(ti);},[]);
  useEffect(()=>{const f=()=>setIsMobile(window.innerWidth<768);window.addEventListener("resize",f);return()=>window.removeEventListener("resize",f);},[]);

  const initials=(user?.full_name||user?.username||"?").split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,2);
  const W=collapsed?58:210;

  if(isMobile) return <MobileNav page={page} setPage={setPage} notifCount={notifCount} dark={dark} toggleTheme={toggleTheme}/>;

  return (
    <>
      <div style={{
        width:W,flexShrink:0,
        background: dark?"rgba(7,8,11,0.98)":"rgba(253,250,244,0.98)",
        borderRight:`1px solid ${dark?"rgba(144,96,240,0.12)":t.border}`,
        backdropFilter:"blur(24px)",
        display:"flex",flexDirection:"column",
        height:"100vh",position:"sticky",top:0,zIndex:100,
        transition:"width .28s cubic-bezier(.16,.84,.44,1)",
        overflow:"visible",
        boxShadow: dark?"2px 0 40px rgba(0,0,0,.4)":"2px 0 16px rgba(0,0,0,.05)",
      }}>
        {/* Top aurora line */}
        <div style={{height:1.5,flexShrink:0,background:"linear-gradient(90deg,transparent,#FF6B2B,#00E5FF,#D500F9,transparent)",backgroundSize:"200% 100%",animation:"gradShift 5s linear infinite"}}/>

        {/* Logo */}
        <div style={{padding:collapsed?"11px 0":"11px 12px",display:"flex",alignItems:"center",gap:8,borderBottom:`1px solid ${dark?"rgba(144,96,240,0.1)":t.border}`,justifyContent:collapsed?"center":"flex-start",flexShrink:0,minHeight:54,overflow:"hidden"}}>
          <div onClick={()=>setPage("dashboard")} style={{width:32,height:32,borderRadius:9,flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer",transition:"transform .18s ease"}}
            onMouseEnter={e=>{e.currentTarget.style.transform="scale(1.12) rotate(-8deg)";}}
            onMouseLeave={e=>{e.currentTarget.style.transform="";}}>
            <CompassMark size={32}/>
          </div>
          {!collapsed&&(
            <div style={{overflow:"hidden",flex:1}}>
              <div style={{fontFamily:"'Syne',sans-serif",fontSize:15,fontWeight:700,letterSpacing:".06em",lineHeight:1.1,whiteSpace:"nowrap",background:"linear-gradient(135deg,#C8A0FF,#9060F0,#6A3EC8)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text"}}>TravelMate</div>
              <div style={{fontSize:9,color:t.textDim,marginTop:1,fontFamily:"'Space Mono',monospace",letterSpacing:".05em"}}>{time.toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"})}</div>
            </div>
          )}
          {!collapsed&&(
            <button onClick={toggleTheme} style={{width:24,height:24,borderRadius:7,border:`1px solid ${dark?"rgba(144,96,240,0.2)":t.border}`,background:dark?"rgba(144,96,240,0.08)":"transparent",color:t.text,cursor:"pointer",fontSize:12,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"all .18s"}}
              onMouseEnter={e=>{e.currentTarget.style.background=dark?"rgba(144,96,240,0.15)":t.surface;}}
              onMouseLeave={e=>{e.currentTarget.style.background=dark?"rgba(144,96,240,0.08)":"transparent";}}>
              {dark?"\u2600\uFE0F":"\u{1F319}"}
            </button>
          )}
        </div>

        {/* Offline indicator */}
        {(!online||syncing)&&(
          <div style={{background:syncing?`${t.green}08`:`${t.amber}08`,borderBottom:`1px solid ${syncing?t.green:t.amber}18`,padding:collapsed?"4px 0":"4px 11px",display:"flex",alignItems:"center",justifyContent:collapsed?"center":"flex-start",gap:6,flexShrink:0}}>
            {syncing
              ? <span className="spin" style={{display:"inline-block",fontSize:9}}>{"\u21BB"}</span>
              : <span style={{fontSize:9}}>{"\u{1F4F6}"}</span>}
            {!collapsed&&<span style={{fontSize:8,fontWeight:700,color:syncing?t.green:t.amber,textTransform:"uppercase",letterSpacing:".08em"}}>{syncing?`Syncing`:`Offline${pendingCount>0?` · ${pendingCount}`:""}`}</span>}
          </div>
        )}

        {/* Nav */}
        <nav style={{flex:1,overflowY:"auto",overflowX:"visible",padding:"6px 5px",display:"flex",flexDirection:"column",gap:1}}>
          {NAV.map(item=>(
            <div key={item.id} style={{position:"relative"}}
              onMouseEnter={()=>collapsed&&setHovId(item.id)}
              onMouseLeave={()=>setHovId(null)}>
              <NavItem item={item} active={page===item.id} onClick={()=>setPage(item.id)} collapsed={collapsed} t={t} dark={dark}/>
              {collapsed&&hovId===item.id&&(
                <div style={{position:"absolute",left:"calc(100% + 8px)",top:"50%",transform:"translateY(-50%)",background:t.card,border:`1px solid ${dark?"rgba(144,96,240,0.2)":t.border}`,borderRadius:8,padding:"5px 11px",fontSize:11,fontWeight:600,color:t.text,whiteSpace:"nowrap",zIndex:999,pointerEvents:"none",boxShadow:"0 8px 24px rgba(0,0,0,.25)",animation:"slideR .14s ease"}}>{item.label}</div>
              )}
            </div>
          ))}
        </nav>

        {/* Footer */}
        <div style={{padding:"6px 5px 8px",borderTop:`1px solid ${dark?"rgba(144,96,240,0.1)":t.border}`,flexShrink:0,display:"flex",flexDirection:"column",gap:1}}>
          {collapsed&&<button onClick={toggleTheme} style={{display:"flex",alignItems:"center",justifyContent:"center",padding:"8px 0",borderRadius:9,border:"none",background:"transparent",cursor:"pointer",fontSize:13,marginBottom:1}}>{dark?"\u2600\uFE0F":"\u{1F319}"}</button>}

          <button onClick={()=>setPage("notifications")} style={{display:"flex",alignItems:"center",gap:9,padding:collapsed?"9px 0":"7px 11px",borderRadius:9,border:"none",background:page==="notifications"?dark?"rgba(144,96,240,0.1)":t.accentSoft:"transparent",color:page==="notifications"?goldAccent:t.textSub,cursor:"pointer",width:"100%",justifyContent:collapsed?"center":"flex-start",fontSize:12}}>
            <span style={{fontSize:13,position:"relative",flexShrink:0}}>
              {"\u{1F514}"}{notifCount>0&&<span style={{position:"absolute",top:-3,right:-3,width:6,height:6,background:t.rose,borderRadius:"50%",display:"block"}}/>}
            </span>
            {!collapsed&&<><span style={{flex:1,letterSpacing:".01em"}}>Notifications</span>{notifCount>0&&<span style={{background:t.rose,color:"#fff",borderRadius:999,padding:"1px 6px",fontSize:8,fontWeight:700}}>{notifCount}</span>}</>}
          </button>

          <button onClick={()=>setPage("profile")} style={{display:"flex",alignItems:"center",gap:9,padding:collapsed?"8px 0":"6px 11px",borderRadius:9,border:"none",background:page==="profile"?dark?"rgba(144,96,240,0.1)":t.accentSoft:"transparent",cursor:"pointer",width:"100%",justifyContent:collapsed?"center":"flex-start"}}>
            <UserAvatar
              url={user?.avatar_url}
              initials={initials}
              size={26}
              borderColor={dark ? "rgba(144,96,240,0.25)" : t.border}
            />
            {!collapsed&&<div style={{flex:1,minWidth:0,textAlign:"left"}}><div style={{fontSize:11,fontWeight:600,color:t.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{user?.full_name||user?.username}</div><div style={{fontSize:9,color:t.textDim}}>@{user?.username}</div></div>}
          </button>

          <button onClick={()=>setShowLogout(true)}
            onMouseEnter={e=>{e.currentTarget.style.background="rgba(239,68,68,0.08)";e.currentTarget.style.color=t.red;}}
            onMouseLeave={e=>{e.currentTarget.style.background="transparent";e.currentTarget.style.color=t.textDim;}}
            style={{display:"flex",alignItems:"center",gap:9,padding:collapsed?"8px 0":"7px 11px",borderRadius:9,border:"none",background:"transparent",color:t.textDim,cursor:"pointer",width:"100%",justifyContent:collapsed?"center":"flex-start",fontSize:11,transition:"all .15s"}}>
            <span style={{fontSize:13,flexShrink:0}}>{"\u23FB"}</span>
            {!collapsed&&<span style={{letterSpacing:".01em"}}>Sign Out</span>}
          </button>

          <button onClick={()=>setCollapsed(c=>!c)}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=dark?"rgba(144,96,240,0.3)":t.accentSoft;e.currentTarget.style.color=goldAccent;}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor=dark?"rgba(144,96,240,0.1)":t.border;e.currentTarget.style.color=t.textDim;}}
            style={{display:"flex",alignItems:"center",justifyContent:"center",padding:"5px",borderRadius:8,marginTop:3,border:`1px solid ${dark?"rgba(144,96,240,0.1)":t.border}`,background:"transparent",color:t.textDim,cursor:"pointer",width:"100%",fontSize:10,transition:"all .18s"}}>
            <span style={{display:"inline-block",transition:"transform .28s cubic-bezier(.16,.84,.44,1)",transform:collapsed?"rotate(180deg)":"none"}}>{"\u25C0"}</span>
          </button>
        </div>
      </div>

      {showLogout&&<ConfirmDialog title="Sign Out?" message="Are you sure you want to sign out of TravelMate?" confirmLabel="Sign Out" danger dark={dark} onConfirm={()=>{logout();setShowLogout(false);}} onCancel={()=>setShowLogout(false)}/>}
    </>
  );
}
