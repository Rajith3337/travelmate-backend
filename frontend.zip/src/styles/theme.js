// TravelMate — Volcanic Explorer Theme
// DARK:  Deep volcanic black × neon ember orange × electric cyan
// LIGHT: Bleached linen × rich ink × saffron gold

export const DARK = {
  // Twilight Wanderer — Deep violet × Electric purple × Lavender
  bg:          "#080510",
  surface:     "#0D0A1C",
  card:        "#120C28",
  cardHover:   "#1A1240",
  glass:       "rgba(8,5,16,0.94)",
  border:      "#241850",
  borderLight: "#3A2870",

  // PRIMARY: Electric purple
  accent:      "#9060F0",
  accentDeep:  "#6A3EC8",
  accentSoft:  "#9060F010",
  accentGlow:  "#9060F035",

  // SECONDARY: Lavender glow
  cyan:        "#C8A0FF",
  cyanSoft:    "#C8A0FF10",
  cyanGlow:    "#C8A0FF28",

  // TERTIARY: Deep violet
  lime:        "#D500F9",
  limeSoft:    "#D500F90A",

  // Semantic
  green:       "#00E676",
  greenSoft:   "#00E67610",
  amber:       "#FFD600",
  amberSoft:   "#FFD60012",
  red:         "#FF1744",
  redSoft:     "#FF174412",
  rose:        "#FF4081",
  roseSoft:    "#FF408112",
  roseDeep:    "#F50057",
  violet:      "#9060F0",
  violetLight: "#C8A0FF",
  violetSoft:  "#9060F012",
  blue:        "#5030A8",
  blueSoft:    "#5030A810",
  teal:        "#C8A0FF",
  tealSoft:    "#C8A0FF10",
  pink:        "#FF4081",
  pinkSoft:    "#FF408110",
  orange:      "#FF6D00",
  indigo:      "#5030A8",
  sky:         "#C8A0FF",
  emerald:     "#00E676",
  emeraldSoft: "#00E67610",

  // Text
  text:        "#F5F0FF",
  textSub:     "#C8B0E8",
  textDim:     "#9080B8",
  muted:       "#4A3870",
  white:       "#FFFFFF",

  mapFilter: "none",
};

export const LIGHT = {
  // Coastal Breeze — Sky white × Ocean blue × Deep sea
  bg:          "#EEF6FF",
  surface:     "#F8FBFF",
  card:        "#FFFFFF",
  cardHover:   "#F0F7FF",
  glass:       "rgba(238,246,255,0.96)",
  border:      "#C0D8F0",
  borderLight: "#A8C8E8",

  // PRIMARY: Ocean blue
  accent:      "#1868C0",
  accentDeep:  "#0A3880",
  accentSoft:  "#1868C00D",
  accentGlow:  "#1868C022",

  // SECONDARY: Sky
  cyan:        "#4898E8",
  cyanSoft:    "#4898E80D",
  cyanGlow:    "#4898E820",

  // TERTIARY: Deep sea
  lime:        "#0A3880",
  limeSoft:    "#0A38800A",

  // Semantic
  green:       "#1B7A3E",
  greenSoft:   "#1B7A3E10",
  amber:       "#B8860B",
  amberSoft:   "#B8860B10",
  red:         "#C62828",
  redSoft:     "#C6282810",
  rose:        "#AD1457",
  roseSoft:    "#AD145710",
  roseDeep:    "#880E4F",
  violet:      "#1868C0",
  violetLight: "#4898E8",
  violetSoft:  "#1868C010",
  blue:        "#1868C0",
  blueSoft:    "#1868C010",
  teal:        "#0277BD",
  tealSoft:    "#0277BD10",
  pink:        "#AD1457",
  pinkSoft:    "#AD145710",
  orange:      "#E65100",
  indigo:      "#283593",
  sky:         "#4898E8",
  emerald:     "#1B7A3E",
  emeraldSoft: "#1B7A3E10",

  // Text
  text:        "#040D28",
  textSub:     "#0A3880",
  textDim:     "#2858A0",
  muted:       "#B8D8FF",
  white:       "#FFFFFF",

  mapFilter: "brightness(1.02) saturate(1.1)",
};

export let C = DARK;
export const setTheme = (dark) => { C = dark ? DARK : LIGHT; };

export function buildCSS(dark) {
  const t = dark ? DARK : LIGHT;
  const a = t.accent;
  const c2 = t.cyan;

  return `
  *,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
  html,body,#root{height:100%;width:100%}
  html{background:${dark?'#080510':'#EEF6FF'}} /* fallback */
  body{
    /* DARK: Twilight Wanderer — deep violet gradient */
    /* LIGHT: Coastal Breeze — sky blue gradient */
    background:${dark
      ? "linear-gradient(135deg, #080510 0%, #0F0828 40%, #080510 70%, #0D0A1C 100%)"
      : "linear-gradient(135deg, #EEF6FF 0%, #D8EBFF 35%, #EEF6FF 65%, #F8FBFF 100%)"
    };
    background-attachment:fixed;
    color:${t.text};
    font-family:'DM Sans','Syne',sans-serif;
    -webkit-font-smoothing:antialiased;
    overflow-x:hidden;
    transition:background .5s,color .5s;
  }

  *{scrollbar-width:none}
  ::-webkit-scrollbar{display:none;width:0;height:0}

  input,textarea,select,button,option{font-family:inherit}
  option{background:${t.surface};color:${t.text}}

  /* ── Keyframes ── */
  @keyframes fadeUp    {from{opacity:0;transform:translateY(22px)}to{opacity:1;transform:none}}
  @keyframes fadeIn    {from{opacity:0}to{opacity:1}}
  @keyframes slideR    {from{opacity:0;transform:translateX(-18px)}to{opacity:1;transform:none}}
  @keyframes slideD    {from{opacity:0;transform:translateY(-14px)}to{opacity:1;transform:none}}
  @keyframes pop       {0%{opacity:0;transform:scale(.82)}55%{transform:scale(1.05)}100%{opacity:1;transform:scale(1)}}
  @keyframes spin      {to{transform:rotate(360deg)}}
  @keyframes ping      {0%{transform:scale(1);opacity:.8}100%{transform:scale(2.6);opacity:0}}
  @keyframes shimmer   {0%{background-position:-200% 0}100%{background-position:200% 0}}
  @keyframes float     {0%,100%{transform:translateY(0)}50%{transform:translateY(-12px)}}
  @keyframes pulse     {0%,100%{opacity:1}50%{opacity:.3}}
  @keyframes ripple    {from{transform:scale(0);opacity:.6}to{transform:scale(5);opacity:0}}
  @keyframes countUp   {from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:none}}
  @keyframes gradShift {0%{background-position:0% 50%}50%{background-position:100% 50%}100%{background-position:0% 50%}}
  @keyframes sheetUp   {from{transform:translateY(100%)}to{transform:translateY(0)}}
  @keyframes orbFloat  {0%,100%{transform:translate(0,0)}33%{transform:translate(2%,-5%)}66%{transform:translate(-2%,3%)}}
  @keyframes scanline  {0%{transform:translateY(-100%)}100%{transform:translateY(100vh)}}
  @keyframes neonFlick {0%,95%,100%{opacity:1}96%,99%{opacity:.4}}
  @keyframes ember     {0%,100%{box-shadow:0 0 8px ${a}60,0 0 20px ${a}30}50%{box-shadow:0 0 16px ${a}90,0 0 40px ${a}50,0 0 60px ${a}20}}
  @keyframes cyanPulse {0%,100%{box-shadow:0 0 8px ${c2}50,0 0 20px ${c2}20}50%{box-shadow:0 0 20px ${c2}80,0 0 40px ${c2}40}}
  @keyframes speen     {0%{rotate:10deg}50%{rotate:190deg}to{rotate:370deg}}
  @keyframes woah      {0%,to{scale:1}50%{scale:.72}}
  @keyframes planeFly  {
    0%{transform:translate(-100px,10px) rotate(8deg);opacity:0}
    5%{opacity:.5} 95%{opacity:.5}
    100%{transform:translate(calc(100vw+100px),-40px) rotate(5deg);opacity:0}
  }
  @keyframes writeIn   {from{width:0;opacity:0}to{width:100%;opacity:1}}
  @keyframes glitch1   {0%,90%,100%{clip-path:none;transform:none}91%{clip-path:polygon(0 20%,100% 20%,100% 40%,0 40%);transform:translate(-2px)}93%{clip-path:polygon(0 60%,100% 60%,100% 80%,0 80%);transform:translate(2px)}}
  @keyframes scanMove  {0%{top:-2px}100%{top:100%}}

  /* ── Classes ── */
  .fade-up  {animation:fadeUp  .44s cubic-bezier(.16,.84,.44,1) both}
  .fade-in  {animation:fadeIn  .26s ease both}
  .slide-r  {animation:slideR  .34s cubic-bezier(.16,.84,.44,1) both}
  .pop      {animation:pop     .4s  cubic-bezier(.16,.84,.44,1) both}
  .pulse    {animation:pulse   2.2s ease-in-out infinite}
  .spin     {animation:spin    .8s  linear infinite}
  .float    {animation:float   3.5s ease-in-out infinite}
  .count-up {animation:countUp .46s cubic-bezier(.16,.84,.44,1) both}
  .ember    {animation:ember   2.4s ease-in-out infinite}
  .neon-flick{animation:neonFlick 6s ease-in-out infinite}

  .s1{animation-delay:.04s}.s2{animation-delay:.09s}.s3{animation-delay:.14s}
  .s4{animation-delay:.20s}.s5{animation-delay:.26s}.s6{animation-delay:.32s}

  .skeleton{
    background:linear-gradient(90deg,${t.card} 25%,${t.border} 50%,${t.card} 75%);
    background-size:200%;animation:shimmer 1.6s infinite;border-radius:6px;
  }

  /* Gradient text */
  .g-ember  {background:linear-gradient(135deg,${a},#FF9B4D);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
  .g-cyan   {background:linear-gradient(135deg,${c2},${t.teal});-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
  .g-hero   {background:linear-gradient(135deg,${a} 0%,#FF9B4D 35%,${c2} 70%,${t.violet} 100%);background-size:200% 200%;animation:gradShift 4s linear infinite;-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}

  *:focus-visible{outline:2px solid ${a};outline-offset:3px;border-radius:4px}
  .page-enter{animation:fadeUp .4s cubic-bezier(.16,.84,.44,1) both}

  /* ── App background ── */
  .app-bg{position:fixed;inset:0;pointer-events:none;z-index:0;overflow:hidden}

  /* Dark: volcanic scanline + noise */
  ${dark ? `
  .vol-noise {
    position:absolute;inset:0;
    background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='.035'/%3E%3C/svg%3E");
    background-size:200px 200px;
    opacity:.6;
  }

  .vol-grid {
    position:absolute;inset:0;
    background-image:
      linear-gradient(rgba(144,96,240,0.05) 1px,transparent 1px),
      linear-gradient(90deg,rgba(144,96,240,0.05) 1px,transparent 1px);
    background-size:40px 40px;
    mask-image:radial-gradient(ellipse 85% 85% at 50% 50%,black 20%,transparent 100%);
  }
  ` : `
  .paper-texture {
    position:absolute;inset:0;
    background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='300'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.65' numOctaves='3' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='300' height='300' filter='url(%23n)' opacity='.04'/%3E%3C/svg%3E");
    background-size:300px;
    opacity:.8;
  }
  `}

  /* Plane */
  .plane-fly{position:absolute;animation:planeFly linear infinite;pointer-events:none}

  /* Aurora button CSS */
  .ab-wrap{position:relative;display:inline-flex;border-radius:inherit}
  .ab-spin{position:absolute;inset:0;z-index:-1;opacity:0;overflow:hidden;transition:.25s;border-radius:inherit}
  .ab-wrap:hover .ab-spin,.ab-wrap:focus-within .ab-spin{opacity:1}
  .ab-spin::before{content:"";position:absolute;inset:-150%;animation:speen 5s cubic-bezier(.56,.15,.28,.86) infinite,woah 3s infinite;animation-play-state:paused}
  .ab-wrap:hover .ab-spin::before,.ab-wrap:focus-within .ab-spin::before{animation-play-state:running}
  .ab-blur::before{background:linear-gradient(90deg,#9060F0 20%,transparent 50%,#C8A0FF 80%);filter:blur(1.8em)}
  .ab-glow::before{background:linear-gradient(90deg,#9060F0CC 15%,transparent 45% 55%,#C8A0FFCC 85%);filter:blur(.3em)}

  /* Neon border effect */
  .neon-border {
    position:relative;
  }
  .neon-border::after {
    content:"";position:absolute;inset:-1px;border-radius:inherit;
    background:linear-gradient(135deg,${a}55,transparent 40%,${c2}44,transparent 70%,${a}33);
    z-index:-1;filter:blur(1px);
  }

  /* Card hover lift */
  .card-hover{transition:transform .2s cubic-bezier(.22,.68,0,1.2),box-shadow .2s ease}
  .card-hover:hover{transform:translateY(-4px)}

  /* ── Responsive ── */
  @media(max-width:767px){main>div{padding:14px 14px calc(62px + env(safe-area-inset-bottom,0px)) !important}}
  @media(min-width:768px){main>div{padding:22px 26px 26px !important}}
  @media(min-width:1024px){main>div{padding:26px 34px 30px !important}}

  button{touch-action:manipulation}
  button,[role="button"],a{-webkit-tap-highlight-color:transparent}

  /* Global transition — scoped to avoid jank */
  body,nav,main,.app-bg,
  [class*="card"],[class*="Card"]{
    transition-property:background-color,border-color,color,box-shadow;
    transition-duration:.22s;
    transition-timing-function:ease;
  }
  svg *,canvas,img,button span,input,textarea,select,.page-enter,.leaflet-container *{transition:none!important}
  `;
}

export const globalCSS = buildCSS(true);
