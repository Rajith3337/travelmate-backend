import { isNativePlatform, readTileDataUrl } from "./offline";

const BACKEND_BASE = (() => {
    const b = import.meta.env.VITE_API_URL || "http://localhost:8000";
    return b.replace(/\/+$/, "") + "/api/v1";
  })();

const OVERPASS_MIRRORS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
];

const TILES = {
  standard: {
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    label: "🗺 Map",
    attribution: "© OpenStreetMap contributors",
  },
  satellite: {
    url: "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    overlayUrl: "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
    label: "🛰 Satellite",
    attribution: "© Esri, Maxar, Earthstar Geographics, and the GIS User Community",
  },
  topo: {
    url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    label: "⛰ Terrain",
    attribution: "© OpenTopoMap (CC-BY-SA)",
  },
};

const TILE_OPTIONS = {
  maxZoom: 19,
  updateWhenZooming: false,
  updateWhenIdle: true,
  keepBuffer: 2,
  crossOrigin: true,
};

export function injectLeafletCSS(t) {
  if (document.getElementById("leaflet-css")) return;
  const link = document.createElement("link");
  link.id = "leaflet-css";
  link.rel = "stylesheet";
  link.href = "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css";
  document.head.appendChild(link);

  const style = document.createElement("style");
  style.innerHTML = `
    .leaflet-container { font-family: inherit; background: ${t?.bg || '#111'}; }
    .leaflet-control-zoom a { background: ${t?.surface || '#222'} !important; color: ${t?.text || '#fff'} !important; border-color: ${t?.border || '#333'} !important; }
    .leaflet-popup-content-wrapper { background: ${t?.card || '#1a1a1a'}; color: ${t?.text || '#fff'}; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
    .leaflet-popup-tip { background: ${t?.card || '#1a1a1a'}; }
  `;
  document.head.appendChild(style);
}

export function loadLeaflet() {
  return new Promise((resolve, reject) => {
    if (window.L && window.L.MarkerClusterGroup) return resolve(window.L);
    const finish = () => {
      if (!document.getElementById("leaflet-cluster-css")) {
        const css = document.createElement("link");
        css.id = "leaflet-cluster-css";
        css.rel = "stylesheet";
        css.href = "https://cdn.jsdelivr.net/npm/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css";
        document.head.appendChild(css);
        const css2 = document.createElement("link");
        css2.rel = "stylesheet";
        css2.href = "https://cdn.jsdelivr.net/npm/leaflet.markercluster@1.5.3/dist/MarkerCluster.css";
        document.head.appendChild(css2);
      }
      if (window.L.MarkerClusterGroup) return resolve(window.L);
      const s2 = document.createElement("script");
      s2.src = "https://cdn.jsdelivr.net/npm/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js";
      s2.onload = () => resolve(window.L);
      s2.onerror = () => resolve(window.L);
      document.head.appendChild(s2);
    };
    if (window.L) { finish(); return; }
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js";
    script.onload = finish;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

export function simplifyCoords(coords, tolerance = 0.0001) {
  if (coords.length <= 2) return coords;
  const sqDist = (p, a, b) => {
    let dx = b[0] - a[0], dy = b[1] - a[1];
    if (dx || dy) {
        const t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy);
        if (t > 1) { a = b; } else if (t > 0) { a = [a[0] + dx * t, a[1] + dy * t]; }
    }
    dx = p[0] - a[0]; dy = p[1] - a[1];
    return dx * dx + dy * dy;
  };
  const simplify = (pts, tol) => {
    const sq = tol * tol;
    let maxSq = 0, idx = 0;
    for (let i = 1; i < pts.length - 1; i++) {
        const d = sqDist(pts[i], pts[0], pts[pts.length - 1]);
        if (d > maxSq) { maxSq = d; idx = i; }
    }
    if (maxSq > sq) {
        const l = simplify(pts.slice(0, idx + 1), tol);
        const r = simplify(pts.slice(idx), tol);
        return [...l.slice(0, -1), ...r];
    }
    return [pts[0], pts[pts.length - 1]];
  };
  return simplify(coords, tolerance);
}

export function createTileLayer(url, options) {
  const L = window.L;
  if (!L) return null;
  if (!isNativePlatform()) return L.tileLayer(url, options);
  const OfflineTileLayer = L.TileLayer.extend({
    createTile(coords, done) {
      const tile = document.createElement("img");
      tile.alt = "";
      tile.setAttribute("role", "presentation");
      const finish = () => done && done(null, tile);
      (async () => {
        const cached = await readTileDataUrl(coords.z, coords.x, coords.y);
        if (cached) {
          tile.src = cached;
          finish();
          return;
        }
        tile.onload = finish;
        tile.onerror = finish;
        tile.src = this.getTileUrl(coords);
      })();
      return tile;
    }
  });
  return new OfflineTileLayer(url, options);
}

export function applyTileLayers(map, key, baseRef, overlayRef) {
  if (!map) return;
  const cfg = TILES[key] || TILES.standard;
  if (baseRef.current) map.removeLayer(baseRef.current);
  if (overlayRef.current) {
    map.removeLayer(overlayRef.current);
    overlayRef.current = null;
  }
  baseRef.current = createTileLayer(cfg.url, { ...TILE_OPTIONS, attribution: cfg.attribution })?.addTo(map);
  if (cfg.overlayUrl) {
    overlayRef.current = createTileLayer(cfg.overlayUrl, { ...TILE_OPTIONS, attribution: cfg.attribution, opacity: 0.9 })?.addTo(map);
  }
}

export function pinIcon(color, text) {
  return window.L.divIcon({
    className: "custom-pin",
    html: `<div style="background:${color};width:24px;height:24px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);position:relative;border:2px solid #fff;box-shadow:0 3px 6px rgba(0,0,0,.3);display:flex;align-items:center;justify-content:center;"><div style="transform:rotate(45deg);color:#fff;font-size:11px;font-weight:bold;text-align:center;">${text || ''}</div></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 24],
    popupAnchor: [0, -24]
  });
}

export function nearbyDot(color, zoom) {
  const size = zoom > 14 ? 22 : Math.max(16, zoom * 1.5);
  return window.L.divIcon({
    className: "nearby-dot",
    html: `<div style="background:${color};width:${size}px;height:${size}px;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.6);cursor:pointer;transition:all 0.2s ease;transform:scale(1);"></div>`,
    iconSize: [size, size],
    iconAnchor: [size/2, size/2],
    popupAnchor: [0, -size/2 - 8]
  });
}

export function gpsIcon(isNavigating) {
  return window.L.divIcon({
    className: "gps-marker",
    html: `<div style="background:${isNavigating ? '#34D399' : '#38BDF8'};width:18px;height:18px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 10px rgba(0,0,0,.4);"></div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9]
  });
}

export function headingIcon(deg = 0) {
  return window.L.divIcon({
    className: "gps-heading-marker",
    html: `<div style="transform: rotate(${deg}deg); font-size: 20px; color: #22D3EE; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.55)); line-height: 1;">➤</div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10],
  });
}

export function tripNavArrowIcon(deg = 0) {
  return window.L.divIcon({
    className: "trip-nav-arrow-marker",
    html: `<div style="width:36px;height:36px;display:flex;align-items:center;justify-content:center;filter:drop-shadow(0 3px 8px rgba(0,0,0,0.75));">
      <svg viewBox="0 0 36 36" width="36" height="36" style="transform:rotate(${deg}deg);transition:transform 0.35s cubic-bezier(.4,0,.2,1);">
        <circle cx="18" cy="18" r="16" fill="rgba(52,211,153,0.18)" stroke="#34D399" stroke-width="2"/>
        <polygon points="18,4 30,30 18,23 6,30" fill="#34D399" stroke="#fff" stroke-width="1.5" stroke-linejoin="round"/>
        <circle cx="18" cy="18" r="3" fill="#fff"/>
      </svg>
    </div>`,
    iconSize: [36, 36],
    iconAnchor: [18, 18],
  });
}

export function tripStartMarkerIcon() {
  return window.L.divIcon({
    className: "trip-start-pin",
    html: `<div style="display:flex;flex-direction:column;align-items:center;">
      <div style="background:linear-gradient(135deg,#34D399,#059669);width:30px;height:30px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);border:2.5px solid #fff;box-shadow:0 4px 12px rgba(52,211,153,0.5);display:flex;align-items:center;justify-content:center;">
        <div style="transform:rotate(45deg);font-size:14px;">🏁</div>
      </div>
    </div>`,
    iconSize: [30, 30],
    iconAnchor: [15, 30],
    popupAnchor: [0, -32],
  });
}

export function parseOverpassElements(elements) {
  return (elements || [])
    .filter(e => {
      const lat = parseFloat(e.lat);
      const lon = parseFloat(e.lon);
      return e.lat && e.lon && !isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
    })
    .map(e => {
      const lat = parseFloat(e.lat);
      const lon = parseFloat(e.lon);
      return {
        id:    String(e.id),
        lat:   lat,
        lng:   lon,
        name:  e.tags?.name || e.tags?.["name:en"] || e.tags?.amenity || e.tags?.tourism || e.tags?.highway || "Unnamed",
        type:  e.tags?.amenity || e.tags?.tourism || e.tags?.highway || "",
        phone: e.tags?.phone  || e.tags?.["contact:phone"] || null,
        hours: e.tags?.opening_hours || null,
        addr:  [e.tags?.["addr:street"], e.tags?.["addr:city"]].filter(Boolean).join(", ") || null,
      };
    });
}

export async function overpassQuery(q) {
  try {
    const token = localStorage.getItem("tm_token");
    const ctrl  = new AbortController();
    const tid   = setTimeout(() => ctrl.abort(), 65000);
    const res = await fetch(`${BACKEND_BASE}/ai/overpass`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json", 
        ...(token ? { Authorization: `Bearer ${token}` } : {}) 
      },
      body: JSON.stringify({ query: q }),
      signal: ctrl.signal,
    });
    clearTimeout(tid);
    if (!res.ok) throw new Error(`Overpass proxy failed: ${res.status}`);
    const data = await res.json();
    const elements = Array.isArray(data) ? data : data?.elements || [];
    const parsed = parseOverpassElements(elements);
    if (parsed.length) return parsed;
  } catch (error) {
    console.error("Overpass proxy error:", error);
  }
  for (const mirror of OVERPASS_MIRRORS) {
    try {
      const body = new URLSearchParams({ data: q });
      const res = await fetch(mirror, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body,
      });
      if (!res.ok) continue;
      const data = await res.json();
      const elements = data?.elements || [];
      const parsed = parseOverpassElements(elements);
      if (parsed.length) return parsed;
    } catch (e) {
      console.warn("Overpass mirror failed:", mirror, e);
    }
  }
  return [];
}

export async function geocode(q) {
  const key = normText(q);
  if (!geocode.cache) geocode.cache = new Map();
  if (geocode.cache.has(key)) return geocode.cache.get(key);
  const r = await fetch(
    `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&limit=5&addressdetails=1`,
    { signal: AbortSignal.timeout(6000) }
  );
  const data = await r.json();
  geocode.cache.set(key, data);
  return data;
}

export function parseLatLngInput(v) {
  const m = String(v || "").trim().match(/^(-?d+(?:.d+)?)s*,s*(-?d+(?:.d+)?)$/);
  if (!m) return null;
  const lat = parseFloat(m[1]);
  const lng = parseFloat(m[2]);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat, lng };
}

export function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371000, dL = (lat2 - lat1) * Math.PI / 180, dG = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dL / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dG / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

export function splitRouteByDistance(coords, segmentKm = 10) {
  if (!Array.isArray(coords) || coords.length < 2) return [];
  const segments = [];
  let seg = [coords[0]];
  let dist = 0;
  for (let i = 1; i < coords.length; i++) {
    const prev = coords[i - 1];
    const cur = coords[i];
    dist += haversine(prev[0], prev[1], cur[0], cur[1]);
    seg.push(cur);
    if (dist >= segmentKm * 1000) {
      segments.push(seg);
      seg = [cur];
      dist = 0;
    }
  }
  if (seg.length > 1) segments.push(seg);
  return segments;
}

export function bboxForCoords(coords, pad = 0.06) {
  if (!Array.isArray(coords) || !coords.length) return null;
  let minLat = Infinity, maxLat = -Infinity, minLng = Infinity, maxLng = -Infinity;
  for (const [la, ln] of coords) {
    if (la < minLat) minLat = la;
    if (la > maxLat) maxLat = la;
    if (ln < minLng) minLng = ln;
    if (ln > maxLng) maxLng = ln;
  }
  if (!Number.isFinite(minLat) || !Number.isFinite(minLng)) return null;
  return { minLat: minLat - pad, maxLat: maxLat + pad, minLng: minLng - pad, maxLng: maxLng + pad };
}

export function parseLatLngText(text) {
  if (!text) return null;
  const m = String(text).match(/(-?d+(?:.d+)?)s*,s*(-?d+(?:.d+)?)/);
  if (!m) return null;
  const lat = parseFloat(m[1]);
  const lng = parseFloat(m[2]);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  return { lat, lng };
}

export function nearestPointOnCoords(coords, lat, lng) {
  if (!Array.isArray(coords) || !coords.length) return { point: null, dist: Infinity };
  let best = null;
  let bestDist = Infinity;
  for (const [la, ln] of coords) {
    const d = haversine(lat, lng, la, ln);
    if (d < bestDist) {
      bestDist = d;
      best = [la, ln];
    }
  }
  return { point: best, dist: bestDist };
}

export function normText(v) {
  return String(v || "").trim().toLowerCase().replace(/s+/g, " ");
}

export function greatCircleArc(lat1, lng1, lat2, lng2, steps = 80) {
  const toRad = d => d * Math.PI / 180;
  const toDeg = r => r * 180 / Math.PI;
  const φ1 = toRad(lat1), λ1 = toRad(lng1);
  const φ2 = toRad(lat2), λ2 = toRad(lng2);
  const d = 2 * Math.asin(Math.sqrt(Math.sin((φ2 - φ1) / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin((λ2 - λ1) / 2) ** 2));
  if (d < 0.0001) return [[lat1, lng1], [lat2, lng2]];
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    const f = i / steps;
    const A = Math.sin((1 - f) * d) / Math.sin(d);
    const B = Math.sin(f * d) / Math.sin(d);
    const x = A * Math.cos(φ1) * Math.cos(λ1) + B * Math.cos(φ2) * Math.cos(λ2);
    const y = A * Math.cos(φ1) * Math.sin(λ1) + B * Math.cos(φ2) * Math.sin(λ2);
    const z = A * Math.sin(φ1) + B * Math.sin(φ2);
    pts.push([toDeg(Math.atan2(z, Math.sqrt(x * x + y * y))), toDeg(Math.atan2(y, x))]);
  }
  return pts;
}

export async function findNearestHub(lat, lng, type = "air") {
  const r = 0.8;
  const bbox = `${lat - r},${lng - r},${lat + r},${lng + r}`;
  const q = type === "air"
    ? `[out:json][timeout:20];(node["aeroway"="aerodrome"][bbox:${bbox}];way["aeroway"="aerodrome"][bbox:${bbox}];);out center 5;`
    : `[out:json][timeout:20];(node["harbour"="yes"][bbox:${bbox}];node["seamark:type"="harbour"][bbox:${bbox}];node["amenity"="ferry_terminal"][bbox:${bbox}];way["amenity"="ferry_terminal"][bbox:${bbox}];);out center 5;`;
  try {
    const token = localStorage.getItem("tm_token");
    const res = await fetch(`${BACKEND_BASE}/ai/overpass`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ query: q }),
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return null;
    const data = await res.json();
    const els = Array.isArray(data) ? data : data?.elements || [];
    for (const e of els) {
      const elat = e.lat ?? e.center?.lat;
      const elng = e.lon ?? e.center?.lon;
      if (elat && elng) {
        return {
          lat: elat, lng: elng,
          name: e.tags?.name || e.tags?.["iata"] || (type === "air" ? "Airport" : "Harbour"),
          iata: e.tags?.iata || null,
        };
      }
    }
  } catch {}
  return null;
}

export async function detectRouteType(fLat, fLng, tLat, tLng) {
  const distKm = haversine(fLat, fLng, tLat, tLng) / 1000;
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${fLng},${fLat};${tLng},${tLat}?overview=false`;
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), 7000);
    const res = await fetch(url, { signal: ctrl.signal });
    clearTimeout(tid);
    const data = await res.json();
    if (data.routes?.length) {
      const roadKm = data.routes[0].distance / 1000;
      if (roadKm > distKm * 3.5 || roadKm > 5000) return "air";
      return null;
    }
    return distKm > 800 ? "air" : "sea";
  } catch {
    return distKm > 800 ? "air" : "sea";
  }
}

export async function findBestAirport(lat, lng, minRadius = 0.3, maxRadius = 2.5) {
  for (let r = minRadius; r <= maxRadius; r += 0.5) {
    const bbox = `${lat - r},${lng - r},${lat + r},${lng + r}`;
    const q = `[out:json][timeout:20];(
      node["aeroway"="aerodrome"]["iata"]["icao"][bbox:${bbox}];
      way["aeroway"="aerodrome"]["iata"]["icao"][bbox:${bbox}];
      node["aeroway"="aerodrome"]["iata"][bbox:${bbox}];
      way["aeroway"="aerodrome"]["iata"][bbox:${bbox}];
      node["aeroway"="aerodrome"][bbox:${bbox}];
      way["aeroway"="aerodrome"][bbox:${bbox}];
    );out center 15;`;
    
    try {
      const token = localStorage.getItem("tm_token");
      const res = await fetch(`${BACKEND_BASE}/ai/overpass`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ query: q }),
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) continue;
      const data = await res.json();
      const els = Array.isArray(data) ? data : data?.elements || [];
      
      const airports = els
        .map(e => {
          const elat = e.lat ?? e.center?.lat;
          const elng = e.lon ?? e.center?.lon;
          if (!elat || !elng) return null;
          const dist = haversine(lat, lng, elat, elng);
          const hasIATA = !!e.tags?.iata;
          const hasICAO = !!e.tags?.icao;
          const hasName = !!e.tags?.name;
          const score = (hasIATA ? 100000 : 0) + (hasICAO ? 50000 : 0) + (hasName ? 10000 : 0) - dist;
          return {
            lat: elat, lng: elng,
            name: e.tags?.name || e.tags?.iata || "Airport",
            iata: e.tags?.iata || null,
            icao: e.tags?.icao || null,
            distance: dist, score: score
          };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score);
      
      if (airports.length > 0) return airports[0];
    } catch (e) { console.warn(`Airport search failed:`, e); }
  }
  return null;
}

export async function getRoadRoute(fromLat, fromLng, toLat, toLng, mode = "driving") {
  const OSRM_ENDPOINTS = {
    driving: "https://router.project-osrm.org/route/v1/driving",
    cycling: "https://routing.openstreetmap.de/routed-bike/route/v1/driving",
    walking: "https://routing.openstreetmap.de/routed-foot/route/v1/driving",
  };
  const base = OSRM_ENDPOINTS[mode] || OSRM_ENDPOINTS.driving;
  const url = `${base}/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson&steps=true`;
  
  try {
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), 8500);
    const res = await fetch(url, { signal: ctrl.signal });
    clearTimeout(tid);
    const data = await res.json();
    if (!data.routes?.length) return null;
    const route = data.routes[0];
    return {
      coords: route.geometry.coordinates.map(([ln, la]) => [la, ln]),
      distance: route.distance,
      duration: route.duration,
      steps: route.legs?.[0]?.steps || []
    };
  } catch (e) { return null; }
}

export async function buildMultiSegmentRoute(fromLat, fromLng, toLat, toLng, routeMode, isInternational = false) {
  const segments = [];
  const distKm = haversine(fromLat, fromLng, toLat, toLng) / 1000;
  const useHybrid = isInternational;
  
  if (!useHybrid) {
    const roadRoute = await getRoadRoute(fromLat, fromLng, toLat, toLng, routeMode);
    if (roadRoute) {
      return {
        type: 'road',
        segments: [{ type: 'road', label: 'Direct Route', coords: roadRoute.coords, distance: roadRoute.distance, duration: roadRoute.duration, steps: roadRoute.steps, color: '#22c55e' }],
        totalDistance: roadRoute.distance / 1000,
        totalDuration: Math.round(roadRoute.duration / 60)
      };
    }
  }
  
  const [fromAirport, toAirport] = await Promise.all([
    findBestAirport(fromLat, fromLng),
    findBestAirport(toLat, toLng)
  ]);
  
  if (!fromAirport || !toAirport) {
    const arcCoords = greatCircleArc(fromLat, fromLng, toLat, toLng, 100);
    return {
      type: 'air',
      segments: [{ type: 'air', label: '✈ Direct Flight', coords: arcCoords, distance: distKm * 1000, duration: Math.round((distKm / 850) * 60 * 60), color: '#818CF8', dashArray: '14,6' }],
      totalDistance: distKm,
      totalDuration: Math.round((distKm / 850) * 60)
    };
  }
  
  const roadToAirport = await getRoadRoute(fromLat, fromLng, fromAirport.lat, fromAirport.lng, routeMode);
  if (roadToAirport) {
    segments.push({ type: 'road', label: `To ${fromAirport.name}`, coords: roadToAirport.coords, distance: roadToAirport.distance, duration: roadToAirport.duration, steps: roadToAirport.steps, color: '#38BDF8', dashArray: '6,6', hub: fromAirport });
  } else {
    segments.push({ type: 'transfer', label: `Transfer to ${fromAirport.name}`, coords: [[fromLat, fromLng], [fromAirport.lat, fromAirport.lng]], distance: haversine(fromLat, fromLng, fromAirport.lat, fromAirport.lng), duration: 1800, color: '#38BDF8', dashArray: '6,6', hub: fromAirport });
  }
  
  const airArc = greatCircleArc(fromAirport.lat, fromAirport.lng, toAirport.lat, toAirport.lng, 100);
  const airDistKm = haversine(fromAirport.lat, fromAirport.lng, toAirport.lat, toAirport.lng) / 1000;
  const airDurMin = Math.round((airDistKm / 850) * 60);
  segments.push({ type: 'air', label: `Flight: ${fromAirport.iata || fromAirport.name} → ${toAirport.iata || toAirport.name}`, coords: airArc, distance: airDistKm * 1000, duration: airDurMin * 60, color: '#818CF8', dashArray: '14,6', fromHub: fromAirport, toHub: toAirport });
  
  const roadFromAirport = await getRoadRoute(toAirport.lat, toAirport.lng, toLat, toLng, routeMode);
  if (roadFromAirport) {
    segments.push({ type: 'road', label: `From ${toAirport.name}`, coords: roadFromAirport.coords, distance: roadFromAirport.distance, duration: roadFromAirport.duration, steps: roadFromAirport.steps, color: '#38BDF8', dashArray: '6,6', hub: toAirport });
  } else {
    segments.push({ type: 'transfer', label: `Transfer from ${toAirport.name}`, coords: [[toAirport.lat, toAirport.lng], [toLat, toLng]], distance: haversine(toAirport.lat, toAirport.lng, toLat, toLng), duration: 1800, color: '#38BDF8', dashArray: '6,6', hub: toAirport });
  }
  
  const totalDistance = segments.reduce((sum, s) => sum + s.distance, 0) / 1000;
  const totalDuration = Math.round(segments.reduce((sum, s) => sum + s.duration, 0) / 60);
  return { type: 'hybrid', segments, totalDistance, totalDuration, fromAirport, toAirport };
}

export function renderMultiSegmentRoute(L, routeLay, multiRoute, fromLabel, toLabel, pinIcon, t) {
  const { segments, fromAirport, toAirport } = multiRoute;
  routeLay.clearLayers();
  
  segments.forEach((segment) => {
    const { coords, color, dashArray, type, label, fromHub, toHub } = segment;
    L.polyline(coords, { color: '#000', weight: type === 'air' ? 7 : 5, opacity: type === 'air' ? 0.25 : 0.3, lineCap: 'round', lineJoin: 'round' }).addTo(routeLay);
    const mainLine = L.polyline(coords, { color: color, weight: type === 'air' ? 4 : 3, opacity: type === 'air' ? 0.95 : 0.8, lineCap: 'round', lineJoin: 'round', dashArray: dashArray || null });
    
    const distKm = (segment.distance / 1000).toFixed(1);
    const durMin = Math.round(segment.duration / 60);
    const durStr = durMin < 60 ? `${durMin} min` : `${Math.floor(durMin / 60)}h ${durMin % 60}m`;
    let popupHTML = `<div style="padding:6px 2px"><b style="color:${color};font-size:13px">${label || type.toUpperCase()}</b><br><span style="font-size:12px;color:${t?.text || '#fff'}">📏 ${distKm} km · ⏱ ${durStr}</span>`;
    if (fromHub || toHub) {
      if (fromHub) popupHTML += `<br><span style="font-size:11px;color:#94A3B8">From: ${fromHub.name}${fromHub.iata ? ' (' + fromHub.iata + ')' : ''}</span>`;
      if (toHub) popupHTML += `<br><span style="font-size:11px;color:#94A3B8">To: ${toHub.name}${toHub.iata ? ' (' + toHub.iata + ')' : ''}</span>`;
    }
    popupHTML += '</div>';
    mainLine.bindPopup(popupHTML).addTo(routeLay);
    
    if (type === 'air' && coords.length > 2) {
      const midIdx = Math.floor(coords.length / 2);
      const [mLat, mLng] = coords[midIdx];
      L.marker([mLat, mLng], { icon: L.divIcon({ className: "", html: `<div style="font-size:28px;filter:drop-shadow(0 2px 6px rgba(0,0,0,.6));animation:tmFloat 2s ease-in-out infinite alternate;">✈</div>`, iconSize: [36, 36], iconAnchor: [18, 18] }), zIndexOffset: 800 }).bindPopup(label || 'Flight').addTo(routeLay);
    }
  });
  
  const firstCoord = segments[0].coords[0];
  const lastSegment = segments[segments.length - 1];
  const lastCoord = lastSegment.coords[lastSegment.coords.length - 1];
  L.marker(firstCoord, { icon: pinIcon('#38BDF8', 'A'), zIndexOffset: 600 }).bindPopup(`<b>From:</b> ${fromLabel || 'Origin'}`).addTo(routeLay);
  L.marker(lastCoord, { icon: pinIcon('#34D399', 'B'), zIndexOffset: 600 }).bindPopup(`<b>To:</b> ${toLabel || 'Destination'}`).addTo(routeLay);
  
  if (fromAirport) {
    L.marker([fromAirport.lat, fromAirport.lng], { icon: L.divIcon({ className: "", html: `<div style="font-size:20px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.5));">🛫</div>`, iconSize: [24, 24], iconAnchor: [12, 12] }), zIndexOffset: 700 }).bindPopup(`<b>${fromAirport.name}</b>${fromAirport.iata ? '<br>IATA: ' + fromAirport.iata : ''}${fromAirport.icao ? '<br>ICAO: ' + fromAirport.icao : ''}`).addTo(routeLay);
  }
  if (toAirport && toAirport !== fromAirport) {
    L.marker([toAirport.lat, toAirport.lng], { icon: L.divIcon({ className: "", html: `<div style="font-size:20px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.5));">🛬</div>`, iconSize: [24, 24], iconAnchor: [12, 12] }), zIndexOffset: 700 }).bindPopup(`<b>${toAirport.name}</b>${toAirport.iata ? '<br>IATA: ' + toAirport.iata : ''}${toAirport.icao ? '<br>ICAO: ' + toAirport.icao : ''}`).addTo(routeLay);
  }
  
  if (!document.getElementById("tm-airways-css")) {
    const s = document.createElement("style");
    s.id = "tm-airways-css";
    s.innerHTML = `@keyframes tmFloat { from { transform: translateY(0); } to { transform: translateY(-6px); } }
      .tm-airway-line { animation: tmDash 1.8s linear infinite; }
      @keyframes tmDash { to { stroke-dashoffset: -40; } }`;
    document.head.appendChild(s);
  }
}
