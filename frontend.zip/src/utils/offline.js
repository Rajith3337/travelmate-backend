import { Capacitor } from "@capacitor/core";
import { Filesystem, Directory, Encoding } from "@capacitor/filesystem";

const DB = "tm_offline";
const VER = 2;
const OFFLINE_DIR = "TravelMateOffline";
const TILE_DIR = `${OFFLINE_DIR}/tiles`;
const QUEUE_FILE = `${OFFLINE_DIR}/queue.json`;
let dirReady = false;
let baseDir = Directory.Documents;
let baseDirLabel = "Documents";

export const isNativePlatform = () => Capacitor.isNativePlatform();

async function tryEnsureDir(directory) {
  try {
    await Filesystem.mkdir({ path: OFFLINE_DIR, directory, recursive: true });
    return true;
  } catch (e) {
    const msg = String(e?.message || e || "");
    if (msg.toLowerCase().includes("exists")) return true;
    return false;
  }
}

export async function ensureOfflineDir() {
  if (!Capacitor.isNativePlatform()) return false;
  if (dirReady) return true;
  if (await tryEnsureDir(Directory.Documents)) {
    baseDir = Directory.Documents;
    baseDirLabel = "Documents";
    dirReady = true;
    // Also ensure core subdirs exist
    try { await Filesystem.mkdir({ path: `${OFFLINE_DIR}/trips`, directory: baseDir, recursive: true }); } catch {}
    try { await Filesystem.mkdir({ path: TILE_DIR, directory: baseDir, recursive: true }); } catch {}
    return true;
  }
  if (await tryEnsureDir(Directory.Data)) {
    baseDir = Directory.Data;
    baseDirLabel = "Data";
    dirReady = true;
    try { await Filesystem.mkdir({ path: `${OFFLINE_DIR}/trips`, directory: baseDir, recursive: true }); } catch {}
    try { await Filesystem.mkdir({ path: TILE_DIR, directory: baseDir, recursive: true }); } catch {}
    return true;
  }
  return false;
}

/** Create a named folder for a specific trip inside TravelMateOffline/trips/{tripId}/ */
export async function ensureTripOfflineFolder(tripId, tripName) {
  if (!Capacitor.isNativePlatform()) return null;
  if (!await ensureOfflineDir()) return null;
  const safeName = String(tripName || tripId).replace(/[^a-zA-Z0-9_\- ]/g, "").trim().slice(0, 40) || String(tripId);
  const folderName = `${safeName}_${tripId}`;
  const folderPath = `${OFFLINE_DIR}/trips/${folderName}`;
  try {
    await Filesystem.mkdir({ path: folderPath, directory: baseDir, recursive: true });
    // Write a manifest file so the folder is discoverable
    await Filesystem.writeFile({
      path: `${folderPath}/manifest.json`,
      directory: baseDir,
      data: JSON.stringify({ tripId, tripName: tripName || safeName, createdAt: new Date().toISOString(), version: 1 }),
      encoding: Encoding.UTF8,
    });
    return `${baseDirLabel}/${folderPath}`;
  } catch {
    return null;
  }
}

/** Save trip data blob (places, itinerary, notes) to its offline folder */
export async function saveTripDataOffline(tripId, tripName, data) {
  if (!Capacitor.isNativePlatform()) return false;
  if (!await ensureOfflineDir()) return false;
  const safeName = String(tripName || tripId).replace(/[^a-zA-Z0-9_\- ]/g, "").trim().slice(0, 40) || String(tripId);
  const folderPath = `${OFFLINE_DIR}/trips/${safeName}_${tripId}`;
  try {
    await Filesystem.mkdir({ path: folderPath, directory: baseDir, recursive: true });
    await Filesystem.writeFile({
      path: `${folderPath}/data.json`,
      directory: baseDir,
      data: JSON.stringify({ ...data, savedAt: new Date().toISOString() }),
      encoding: Encoding.UTF8,
    });
    await Filesystem.writeFile({
      path: `${folderPath}/manifest.json`,
      directory: baseDir,
      data: JSON.stringify({ tripId, tripName: tripName || safeName, savedAt: new Date().toISOString(), hasTiles: false, version: 1 }),
      encoding: Encoding.UTF8,
    });
    return true;
  } catch {
    return false;
  }
}

/** List all trip folders saved offline */
export async function listOfflineTripFolders() {
  if (!Capacitor.isNativePlatform()) return [];
  if (!await ensureOfflineDir()) return [];
  try {
    const res = await Filesystem.readdir({ path: `${OFFLINE_DIR}/trips`, directory: baseDir });
    const entries = res.files || [];
    const folders = [];
    for (const entry of entries) {
      const name = typeof entry === "string" ? entry : entry.name;
      if (!name) continue;
      try {
        const mf = await Filesystem.readFile({
          path: `${OFFLINE_DIR}/trips/${name}/manifest.json`,
          directory: baseDir,
          encoding: Encoding.UTF8,
        });
        folders.push(JSON.parse(mf.data));
      } catch {}
    }
    return folders;
  } catch {
    return [];
  }
}

/** Read the data.json for a specific trip folder */
export async function readTripDataOffline(tripId) {
  if (!Capacitor.isNativePlatform()) {
    // Web fallback: read from localStorage
    try {
      const raw = localStorage.getItem(`tm_offline_trip_${tripId}`);
      return raw ? JSON.parse(raw) : null;
    } catch { return null; }
  }
  if (!await ensureOfflineDir()) return null;
  try {
    // Find the folder matching this tripId
    const res = await Filesystem.readdir({ path: `${OFFLINE_DIR}/trips`, directory: baseDir });
    const entries = res.files || [];
    for (const entry of entries) {
      const name = typeof entry === "string" ? entry : entry.name;
      if (!name) continue;
      try {
        const mfRaw = await Filesystem.readFile({
          path: `${OFFLINE_DIR}/trips/${name}/manifest.json`,
          directory: baseDir,
          encoding: Encoding.UTF8,
        });
        const mf = JSON.parse(mfRaw.data);
        if (String(mf.tripId) === String(tripId)) {
          const dataRaw = await Filesystem.readFile({
            path: `${OFFLINE_DIR}/trips/${name}/data.json`,
            directory: baseDir,
            encoding: Encoding.UTF8,
          });
          return JSON.parse(dataRaw.data);
        }
      } catch {}
    }
    return null;
  } catch { return null; }
}

/** Load all saved offline trips with their data */
export async function loadAllOfflineTrips() {
  if (!Capacitor.isNativePlatform()) {
    // Web fallback: scan localStorage for tm_offline_trip_* keys
    const trips = [];
    try {
      for (let i = 0; i < localStorage.length; i++) {
        const key = localStorage.key(i);
        if (!key?.startsWith("tm_offline_trip_")) continue;
        try {
          const data = JSON.parse(localStorage.getItem(key));
          if (data) trips.push(data);
        } catch {}
      }
    } catch {}
    return trips;
  }
  if (!await ensureOfflineDir()) return [];
  try {
    const res = await Filesystem.readdir({ path: `${OFFLINE_DIR}/trips`, directory: baseDir });
    const entries = res.files || [];
    const results = [];
    for (const entry of entries) {
      const name = typeof entry === "string" ? entry : entry.name;
      if (!name) continue;
      try {
        const dataRaw = await Filesystem.readFile({
          path: `${OFFLINE_DIR}/trips/${name}/data.json`,
          directory: baseDir,
          encoding: Encoding.UTF8,
        });
        const data = JSON.parse(dataRaw.data);
        if (data) results.push(data);
      } catch {}
    }
    return results;
  } catch { return []; }
}

export async function getOfflineBaseLocation() {
  if (!Capacitor.isNativePlatform()) return "";
  await ensureOfflineDir();
  return `${baseDirLabel}/${OFFLINE_DIR}`;
}

async function ensureTileDir(z, x) {
  if (!await ensureOfflineDir()) return false;
  try {
    await Filesystem.mkdir({ path: `${TILE_DIR}/${z}/${x}`, directory: baseDir, recursive: true });
    return true;
  } catch {
    return false;
  }
}

function parseTileUrl(url) {
  const m = String(url || "").match(/\/(\d+)\/(\d+)\/(\d+)\.png/);
  if (!m) return null;
  return { z: Number(m[1]), x: Number(m[2]), y: Number(m[3]) };
}

async function blobToBase64(blob) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onloadend = () => {
      const s = String(r.result || "");
      const idx = s.indexOf(",");
      res(idx >= 0 ? s.slice(idx + 1) : s);
    };
    r.onerror = rej;
    r.readAsDataURL(blob);
  });
}

export async function cacheTileFromUrl(url) {
  if (!Capacitor.isNativePlatform()) return false;
  const coords = parseTileUrl(url);
  if (!coords) return false;
  try {
    const res = await fetch(url);
    if (!res.ok) return false;
    const blob = await res.blob();
    const base64 = await blobToBase64(blob);
    if (!await ensureTileDir(coords.z, coords.x)) return false;
    await Filesystem.writeFile({
      path: `${TILE_DIR}/${coords.z}/${coords.x}/${coords.y}.png`,
      directory: baseDir,
      data: base64,
    });
    return true;
  } catch {
    return false;
  }
}

export async function readTileDataUrl(z, x, y) {
  if (!Capacitor.isNativePlatform()) return null;
  if (!await ensureOfflineDir()) return null;
  try {
    const res = await Filesystem.readFile({
      path: `${TILE_DIR}/${z}/${x}/${y}.png`,
      directory: baseDir,
    });
    if (!res?.data) return null;
    return `data:image/png;base64,${res.data}`;
  } catch {
    return null;
  }
}

export async function clearTileFiles() {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await Filesystem.rmdir({ path: TILE_DIR, directory: baseDir, recursive: true });
  } catch {}
}

async function fsWrite(key, value) {
  if (!await ensureOfflineDir()) return;
  try {
    await Filesystem.writeFile({
      path: `${OFFLINE_DIR}/${key}.json`,
      directory: baseDir,
      data: JSON.stringify(value),
      encoding: Encoding.UTF8,
    });
  } catch {}
}

async function fsRead(key) {
  if (!await ensureOfflineDir()) return null;
  try {
    const res = await Filesystem.readFile({
      path: `${OFFLINE_DIR}/${key}.json`,
      directory: baseDir,
      encoding: Encoding.UTF8,
    });
    if (!res?.data) return null;
    return JSON.parse(res.data);
  } catch {
    return null;
  }
}

async function fsDelete(key) {
  if (!await ensureOfflineDir()) return;
  try {
    await Filesystem.deleteFile({
      path: `${OFFLINE_DIR}/${key}.json`,
      directory: baseDir,
    });
  } catch {}
}

async function fsClear() {
  if (!Capacitor.isNativePlatform()) return;
  try {
    await Filesystem.rmdir({ path: OFFLINE_DIR, directory: baseDir, recursive: true });
  } catch {}
  dirReady = false;
  await ensureOfflineDir();
}

async function readQueueFile() {
  if (!await ensureOfflineDir()) return [];
  try {
    const res = await Filesystem.readFile({
      path: QUEUE_FILE,
      directory: baseDir,
      encoding: Encoding.UTF8,
    });
    const parsed = JSON.parse(res?.data || "[]");
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function writeQueueFile(items) {
  if (!await ensureOfflineDir()) return;
  try {
    await Filesystem.writeFile({
      path: QUEUE_FILE,
      directory: baseDir,
      data: JSON.stringify(items || []),
      encoding: Encoding.UTF8,
    });
  } catch {}
}

export function openOfflineDB() {
  return new Promise((res, rej) => {
    const r = indexedDB.open(DB, VER);
    r.onupgradeneeded = e => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("queue")) {
        db.createObjectStore("queue", { keyPath: "id", autoIncrement: true });
      }
      if (!db.objectStoreNames.contains("cache")) {
        db.createObjectStore("cache", { keyPath: "key" });
      }
    };
    r.onsuccess = e => res(e.target.result);
    r.onerror = rej;
  });
}

export async function enqueueAction(action) {
  if (Capacitor.isNativePlatform()) {
    const q = await readQueueFile();
    const id = Date.now() + Math.floor(Math.random() * 100000);
    q.push({ id, ...action, timestamp: Date.now() });
    await writeQueueFile(q);
    return;
  }
  const db = await openOfflineDB();
  return new Promise((res, rej) => {
    const tx = db.transaction("queue", "readwrite");
    tx.objectStore("queue").add({ ...action, timestamp: Date.now() });
    tx.oncomplete = () => res();
    tx.onerror = rej;
  });
}

export async function getQueue() {
  if (Capacitor.isNativePlatform()) {
    return await readQueueFile();
  }
  const db = await openOfflineDB();
  return new Promise((res, rej) => {
    const tx = db.transaction("queue", "readonly");
    const r = tx.objectStore("queue").getAll();
    r.onsuccess = () => res(r.result || []);
    r.onerror = rej;
  });
}

export async function clearQueueItem(id) {
  if (Capacitor.isNativePlatform()) {
    const q = await readQueueFile();
    await writeQueueFile(q.filter(item => item.id !== id));
    return;
  }
  const db = await openOfflineDB();
  return new Promise((res, rej) => {
    const tx = db.transaction("queue", "readwrite");
    tx.objectStore("queue").delete(id);
    tx.oncomplete = res;
    tx.onerror = rej;
  });
}

export async function cacheSet(key, value) {
  if (Capacitor.isNativePlatform()) {
    await fsWrite(key, value);
    return;
  }
  const db = await openOfflineDB();
  await new Promise((res, rej) => {
    const tx = db.transaction("cache", "readwrite");
    tx.objectStore("cache").put({ key, value, ts: Date.now() });
    tx.oncomplete = res;
    tx.onerror = rej;
  });
  fsWrite(key, value);
}

export async function cacheGet(key) {
  if (Capacitor.isNativePlatform()) {
    return fsRead(key);
  }
  const db = await openOfflineDB();
  const val = await new Promise((res, rej) => {
    const tx = db.transaction("cache", "readonly");
    const r = tx.objectStore("cache").get(key);
    r.onsuccess = () => res(r.result?.value ?? null);
    r.onerror = rej;
  });
  if (val != null) return val;
  return fsRead(key);
}

export async function cacheDelete(key) {
  if (Capacitor.isNativePlatform()) {
    await fsDelete(key);
    return;
  }
  const db = await openOfflineDB();
  await new Promise((res, rej) => {
    const tx = db.transaction("cache", "readwrite");
    tx.objectStore("cache").delete(key);
    tx.oncomplete = res;
    tx.onerror = rej;
  });
  fsDelete(key);
}

export async function cacheClear() {
  if (Capacitor.isNativePlatform()) {
    await fsClear();
    return;
  }
  const db = await openOfflineDB();
  await new Promise((res, rej) => {
    const tx = db.transaction("cache", "readwrite");
    tx.objectStore("cache").clear();
    tx.oncomplete = res;
    tx.onerror = rej;
  });
  fsClear();
}

export const isOnline = () => navigator.onLine;

export async function getOfflineStorageInfo() {
  if (!Capacitor.isNativePlatform()) return { used: 0, quota: 0, location: "" };
  await ensureOfflineDir();
  const dirSize = async (path) => {
    let total = 0;
    try {
      const res = await Filesystem.readdir({ path, directory: baseDir });
      const entries = res.files || [];
      for (const entry of entries) {
        const name = typeof entry === "string" ? entry : entry.name;
        if (!name) continue;
        const full = `${path}/${name}`;
        try {
          const st = await Filesystem.stat({ path: full, directory: baseDir });
          if (st.type === "directory") {
            total += await dirSize(full);
          } else {
            total += st.size || 0;
          }
        } catch {}
      }
    } catch {}
    return total;
  };
  const used = await dirSize(OFFLINE_DIR);
  return { used, quota: 0, location: `${baseDirLabel}/${OFFLINE_DIR}` };
}

export async function clearOfflineStorage() {
  if (!Capacitor.isNativePlatform()) return;
  await fsClear();
}
