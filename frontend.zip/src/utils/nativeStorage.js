// Storage utility — uses Capacitor Preferences on native, localStorage on web
// Drop-in replacement for localStorage.getItem / setItem

async function getPlugin() {
  if (isNative()) {
    const { Preferences } = await import('@capacitor/preferences');
    return Preferences;
  }
  return null;
}

export function isNative() {
  return typeof window !== 'undefined' && window.Capacitor?.isNativePlatform?.();
}

export async function storageGet(key) {
  const p = await getPlugin();
  if (p) {
    const { value } = await p.get({ key });
    return value;
  }
  return localStorage.getItem(key);
}

export async function storageSet(key, value) {
  const p = await getPlugin();
  if (p) {
    await p.set({ key, value: String(value) });
  } else {
    localStorage.setItem(key, value);
  }
}

export async function storageRemove(key) {
  const p = await getPlugin();
  if (p) {
    await p.remove({ key });
  } else {
    localStorage.removeItem(key);
  }
}
