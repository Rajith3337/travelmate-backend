import { createContext, useContext, useState, useEffect } from "react";

export const ThemeCtx = createContext(null);

export function ThemeProvider({ children }) {
  const [dark, setDark] = useState(() => {
    const saved = localStorage.getItem("tm_theme");
    return saved ? saved === "dark" : true; // default dark
  });

  // Keep html class + theme-color meta in sync with React state
  useEffect(() => {
    document.documentElement.classList.toggle("tm-light", !dark);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", dark ? "#080510" : "#EEF6FF");
  }, [dark]);

  const toggle = () => setDark(d => {
    const next = !d;
    localStorage.setItem("tm_theme", next ? "dark" : "light");
    return next;
  });

  return <ThemeCtx.Provider value={{ dark, toggle }}>{children}</ThemeCtx.Provider>;
}

export const useTheme = () => useContext(ThemeCtx);
