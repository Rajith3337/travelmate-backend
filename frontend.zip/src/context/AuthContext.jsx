import { createContext, useContext, useState, useEffect, useCallback, useRef } from "react";
import { authApi } from "../api/client";
import { prefetchAll } from "../cache/dataStore";

// ── Offline user helpers ───────────────────────────────────────────────────
// Build a minimal synthetic user from whatever we cached at last login.
function buildOfflineUser() {
  try {
    const raw = localStorage.getItem("tm_cached_user");
    if (raw) return { ...JSON.parse(raw), _offline: true };
  } catch {}
  return { id: 0, name: "Offline", email: "", _offline: true };
}

function cacheUser(u) {
  if (!u || u._offline) return;
  try { localStorage.setItem("tm_cached_user", JSON.stringify(u)); } catch {}
}

const Ctx = createContext(null);
export { Ctx as AuthContext };

// Auto-logout after 20 minutes of inactivity
const INACTIVITY_TIMEOUT = 20 * 60 * 1000;
// Warning shown 2 minutes before logout
const WARN_BEFORE = 2 * 60 * 1000;

// Delay before firing precompute after login — lets the app become fully interactive first.
// Debounced so login + load() both triggering within the same second only fires once.
let _precomputeTimer = null;
function schedulePrecompute() {
  if (_precomputeTimer) return; // already scheduled — skip
  _precomputeTimer = setTimeout(() => {
    _precomputeTimer = null;
    // Fire the actual background warm-up (import lazily to avoid circular deps)
    import("../api/client").then(({ aiApi }) => {
      aiApi.precomputeRoadmaps().catch(() => {});
    }).catch(() => {});
  }, 5000); // 5s after login before kicking off background warmup
}

export function AuthProvider({ children }) {
  const [user,        setUser]        = useState(null);
  const [loading,     setLoading]     = useState(true);
  const [showWarning, setShowWarning] = useState(false);
  const [countdown,   setCountdown]   = useState(120);
  const [isOfflineMode, setIsOfflineMode] = useState(false);
  const offlineModeRef = useRef(false);

  const logoutTimer  = useRef(null);
  const warnTimer    = useRef(null);
  const countRef     = useRef(null);
  const loadRunRef   = useRef(0);

  const logout = useCallback(() => {
    localStorage.removeItem("tm_token");
    sessionStorage.removeItem("tm_page");
    setUser(null);
    setShowWarning(false);
    clearTimeout(logoutTimer.current);
    clearTimeout(warnTimer.current);
    clearInterval(countRef.current);
    window.dispatchEvent(new CustomEvent("navigate", { detail: "dashboard" }));
  }, []);

  const resetTimers = useCallback(() => {
    // Timers removed to prevent auto-logout.
  }, []);

  // Track user activity - not strictly needed anymore, but keeping effect for safety if other things depend on it.
  useEffect(() => {
    // No-op
  }, []);

  // Enter offline mode — keep user logged in using cached profile
  const enterOfflineMode = useCallback(() => {
    if (offlineModeRef.current) return; // already offline
    const token = localStorage.getItem("tm_token");
    if (!token) return; // no token = not logged in, nothing to preserve
    offlineModeRef.current = true;
    setIsOfflineMode(true);
    const offlineUser = buildOfflineUser();
    setUser(prev => prev ?? offlineUser); // keep real user if already set
    console.info("[Auth] Device went offline — staying on current page with cached session.");
  }, []);

  const exitOfflineMode = useCallback(() => {
    if (!offlineModeRef.current) return;
    offlineModeRef.current = false;
    setIsOfflineMode(false);
    // Re-validate session silently when network returns
    const token = localStorage.getItem("tm_token");
    if (!token) return;
    authApi.me().then(u => {
      if (u) { cacheUser(u); setUser(u); resetTimers(); }
    }).catch(() => {});
  }, [resetTimers]);

  const load = useCallback(async () => {
    const runId = Date.now();
    loadRunRef.current = runId;
    const t = localStorage.getItem("tm_token");

    // No token at all — show login (but only if actually online; if offline with no token there's nothing we can do)
    if (!t) {
      if (!navigator.onLine) {
        offlineModeRef.current = true;
        setIsOfflineMode(true);
        setUser(buildOfflineUser());
        setLoading(false);
        return;
      }
      setLoading(false);
      return;
    }

    // If already offline at app-start, stay logged in with cached session
    if (!navigator.onLine) {
      offlineModeRef.current = true;
      setIsOfflineMode(true);
      setUser(buildOfflineUser());
      setLoading(false);
      return;
    }

    // Safety valve: never keep app on splash forever.
    const loadingGuard = setTimeout(() => {
      if (loadRunRef.current === runId) {
        // Timed out — if offline by now, use cached session
        if (!navigator.onLine) {
          offlineModeRef.current = true;
          setIsOfflineMode(true);
          setUser(buildOfflineUser());
        }
        setLoading(false);
      }
    }, 12000);

    try {
      // Retry a few times because backend can be temporarily unavailable (e.g. cold start).
      let u = null;
      let lastErr = null;
      for (let i = 0; i < 3; i++) {
        try {
          u = await authApi.me();
          break;
        } catch (e) {
          lastErr = e;
          if (String(e?.message || "").includes("401")) break;
          // If we lost network mid-retry, bail early and use cached session
          if (!navigator.onLine) break;
          await new Promise(r => setTimeout(r, 900 * (i + 1)));
        }
      }
      if (u) {
        cacheUser(u); // persist fresh profile for next offline session
        setUser(u);
        resetTimers();
        schedulePrecompute();
        // Kick off background prefetch of trips + summaries + notes immediately
        setTimeout(() => prefetchAll(), 100);
      } else if (!navigator.onLine) {
        // Network dropped during retries — use cached session, do NOT clear token
        offlineModeRef.current = true;
        setIsOfflineMode(true);
        setUser(buildOfflineUser());
      } else if (String(lastErr?.message || "").includes("401")) {
        // Genuine 401 — token is invalid, force re-login
        localStorage.removeItem("tm_token");
      } else {
        // Transient backend failure but we are online — use cached session rather
        // than forcing a logout (render may recover on its own, e.g. cold-start)
        const cached = buildOfflineUser();
        if (cached.id) {
          console.warn("[Auth] Backend unreachable — using cached session:", lastErr?.message);
          setUser(cached);
        } else {
          localStorage.removeItem("tm_token");
        }
      }
    } finally {
      clearTimeout(loadingGuard);
      if (loadRunRef.current === runId) setLoading(false);
    }
  }, [resetTimers]);

  useEffect(() => { load(); }, [load]);

  useEffect(() => {
    const onAuthInvalid = () => logout();
    window.addEventListener("tm_auth_invalid", onAuthInvalid);
    return () => window.removeEventListener("tm_auth_invalid", onAuthInvalid);
  }, [logout]);

  // ── Network change listeners — keep user on current page when offline ─────
  useEffect(() => {
    const onOffline = () => enterOfflineMode();
    const onOnline  = () => exitOfflineMode();
    window.addEventListener("offline", onOffline);
    window.addEventListener("online",  onOnline);
    return () => {
      window.removeEventListener("offline", onOffline);
      window.removeEventListener("online",  onOnline);
    };
  }, [enterOfflineMode, exitOfflineMode]);

  // Cleanup on unmount
  useEffect(() => () => {
    clearTimeout(logoutTimer.current);
    clearTimeout(warnTimer.current);
    clearInterval(countRef.current);
  }, []);

  const login = async (emailOrUsername, password) => {
    const { access_token } = await authApi.login({ email: emailOrUsername, password });
    localStorage.setItem("tm_token", access_token);
    const u = await authApi.me();
    cacheUser(u);
    setUser(u);
    resetTimers();
    schedulePrecompute();
    offlineModeRef.current = false;
    setIsOfflineMode(false);
    // Background prefetch right after login
    setTimeout(() => prefetchAll(), 100);
    sessionStorage.removeItem("tm_page");
    window.dispatchEvent(new CustomEvent("navigate", { detail: "dashboard" }));
  };

  const register = async (data) => {
    const result = await authApi.register(data);
    if (result?.access_token) {
      localStorage.setItem("tm_token", result.access_token);
      const u = await authApi.me();
      setUser(u);
      schedulePrecompute();
    } else {
      // Registration returned an unexpected response — don't silently attempt login
      // as that would surface a misleading "Invalid credentials" error.
      throw new Error("Registration failed: unexpected server response");
    }
    resetTimers();
    sessionStorage.removeItem("tm_page");
    window.dispatchEvent(new CustomEvent("navigate", { detail: "dashboard" }));
  };

  const stayLoggedIn = () => {
    setShowWarning(false);
    resetTimers();
  };

  return (
    <Ctx.Provider value={{ user, setUser, loading, login, register, logout, reload: load, resetTimers, isOfflineMode }}>
      {children}

      {/* Inactivity warning modal */}
      {showWarning && user && (
        <div style={{
          position:"fixed", inset:0, zIndex:99999,
          background:"rgba(0,0,0,0.75)",
          backdropFilter:"blur(8px)",
          display:"flex", alignItems:"center", justifyContent:"center",
          padding:20,
        }}>
          <div style={{
            background:"#120C28",
            border:"1px solid rgba(144,96,240,0.4)",
            borderRadius:18, padding:"32px 28px",
            width:"100%", maxWidth:380,
            textAlign:"center",
            boxShadow:"0 32px 80px rgba(0,0,0,0.6), 0 0 0 1px rgba(144,96,240,0.15)",
            animation:"pop .35s cubic-bezier(.16,.84,.44,1) both",
          }}>
            {/* Top accent line */}
            <div style={{
              position:"absolute", top:0, left:"10%", right:"10%", height:1.5,
              borderRadius:"18px 18px 0 0",
              background:"linear-gradient(90deg,transparent,#9060F0,#C8A0FF,transparent)",
            }}/>

            {/* Icon */}
            <div style={{
              width:60, height:60, borderRadius:16,
              background:"rgba(144,96,240,0.12)",
              border:"1px solid rgba(144,96,240,0.3)",
              display:"flex", alignItems:"center", justifyContent:"center",
              fontSize:28, margin:"0 auto 18px",
            }}>⏱️</div>

            <div style={{
              fontSize:18, fontWeight:800, color:"#F5F0FF",
              marginBottom:8, letterSpacing:"-.01em",
            }}>Still there?</div>

            <div style={{
              fontSize:13, color:"rgba(144,96,240,0.8)",
              marginBottom:6, lineHeight:1.6,
            }}>
              You'll be logged out due to inactivity in
            </div>

            {/* Countdown */}
            <div style={{
              fontSize:42, fontWeight:800,
              background:"linear-gradient(135deg,#9060F0,#C8A0FF)",
              WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent",
              backgroundClip:"text",
              marginBottom:22, letterSpacing:"-.02em",
              fontFamily:"'Space Mono',monospace",
            }}>
              {Math.floor(countdown/60)}:{String(countdown%60).padStart(2,"0")}
            </div>

            {/* Buttons */}
            <div style={{display:"flex", gap:10}}>
              <button onClick={logout} style={{
                flex:1, padding:"11px", borderRadius:10,
                border:"1px solid rgba(239,68,68,0.3)",
                background:"rgba(239,68,68,0.08)",
                color:"#EF4444", fontSize:13, fontWeight:700,
                cursor:"pointer", fontFamily:"inherit",
                letterSpacing:".04em",
              }}>Sign Out</button>
              <button onClick={stayLoggedIn} style={{
                flex:2, padding:"11px", borderRadius:10,
                border:"none",
                background:"linear-gradient(135deg,#9060F0,#6A3EC8)",
                color:"#fff", fontSize:13, fontWeight:800,
                cursor:"pointer", fontFamily:"inherit",
                letterSpacing:".04em",
                boxShadow:"0 4px 20px rgba(144,96,240,0.4)",
              }}>Stay Logged In</button>
            </div>
          </div>
        </div>
      )}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);

