import { useEffect } from "react";
import { globalCSS } from "../styles/theme";

export function useGlobalStyles() {
  useEffect(() => {
    const id = "tm-global";
    if (document.getElementById(id)) return;
    const el = document.createElement("style");
    el.id = id;
    el.textContent = globalCSS;
    document.head.appendChild(el);
    return () => { document.getElementById(id)?.remove(); };
  }, []);
}
