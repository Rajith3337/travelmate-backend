import { useState, useEffect, useCallback } from "react";
import { getQueue, clearQueueItem } from "../utils/offline";

export function useOnlineStatus() {
  const [online, setOnline] = useState(navigator.onLine);
  useEffect(() => {
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => { window.removeEventListener("online", on); window.removeEventListener("offline", off); };
  }, []);
  return online;
}

export function useOfflineSync() {
  const online = useOnlineStatus();
  const [syncing, setSyncing] = useState(false);
  const [pendingCount, setPendingCount] = useState(0);

  const checkQueue = useCallback(async () => {
    const q = await getQueue();
    setPendingCount(q.length);
  }, []);

  const sync = useCallback(async () => {
    if (!online) return;
    setSyncing(true);
    const queue = await getQueue();
    for (const item of queue) {
      try {
        await fetch(item.url, { method: item.method, headers: { "Content-Type": "application/json", Authorization: `Bearer ${localStorage.getItem("tm_token")}` }, body: item.body ? JSON.stringify(item.body) : undefined });
        await clearQueueItem(item.id);
      } catch (e) { break; }
    }
    await checkQueue();
    setSyncing(false);
  }, [online]);

  useEffect(() => { checkQueue(); }, []);
  useEffect(() => {
    if (!online) return;
    const autoSyncRaw = localStorage.getItem("offline_auto_sync");
    const autoSync = autoSyncRaw == null ? true : ["1", "true", "yes", "on"].includes(String(autoSyncRaw).toLowerCase());
    if (autoSync) sync();
  }, [online, sync]);

  return { online, syncing, pendingCount, sync };
}
