import { useState, useEffect } from "react";

export default function useActiveTrip() {
  const [tripId, setTripId] = useState(localStorage.getItem("tm_active_trip") || "");

  useEffect(() => {
    const handler = (e) => setTripId(e.detail);
    window.addEventListener("tm_active_trip_change", handler);
    return () => window.removeEventListener("tm_active_trip_change", handler);
  }, []);

  const changeTrip = (eOrVal) => {
    const val = typeof eOrVal === "object" && eOrVal !== null && eOrVal.target ? eOrVal.target.value : eOrVal;
    localStorage.setItem("tm_active_trip", val);
    setTripId(val);
    window.dispatchEvent(new CustomEvent("tm_active_trip_change", { detail: val }));
  };

  // Provide a silent setter that doesn't trigger global sync, for initial mounts where we want to avoid infinite loops,
  // or return [tripId, changeTrip, changeTrip] so it can be used identically to setState
  return [tripId, changeTrip];
}
