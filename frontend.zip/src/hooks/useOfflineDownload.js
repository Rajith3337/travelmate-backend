// useOfflineDownload - manages downloading map tiles and translations for offline use
import { useState, useCallback, useEffect } from "react";
import {
  isNativePlatform,
  cacheTileFromUrl,
  cacheGet,
  cacheSet,
  cacheDelete,
  cacheClear,
  clearTileFiles,
} from "../utils/offline";

const OFFLINE_PHRASE_CATEGORY = "Offline Pack";

// Generate OSM tile URLs for a bounding box at given zoom levels
function tileUrlsForBbox(minLat, minLng, maxLat, maxLng, minZoom = 8, maxZoom = 13) {
  const urls = [];
  const BASE = "https://tile.openstreetmap.org";

  function latToTileY(lat, z) {
    const latR = (lat * Math.PI) / 180;
    return Math.floor(((1 - Math.log(Math.tan(latR) + 1 / Math.cos(latR)) / Math.PI) / 2) * Math.pow(2, z));
  }
  function lngToTileX(lng, z) {
    return Math.floor(((lng + 180) / 360) * Math.pow(2, z));
  }

  for (let z = minZoom; z <= maxZoom; z++) {
    const x0 = lngToTileX(minLng, z), x1 = lngToTileX(maxLng, z);
    const y0 = latToTileY(maxLat, z), y1 = latToTileY(minLat, z); // y0 < y1 (north = lower y)
    for (let x = x0; x <= x1; x++) {
      for (let y = y0; y <= y1; y++) {
        urls.push(`${BASE}/${z}/${x}/${y}.png`);
        if (urls.length > 2000) return urls; // safety cap
      }
    }
  }
  return urls;
}

export function useOfflineDownload() {
  const [tileProgress, setTileProgress] = useState(null); // { done, total, active }
  const [transProgress, setTransProgress] = useState(null); // { done, total, active, lang }
  const [tripProgress, setTripProgress] = useState(null); // { done, total, active }
  const [bundleProgress, setBundleProgress] = useState(null); // { done, total, active, tripName }
  const [cachedRoutes, setCachedRoutes] = useState([]);
  const [cachedLangs, setCachedLangs] = useState([]);
  const [cachedTrips, setCachedTrips] = useState([]);

  useEffect(() => {
    const handler = () => {
      setCachedRoutes([]);
      setCachedLangs([]);
      setCachedTrips([]);
      localStorage.removeItem("tm_cached_routes");
      localStorage.removeItem("tm_cached_langs");
      localStorage.removeItem("tm_cached_trips");
    };
    window.addEventListener("tm_offline_storage_cleared", handler);
    return () => window.removeEventListener("tm_offline_storage_cleared", handler);
  }, []);

  const isNative = isNativePlatform();
  const INDEX_KEYS = {
    routes: "offline_routes_index",
    langs: "offline_langs_index",
    trips: "offline_trips_index",
  };

  useEffect(() => {
    let cancelled = false;
    (async () => {
      if (isNative) {
        const [r, l, t] = await Promise.all([
          cacheGet(INDEX_KEYS.routes),
          cacheGet(INDEX_KEYS.langs),
          cacheGet(INDEX_KEYS.trips),
        ]);
        if (!cancelled) {
          setCachedRoutes(Array.isArray(r) ? r : []);
          setCachedLangs(Array.isArray(l) ? l : []);
          setCachedTrips(Array.isArray(t) ? t : []);
        }
        return;
      }
      try {
        setCachedRoutes(JSON.parse(localStorage.getItem("tm_cached_routes") || "[]"));
      } catch {}
      try {
        setCachedLangs(JSON.parse(localStorage.getItem("tm_cached_langs") || "[]"));
      } catch {}
      try {
        setCachedTrips(JSON.parse(localStorage.getItem("tm_cached_trips") || "[]"));
      } catch {}
    })();
    return () => { cancelled = true; };
  }, [isNative]);

  function coordsToBbox(coords = []) {
    let minLat = 90, maxLat = -90, minLng = 180, maxLng = -180;
    coords.forEach(([lat, lng]) => {
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
      minLat = Math.min(minLat, lat);
      maxLat = Math.max(maxLat, lat);
      minLng = Math.min(minLng, lng);
      maxLng = Math.max(maxLng, lng);
    });
    if (minLat > maxLat || minLng > maxLng) return null;
    return { minLat, maxLat, minLng, maxLng };
  }

  // Download map tiles for a route/area bounding box (native only)
  const downloadRouteTiles = useCallback(async ({ label, minLat, minLng, maxLat, maxLng, minZoom = 8, maxZoom = 13 }) => {
    if (!isNative) {
      alert("Offline downloads are available only in the app build.");
      return;
    }
    const tiles = tileUrlsForBbox(minLat, minLng, maxLat, maxLng, minZoom, maxZoom);
    setTileProgress({ done: 0, total: tiles.length, active: true, label });

    let okCount = 0;
    for (let i = 0; i < tiles.length; i++) {
      const ok = await cacheTileFromUrl(tiles[i]);
      if (ok) okCount += 1;
      setTileProgress(p => ({ ...p, done: i + 1, total: tiles.length }));
    }
    setTileProgress(p => ({ ...p, active: false, done: okCount, total: tiles.length }));
    const routes = [...cachedRoutes.filter(r => r.label !== label), { label, tiles: okCount, ts: Date.now() }];
    setCachedRoutes(routes);
    if (isNative) {
      await cacheSet(INDEX_KEYS.routes, routes);
    } else {
      localStorage.setItem("tm_cached_routes", JSON.stringify(routes));
    }
  }, [cachedRoutes, isNative]);

  // Download offline translations for a language + phrase set (native only)
  const downloadTranslations = useCallback(async (langCode, langName, phrases) => {
    if (!isNative) {
      alert("Offline downloads are available only in the app build.");
      return;
    }
    setTransProgress({ done: 0, total: phrases.length, active: true, lang: langName });
    const existing = (await cacheGet("translate_phrasebook")) || {};
    const out = { ...existing };
    for (let i = 0; i < phrases.length; i++) {
      const phrase = phrases[i];
      const key = `${OFFLINE_PHRASE_CATEGORY}||${langCode}||${phrase}`;
      if (!out[key]) {
        try {
          const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=en&tl=${langCode}&dt=t&q=${encodeURIComponent(phrase)}`;
          const r = await fetch(url);
          const d = await r.json();
          const translated = d?.[0]?.map(chunk => chunk[0] || "").join("").trim();
          out[key] = translated || "---";
        } catch {
          out[key] = "---";
        }
      }
      setTransProgress(p => ({ ...p, done: i + 1 }));
    }
    await cacheSet("translate_phrasebook", out);
    setTransProgress(p => ({ ...p, active: false }));
    const langs = [...cachedLangs.filter(l => l.code !== langCode), { code: langCode, name: langName, phrases: phrases.length, ts: Date.now() }];
    setCachedLangs(langs);
    if (isNative) {
      await cacheSet(INDEX_KEYS.langs, langs);
    } else {
      localStorage.setItem("tm_cached_langs", JSON.stringify(langs));
    }
  }, [cachedLangs, isNative]);

  // Download complete trip data for offline use (native only)
  const downloadTripData = useCallback(async (trip) => {
    if (!isNative) {
      alert("Offline downloads are available only in the app build.");
      return;
    }
    setTripProgress({ done: 0, total: 3, active: true, tripName: trip.name });

    try {
      const [places, itinerary, expenses] = await Promise.all([
        fetch(`/api/v1/trips/${trip.id}/places`).then(r => r.json()).catch(() => []),
        fetch(`/api/v1/trips/${trip.id}/itinerary`).then(r => r.json()).catch(() => []),
        fetch(`/api/v1/trips/${trip.id}/expenses`).then(r => r.json()).catch(() => []),
      ]);

      setTripProgress(p => ({ ...p, done: 1 }));

      try {
        await Promise.all([
          cacheSet(`trip_${trip.id}_places`, places),
          cacheSet(`trip_${trip.id}_itinerary`, itinerary),
          cacheSet(`trip_${trip.id}_expenses`, expenses),
          cacheSet(`trip_${trip.id}_meta`, {
            id: trip.id,
            name: trip.name,
            cover_emoji: trip.cover_emoji,
            destination: trip.destination,
            start_date: trip.start_date,
            end_date: trip.end_date,
            budget: trip.budget,
            active_route: trip.active_route || null,
            places_route: trip.places_route || null,
            preloaded_facilities: trip.preloaded_facilities || null,
          }),
        ]);
      } catch {}

      const trips = [...cachedTrips.filter(t => t.id !== trip.id), {
        id: trip.id,
        name: trip.name,
        emoji: trip.cover_emoji,
        places: Array.isArray(places) ? places.length : 0,
        ts: Date.now(),
      }];
      setCachedTrips(trips);
      if (isNative) {
        await cacheSet(INDEX_KEYS.trips, trips);
      } else {
        localStorage.setItem("tm_cached_trips", JSON.stringify(trips));
      }

      setTripProgress(p => ({ ...p, done: 3, active: false }));
    } catch (error) {
      console.error("Failed to download trip data:", error);
      setTripProgress(p => ({ ...p, active: false }));
      alert("Failed to download trip data. Please try again.");
    }
  }, [cachedTrips, isNative]);

  const downloadTripBundle = useCallback(async (trip, opts = {}) => {
    const silent = !!opts.silent;
    if (!isNative) {
      if (!silent) alert("Offline downloads are available only in the app build.");
      return false;
    }
    if (!trip) return false;
    setBundleProgress({ done: 0, total: 3, active: true, tripName: trip.name });
    try {
      const [places, itinerary, expenses] = await Promise.all([
        fetch(`/api/v1/trips/${trip.id}/places`).then(r => r.json()).catch(() => []),
        fetch(`/api/v1/trips/${trip.id}/itinerary`).then(r => r.json()).catch(() => []),
        fetch(`/api/v1/trips/${trip.id}/expenses`).then(r => r.json()).catch(() => []),
      ]);
      await Promise.all([
        cacheSet(`trip_${trip.id}_places`, places),
        cacheSet(`trip_${trip.id}_itinerary`, itinerary),
        cacheSet(`trip_${trip.id}_expenses`, expenses),
        cacheSet(`trip_${trip.id}_meta`, {
          id: trip.id,
          name: trip.name,
          cover_emoji: trip.cover_emoji,
          destination: trip.destination,
          start_date: trip.start_date,
          end_date: trip.end_date,
          budget: trip.budget,
          active_route: trip.active_route || null,
          places_route: trip.places_route || null,
          preloaded_facilities: trip.preloaded_facilities || null,
        }),
        cacheSet(`trip_${trip.id}_routes`, {
          active_route: trip.active_route || null,
          places_route: trip.places_route || null,
          savedAt: Date.now(),
        }),
      ]);
      setBundleProgress(p => ({ ...p, done: 1 }));

      const coords = [];
      try {
        if (trip.active_route) {
          const parsed = JSON.parse(trip.active_route);
          const routes = parsed?.routes || [];
          const sel = routes[parsed?.selectedIdx || 0] || routes[0];
          if (Array.isArray(sel?.coords)) coords.push(...sel.coords);
        }
      } catch {}
      try {
        if (trip.places_route) {
          const parsed = (() => { try { return typeof trip.places_route === 'string' ? JSON.parse(trip.places_route) : trip.places_route; } catch { return null; } })();
          if (Array.isArray(parsed?.coords)) coords.push(...parsed.coords);
        }
      } catch {}
      if (Array.isArray(places)) {
        places.forEach(p => {
          if (Number.isFinite(p.latitude) && Number.isFinite(p.longitude)) {
            coords.push([Number(p.latitude), Number(p.longitude)]);
          }
        });
      }

      let bbox = coordsToBbox(coords);
      if (!bbox && trip.destination) {
        try {
          const r = await fetch(`https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(trip.destination)}&format=json&limit=1`);
          const d = await r.json();
          if (d[0]) {
            const lat = parseFloat(d[0].lat);
            const lng = parseFloat(d[0].lon);
            bbox = { minLat: lat - 1.5, maxLat: lat + 1.5, minLng: lng - 1.5, maxLng: lng + 1.5 };
          }
        } catch {}
      }
      setBundleProgress(p => ({ ...p, done: 2 }));

      if (bbox) {
        const pad = 0.15;
        const minLat = bbox.minLat - pad;
        const maxLat = bbox.maxLat + pad;
        const minLng = bbox.minLng - pad;
        const maxLng = bbox.maxLng + pad;
        await downloadRouteTiles({
          label: `${trip.name} - Routes`,
          minLat, maxLat, minLng, maxLng,
          minZoom: 7,
          maxZoom: 12,
        });
      }
      setBundleProgress(p => ({ ...p, done: 3, active: false }));
      return true;
    } catch (e) {
      console.error("Failed to download trip bundle:", e);
      setBundleProgress(p => ({ ...p, active: false }));
      if (!silent) alert("Failed to save trip for offline use. Please try again.");
      return false;
    }
  }, [downloadRouteTiles, isNative]);

  const clearTileCache = useCallback(async () => {
    if (!isNative) return;
    await clearTileFiles();
    setCachedRoutes([]);
    if (isNative) {
      await cacheDelete(INDEX_KEYS.routes);
    } else {
      localStorage.removeItem("tm_cached_routes");
    }
  }, [isNative]);

  const clearTranslationCache = useCallback(async () => {
    if (!isNative) return;
    await cacheDelete("translate_phrasebook");
    setCachedLangs([]);
    if (isNative) {
      await cacheDelete(INDEX_KEYS.langs);
    } else {
      localStorage.removeItem("tm_cached_langs");
    }
  }, [isNative]);

  const clearTripCache = useCallback(async () => {
    if (!isNative) return;
    try {
      await Promise.all(
        cachedTrips.flatMap(t => ([
          cacheDelete(`trip_${t.id}_places`),
          cacheDelete(`trip_${t.id}_itinerary`),
          cacheDelete(`trip_${t.id}_expenses`),
          cacheDelete(`trip_${t.id}_meta`),
        ]))
      );
    } catch {}
    setCachedTrips([]);
    if (isNative) {
      await cacheDelete(INDEX_KEYS.trips);
    } else {
      localStorage.removeItem("tm_cached_trips");
    }
  }, [cachedTrips, isNative]);

  const clearAllOfflineCaches = useCallback(async () => {
    if (!isNative) return;
    await clearTileFiles();
    try { await cacheClear(); } catch {}
    setCachedRoutes([]);
    setCachedLangs([]);
    setCachedTrips([]);
    if (isNative) {
      await Promise.all([
        cacheDelete(INDEX_KEYS.routes),
        cacheDelete(INDEX_KEYS.langs),
        cacheDelete(INDEX_KEYS.trips),
      ]);
    } else {
      localStorage.removeItem("tm_cached_routes");
      localStorage.removeItem("tm_cached_langs");
      localStorage.removeItem("tm_cached_trips");
    }
  }, [isNative]);

  return {
    tileProgress, transProgress, tripProgress, bundleProgress,
    cachedRoutes, cachedLangs, cachedTrips,
    downloadRouteTiles, downloadTranslations, downloadTripData, downloadTripBundle,
    clearTileCache, clearTranslationCache, clearTripCache, clearAllOfflineCaches,
  };
}
