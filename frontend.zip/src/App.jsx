import { useContext, useState, useEffect, useRef, useCallback } from "react";
import { AuthContext } from "./context/AuthContext";
import { ThemeCtx, ThemeProvider } from "./context/ThemeContext";
import { buildCSS, DARK, LIGHT } from "./styles/theme";
import { lazy, Suspense } from "react";
import Sidebar from "./components/Sidebar";
import Notifications from "./components/Notifications";
import PullToRefresh from "./components/PullToRefresh";
import ErrorBoundary from "./components/ErrorBoundary";
import { Spinner } from "./components/UI";

const AuthPage = lazy(() => import("./pages/AuthPage"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const MyTrips = lazy(() => import("./pages/MyTrips"));
const LiveMap = lazy(() => import("./pages/LiveMap"));
const Planner = lazy(() => import("./pages/Planner"));
const Budget = lazy(() => import("./pages/Budget"));
const AIAssist = lazy(() => import("./pages/AIAssist"));
const Offline = lazy(() => import("./pages/Offline"));
const PackingList = lazy(() => import("./pages/PackingList"));
const WeatherWidget = lazy(() => import("./pages/WeatherWidget"));
const Currency = lazy(() => import("./pages/Currency"));
const FlightHotel = lazy(() => import("./pages/FlightHotel"));
const Profile = lazy(() => import("./pages/Profile"));
const Translate = lazy(() => import("./pages/Translate"));
const Notes = lazy(() => import("./pages/Notes"));
const StatsPage = lazy(() => import("./pages/StatsPage"));
import { useNotifCount } from "./components/Notifications";
import AutomationRunner from "./components/AutomationRunner";

const PAGE_MAP = {
  dashboard: Dashboard, trips: MyTrips, map: LiveMap,
  planner: Planner, budget: Budget,
  packing: PackingList, weather: WeatherWidget, currency: Currency,
  flights: FlightHotel, ai: AIAssist, offline: Offline,
  profile: Profile, translate: Translate,
  notes: Notes, stats: StatsPage,
};

// Inject/update CSS based on theme
function injectCSS(dark) {
  let s = document.getElementById("tm-global");
  if (!s) { s = document.createElement("style"); s.id = "tm-global"; document.head.appendChild(s); }
  s.textContent = buildCSS(dark);
}

// Background particles/effects
function AppBg({ dark }) {
  useEffect(() => {
    // Dynamic background effects disabled for better performance on APK/WebViews
  }, [dark]);

  if (!dark) return (
    <div className="app-bg">

      <div style={{position:"absolute",inset:0,pointerEvents:"none",
        background:"radial-gradient(ellipse 65% 55% at 15% 20%,rgba(168,208,248,0.22),transparent 55%),radial-gradient(ellipse 55% 55% at 85% 80%,rgba(168,208,248,0.16),transparent 55%)"
      }}/>
    </div>
  );

  return (
    <div className="app-bg">

      <div style={{position:"absolute",inset:0,pointerEvents:"none",
        background:"radial-gradient(ellipse 65% 55% at 15% 20%,rgba(144,96,240,0.10),transparent 55%),radial-gradient(ellipse 55% 55% at 85% 80%,rgba(80,48,168,0.07),transparent 55%)"
      }}/>
      <div style={{position:"absolute",inset:0,pointerEvents:"none",
        backgroundImage:"linear-gradient(rgba(144,96,240,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(144,96,240,0.04) 1px,transparent 1px)",
        backgroundSize:"60px 60px",
        maskImage:"radial-gradient(ellipse 85% 85% at 50% 50%,black 20%,transparent 100%)",
        WebkitMaskImage:"radial-gradient(ellipse 85% 85% at 50% 50%,black 20%,transparent 100%)"
      }}/>
    </div>
  );
}

function AppLoader({ dark }) {
  const t = dark ? DARK : LIGHT;
  return (
    <div style={{height:"100vh",display:"flex",alignItems:"center",justifyContent:"center",background:t.bg,position:"relative",overflow:"hidden"}}>
      <AppBg dark={dark}/>
      <div style={{
        position:"relative",
        zIndex:2,
        display:"flex",
        flexDirection:"column",
        alignItems:"center",
        gap:10,
        color:t.text,
      }}>
        <div style={{
          width:34,
          height:34,
          borderRadius:"50%",
          border:"3px solid rgba(144,96,240,0.2)",
          borderTopColor:"#9060F0",
          animation:"spin 0.9s linear infinite",
        }}/>
        <div style={{fontSize:13,color:t.textSub}}>Connecting to backend...</div>
        <style>{`
          @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
        `}</style>
      </div>
    </div>
  );
}

function ThemedApp() {
  const { user, loading } = useContext(AuthContext);
  const { dark, toggle }  = useContext(ThemeCtx);
  const [page, setPage]   = useState(sessionStorage.getItem("tm_page") || "dashboard");
  const [pageKey, setPageKey] = useState(0);
  const notifCount = useNotifCount();
  const t = dark ? DARK : LIGHT;
  const preloadedRef = useRef(false);

  // Inject CSS whenever theme changes
  useEffect(() => { injectCSS(dark); }, [dark]);

  // Warm-load non-critical tabs after login so navigation feels instant
  useEffect(() => {
    if (!user || preloadedRef.current) return;
    preloadedRef.current = true;
    const warm = () => {
      const loaders = [
        () => import("./pages/MyTrips"),
        () => import("./pages/LiveMap"),
        () => import("./pages/Planner"),
        () => import("./pages/Budget"),
        () => import("./pages/PackingList"),
        () => import("./pages/Notes"),
        () => import("./pages/StatsPage"),
        () => import("./pages/FlightHotel"),
        () => import("./pages/WeatherWidget"),
        () => import("./pages/Currency"),
        () => import("./pages/Translate"),
        () => import("./pages/Offline"),
        () => import("./pages/AIAssist"),
        () => import("./pages/Profile"),
      ];
      Promise.all(loaders.map(fn => fn().catch(() => {}))).catch(() => {});
    };
    if (typeof window !== "undefined" && "requestIdleCallback" in window) {
      window.requestIdleCallback(() => warm(), { timeout: 2000 });
    } else {
      setTimeout(warm, 1200);
    }
  }, [user]);

  // Use a ref so navigate never captures stale page state
  const pageRef = useRef(sessionStorage.getItem("tm_page") || "dashboard");
  const navigate = useCallback(p => {
    if (pageRef.current === p) return;
    pageRef.current = p;
    setPage(p);
    sessionStorage.setItem("tm_page", p);
    setPageKey(k => k + 1);
    setTimeout(() => {
      const el = document.querySelector(".app-scroll-area");
      if (el) el.scrollTop = 0;
    }, 10);
  }, []);

  // Sync ref when page state changes
  useEffect(() => { pageRef.current = page; }, [page]);

  // Global navigate event — stable listener, no stale closure
  useEffect(() => {
    const handler = e => navigate(e.detail);
    window.addEventListener("navigate", handler);
    return () => window.removeEventListener("navigate", handler);
  }, [navigate]);

  // Pages that stay mounted after first visit — mount lazily so Leaflet inits into visible DOM
  const PERSISTENT_PAGES = ["map", "planner", "ai"];
  const [visitedPersistent, setVisitedPersistent] = useState(new Set());
  useEffect(() => {
    if (PERSISTENT_PAGES.includes(page)) {
      setVisitedPersistent(prev => prev.has(page) ? prev : new Set([...prev, page]));
    }
  }, [page]);

  // Normalize unknown/removed pages (e.g. older sessionStorage values)
  useEffect(() => {
    if (page === "notifications") return;
    if (!PAGE_MAP[page]) navigate("dashboard");
  }, [page, navigate]);

  if (loading) return <AppLoader dark={dark}/>;
  if (!user)   return <Suspense fallback={<AppLoader dark={dark}/>}><AuthPage/></Suspense>;

  const PageComponent = PAGE_MAP[page] || Dashboard;

  return (
    <div style={{display:"flex",height:"100vh",background:t.bg,overflow:"hidden",position:"relative"}}>
      <AutomationRunner user={user} />
      <AppBg dark={dark}/>
      <div style={{position:"relative",zIndex:10,flexShrink:0}}>
        <Sidebar page={page} setPage={navigate} notifCount={notifCount} dark={dark} toggleTheme={toggle}/>
      </div>
      <main style={{flex:1,overflow:"hidden",position:"relative",zIndex:1,display:"flex",flexDirection:"column"}}>
        <PullToRefresh dark={dark} disabled={page === "map"} className="app-scroll-area" style={{flex:1,overflowY:"auto",padding:"24px 28px",paddingBottom:"max(80px, calc(env(safe-area-inset-bottom, 0px) + 80px))",WebkitOverflowScrolling:"touch"}}>
          <style>{`
            @media(max-width:767px){
              .app-scroll-area { padding: 12px 12px calc(80px + env(safe-area-inset-bottom,0px)) 12px !important; }
              main { overflow-x: hidden !important; }
            }
            @media(max-width:640px){
              .page-enter, .fade-up { overflow-x: hidden; max-width: 100%; }
              main { overflow-x: hidden !important; }
            }
          `}</style>

          {/* Persistent pages — mounted lazily on first visit, then kept alive hidden */}
          {PERSISTENT_PAGES.map(pid => {
            const Comp = PAGE_MAP[pid];
            if (!Comp || !visitedPersistent.has(pid)) return null;
            return (
              <div key={pid} style={{display: page === pid ? "block" : "none"}}>
                <ErrorBoundary dark={dark}>
                  <Suspense fallback={<div style={{display:"flex",justifyContent:"center",padding:"40px 0"}}><Spinner dark={dark}/></div>}>
                    <Comp dark={dark} active={page === pid}/>
                  </Suspense>
                </ErrorBoundary>
              </div>
            );
          })}

          {/* Normal pages — remounted on each visit */}
          {!PERSISTENT_PAGES.includes(page) && (
            <div key={pageKey} className="page-enter">
              <ErrorBoundary dark={dark}>
                {page === "notifications"
                  ? <Notifications dark={dark} onClose={() => navigate("dashboard")}/>
                  : <Suspense fallback={<div style={{display:"flex",justifyContent:"center",padding:"40px 0"}}><Spinner dark={dark}/></div>}>
                      <PageComponent dark={dark} active />
                    </Suspense>
                }
              </ErrorBoundary>
            </div>
          )}
        </PullToRefresh>
      </main>
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <ThemedApp/>
    </ThemeProvider>
  );
}
