import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { AuthProvider } from "./context/AuthContext";
import { ensureOfflineDir } from "./utils/offline";
import "./styles/mobile.css";

if (typeof window !== "undefined" && "serviceWorker" in navigator) {
  const isLocalDev = window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1";
  if (isLocalDev) {
    navigator.serviceWorker.getRegistrations().then(regs => {
      regs.forEach(r => r.unregister());
    }).catch(() => {});
  }
}

ensureOfflineDir().catch(() => {});

const rootNode = (
  <AuthProvider>
    <App />
  </AuthProvider>
);

ReactDOM.createRoot(document.getElementById("root")).render(
  import.meta.env.DEV ? rootNode : <React.StrictMode>{rootNode}</React.StrictMode>
);
