// ─── TravelMate API Client ─────────────────────────────────────────────────
import { cacheGet, cacheSet, cacheDelete } from "../utils/offline";

// Automatically use env variable
const BASE = import.meta.env.VITE_API_URL ? `${import.meta.env.VITE_API_URL}/api/v1` : "http://localhost:8000/api/v1";
// path -> { promise, cacheKey, gen }
const pendingGets = new Map();

// ─── BroadcastChannel for instant cross-tab sync ───────────────────────────
let _bc = null;
try { _bc = new BroadcastChannel("tm_sync"); } catch {}

function broadcastUpdate(type, tripId) {
  try { _bc?.postMessage({ type, tripId, ts: Date.now() }); } catch {}
}

if (_bc) {
  _bc.onmessage = (ev) => {
    const { type, tripId } = ev.data || {};
    try {
      // Ensure receiving tabs don't serve stale cached data
      invalidateCache(type, tripId);
      window.dispatchEvent(new CustomEvent("tm_data_updated", { detail: { type, tripId, fromBc: true } }));
      if (type === "trips") window.dispatchEvent(new Event("tm_trips_updated"));
    } catch {}
  };
}

function token() { return localStorage.getItem("tm_token"); }
function authHeaders(extra = {}) {
  const t = token();
  return t ? { Authorization: `Bearer ${t}`, ...extra } : { ...extra };
}

// In-memory fetch cache for instant reads (separate from offline IndexedDB cache)
const memCache = new Map(); // key -> { data, ts }
const MEM_TTL = 8000; // 8s — stale after mutations
const memGen = new Map(); // key -> generation counter (prevents stale in-flight overwrites)

function genGet(key) { return memGen.get(key) || 0; }
function genBump(key) { memGen.set(key, genGet(key) + 1); }

function memGet(key) {
  const e = memCache.get(key);
  if (!e) return null;
  if (Date.now() - e.ts > MEM_TTL) { memCache.delete(key); return null; }
  return e.data;
}
function memSet(key, data) { memCache.set(key, { data, ts: Date.now() }); }
function memDel(...keys) { keys.forEach(k => { if (k) memCache.delete(k); }); }

function cacheKeyForPath(path) {
  const clean = String(path || "").split("?")[0];
  if (clean === "/trips/") return "trip_list";
  const m = clean.match(/^\/trips\/(\d+)\/(places|itinerary|expenses|notes|checklist)\/?$/);
  if (m) return `trip_${m[1]}_${m[2]}`;
  const s = clean.match(/^\/trips\/(\d+)\/expenses\/summary\/?$/);
  if (s) return `trip_${s[1]}_expenses_summary`;
  const t = clean.match(/^\/trips\/(\d+)\/?$/);
  if (t) return `trip_${t[1]}_meta`;
  return null;
}

class ApiError extends Error {
  constructor(message, { status = 0, detail = null, data = null, retryAfter = null } = {}) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.detail = detail ?? message;
    this.data = data;
    this.retryAfter = retryAfter;
  }
}

async function req(method, path, body, isForm = false, timeout = 30000, cacheGen = null) {
  const isGet = method === "GET";
  const cacheKey = isGet ? cacheKeyForPath(path) : null;
  const genAtStart = (isGet && cacheKey) ? (cacheGen ?? genGet(cacheKey)) : null;

  // Instant in-memory cache hit (sub-ms, always fresh after mutations)
  if (isGet && cacheKey) {
    const mem = memGet(cacheKey);
    if (mem != null) return mem;
  }

  if (isGet && !navigator.onLine && cacheKey) {
    const cached = await cacheGet(cacheKey);
    if (cached != null) return cached;
    // No cache entry at all — return empty defaults per endpoint type so pages
    // don't hard-crash (trips → [], other → null).
    if (path.includes("/trips") && !path.match(/\/trips\/\d/)) return [];
    return null;
  }

  const opts = {
    method,
    headers: isForm ? authHeaders() : authHeaders({ "Content-Type": "application/json" }),
    signal: AbortSignal.timeout(timeout),
  };
  if (body) opts.body = isForm ? body : JSON.stringify(body);
  let res;
  try {
    res = await fetch(`${BASE}${path}`, opts);
  } catch (err) {
    if (err?.name === "TimeoutError" || err?.name === "AbortError") {
      throw new ApiError("Network timeout: backend took too long to respond", { status: 0 });
    }
    throw new ApiError("Network error: could not reach backend", { status: 0 });
  }
  if (res.status === 204) return null;
  const retryAfterHdr = res.headers?.get?.("Retry-After");
  const retryAfter = retryAfterHdr != null && retryAfterHdr !== ""
    ? Number.parseInt(String(retryAfterHdr), 10)
    : null;
  const retryAfterSec = Number.isFinite(retryAfter) ? retryAfter : null;
  let data = null;
  try {
    data = await res.json();
  } catch (err) {
    data = null;
  }
  if (!res.ok) {
    if (res.status === 401) {
      // Only treat as invalid auth if we're actually online.
      // A 401 while the device is offline can be a proxy/cache artefact — don't
      // log the user out in that case; AuthContext handles offline sessions.
      if (navigator.onLine) {
        localStorage.removeItem("tm_token");
        window.dispatchEvent(new Event("tm_auth_invalid"));
      }
    }
    throw new ApiError(data?.detail || `Request failed (${res.status})`, {
      status: res.status,
      detail: data?.detail || null,
      data,
      retryAfter: retryAfterSec,
    });
  }
  if (isGet && cacheKey && data != null) {
    // Don't let an in-flight stale request overwrite a freshly-invalidated cache key.
    if (genGet(cacheKey) === genAtStart) {
      memSet(cacheKey, data);
      cacheSet(cacheKey, data).catch(() => {});
    }
  }
  return data;
}

const get = p => {
  const cacheKey = cacheKeyForPath(p);
  const gen = cacheKey ? genGet(cacheKey) : null;
  const existing = pendingGets.get(p);
  if (existing) {
    if (existing.cacheKey === cacheKey && existing.gen === gen) return existing.promise;
    pendingGets.delete(p);
  }
  const inFlight = req("GET", p, null, false, 30000, gen);
  const entry = { promise: inFlight, cacheKey, gen };
  pendingGets.set(p, entry);
  inFlight.finally(() => {
    const cur = pendingGets.get(p);
    if (cur?.promise === inFlight) pendingGets.delete(p);
  });
  return inFlight;
};
const post     = (p, b, t) => req("POST",   p, b, false, t || 30000);
const put      = (p, b, t) => req("PUT",    p, b, false, t || 30000);
const patch    = (p, b, t) => req("PATCH",  p, b, false, t || 30000);
const del      = p       => req("DELETE", p);
const postForm = (p, fd) => req("POST",   p, fd, true);

function emitDataUpdate(type, tripId) {
  try {
    window.dispatchEvent(new CustomEvent("tm_data_updated", { detail: { type, tripId } }));
    broadcastUpdate(type, tripId);
  } catch {}
}

function invalidateCacheKey(cacheKey, path) {
  if (cacheKey) {
    genBump(cacheKey);
    memDel(cacheKey);
    cacheDelete(cacheKey).catch(() => {});
  }
  if (path) pendingGets.delete(path);
}

// Invalidate mem cache keys for a given trip + type
function invalidateCache(type, tripId) {
  invalidateCacheKey("trip_list", "/trips/");
  if (tripId) {
    invalidateCacheKey(`trip_${tripId}_meta`, `/trips/${tripId}`);
    if (type === "places")    invalidateCacheKey(`trip_${tripId}_places`, `/trips/${tripId}/places/`);
    if (type === "itinerary") invalidateCacheKey(`trip_${tripId}_itinerary`, `/trips/${tripId}/itinerary/`);
    if (type === "expenses") {
      invalidateCacheKey(`trip_${tripId}_expenses`, `/trips/${tripId}/expenses/`);
      invalidateCacheKey(`trip_${tripId}_expenses_summary`, `/trips/${tripId}/expenses/summary`);
    }
    if (type === "checklist") invalidateCacheKey(`trip_${tripId}_checklist`, `/trips/${tripId}/checklist/`);
    if (type === "notes")     invalidateCacheKey(`trip_${tripId}_notes`, `/trips/${tripId}/notes/`);
  }
}

export const authApi = {
  register: b  => req("POST", "/auth/register", b, false, 60000),
  login:    b  => req("POST", "/auth/login",    b, false, 60000),
  me:       () => req("GET",  "/auth/me",  null, false, 60000),
  updateMe: b  => patch("/auth/me", b, 60000),
  ping:     () => req("GET",  "/health",   null, false, 10000).catch(() => null),
};

export const passwordApi = {
  change: b => post("/auth/me/password", b),
};

export const tripsApi = {
  list: () => get("/trips/"),
  get:    id        => get(`/trips/${id}`),
  create: async b   => {
    invalidateCache("trips", null);
    const r = await post("/trips/", b);
    window.dispatchEvent(new Event("tm_trips_updated"));
    emitDataUpdate("trips", r?.id ?? null);
    return r;
  },
  update: async (id, b) => {
    invalidateCache("trips", id);
    const r = await patch(`/trips/${id}`, b);
    window.dispatchEvent(new Event("tm_trips_updated"));
    emitDataUpdate("trips", id);
    return r;
  },
  delete: async id  => {
    invalidateCache("trips", id);
    const r = await del(`/trips/${id}`);
    window.dispatchEvent(new Event("tm_trips_updated"));
    emitDataUpdate("trips", id);
    return r;
  },
};

export const placesApi = {
  list:   tid        => get(`/trips/${tid}/places/`),
  create: async (tid, b)   => { invalidateCache("places", tid); const r = await post(`/trips/${tid}/places/`, b); emitDataUpdate("places", tid); return r; },
  update: async (tid,id,b) => { invalidateCache("places", tid); const r = await patch(`/trips/${tid}/places/${id}`, b); emitDataUpdate("places", tid); return r; },
  delete: async (tid, id)  => { invalidateCache("places", tid); const r = await del(`/trips/${tid}/places/${id}`); emitDataUpdate("places", tid); return r; },
  optimize: tid      => post(`/trips/${tid}/places/optimize`),
};

export const expensesApi = {
  list:    tid        => get(`/trips/${tid}/expenses/`),
  summary: tid        => get(`/trips/${tid}/expenses/summary`),
  create:  async (tid, b)   => { invalidateCache("expenses", tid); const r = await post(`/trips/${tid}/expenses/`, b); emitDataUpdate("expenses", tid); return r; },
  update:  async (tid,id,b) => { invalidateCache("expenses", tid); const r = await patch(`/trips/${tid}/expenses/${id}`, b); emitDataUpdate("expenses", tid); return r; },
  delete:  async (tid, id)  => { invalidateCache("expenses", tid); const r = await del(`/trips/${tid}/expenses/${id}`); emitDataUpdate("expenses", tid); return r; },
};

export const itineraryApi = {
  list:   tid        => get(`/trips/${tid}/itinerary/`),
  create: async (tid, b)   => { invalidateCache("itinerary", tid); const r = await post(`/trips/${tid}/itinerary/`, b); emitDataUpdate("itinerary", tid); return r; },
  update: async (tid,id,b) => { invalidateCache("itinerary", tid); const r = await patch(`/trips/${tid}/itinerary/${id}`, b); emitDataUpdate("itinerary", tid); return r; },
  delete: async (tid, id)  => { invalidateCache("itinerary", tid); const r = await del(`/trips/${tid}/itinerary/${id}`); emitDataUpdate("itinerary", tid); return r; },
};

export const notesApi = {
  list:   tid        => get(`/trips/${tid}/notes/`),
  create: async (tid, b)   => { invalidateCache("notes", tid); const r = await post(`/trips/${tid}/notes/`, b); emitDataUpdate("notes", tid); return r; },
  update: async (tid,id,b) => { invalidateCache("notes", tid); const r = await patch(`/trips/${tid}/notes/${id}`, b); emitDataUpdate("notes", tid); return r; },
  delete: async (tid, id)  => { invalidateCache("notes", tid); const r = await del(`/trips/${tid}/notes/${id}`); emitDataUpdate("notes", tid); return r; },
};

export const checklistApi = {
  list:      tid        => get(`/trips/${tid}/checklist/`),
  create:    async (tid, b)   => { invalidateCache("checklist", tid); const r = await post(`/trips/${tid}/checklist/`, b); emitDataUpdate("checklist", tid); return r; },
  update:    async (tid,id,b) => { invalidateCache("checklist", tid); const r = await patch(`/trips/${tid}/checklist/${id}`, b); emitDataUpdate("checklist", tid); return r; },
  delete:    async (tid, id)  => { invalidateCache("checklist", tid); const r = await del(`/trips/${tid}/checklist/${id}`); emitDataUpdate("checklist", tid); return r; },
  clearDone: async (tid)      => { invalidateCache("checklist", tid); const r = await del(`/trips/${tid}/checklist/`); emitDataUpdate("checklist", tid); return r; },
};

export const statsApi = {
  stats:    () => get("/stats"),
  activity: () => get("/activity"),
};

export const aiApi = {
  recommend:      (trip_id, query) => post("/ai/recommend", { trip_id, query }, 60000),
  travelInsights: async b          => {
    // Travel insights can hit provider rate limits; dedupe in-flight calls and retry once on 429.
    const key = JSON.stringify(b || {});
    aiApi._pendingTravelInsights = aiApi._pendingTravelInsights || new Map();
    const pending = aiApi._pendingTravelInsights.get(key);
    if (pending) return pending;

    const run = async () => {
      try {
        return await post("/ai/travel-insights", b, 60000);
      } catch (e) {
        const status = e?.status ?? null;
        const retryAfter = Number.isFinite(e?.retryAfter) ? e.retryAfter : null;
        const msg = String(e?.message || "");
        const isRateLimit = status === 429 || msg.includes("429") || msg.toLowerCase().includes("rate limited");
        if (!isRateLimit) throw e;
        const waitMs = (retryAfter != null ? retryAfter * 1000 : 5000);
        await new Promise(r => setTimeout(r, Math.max(0, waitMs)));
        return await post("/ai/travel-insights", b, 60000);
      }
    };

    const p = run().finally(() => {
      const cur = aiApi._pendingTravelInsights.get(key);
      if (cur === p) aiApi._pendingTravelInsights.delete(key);
    });
    aiApi._pendingTravelInsights.set(key, p);
    return p;
  },
  overpass:       query            => post("/ai/overpass", { query }),
  precomputeRoadmaps: ()           => post("/ai/roadmaps/precompute", {}),
  roadmapStatus: ()                => get("/ai/roadmaps/status"),
  getChat:        trip_id          => get(`/ai/chat/${trip_id}`),
  saveChat:       (trip_id, messages) => put(`/ai/chat/${trip_id}`, { messages }),
};
export const settingsApi = {
  get: key => get(`/settings/${encodeURIComponent(key)}`),
  put: (key, value_text) => req("PUT", `/settings/${encodeURIComponent(key)}`, { value_text }),
};

export const shareApi = {
  create: trip_id => post(`/share/trips/${trip_id}`),
  revoke: trip_id => del(`/share/trips/${trip_id}`),
  view:   token   => get(`/share/view/${token}`),
};
