﻿import { useEffect, useMemo, useState, useContext } from "react";
import { tripsApi, settingsApi } from "../api/client";
import OfflineDownloadPanel from "../components/OfflineDownloadPanel";
import { DARK, LIGHT } from "../styles/theme";
import useActiveTrip from "../hooks/useActiveTrip";
import { useOfflineSync } from "../hooks/useOfflineSync";
import { getQueue, clearQueueItem, getOfflineStorageInfo, clearOfflineStorage, isNativePlatform, ensureTripOfflineFolder, saveTripDataOffline, listOfflineTripFolders, loadAllOfflineTrips } from "../utils/offline";
import { AuthContext } from "../context/AuthContext";
const SAFETY_NUMBERS = [
  { label: "Ambulance", no: "108" },
  { label: "Police", no: "100" },
  { label: "Women", no: "1091" },
  { label: "Road Help", no: "1073" },
];

function toBool(v, fallback = false) {
  if (v == null || v === "") return fallback;
  if (typeof v === "boolean") return v;
  const s = String(v).trim().toLowerCase();
  return s === "1" || s === "true" || s === "yes" || s === "on";
}

function fromBool(v) {
  return v ? "true" : "false";
}

function fmtBytes(n) {
  if (!Number.isFinite(n) || n <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB"];
  let val = n;
  let idx = 0;
  while (val >= 1024 && idx < units.length - 1) {
    val /= 1024;
    idx += 1;
  }
  return `${val.toFixed(idx === 0 ? 0 : 1)} ${units[idx]}`;
}

function safePath(url) {
  try {
    return new URL(url).pathname;
  } catch {
    return url || "";
  }
}

export default function Offline({ dark = true }) {
  const t = dark ? DARK : LIGHT;
  const { isOfflineMode } = useContext(AuthContext);
  const [trips, setTrips] = useState([]);
  const [tripId, setTripId] = useActiveTrip();
  const { online, syncing, pendingCount, sync } = useOfflineSync();
  const [offlineLoadedTrips, setOfflineLoadedTrips] = useState([]);
  const [offlineDataLoaded, setOfflineDataLoaded] = useState(false);

  const [queue, setQueue] = useState([]);
  const [prefsLoading, setPrefsLoading] = useState(true);
  const [savingKey, setSavingKey] = useState("");
  const [prefs, setPrefs] = useState({
    auto_sync: true,
    wifi_only_downloads: true,
    auto_cache_translations: false,
  });

  const [storageInfo, setStorageInfo] = useState({ used: 0, quota: 0, location: "" });
  const [offlineFolders, setOfflineFolders] = useState([]);
  const [folderSaving, setFolderSaving] = useState("");
  const [folderMsg, setFolderMsg] = useState("");

  const cardStyle = {
    background: t.card,
    border: `1px solid ${t.border}`,
    borderRadius: 18,
    padding: 20,
    boxShadow: dark ? "0 2px 10px rgba(0,0,0,.3)" : "0 1px 5px rgba(0,0,0,.06)",
  };

  const storagePct = useMemo(() => {
    if (!storageInfo.quota) return 0;
    return Math.min(100, Math.round((storageInfo.used / storageInfo.quota) * 100));
  }, [storageInfo]);

  async function refreshQueue() {
    try {
      const q = await getQueue();
      q.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
      setQueue(q);
    } catch {
      setQueue([]);
    }
  }

  async function refreshStorage() {
    try {
      if (isNativePlatform()) {
        const info = await getOfflineStorageInfo();
        setStorageInfo(info);
        const folders = await listOfflineTripFolders();
        setOfflineFolders(folders);
        return;
      }
      if (navigator.storage?.estimate) {
        const est = await navigator.storage.estimate();
        setStorageInfo({ used: est.usage || 0, quota: est.quota || 0, location: "" });
      }
    } catch {}
  }

  // Load trips — from API when online, from local device storage when offline
  useEffect(() => {
    if (!online) {
      // Offline: load from TravelMateOffline/trips/*/data.json (or localStorage)
      loadAllOfflineTrips().then(localTrips => {
        const tripList = localTrips
          .map(d => d.trip)
          .filter(Boolean)
          .sort((a, b) => (b.id || 0) - (a.id || 0));
        setOfflineLoadedTrips(localTrips);
        setOfflineDataLoaded(true);
        if (tripList.length) {
          setTrips(tripList);
          if (!localStorage.getItem("tm_active_trip")) {
            setTripId(String(tripList[0].id));
            localStorage.setItem("tm_active_trip", String(tripList[0].id));
          }
        }
      }).catch(() => { setOfflineDataLoaded(true); });
      return;
    }
    tripsApi.list().then(d => {
      setTrips(d);
      if (!localStorage.getItem("tm_active_trip") && d.length) {
        setTripId(String(d[0].id));
        localStorage.setItem("tm_active_trip", String(d[0].id));
      }
    }).catch(() => {});
  }, [online, setTripId]);

  useEffect(() => {
    let stop = false;
    (async () => {
      setPrefsLoading(true);
      // Always use localStorage when offline (no backend available)
      if (!online) {
        if (!stop) {
          setPrefs({
            auto_sync: toBool(localStorage.getItem("offline_auto_sync"), true),
            wifi_only_downloads: toBool(localStorage.getItem("offline_wifi_only_downloads"), true),
            auto_cache_translations: toBool(localStorage.getItem("offline_auto_cache_translations"), false),
          });
          setPrefsLoading(false);
        }
        return;
      }
      try {
        const [a, w, tr] = await Promise.all([
          settingsApi.get("offline_auto_sync"),
          settingsApi.get("offline_wifi_only_downloads"),
          settingsApi.get("offline_auto_cache_translations"),
        ]);
        if (!stop) {
          setPrefs({
            auto_sync: toBool(a?.value_text, true),
            wifi_only_downloads: toBool(w?.value_text, true),
            auto_cache_translations: toBool(tr?.value_text, false),
          });
        }
      } catch {
        if (!stop) {
          setPrefs({
            auto_sync: toBool(localStorage.getItem("offline_auto_sync"), true),
            wifi_only_downloads: toBool(localStorage.getItem("offline_wifi_only_downloads"), true),
            auto_cache_translations: toBool(localStorage.getItem("offline_auto_cache_translations"), false),
          });
        }
      } finally {
        if (!stop) setPrefsLoading(false);
      }
    })();
    return () => { stop = true; };
  }, [online]);

  useEffect(() => {
    refreshQueue();
    refreshStorage();
    const intervalMs = isNativePlatform() ? 15000 : 5000;
    const id = setInterval(() => {
      refreshQueue();
      refreshStorage();
    }, intervalMs);
    return () => clearInterval(id);
  }, []);

  async function savePref(key, val) {
    setPrefs(prev => ({ ...prev, [key]: val }));
    localStorage.setItem(key === "auto_sync" ? "offline_auto_sync" : key === "wifi_only_downloads" ? "offline_wifi_only_downloads" : "offline_auto_cache_translations", fromBool(val));

    const apiKey =
      key === "auto_sync"
        ? "offline_auto_sync"
        : key === "wifi_only_downloads"
          ? "offline_wifi_only_downloads"
          : "offline_auto_cache_translations";

    setSavingKey(key);
    try {
      await settingsApi.put(apiKey, fromBool(val));
    } catch {
      // Keep local preference even if backend is unreachable.
    } finally {
      setSavingKey("");
    }
  }

  async function runManualSync() {
    await sync();
    await refreshQueue();
  }

  async function clearAllQueued() {
    const q = await getQueue();
    await Promise.all(q.map(item => clearQueueItem(item.id)));
    await refreshQueue();
  }

  async function clearOfflineFiles() {
    await clearOfflineStorage();
    localStorage.removeItem("tm_cached_routes");
    localStorage.removeItem("tm_cached_langs");
    localStorage.removeItem("tm_cached_trips");
    window.dispatchEvent(new Event("tm_offline_storage_cleared"));
    await refreshStorage();
  }

  async function saveSelectedTripOffline() {
    const trip = trips.find(tr => String(tr.id) === tripId);
    if (!trip) return;
    setFolderSaving(tripId);
    setFolderMsg("");
    try {
      if (isNativePlatform()) {
        // Create the folder first
        const folderPath = await ensureTripOfflineFolder(trip.id, trip.name);
        // Fetch and save trip data
        const [places, itinerary] = await Promise.all([
          fetch(`/api/v1/trips/${trip.id}/places`, { headers: { Authorization: `Bearer ${localStorage.getItem("tm_token")}` } }).then(r => r.json()).catch(() => []),
          fetch(`/api/v1/trips/${trip.id}/itinerary`, { headers: { Authorization: `Bearer ${localStorage.getItem("tm_token")}` } }).then(r => r.json()).catch(() => []),
        ]);
        await saveTripDataOffline(trip.id, trip.name, { trip, places, itinerary });
        setFolderMsg(`✅ Saved to device: ${folderPath || "Documents/TravelMateOffline/trips/"}`);
      } else {
        // Web: save to localStorage + optionally File System Access API
        const data = { trip, savedAt: new Date().toISOString() };
        localStorage.setItem(`tm_offline_trip_${trip.id}`, JSON.stringify(data));
        // Try File System Access API for real folder creation
        if (window.showDirectoryPicker) {
          try {
            const dirHandle = await window.showDirectoryPicker({ mode: "readwrite" });
            const tripFolder = await dirHandle.getDirectoryHandle(`TravelMateOffline`, { create: true });
            const tripSubfolder = await tripFolder.getDirectoryHandle(`${trip.name}_${trip.id}`.replace(/[^a-zA-Z0-9_\- ]/g, ""), { create: true });
            const fileHandle = await tripSubfolder.getFileHandle("data.json", { create: true });
            const writable = await fileHandle.createWritable();
            await writable.write(JSON.stringify(data, null, 2));
            await writable.close();
            setFolderMsg(`✅ Saved folder on your device: TravelMateOffline/${trip.name}_${trip.id}/`);
          } catch (err) {
            if (err.name !== "AbortError") {
              // Fallback — localStorage saved above is sufficient
              setFolderMsg("✅ Saved to browser storage (folder creation unavailable)");
            }
          }
        } else {
          setFolderMsg("✅ Saved to browser offline storage");
        }
      }
      await refreshStorage();
    } catch (e) {
      setFolderMsg(`❌ Failed: ${e?.message || "Unknown error"}`);
    } finally {
      setFolderSaving("");
    }
  }

  const selectedTrip = trips.find(tr => String(tr.id) === tripId);

  // Compute offline trip data view — finds the active trip in localised store
  const activeTripOfflineData = useMemo(() => {
    if (!tripId || online) return null;
    return offlineLoadedTrips.find(d => String(d.trip?.id) === String(tripId)) || null;
  }, [tripId, offlineLoadedTrips, online]);

  return (
    <div className="fade-up">

      {/* ── Offline Mode Banner ─────────────────────────────────────────────── */}
      {!online && (
        <div style={{
          background: "linear-gradient(135deg,rgba(245,158,11,0.12),rgba(217,119,6,0.08))",
          border: "1px solid rgba(245,158,11,0.35)",
          borderRadius: 14, padding: "14px 18px", marginBottom: 18,
          display: "flex", alignItems: "flex-start", gap: 12,
        }}>
          <div style={{ fontSize: 24, lineHeight: 1, flexShrink: 0 }}>📡</div>
          <div>
            <div style={{ fontWeight: 800, color: "#FBBF24", fontSize: 14, marginBottom: 3 }}>
              You are offline
            </div>
            <div style={{ color: t.textSub, fontSize: 12, lineHeight: 1.6 }}>
              Showing locally stored data from{" "}
              <span style={{ color: t.accent, fontWeight: 700 }}>Documents/TravelMateOffline</span>.
              {offlineLoadedTrips.length > 0
                ? ` ${offlineLoadedTrips.length} trip${offlineLoadedTrips.length > 1 ? "s" : ""} available offline.`
                : " No trips saved offline yet — save one when you're back online."}
            </div>
          </div>
        </div>
      )}

      {/* ── Offline Trip Data Viewer (shows when offline) ─────────────────────── */}
      {!online && offlineDataLoaded && offlineLoadedTrips.length > 0 && activeTripOfflineData && (
        <div style={{ ...cardStyle, marginBottom: 16 }}>
          <div style={{ fontWeight: 800, color: t.text, fontSize: 15, marginBottom: 2 }}>
            📂 {activeTripOfflineData.trip?.name || "Offline Trip"} — Saved Data
          </div>
          <div style={{ fontSize: 11, color: t.textSub, marginBottom: 12 }}>
            Saved {activeTripOfflineData.savedAt ? new Date(activeTripOfflineData.savedAt).toLocaleString() : "locally"}
          </div>

          {/* Trip details */}
          {activeTripOfflineData.trip && (
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 12 }}>
              {[
                { label: "Destination", value: activeTripOfflineData.trip.destination },
                { label: "Start", value: activeTripOfflineData.trip.start_location },
                { label: "Dates", value: [activeTripOfflineData.trip.start_date, activeTripOfflineData.trip.end_date].filter(Boolean).join(" → ") },
                { label: "Budget", value: activeTripOfflineData.trip.budget ? `${activeTripOfflineData.trip.currency || ""}${activeTripOfflineData.trip.budget}` : null },
              ].filter(x => x.value).map(({ label, value }) => (
                <div key={label} style={{
                  background: t.surface, borderRadius: 8, padding: "5px 10px",
                  fontSize: 11, color: t.textSub,
                }}>
                  <span style={{ color: t.textDim, fontWeight: 600 }}>{label}: </span>
                  <span style={{ color: t.text }}>{value}</span>
                </div>
              ))}
            </div>
          )}

          {/* Places */}
          {Array.isArray(activeTripOfflineData.places) && activeTripOfflineData.places.length > 0 && (
            <div style={{ marginBottom: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: t.textSub, marginBottom: 6 }}>
                📍 Places ({activeTripOfflineData.places.length})
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 5, maxHeight: 180, overflowY: "auto" }}>
                {activeTripOfflineData.places.slice(0, 30).map((p, i) => (
                  <div key={p.id || i} style={{
                    display: "flex", alignItems: "center", gap: 8,
                    background: t.surface, borderRadius: 7, padding: "5px 10px", fontSize: 12,
                  }}>
                    <span style={{ fontSize: 14 }}>
                      {p.status === "visited" ? "✅" : p.status === "upcoming" ? "🔜" : "📍"}
                    </span>
                    <span style={{ color: t.text, fontWeight: 600, flex: 1 }}>{p.name || "Place"}</span>
                    {p.place_type && <span style={{ color: t.textDim, fontSize: 10 }}>{p.place_type}</span>}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Itinerary */}
          {Array.isArray(activeTripOfflineData.itinerary) && activeTripOfflineData.itinerary.length > 0 && (
            <div>
              <div style={{ fontSize: 12, fontWeight: 700, color: t.textSub, marginBottom: 6 }}>
                🗓️ Itinerary ({activeTripOfflineData.itinerary.length} items)
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 5, maxHeight: 150, overflowY: "auto" }}>
                {activeTripOfflineData.itinerary.slice(0, 20).map((item, i) => (
                  <div key={item.id || i} style={{
                    background: t.surface, borderRadius: 7, padding: "5px 10px", fontSize: 12,
                    color: t.text,
                  }}>
                    <span style={{ color: t.accent, fontWeight: 700, marginRight: 6 }}>Day {item.day || "?"}</span>
                    {item.title || item.description || "Itinerary item"}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {!online && offlineDataLoaded && offlineLoadedTrips.length === 0 && (
        <div style={{ ...cardStyle, marginBottom: 16, textAlign: "center", padding: 28 }}>
          <div style={{ fontSize: 36, marginBottom: 10 }}>📥</div>
          <div style={{ fontWeight: 700, color: t.text, fontSize: 14, marginBottom: 6 }}>No offline data found</div>
          <div style={{ color: t.textSub, fontSize: 12 }}>
            Go online and save a trip from the "Trip Offline Folder" section below to access it here.
          </div>
        </div>
      )}

      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 22, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0 }}>
            Offline Center
          </h1>
          <p style={{ color: t.textSub, fontSize: 13, marginTop: 4 }}>
            Download maps and packs, manage queued changes, and track storage.
          </p>
        </div>
        <select
          value={tripId}
          onChange={e => setTripId(e.target.value)}
          style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 11, padding: "9px 14px", color: t.text, fontSize: 13, fontFamily: "inherit", outline: "none", cursor: "pointer" }}
        >
          <option value="">Select trip...</option>
          {trips.map(tr => (
            <option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name}</option>
          ))}
        </select>
      </div>

      <div style={{ ...cardStyle, marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
          <div>
            <div style={{ fontWeight: 800, color: t.text, fontSize: 15, marginBottom: 4 }}>Connection & Sync</div>
            <div style={{ color: t.textSub, fontSize: 12 }}>
              {online ? "🟢 Online" : "🔴 Offline"} · {syncing ? "Syncing queue..." : `${pendingCount} queued`}
            </div>
          </div>
          <button
            onClick={runManualSync}
            disabled={!online || syncing}
            style={{ padding: "8px 14px", borderRadius: 9, border: "none", background: (!online || syncing) ? t.surface : `linear-gradient(135deg,${t.accent},${t.accentDeep})`, color: (!online || syncing) ? t.textSub : "#fff", cursor: (!online || syncing) ? "not-allowed" : "pointer", fontFamily: "inherit", fontSize: 12, fontWeight: 700 }}
          >
            {syncing ? "Syncing..." : "Sync Queue"}
          </button>
        </div>
      </div>

      {/* ── Trip Offline Folder ── */}
      <div style={{ ...cardStyle, marginBottom: 16 }}>
        <div style={{ fontWeight: 800, color: t.text, fontSize: 15, marginBottom: 4 }}>📁 Trip Offline Folder</div>
        <div style={{ fontSize: 12, color: t.textSub, marginBottom: 12, lineHeight: 1.6 }}>
          Save a trip as a local folder on your device. On Android/iOS this creates <code style={{ fontSize: 11, background: t.surface, padding: "1px 5px", borderRadius: 4, color: t.accent }}>Documents/TravelMateOffline/trips/</code>. On web it lets you choose a folder.
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <button
            onClick={saveSelectedTripOffline}
            disabled={!tripId || folderSaving === tripId}
            style={{
              padding: "9px 16px", borderRadius: 9, border: "none", fontFamily: "inherit", fontSize: 12, fontWeight: 700, cursor: !tripId ? "not-allowed" : "pointer",
              background: tripId ? `linear-gradient(135deg,${t.accent},${t.accentDeep})` : t.surface,
              color: tripId ? "#fff" : t.textSub,
              display: "flex", alignItems: "center", gap: 8,
            }}
          >
            {folderSaving === tripId ? (
              <><span style={{ width: 12, height: 12, border: "2px solid rgba(255,255,255,0.3)", borderTopColor: "#fff", borderRadius: "50%", display: "inline-block", animation: "spin .7s linear infinite" }} /> Saving…</>
            ) : (
              <>📥 Save "{selectedTrip?.name || "selected trip"}" Offline</>
            )}
          </button>
          {folderMsg && (
            <div style={{ fontSize: 12, color: folderMsg.startsWith("✅") ? "#34D399" : "#F87171", fontWeight: 600 }}>
              {folderMsg}
            </div>
          )}
        </div>

        {/* Show existing offline folders */}
        {isNativePlatform() && offlineFolders.length > 0 && (
          <div style={{ marginTop: 14 }}>
            <div style={{ fontSize: 11, fontWeight: 700, color: t.textSub, textTransform: "uppercase", letterSpacing: ".05em", marginBottom: 8 }}>Saved Offline Trips</div>
            <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
              {offlineFolders.map((f, i) => (
                <div key={i} style={{ display: "flex", alignItems: "center", gap: 10, background: t.surface, border: `1px solid ${t.border}`, borderRadius: 9, padding: "8px 12px" }}>
                  <span style={{ fontSize: 16 }}>📂</span>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: t.text, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{f.tripName}</div>
                    <div style={{ fontSize: 10, color: t.textDim }}>Saved {f.savedAt ? new Date(f.savedAt).toLocaleDateString() : "—"}</div>
                  </div>
                  <span style={{ fontSize: 10, color: "#34D399", fontWeight: 700, background: "#34D39915", border: "1px solid #34D39933", borderRadius: 99, padding: "2px 7px" }}>On Device</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <div style={{ ...cardStyle, marginBottom: 16 }}>
        <div style={{ fontWeight: 800, color: t.text, fontSize: 15, marginBottom: 10 }}>Emergency Numbers</div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          {SAFETY_NUMBERS.map(n => (
            <a
              key={n.no}
              href={`tel:${n.no}`}
              style={{ fontSize: 11, textDecoration: "none", color: "#FCA5A5", background: "#F43F5E1A", border: "1px solid #F43F5E40", borderRadius: 99, padding: "5px 10px", fontWeight: 700 }}
            >
              {n.label} - {n.no}
            </a>
          ))}
        </div>
      </div>

      <div style={{ ...cardStyle, marginBottom: 16 }}>
        <div style={{ fontWeight: 800, color: t.text, fontSize: 15, marginBottom: 10 }}>Offline Settings</div>
        {prefsLoading ? (
          <div style={{ color: t.textSub, fontSize: 12 }}>Loading preferences...</div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 10 }}>
            {[
              { key: "auto_sync", title: "Auto-sync when online" },
              { key: "wifi_only_downloads", title: "Wi-Fi only downloads" },
              { key: "auto_cache_translations", title: "Auto-save phrase packs" },
            ].map(item => (
              <label key={item.key} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, border: `1px solid ${t.border}`, borderRadius: 10, padding: "10px 12px", background: t.surface, fontSize: 12, color: t.text }}>
                <span>{item.title}</span>
                <input
                  type="checkbox"
                  checked={!!prefs[item.key]}
                  onChange={e => savePref(item.key, e.target.checked)}
                  disabled={savingKey === item.key}
                />
              </label>
            ))}
          </div>
        )}
      </div>

      <div style={{ ...cardStyle, marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10, gap: 8, flexWrap: "wrap" }}>
          <div style={{ fontWeight: 800, color: t.text, fontSize: 15 }}>Queued Changes ({queue.length})</div>
          <button
            onClick={clearAllQueued}
            disabled={!queue.length}
            style={{ padding: "6px 12px", borderRadius: 8, border: `1px solid ${t.red}44`, background: queue.length ? `${t.red}12` : t.surface, color: queue.length ? t.red : t.textSub, cursor: queue.length ? "pointer" : "not-allowed", fontFamily: "inherit", fontSize: 11, fontWeight: 700 }}
          >
            Clear Queue
          </button>
        </div>
        {queue.length === 0 ? (
          <div style={{ color: t.textSub, fontSize: 12 }}>No pending actions.</div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 6, maxHeight: 220, overflowY: "auto" }}>
            {queue.map(item => (
              <div key={item.id} style={{ display: "grid", gridTemplateColumns: "78px 1fr auto", gap: 8, alignItems: "center", border: `1px solid ${t.border}`, borderRadius: 9, background: t.surface, padding: "8px 10px" }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: t.accent }}>{(item.method || "POST").toUpperCase()}</div>
                <div style={{ fontSize: 11, color: t.textSub, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{safePath(item.url)}</div>
                <button
                  onClick={async () => { await clearQueueItem(item.id); refreshQueue(); }}
                  style={{ fontSize: 10, border: `1px solid ${t.border}`, borderRadius: 7, padding: "3px 8px", background: "transparent", color: t.textSub, cursor: "pointer", fontFamily: "inherit" }}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <div style={{ ...cardStyle, marginBottom: 16 }}>
        <div style={{ fontWeight: 800, color: t.text, fontSize: 15, marginBottom: 10 }}>Device Storage</div>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: t.textSub, marginBottom: 6, gap: 8, flexWrap: "wrap" }}>
          <span>Storage used</span>
          <span>
            {fmtBytes(storageInfo.used)}
            {storageInfo.quota ? ` / ${fmtBytes(storageInfo.quota)}` : ""}
          </span>
        </div>
        {storageInfo.location && (
          <div style={{ fontSize: 11, color: t.textDim, marginBottom: 8, fontFamily: "monospace", background: t.surface, border: `1px solid ${t.border}`, borderRadius: 6, padding: "4px 8px" }}>
            📂 {storageInfo.location}
          </div>
        )}
        <div style={{ height: 6, borderRadius: 99, background: t.border, overflow: "hidden", marginBottom: 10 }}>
          <div style={{ height: "100%", width: `${storagePct}%`, background: t.accent, borderRadius: 99, transition: "width .2s" }} />
        </div>
        {isNativePlatform() && (
          <button
            onClick={clearOfflineFiles}
            style={{ padding: "6px 12px", borderRadius: 8, border: `1px solid ${t.red}44`, background: `${t.red}12`, color: t.red, cursor: "pointer", fontFamily: "inherit", fontSize: 11, fontWeight: 700 }}
          >
            Clear Offline Files
          </button>
        )}
      </div>

      <div style={{ ...cardStyle, marginBottom: 16 }}>
        <div style={{ fontWeight: 800, color: t.text, fontSize: 15, marginBottom: 8 }}>Offline Downloads</div>
        <div style={{ fontSize: 12, color: t.textSub, marginBottom: 10 }}>
          Save full trips with routes + map tiles so you can open the map anytime without internet. Files are stored on the device.
        </div>
        <OfflineDownloadPanel t={t} trips={trips} />
      </div>

      <div style={cardStyle}>
        <div style={{ fontWeight: 800, color: t.text, fontSize: 15, marginBottom: 10 }}>How Offline Works</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8, color: t.textSub, fontSize: 12 }}>
          <div>📁 <strong style={{ color: t.text }}>Trip Folders:</strong> Each saved trip gets its own folder at <code style={{ fontSize: 11 }}>Documents/TravelMateOffline/trips/</code></div>
          <div>🔄 <strong style={{ color: t.text }}>Auto Sync:</strong> Changes made offline are queued and sent when you are back online.</div>
          <div>🗺️ <strong style={{ color: t.text }}>Map Tiles:</strong> Downloaded via the Offline Downloads panel — stored in <code style={{ fontSize: 11 }}>TravelMateOffline/tiles/</code></div>
          <div>⚡ <strong style={{ color: t.text }}>AI + Rates:</strong> Require internet — cached responses are used when offline.</div>
        </div>
      </div>
    </div>
  );
}