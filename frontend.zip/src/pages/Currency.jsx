import { useState, useEffect, useRef } from "react";
import { DARK, LIGHT } from "../styles/theme";
import { Spinner } from "../components/UI";

const CURRENCIES = [
  {code:"INR",name:"Indian Rupee",      symbol:"₹", flag:"🇮🇳"},
  {code:"USD",name:"US Dollar",         symbol:"$", flag:"🇺🇸"},
  {code:"EUR",name:"Euro",              symbol:"€", flag:"🇪🇺"},
  {code:"GBP",name:"British Pound",     symbol:"£", flag:"🇬🇧"},
  {code:"JPY",name:"Japanese Yen",      symbol:"¥", flag:"🇯🇵"},
  {code:"AUD",name:"Australian Dollar", symbol:"A$",flag:"🇦🇺"},
  {code:"SGD",name:"Singapore Dollar",  symbol:"S$",flag:"🇸🇬"},
  {code:"AED",name:"UAE Dirham",        symbol:"د.إ",flag:"🇦🇪"},
  {code:"THB",name:"Thai Baht",         symbol:"฿", flag:"🇹🇭"},
  {code:"MYR",name:"Malaysian Ringgit", symbol:"RM",flag:"🇲🇾"},
  {code:"SAR",name:"Saudi Riyal",       symbol:"﷼", flag:"🇸🇦"},
  {code:"CNY",name:"Chinese Yuan",      symbol:"¥", flag:"🇨🇳"},
  {code:"KRW",name:"Korean Won",        symbol:"₩", flag:"🇰🇷"},
  {code:"CHF",name:"Swiss Franc",       symbol:"Fr",flag:"🇨🇭"},
  {code:"HKD",name:"Hong Kong Dollar",  symbol:"HK$",flag:"🇭🇰"},
  {code:"CAD",name:"Canadian Dollar",   symbol:"C$",flag:"🇨🇦"},
  {code:"NZD",name:"New Zealand Dollar",symbol:"NZ$",flag:"🇳🇿"},
  {code:"QAR",name:"Qatari Riyal",      symbol:"﷼", flag:"🇶🇦"},
];

const POPULAR=["USD","EUR","GBP","INR","JPY","AUD","SGD","AED","THB","MYR"];

// Fare estimator ranges (per km in INR equivalent roughly)
const FARES = {
  "🛺 Auto-rickshaw": {min:8,max:15,unit:"per km"},
  "🚗 Cab/Taxi":      {min:12,max:25,unit:"per km"},
  "🚌 City Bus":      {min:0.5,max:2,unit:"per km"},
  "🚇 Metro":         {min:1,max:3.5,unit:"per km"},
  "🛵 Bike taxi":     {min:6,max:12,unit:"per km"},
};

function CurrencySelect({value,onChange,label,t}) {
  const [search,setSearch]=useState("");
  const [open,setOpen]=useState(false);
  const cur=CURRENCIES.find(c=>c.code===value);
  const filtered=CURRENCIES.filter(c=>c.code.toLowerCase().includes(search.toLowerCase())||c.name.toLowerCase().includes(search.toLowerCase()));
  const ref=useRef(null);
  useEffect(()=>{
    const h=e=>{if(ref.current&&!ref.current.contains(e.target))setOpen(false);};
    document.addEventListener("mousedown",h);return()=>document.removeEventListener("mousedown",h);
  },[]);
  return(
    <div ref={ref} style={{position:"relative"}}>
      {label&&<div style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",marginBottom:5}}>{label}</div>}
      <button onClick={()=>setOpen(o=>!o)} style={{width:"100%",background:t.surface,border:`1px solid ${t.border}`,borderRadius:10,padding:"10px 14px",color:t.text,fontSize:13,fontFamily:"inherit",cursor:"pointer",display:"flex",alignItems:"center",gap:8,justifyContent:"space-between",textAlign:"left"}}>
        <span>{cur?.flag} {cur?.code} — {cur?.name}</span><span style={{color:t.textSub,fontSize:11}}>▼</span>
      </button>
      {open&&(
        <div style={{position:"absolute",top:"100%",left:0,right:0,zIndex:100,background:t.card,border:`1px solid ${t.border}`,borderRadius:10,boxShadow:"0 8px 32px rgba(0,0,0,.4)",marginTop:4,overflow:"hidden"}}>
          <div style={{padding:"8px 10px",borderBottom:`1px solid ${t.border}`}}>
            <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search currency…" autoFocus
              style={{width:"100%",background:t.surface,border:`1px solid ${t.border}`,borderRadius:7,padding:"6px 10px",color:t.text,fontSize:12,outline:"none",fontFamily:"inherit",boxSizing:"border-box"}}/>
          </div>
          <div style={{maxHeight:220,overflowY:"auto"}}>
            {filtered.map(c=>(
              <button key={c.code} onClick={()=>{onChange(c.code);setOpen(false);setSearch("");}}
                style={{width:"100%",padding:"8px 12px",background:c.code===value?`${t.accent}14`:"transparent",border:"none",color:c.code===value?t.accent:t.text,cursor:"pointer",fontSize:13,fontFamily:"inherit",display:"flex",alignItems:"center",gap:8,textAlign:"left",transition:"background .12s"}}
                onMouseEnter={e=>{if(c.code!==value)e.currentTarget.style.background=t.cardHover;}}
                onMouseLeave={e=>{if(c.code!==value)e.currentTarget.style.background="transparent";}}>
                <span>{c.flag}</span><span style={{fontWeight:600}}>{c.code}</span><span style={{color:t.textSub,fontSize:11}}>{c.name}</span>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function MiniRateChart({history,color,t}) {
  if(!history||history.length<2)return null;
  const vals=history.map(h=>h.rate);
  const min=Math.min(...vals),max=Math.max(...vals),range=max-min||1;
  const W=160,H=40;
  const pts=vals.map((v,i)=>`${(i/(vals.length-1))*W},${H-((v-min)/range)*H}`).join(" ");
  const first=vals[0],last=vals[vals.length-1];
  const up=last>=first;
  return(
    <div style={{display:"flex",alignItems:"center",gap:8}}>
      <svg width={W} height={H} style={{overflow:"visible"}}>
        <polyline points={pts} fill="none" stroke={up?t.green:t.red} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round"/>
        <polyline points={`0,${H} ${pts} ${W},${H}`} fill={up?t.green:t.red} fillOpacity="0.1" stroke="none"/>
      </svg>
      <span style={{fontSize:10,color:up?t.green:t.red,fontWeight:600}}>{up?"↑":"↓"}{Math.abs(((last-first)/first)*100).toFixed(1)}%</span>
    </div>
  );
}

export default function Currency({ dark=true }) {
  const t = dark ? DARK : LIGHT;
  const [from,   setFrom]   = useState("USD");
  const [to,     setTo]     = useState("INR");
  const [amount, setAmount] = useState("1");
  const [rates,  setRates]  = useState(null);
  const [loading,setLoading]= useState(true);
  const [status, setStatus] = useState("loading");
  const [swapAnim,setSwapAnim]=useState(false);
  const [tab,    setTab]    = useState("converter");
  const [compareList,setCompareList]=useState(["USD","EUR","GBP","SGD","AED","THB","MYR","JPY"]);
  const [fareKm, setFareKm] = useState("10");
  const [history,setHistory]=useState({});

  useEffect(()=>{fetchRates("USD");},[]);

  const fetchRates=async base=>{
    setLoading(true);
    try{
      const r=await fetch(`https://open.er-api.com/v6/latest/${base}`);
      const d=await r.json();
      if(d.result==="success"){
        setRates({base,rates:d.rates,time:d.time_last_update_utc});
        setStatus("live");
        // Save a history point for mini charts
        const now=Date.now();
        setHistory(prev=>{
          const key=`${base}_${to}`;
          const pts=[...(prev[key]||[]),{time:now,rate:d.rates[to]||1}].slice(-8);
          return{...prev,[key]:pts};
        });
      }
    }catch{
      setStatus("offline");
    }finally{setLoading(false);}
  };

  useEffect(()=>{
    if(rates&&rates.base!==from)fetchRates(from);
  },[from]);

  const fRate=rates?(rates.base===from?(rates.rates[to]||1):((rates.rates[to]||1)/(rates.rates[from]||1))):null;
  const result=fRate&&amount?(parseFloat(amount||0)*fRate):null;
  const fromC=CURRENCIES.find(c=>c.code===from);
  const toC=CURRENCIES.find(c=>c.code===to);

  const swap=()=>{
    const tmp=from;setFrom(to);setTo(tmp);
    setSwapAnim(true);setTimeout(()=>setSwapAnim(false),400);
  };

  const statusColors={live:t.green,cached:t.amber,offline:t.red,loading:t.textSub};
  const statusLabels={live:"Live rates",cached:"Cached rates",offline:"Offline mode",loading:"Loading…"};

  const cardSt={background:t.card,border:`1px solid ${t.border}`,borderRadius:16,padding:"20px 22px",boxShadow:dark?"0 2px 10px rgba(0,0,0,.3)":"0 1px 5px rgba(0,0,0,.06)"};
  const tabBtnSt=id=>({padding:"7px 16px",borderRadius:8,fontSize:12,fontWeight:tab===id?600:400,cursor:"pointer",fontFamily:"inherit",background:tab===id?t.card:"transparent",color:tab===id?t.accent:t.textSub,border:tab===id?`1px solid ${t.accent}33`:"1px solid transparent",transition:"all .14s"});

  return(
    <div className="fade-up" style={{}}>
      <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>💱 Currency</div>
      <div style={{color:t.textSub,fontSize:13,marginBottom:18,display:"flex",alignItems:"center",gap:8}}>
        <span style={{width:7,height:7,borderRadius:"50%",background:statusColors[status],display:"inline-block"}}/>
        {statusLabels[status]}
        {rates?.time&&<span>· Updated {new Date(rates.time).toLocaleTimeString("en-IN",{hour:"2-digit",minute:"2-digit"})}</span>}
      </div>

      {/* Tab bar */}
      <div style={{display:"flex",gap:3,background:t.surface,borderRadius:10,padding:3,width:"fit-content",border:`1px solid ${t.border}`,marginBottom:20}}>
        {[["converter","🔄 Converter"],["compare","📊 Compare"],["fare","🚗 Fare Estimate"]].map(([id,label])=>(
          <button key={id} onClick={()=>setTab(id)} style={tabBtnSt(id)}>{label}</button>
        ))}
      </div>

      {/* ── CONVERTER ── */}
      {tab==="converter"&&(
        <div style={{display:"flex",flexDirection:"column",gap:16}}>
          <div style={cardSt}>
            <div className="currency-from-to">
              <CurrencySelect value={from} onChange={v=>{setFrom(v);}} label="FROM" t={t}/>
              <button onClick={swap} style={{width:42,height:42,borderRadius:12,background:t.surface,border:`1px solid ${t.accent}44`,color:t.accent,cursor:"pointer",fontSize:20,display:"flex",alignItems:"center",justifyContent:"center",marginBottom:0,transition:"all .3s",transform:swapAnim?"rotate(180deg)":""}}
                onMouseEnter={e=>{e.currentTarget.style.background=`${t.accent}15`;}}
                onMouseLeave={e=>{e.currentTarget.style.background=t.surface;}}>⇄</button>
              <CurrencySelect value={to} onChange={v=>{setTo(v);}} label="TO" t={t}/>
            </div>

            <div className="currency-converter-row">
              <div>
                <div style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",marginBottom:5}}>Amount</div>
                <div style={{display:"flex",alignItems:"center",background:t.surface,border:`1px solid ${t.accent}44`,borderRadius:12,padding:"12px 16px",gap:8}}>
                  <span style={{fontSize:18,fontWeight:700,color:t.accent}}>{fromC?.symbol||from}</span>
                  <input type="number" value={amount} onChange={e=>setAmount(e.target.value)} min="0" step="any"
                    style={{flex:1,background:"transparent",border:"none",color:t.text,fontSize:22,fontWeight:700,outline:"none",fontFamily:"'Playfair Display',serif",width:0}}/>
                </div>
              </div>
              <div>
                <div style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",marginBottom:5}}>Result</div>
                <div style={{background:`linear-gradient(135deg,${t.accent}0D,${t.violet}07)`,border:`1px solid ${t.accent}28`,borderRadius:12,padding:"12px 16px",display:"flex",alignItems:"center",gap:8}}>
                  <span style={{fontSize:18,fontWeight:700,color:t.accent}}>{toC?.symbol||to}</span>
                  {loading?<Spinner size={20} dark={dark}/>:<span style={{fontSize:22,fontWeight:700,color:t.text,fontFamily:"'Playfair Display',serif"}}>{result?result.toLocaleString("en-IN",{maximumFractionDigits:4}):"—"}</span>}
                </div>
              </div>
            </div>

            {fRate&&(
              <div style={{marginTop:16,padding:"10px 14px",background:t.surface,borderRadius:10,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{fontSize:12,color:t.textSub}}>Exchange rate</span>
                <span style={{fontSize:13,fontWeight:700,color:t.text}}>1 {from} = {fRate.toLocaleString("en-IN",{maximumFractionDigits:4})} {to}</span>
              </div>
            )}
          </div>

          {/* Quick conversions */}
          <div style={cardSt}>
            <div style={{fontWeight:600,fontSize:14,marginBottom:14,color:t.text}}>Quick Conversions</div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(60px,1fr))",gap:8}}>
              {[100,500,1000,5000,10000,25000,50000,100000].map(v=>(
                <button key={v} onClick={()=>setAmount(String(v))}
                  style={{padding:"8px",borderRadius:9,background:String(v)===amount?`${t.accent}18`:t.surface,border:`1px solid ${String(v)===amount?t.accent:t.border}`,color:String(v)===amount?t.accent:t.textSub,cursor:"pointer",fontSize:12,fontFamily:"inherit",fontWeight:String(v)===amount?700:400,transition:"all .15s"}}>
                  {fromC?.symbol}{v>=1000?`${v/1000}K`:v}
                </button>
              ))}
            </div>
          </div>

          {/* Rate chart */}
          {history[`${from}_${to}`]?.length>1&&(
            <div style={cardSt}>
              <div style={{fontWeight:600,fontSize:14,marginBottom:12,color:t.text}}>Rate History (session)</div>
              <MiniRateChart history={history[`${from}_${to}`]} color={t.accent} t={t}/>
              <div style={{fontSize:11,color:t.textSub,marginTop:8}}>Rate snapshots since page load · {history[`${from}_${to}`].length} data points</div>
            </div>
          )}
        </div>
      )}

      {/* ── COMPARE ── */}
      {tab==="compare"&&(
        <div style={cardSt}>
          <div style={{fontWeight:600,fontSize:14,marginBottom:4,color:t.text}}>Compare 1 {from} against popular currencies</div>
          <div style={{fontSize:12,color:t.textSub,marginBottom:16}}>{loading?"Loading…":"Live rates"}</div>
          {loading?<div style={{display:"flex",justifyContent:"center",padding:40}}><Spinner dark={dark}/></div>:(
            <div style={{display:"flex",flexDirection:"column",gap:6}}>
              {POPULAR.filter(c=>c!==from).map(code=>{
                const c=CURRENCIES.find(x=>x.code===code);
                const rate=rates?(rates.base===from?(rates.rates[code]||1):((rates.rates[code]||1)/(rates.rates[from]||1))):null;
                const amt=amount?parseFloat(amount)||1:1;
                return(
                  <div key={code} style={{display:"flex",alignItems:"center",gap:12,padding:"11px 14px",background:code===to?`${t.accent}0D`:t.surface,border:`1px solid ${code===to?t.accent+"44":t.border}`,borderRadius:10,cursor:"pointer",transition:"all .15s"}}
                    onClick={()=>{setTo(code);setTab("converter");}}>
                    <span style={{fontSize:20,flexShrink:0}}>{c?.flag}</span>
                    <div style={{flex:1}}>
                      <div style={{fontWeight:600,fontSize:13,color:t.text}}>{code}</div>
                      <div style={{fontSize:11,color:t.textSub}}>{c?.name}</div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontWeight:700,fontSize:15,color:t.text}}>{c?.symbol}{rate?(amt*rate).toLocaleString("en-IN",{maximumFractionDigits:2}):"—"}</div>
                      <div style={{fontSize:11,color:t.textSub}}>1 {from} = {rate?.toLocaleString("en-IN",{maximumFractionDigits:4})}</div>
                    </div>
                    <span style={{color:t.accent,fontSize:12}}>→</span>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ── FARE ESTIMATOR ── */}
      {tab==="fare"&&(
        <div style={{display:"flex",flexDirection:"column",gap:14}}>
          <div style={cardSt}>
            <div style={{fontWeight:600,fontSize:14,marginBottom:4,color:t.text}}>🚗 Travel Fare Estimator</div>
            <div style={{fontSize:12,color:t.textSub,marginBottom:16}}>Approximate fares in India (INR) and your currency</div>
            <div style={{display:"flex",gap:10,alignItems:"center",marginBottom:16}}>
              <div style={{fontSize:13,color:t.textSub}}>Distance:</div>
              <input type="number" value={fareKm} onChange={e=>setFareKm(e.target.value)} min="1" max="500"
                style={{width:80,background:t.surface,border:`1px solid ${t.border}`,borderRadius:8,padding:"7px 10px",color:t.text,fontSize:13,outline:"none",fontFamily:"inherit"}}/>
              <div style={{fontSize:13,color:t.textSub}}>km</div>
              <div style={{fontSize:12,color:t.textSub}}>→ <strong style={{color:t.text}}>showing in {to}</strong></div>
            </div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {Object.entries(FARES).map(([mode,{min,max,unit}])=>{
                const km=parseFloat(fareKm)||10;
                const minINR=min*km,maxINR=max*km;
                const toRate=rates?(rates.base==="INR"?(rates.rates[to]||1):((rates.rates[to]||1)/(rates.rates["INR"]||1))):null;
                const minTo=toRate?minINR*toRate:null;
                const maxTo=toRate?maxINR*toRate:null;
                const toC2=CURRENCIES.find(c=>c.code===to);
                return(
                  <div key={mode} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"12px 14px",background:t.surface,borderRadius:10,border:`1px solid ${t.border}`}}>
                    <div>
                      <div style={{fontWeight:600,fontSize:13,color:t.text}}>{mode}</div>
                      <div style={{fontSize:11,color:t.textSub}}>{unit}</div>
                    </div>
                    <div style={{textAlign:"right"}}>
                      <div style={{fontWeight:700,fontSize:14,color:t.accent}}>₹{minINR.toLocaleString("en-IN")}–₹{maxINR.toLocaleString("en-IN")}</div>
                      {minTo&&<div style={{fontSize:12,color:t.textSub}}>{toC2?.symbol}{minTo.toFixed(1)}–{toC2?.symbol}{maxTo?.toFixed(1)}</div>}
                    </div>
                  </div>
                );
              })}
            </div>
            <div style={{fontSize:11,color:t.textDim,marginTop:12}}>* Estimates only. Actual fares vary by city, time and demand.</div>
          </div>
        </div>
      )}
    </div>
  );
}
