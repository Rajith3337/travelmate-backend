import { useState, useContext, useRef } from "react";
import { AuthContext } from "../context/AuthContext";
import { DARK, LIGHT } from "../styles/theme";
import { Btn, ErrorMsg } from "../components/UI";
import { authApi, passwordApi } from "../api/client";
import { tripsApi, expensesApi } from "../api/client";
import { useEffect } from "react";

export default function Profile({ dark=true }){
  const t=dark?DARK:LIGHT;
  const {user,setUser}=useContext(AuthContext);
  const [tab,setTab]=useState("profile");
  const [form,setForm]=useState({
    full_name:  user?.full_name  ||"",
    username:   user?.username   ||"",
    email:      user?.email      ||"",
    bio:        user?.bio        ||"",
    avatar_url: user?.avatar_url ||"",
  });
  const [pwForm,setPwForm]=useState({current_password:"",new_password:"",confirm_password:""});
  const [saving,setSaving]=useState(false);
  const [err,setErr]=useState("");
  const [success,setSuccess]=useState("");
  const [stats,setStats]=useState(null);
  const [avatarPreview,setAvatarPreview]=useState(user?.avatar_url||null);
  const fileRef=useRef(null);

  useEffect(()=>{
    // Load trip stats
    tripsApi.list().then(async trips=>{
      const summaries=await Promise.all(trips.map(tr=>expensesApi.summary(tr.id).catch(()=>({total_spent:0}))));
      const totalSpent=summaries.reduce((s,v)=>s+(v?.total_spent||0),0);
      const destinations=new Set(trips.map(tr=>tr.destination)).size;
      const completed=trips.filter(tr=>tr.status==="completed").length;
      const totalBudget=trips.reduce((s,tr)=>s+(tr.budget||0),0);
      // Estimate days from trips with dates
      const days=trips.reduce((s,tr)=>{
        if(tr.start_date&&tr.end_date){
          return s+Math.max(0,Math.ceil((new Date(tr.end_date)-new Date(tr.start_date))/86400000));
        }return s;
      },0);
      setStats({trips:trips.length,destinations,completed,totalSpent,totalBudget,days});
    }).catch(()=>{});
  },[]);

  const sf=k=>e=>setForm(f=>({...f,[k]:e.target.value}));
  const spf=k=>e=>setPwForm(f=>({...f,[k]:e.target.value}));

  const handleAvatarFile=e=>{
    const file=e.target.files?.[0];
    if(!file)return;
    
    // Check file size (max 1MB)
    if (file.size > 1048576) {
      setErr("Avatar image too large (max 1MB)");
      return;
    }
    
    // Compress image if needed
    const reader=new FileReader();
    reader.onload=ev=>{
      const dataUrl=ev.target.result;
      
      // Simple compression by resizing if large
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        
        // Resize to max 200x200
        let { width, height } = img;
        if (width > 200 || height > 200) {
          const ratio = Math.min(200 / width, 200 / height);
          width *= ratio;
          height *= ratio;
        }
        
        canvas.width = width;
        canvas.height = height;
        ctx.drawImage(img, 0, 0, width, height);
        
        // Use JPEG for smaller size
        const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setAvatarPreview(compressedDataUrl);
        setForm(f=>({...f,avatar_url:compressedDataUrl}));
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  const saveProfile=async()=>{
    setErr("");setSuccess("");setSaving(true);
    try{
      console.log("Saving profile with data:", {
        full_name: form.full_name,
        username:  form.username,
        email:     form.email,
        bio:       form.bio,
        avatar_url:form.avatar_url?.substring(0, 50) + "...",
      });
      const updated=await authApi.updateMe({
        full_name: form.full_name,
        username:  form.username,
        email:     form.email,
        bio:       form.bio,
        avatar_url:form.avatar_url||null,
      });
      console.log("Profile updated successfully:", updated);
      setUser(updated);
      setSuccess("Profile updated successfully!");
    }catch(ex){
      console.error("Profile update failed:", ex);
      setErr(ex.message || "Failed to update profile");
    }
    finally{setSaving(false);}
  };

  const changePassword=async()=>{
    setErr("");setSuccess("");
    if(pwForm.new_password!==pwForm.confirm_password){setErr("New passwords do not match");return;}
    if(pwForm.new_password.length<6){setErr("New password must be at least 6 characters");return;}
    setSaving(true);
    try{
      await passwordApi.change({current_password:pwForm.current_password,new_password:pwForm.new_password});
      setPwForm({current_password:"",new_password:"",confirm_password:""});
      setSuccess("Password changed successfully!");
    }catch(ex){setErr(ex.message);}
    finally{setSaving(false);}
  };

  const initials=(form.full_name||form.username||"?").split(" ").map(w=>w[0]).join("").toUpperCase().slice(0,2);
  const inpSt={width:"100%",background:t.surface,border:`1px solid ${t.border}`,borderRadius:9,padding:"9px 12px",color:t.text,fontSize:13,outline:"none",fontFamily:"inherit",boxSizing:"border-box"};
  const labelSt={fontSize:11,fontWeight:600,color:t.textSub,display:"block",marginBottom:5,textTransform:"uppercase",letterSpacing:".06em"};

  const TABS=[{id:"profile",label:"\u{1F464} Profile"},{id:"password",label:"\u{1F512} Password"},{id:"stats",label:"\u{1F4CA} My Stats"}];

  return(
    <div style={{}}>
      <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>Profile</h1>
      <div style={{fontSize:13,color:t.textSub,marginBottom:24}}>Manage your account and view travel statistics</div>

      {/* Avatar card */}
      <div className="profile-avatar-card" style={{display:"flex",alignItems:"center",gap:18,marginBottom:24,background:t.card,border:`1px solid ${t.border}`,borderRadius:18,padding:"18px 22px"}}>
        <div style={{position:"relative",flexShrink:0}}>
          <div style={{width:76,height:76,borderRadius:20,background:avatarPreview?"transparent":`linear-gradient(135deg,${t.accent},${t.violet||"#7C3AED"})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:28,fontWeight:700,color:"#fff",overflow:"hidden",border:`2px solid ${t.border}`}}>
            {avatarPreview
              ?<img src={avatarPreview} alt="" style={{width:"100%",height:"100%",objectFit:"cover"}} onError={()=>setAvatarPreview(null)}/>
              :initials}
          </div>
          <button onClick={()=>fileRef.current?.click()}
            style={{position:"absolute",bottom:-4,right:-4,width:24,height:24,borderRadius:7,background:t.accent,border:"2px solid "+t.card,color:"#fff",cursor:"pointer",fontSize:12,display:"flex",alignItems:"center",justifyContent:"center"}}>
            {"\u{1F4F7}"}
          </button>
          <input ref={fileRef} type="file" accept="image/*" onChange={handleAvatarFile} style={{display:"none"}}/>
          <div style={{fontSize:10,color:t.textDim,marginTop:4,textAlign:"center"}}>Max 1MB, auto-resized</div>
        </div>
        <div>
          <div style={{fontSize:18,fontWeight:700,color:t.text}}>{user?.full_name||user?.username}</div>
          <div style={{fontSize:13,color:t.textSub}}>@{user?.username}</div>
          <div style={{fontSize:12,color:t.textSub,marginTop:2}}>{user?.email}</div>
          <div style={{fontSize:11,color:t.textDim,marginTop:3}}>Member since {new Date(user?.created_at||Date.now()).toLocaleDateString("en-IN",{month:"long",year:"numeric"})}</div>
        </div>
      </div>

      {/* Tab bar */}
      <div className="profile-tabs" style={{display:"flex",gap:6,marginBottom:20}}>
        {TABS.map(({id,label})=>(
          <button key={id} onClick={()=>{setTab(id);setErr("");setSuccess("");}}
            style={{padding:"8px 18px",borderRadius:9,fontSize:13,fontWeight:500,cursor:"pointer",fontFamily:"inherit",background:tab===id?t.card:"transparent",color:tab===id?t.accent:t.textSub,border:tab===id?`1px solid ${t.border}`:"1px solid transparent",transition:"all .15s"}}>
            {label}
          </button>
        ))}
      </div>

      <div style={{background:t.card,border:`1px solid ${t.border}`,borderRadius:16,padding:"22px"}}>
        {success&&<div style={{background:`${t.green||"#10b981"}18`,border:`1px solid ${t.green||"#10b981"}44`,borderRadius:10,padding:"10px 14px",color:t.green||"#10b981",fontSize:13,marginBottom:16}}>{"\u2705"} {success}</div>}
        {err&&<ErrorMsg msg={err}/>}

        {tab==="profile"&&(
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:12}}>
              <div><label style={labelSt}>Full Name</label><input style={inpSt} value={form.full_name} onChange={sf("full_name")} placeholder="Your name"/></div>
              <div><label style={labelSt}>Username</label><input style={inpSt} value={form.username} onChange={sf("username")} placeholder="username"/></div>
            </div>
            <div><label style={labelSt}>Email</label><input style={inpSt} type="email" value={form.email} onChange={sf("email")} placeholder="you@email.com"/></div>

            <div><label style={labelSt}>Bio</label><textarea style={{...inpSt,height:80,resize:"vertical"}} value={form.bio} onChange={sf("bio")} placeholder="Tell us about yourself\u2026"/></div>
            <Btn onClick={saveProfile} loading={saving} size="lg" style={{justifyContent:"center"}} dark={dark}>{"\u{1F4BE}"} Save Changes</Btn>
          </div>
        )}

        {tab==="password"&&(
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            <div><label style={labelSt}>Current Password</label><input style={inpSt} type="password" value={pwForm.current_password} onChange={spf("current_password")} placeholder="••••••••" autoComplete="current-password"/></div>
            <div><label style={labelSt}>New Password</label><input style={inpSt} type="password" value={pwForm.new_password} onChange={spf("new_password")} placeholder="Min 6 characters" autoComplete="new-password"/></div>
            <div><label style={labelSt}>Confirm New Password</label><input style={inpSt} type="password" value={pwForm.confirm_password} onChange={spf("confirm_password")} placeholder="Repeat new password" autoComplete="new-password"/></div>
            <Btn onClick={changePassword} loading={saving} size="lg" style={{justifyContent:"center"}} dark={dark}>{"\u{1F512}"} Change Password</Btn>
          </div>
        )}

        {tab==="stats"&&(
          <div>
            <div style={{fontWeight:700,fontSize:14,color:t.text,marginBottom:16}}>Your travel story so far {"\u2708\uFE0F"}</div>
            {stats?(
              <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(180px,1fr))",gap:12}}>
                {[
                  {icon:"\u2708\uFE0F",label:"Total Trips",    val:stats.trips,          color:t.accent},
                  {icon:"\u{1F4CD}",label:"Destinations",   val:stats.destinations,    color:t.violet||"#7C3AED"},
                  {icon:"\u2705",label:"Completed",      val:stats.completed,       color:t.green||"#10b981"},
                  {icon:"\u{1F5D3}\uFE0F",label:"Days Travelled", val:`${stats.days}d`,      color:t.amber||"#f59e0b"},
                  {icon:"\u{1F4B0}",label:"Total Spent",    val:`\u20B9${Math.round(stats.totalSpent/1000)}K`,color:t.red||"#ef4444"},
                  {icon:"\u{1F4CA}",label:"Total Budget",   val:`\u20B9${Math.round(stats.totalBudget/1000)}K`,color:t.accent},
                ].map(({icon,label,val,color})=>(
                  <div key={label} style={{background:t.surface,border:`1px solid ${t.border}`,borderRadius:14,padding:"16px 18px",display:"flex",alignItems:"center",gap:12}}>
                    <div style={{width:44,height:44,borderRadius:12,background:`${color}18`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,flexShrink:0}}>{icon}</div>
                    <div>
                      <div style={{fontSize:22,fontWeight:800,color:t.text,lineHeight:1}}>{val}</div>
                      <div style={{fontSize:11,color:t.textSub,marginTop:3}}>{label}</div>
                    </div>
                  </div>
                ))}
              </div>
            ):<div style={{textAlign:"center",padding:30,color:t.textSub,fontSize:13}}>Loading stats\u2026</div>}
          </div>
        )}
      </div>
    </div>
  );
}
