import { useState, useEffect } from "react";
import { tripsApi, settingsApi } from "../api/client";
import { DARK, LIGHT } from "../styles/theme";
import LocationInput from "../components/LocationInput";

const PROVIDERS = {
  flights: [
    {name:"MakeMyTrip",    color:"#e63946", url:(f,t,d)=>`https://www.makemytrip.com/flights/search?tripType=O&itinerary=${f}-${t}-${d}`},
    {name:"Ixigo",         color:"#f77f00", url:(f,t,d)=>`https://www.ixigo.com/search/result/flight?from=${f}&to=${t}&date=${d}&adults=1`},
    {name:"EaseMyTrip",    color:"#2196f3", url:(f,t,d)=>`https://flight.easemytrip.com/FlightSearch/Search?seg=${f}${t}|${d}`},
    {name:"Goibibo",       color:"#00bcd4", url:(f,t,d)=>`https://www.goibibo.com/flights/search/?sourcecode=${f}&destinationcode=${t}&date=${d}&adults=1`},
    {name:"Google Flights",color:"#4285f4", url:(f,t,d)=>`https://www.google.com/travel/flights?q=flights+from+${f}+to+${t}+on+${d}`},
    {name:"Skyscanner",    color:"#00a598", url:(f,t,d)=>`https://www.skyscanner.co.in/transport/flights/${f}/${t}/${d.replace(/-/g,"")}/`},
  ],
  hotels: [
    {name:"MakeMyTrip",  color:"#e63946", url:(_,t,d,co)=>`https://www.makemytrip.com/hotels/hotel-listing/?checkin=${d}&checkout=${co}&city=${t}`},
    {name:"OYO",         color:"#e63946", url:(_,t,d,co)=>`https://www.oyorooms.com/search/?location=${encodeURIComponent(t)}&checkInDate=${d}&checkOutDate=${co}`},
    {name:"Booking.com", color:"#003580", url:(_,t,d,co)=>`https://www.booking.com/searchresults.html?ss=${encodeURIComponent(t)}&checkin=${d}&checkout=${co}`},
    {name:"Agoda",       color:"#5c3d99", url:(_,t,d,co)=>`https://www.agoda.com/search?city=${encodeURIComponent(t)}&checkIn=${d}&checkOut=${co}`},
    {name:"Goibibo",     color:"#00bcd4", url:(_,t,d)=>`https://www.goibibo.com/hotels/search/?q=${encodeURIComponent(t)}&checkin=${d}`},
    {name:"Airbnb",      color:"#ff5a5f", url:(_,t,d,co)=>`https://www.airbnb.co.in/s/${encodeURIComponent(t)}/homes?checkin=${d}&checkout=${co}`},
  ],
  trains: [
    {name:"IRCTC",        color:"#003366", url:(f,t,d)=>`https://www.irctc.co.in/nget/train-search?fromStationCode=${f}&toStationCode=${t}&journeyDate=${d}`},
    {name:"RailYatri",    color:"#f37021", url:(f,t,d)=>`https://www.railyatri.in/train-between-stations?from=${f}&to=${t}&date=${d}`},
    {name:"Ixigo Trains", color:"#f77f00", url:(f,t,d)=>`https://www.ixigo.com/trains/${f}/${t}/${d}`},
    {name:"Goibibo Rail", color:"#00bcd4", url:(f,t,d)=>`https://www.goibibo.com/trains/results/?src=${f}&dst=${t}&doj=${d}`},
  ],
  buses: [
    {name:"RedBus",     color:"#d63031", url:(f,t,d)=>`https://www.redbus.in/bus-tickets/${encodeURIComponent(f)}-to-${encodeURIComponent(t)}?doj=${d}`},
    {name:"Abhibus",    color:"#e84393", url:(f,t)=>`https://www.abhibus.com/${encodeURIComponent(f)}-to-${encodeURIComponent(t)}-bus-tickets`},
    {name:"MakeMyTrip", color:"#e63946", url:(f,t)=>`https://www.makemytrip.com/bus-tickets/${encodeURIComponent(f)}-to-${encodeURIComponent(t)}/`},
    {name:"Ixigo Bus",  color:"#f77f00", url:(f,t,d)=>`https://www.ixigo.com/bus/search?from=${encodeURIComponent(f)}&to=${encodeURIComponent(t)}&date=${d}`},
  ],
  cabs: [
    {name:"Ola",     color:"#23d160", url:(_,t)=>`https://book.olacabs.com/?drop=${encodeURIComponent(t)}`},
    {name:"Uber",    color:"#222",    url:(f,t)=>`https://m.uber.com/looking?pickup=${encodeURIComponent(f)}&dropoff=${encodeURIComponent(t)}`},
    {name:"Rapido",  color:"#ff6b35", url:()=>"https://www.rapido.bike"},
    {name:"InDrive", color:"#00cc66", url:()=>"https://indrive.com"},
  ],
};

const HELPLINES = {
  national:[
    {name:"Police",          no:"100"},
    {name:"Ambulance",       no:"108"},
    {name:"Fire",            no:"101"},
    {name:"Women Helpline",  no:"1091"},
    {name:"Tourist Helpline",no:"1363"},
    {name:"Railway Enquiry", no:"139"},
    {name:"Road Accident",   no:"1073"},
    {name:"Disaster Mgmt",   no:"1078"},
  ],
  intl:[
    {name:"Emergency (EU)", no:"112"},
    {name:"Emergency (US)", no:"911"},
    {name:"Emergency (UK)", no:"999"},
    {name:"Emergency (AU)", no:"000"},
    {name:"Emergency (JP)", no:"110/119"},
    {name:"Emergency (SG)", no:"999"},
    {name:"Emergency (MY)", no:"999"},
    {name:"Emergency (TH)", no:"191"},
  ],
};

const TRANSPORT_TABS = [
  {key:"flights", label:"✈️ Flights",  emoji:"✈️", short:"Flights",  from:true, to:true, date:true},
  {key:"hotels",  label:"🏨 Hotels",   emoji:"🏨", short:"Hotels",   from:false,to:true, date:true, checkout:true},
  {key:"trains",  label:"🚆 Trains",   emoji:"🚆", short:"Trains",   from:true, to:true, date:true},
  {key:"buses",   label:"🚌 Buses",    emoji:"🚌", short:"Buses",    from:true, to:true, date:true},
  {key:"cabs",    label:"🚗 Cabs",     emoji:"🚗", short:"Cabs",     from:true, to:true, date:false},
];

const DOC_CHECKLIST = [
  {id:"passport", label:"Passport (valid 6+ months)", group:"Identity"},
  {id:"visa",     label:"Visa / e-Visa printout",     group:"Identity"},
  {id:"id",       label:"Government ID (Aadhaar / PAN)",group:"Identity"},
  {id:"tickets",  label:"Flight / Train tickets",     group:"Travel"},
  {id:"hotel",    label:"Hotel booking confirmation", group:"Travel"},
  {id:"insurance",label:"Travel insurance",           group:"Travel"},
  {id:"forex",    label:"Foreign currency / forex card",group:"Money"},
  {id:"cards",    label:"Credit / Debit cards notified",group:"Money"},
  {id:"copies",   label:"Photocopies of all docs",    group:"Safety"},
  {id:"emergency",label:"Emergency contacts written", group:"Safety"},
];

const BOOKING_TIPS = [
  "Book 6–8 weeks early for best flight prices",
  "Compare prices across all platforms before committing",
  "Enable price alerts on Google Flights",
  "Check IRCTC Tatkal for last-minute train availability",
  "OYO and Airbnb often significantly cheaper than hotels",
  "Always read the cancellation policy before booking",
];

export default function FlightHotel({ dark = true }) {
  const t = dark ? DARK : LIGHT;
  const [activeTab,  setActiveTab]  = useState("flights");
  const [from,       setFrom]       = useState("");
  const [to,         setTo]         = useState("");
  const [date,       setDate]       = useState(new Date().toISOString().slice(0,10));
  const [checkout,   setCheckout]   = useState("");
  const [trips,      setTrips]      = useState([]);
  const [helpTab,    setHelpTab]    = useState("national");
  const [docChecked, setDocChecked] = useState({});
  const [foc,        setFoc]        = useState({});
  const [mainTab,    setMainTab]    = useState("book");
  // Mobile: track whether the search panel is collapsed (showing providers)
  const [mobileShowProviders, setMobileShowProviders] = useState(false);

  useEffect(() => {
    tripsApi.list().then(d => {
      setTrips(d);
      const active = d.find(tr => tr.status === "active" || tr.status === "upcoming") || d[0];
      if (active) {
        if (active.start_location) setFrom(active.start_location);
        if (active.destination)    setTo(active.destination);
        if (active.start_date)     setDate(active.start_date);
        if (active.end_date)       setCheckout(active.end_date);
      }
    });
    try {
      navigator.geolocation.getCurrentPosition(pos => {
        fetch(`https://nominatim.openstreetmap.org/reverse?lat=${pos.coords.latitude}&lon=${pos.coords.longitude}&format=json`)
          .then(r => r.json()).then(d => {
            const city = d.address?.city || d.address?.town || d.address?.state || "";
            if (city && !from) setFrom(city);
          });
      });
    } catch {}
    settingsApi.get("doc_checklist")
      .then((row) => {
        if (!row?.value_text) return;
        try { setDocChecked(JSON.parse(row.value_text)); } catch {}
      })
      .catch(() => {});
  }, []);

  // Reset mobile panel state when main tab changes
  useEffect(() => { setMobileShowProviders(false); }, [mainTab, activeTab]);

  const toggleDoc = id => {
    const next = { ...docChecked, [id]: !docChecked[id] };
    setDocChecked(next);
    settingsApi.put("doc_checklist", JSON.stringify(next)).catch(() => {});
  };

  const tab       = TRANSPORT_TABS.find(tb => tb.key === activeTab);
  const providers = PROVIDERS[activeTab] || [];
  const docGroups = [...new Set(DOC_CHECKLIST.map(d => d.group))];
  const checkedCount = Object.values(docChecked).filter(Boolean).length;

  const inpSt = focused => ({
    background: focused ? `${t.accent}08` : t.surface,
    border: `1.5px solid ${focused ? t.accent + "99" : t.border}`,
    borderRadius: 9, padding: "10px 14px", color: t.text,
    fontSize: 16, outline: "none", fontFamily: "inherit",
    width: "100%", boxSizing: "border-box", transition: "all .2s",
    boxShadow: focused ? `0 0 0 3px ${t.accent}18` : dark ? "none" : "0 1px 3px rgba(30,60,120,0.06)",
  });

  const MAIN_TABS = [["book","✈ Book"],["docs","📋 Docs"],["help","🆘 Help"]];

  return (
    <div style={{ display:"flex", flexDirection:"column", height:"calc(100dvh - 56px)", overflow:"hidden" }}>
      {/* ── Top chrome ── */}
      <div style={{ flexShrink:0, background:t.card, borderBottom:`1px solid ${t.border}` }}>
        {/* Header row */}
        <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"14px 16px 10px", flexWrap:"wrap", gap:8 }}>
          <div>
            <div style={{ fontSize:18, fontWeight:700, color:t.text, letterSpacing:"-.02em", lineHeight:1.2 }}>Travel Bookings</div>
            <div style={{ fontSize:11, color:t.textDim, marginTop:2, letterSpacing:".02em" }}>
              Flights · Hotels · Trains · Buses · Cabs
            </div>
          </div>
          {/* Quick-fill chips */}
          {trips.length > 0 && (
            <div style={{ display:"flex", alignItems:"center", gap:6, overflow:"hidden", maxWidth:"100%" }}>
              <span style={{ fontSize:10, color:t.textDim, fontWeight:700, textTransform:"uppercase", letterSpacing:".08em", flexShrink:0 }}>Trip</span>
              <div className="fh-chiprow">
                {trips.slice(0, 4).map(tr => (
                  <button key={tr.id}
                    onClick={() => {
                      if (tr.destination)    setTo(tr.destination);
                      if (tr.start_location) setFrom(tr.start_location);
                      if (tr.start_date)     setDate(tr.start_date);
                      if (tr.end_date)       setCheckout(tr.end_date);
                    }}
                    className="fh-tripchip"
                    style={{
                      flexShrink:0, padding:"5px 12px", borderRadius:99,
                      background:t.surface, border:`1.5px solid ${t.border}`,
                      color:t.textSub, fontSize:12, cursor:"pointer",
                      fontFamily:"inherit", fontWeight:500, transition:"all .18s",
                      whiteSpace:"nowrap", minHeight:36,
                    }}>
                    {tr.cover_emoji} {tr.name}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Main tabs — full width, equal flex */}
        <div style={{ display:"flex", borderTop:`1px solid ${t.border}` }}>
          {MAIN_TABS.map(([id, label]) => (
            <button key={id} onClick={() => setMainTab(id)}
              className={`fh-maintab ${mainTab === id ? "active" : ""}`}
              style={{ color: mainTab===id ? t.accent : t.textSub, fontWeight: mainTab===id ? 600 : 400, fontSize:13 }}>
              {label}
              <span className="underline"/>
            </button>
          ))}
        </div>
      </div>

      {/* ════════════════ BOOK TRAVEL ════════════════ */}
      {mainTab === "book" && (
        <div className="fh-layout">

          {/* Transport mode pills — horizontal scroll */}
          <div style={{ gridColumn:"1 / -1", flexShrink:0 }}>
            <div className="fh-modebar">
              {TRANSPORT_TABS.map(tb => (
                <button key={tb.key}
                  className={`fh-modepill ${activeTab === tb.key ? "active" : ""}`}
                  onClick={() => setActiveTab(tb.key)}>
                  {tb.label}
                </button>
              ))}
            </div>
          </div>

          {/* Providers panel */}
          <div className="fh-providers-panel">
            <div className="fh-pad">
              <div style={{ fontSize:14, fontWeight:700, color:t.text, marginBottom:14, display:"flex", alignItems:"center", gap:8, flexWrap:"wrap" }}>
                <span>{tab?.short} Platforms</span>
                <span style={{ fontSize:12, color:t.textDim, fontWeight:400 }}>tap to open & book</span>
              </div>

              <div className="fh-provider-grid">
                {providers.map((p, i) => {
                  const url = p.url(from, to, date, checkout);
                  return (
                    <a key={p.name} href={url} target="_blank" rel="noopener noreferrer"
                      className="fh-provider fh-pcard"
                      style={{
                        background: t.card,
                        border: `1.5px solid ${t.border}`,
                        boxShadow: dark ? "none" : "0 2px 8px rgba(30,60,120,0.06)",
                        animation: `fhFadeUp .28s cubic-bezier(.16,.84,.44,1) ${i * 40}ms both`,
                      }}
                      onMouseEnter={e => {
                        e.currentTarget.style.borderColor = p.color;
                        e.currentTarget.style.boxShadow = `0 8px 28px ${p.color}28`;
                      }}
                      onMouseLeave={e => {
                        e.currentTarget.style.borderColor = t.border;
                        e.currentTarget.style.boxShadow = dark ? "none" : "0 2px 8px rgba(30,60,120,0.06)";
                      }}>
                      <div style={{
                        width:38, height:38, borderRadius:10,
                        background:`${p.color}14`, border:`1.5px solid ${p.color}33`,
                        display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0,
                      }}>
                        <div style={{ width:14, height:14, borderRadius:3, background:p.color, opacity:.85 }}/>
                      </div>
                      <div>
                        <div style={{ fontSize:13, fontWeight:600, color:t.text, marginBottom:2, lineHeight:1.3 }}>{p.name}</div>
                        <div style={{ fontSize:11, color:p.color, fontWeight:500 }}>Open →</div>
                      </div>
                    </a>
                  );
                })}
              </div>

              {/* Route summary */}
              {(from || to) && (
                <div className="fh-route"
                  style={{ background:`${t.accent}08`, border:`1.5px solid ${t.accent}33`, animation:"fhFadeUp .3s cubic-bezier(.16,.84,.44,1) both" }}>
                  <div style={{ fontSize:11, color:t.textDim, fontWeight:600, textTransform:"uppercase", letterSpacing:".08em" }}>Route</div>
                  {from && <span style={{ fontSize:13, fontWeight:600, color:t.text }}>{from}</span>}
                  {from && to && <span style={{ color:t.textDim }}>→</span>}
                  {to && <span style={{ fontSize:13, fontWeight:600, color:t.text }}>{to}</span>}
                  {date && <span style={{ fontSize:12, color:t.textSub, marginLeft:"auto" }}>{date}{checkout ? ` — ${checkout}` : ""}</span>}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ════════════════ DOC CHECKLIST ════════════════ */}
      {mainTab === "docs" && (
        <div className="fh-docs-layout">
          {/* Left / main — checklist */}
          <div className="fh-docs-left fh-pad" style={{ flex:1 }}>
            {/* Progress */}
            <div style={{ marginBottom:20 }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:10 }}>
                <div>
                  <div style={{ fontSize:15, fontWeight:700, color:t.text }}>Document Checklist</div>
                  <div style={{ fontSize:12, color:t.textDim, marginTop:2 }}>{checkedCount} of {DOC_CHECKLIST.length} ready</div>
                </div>
                <div style={{
                  fontSize:26, fontWeight:800, color: checkedCount === DOC_CHECKLIST.length ? t.emerald : t.accent,
                  fontVariantNumeric:"tabular-nums", transition:"color .3s",
                }}>
                  {Math.round(checkedCount / DOC_CHECKLIST.length * 100)}%
                </div>
              </div>
              <div style={{ height:6, background:t.border, borderRadius:99, overflow:"hidden" }}>
                <div style={{ height:"100%", width:`${checkedCount / DOC_CHECKLIST.length * 100}%`, background:`linear-gradient(90deg,${t.accent},${t.emerald})`, borderRadius:99, transition:"width .5s cubic-bezier(.16,.84,.44,1)" }}/>
              </div>
            </div>

            {docGroups.map(group => (
              <div key={group} style={{ marginBottom:18 }}>
                <div style={{ fontSize:10, fontWeight:700, color:t.textDim, textTransform:"uppercase", letterSpacing:".1em", marginBottom:8 }}>{group}</div>
                {DOC_CHECKLIST.filter(d => d.group === group).map((doc, i) => (
                  <div key={doc.id} onClick={() => toggleDoc(doc.id)}
                    className="fh-docrow"
                    style={{
                      display:"flex", alignItems:"center", gap:12,
                      padding:"12px 14px", borderRadius:10, cursor:"pointer",
                      marginBottom:7,
                      background: docChecked[doc.id] ? `${t.emerald}0D` : t.surface,
                      border: `1.5px solid ${docChecked[doc.id] ? t.emerald + "44" : t.border}`,
                      boxShadow: dark ? "none" : "0 1px 3px rgba(30,60,120,0.05)",
                      animation: `fhFadeUp .24s cubic-bezier(.16,.84,.44,1) ${i * 30}ms both`,
                      minHeight: 52, // comfortable touch target
                    }}>
                    <div style={{
                      width:24, height:24, borderRadius:7, flexShrink:0,
                      border: `2px solid ${docChecked[doc.id] ? t.emerald : t.border}`,
                      background: docChecked[doc.id] ? t.emerald : "transparent",
                      display:"flex", alignItems:"center", justifyContent:"center",
                      fontSize:13, color:"#fff", fontWeight:700, transition:"all .2s",
                    }}>
                      {docChecked[doc.id] ? "✓" : ""}
                    </div>
                    <span style={{
                      fontSize:14, color:t.text,
                      textDecoration: docChecked[doc.id] ? "line-through" : "none",
                      opacity: docChecked[doc.id] ? 0.55 : 1,
                      transition:"all .2s", lineHeight:1.4,
                    }}>{doc.label}</span>
                  </div>
                ))}
              </div>
            ))}
          </div>

          {/* Right — tips (desktop only, hidden on mobile via CSS) */}
          <div className="fh-docs-right fh-pad" style={{ background: dark ? t.surface : "#F4F7FD" }}>
            <div style={{ fontSize:15, fontWeight:700, color:t.text, marginBottom:6 }}>Why documents matter</div>
            <div style={{ fontSize:13, color:t.textSub, lineHeight:1.7, marginBottom:20 }}>
              Carrying the right documents prevents delays at immigration, enables emergency assistance, and ensures your trip goes smoothly.
            </div>
            {[
              ["Passport", "Must be valid for at least 6 months beyond your travel dates. Some countries require a blank visa page."],
              ["Visa", "Check requirements well in advance — e-Visas can take 24–72 hours. Print the approval letter."],
              ["Insurance", "Cover medical emergencies, trip cancellation, and lost luggage. Keep the policy number accessible."],
              ["Forex", "Notify your bank before travelling internationally to avoid card blocks."],
            ].map(([title, body], i) => (
              <div key={i} style={{
                marginBottom:12, padding:"13px 15px",
                background: t.card, border: `1.5px solid ${t.border}`,
                borderRadius:12, borderLeft:`3px solid ${t.accent}`,
                animation:`fhFadeUp .26s cubic-bezier(.16,.84,.44,1) ${i*50}ms both`,
              }}>
                <div style={{ fontSize:13, fontWeight:600, color:t.text, marginBottom:4 }}>{title}</div>
                <div style={{ fontSize:12, color:t.textSub, lineHeight:1.6 }}>{body}</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ════════════════ HELPLINES ════════════════ */}
      {mainTab === "help" && (
        <div style={{ flex:1, overflow:"hidden", display:"flex", flexDirection:"column" }}>
          {/* Toggle bar */}
          <div style={{ padding:"12px 14px", borderBottom:`1px solid ${t.border}`, display:"flex", gap:8, flexShrink:0 }}>
            {[["national","🇮🇳 India"],["intl","🌍 International"]].map(([id, label]) => (
              <button key={id} onClick={() => setHelpTab(id)}
                style={{
                  flex:1, padding:"10px 12px", borderRadius:9,
                  background: helpTab===id ? t.accent : t.surface,
                  color: helpTab===id ? "#fff" : t.textSub,
                  border: `1.5px solid ${helpTab===id ? t.accent : t.border}`,
                  fontSize:13, cursor:"pointer", fontFamily:"inherit",
                  fontWeight: helpTab===id ? 600 : 400, transition:"all .18s",
                  boxShadow: helpTab===id ? `0 4px 14px ${t.accent}33` : "none",
                  minHeight:44,
                }}>
                {label}
              </button>
            ))}
          </div>

          <div style={{ flex:1, overflowY:"auto", WebkitOverflowScrolling:"touch" }}>
            <div className="fh-pad">
              <div className="fh-helpgrid">
                {HELPLINES[helpTab].map((h, i) => (
                  <a key={h.name} href={`tel:${h.no}`}
                    className="fh-helpcard"
                    style={{
                      background: t.card,
                      border: `1.5px solid ${t.border}`,
                      borderRadius:14, padding:"18px 16px",
                      textDecoration:"none", display:"flex",
                      flexDirection:"column", gap:5,
                      boxShadow: dark ? "none" : "0 2px 8px rgba(30,60,120,0.06)",
                      animation:`fhFadeUp .26s cubic-bezier(.16,.84,.44,1) ${i*35}ms both`,
                    }}>
                    <div style={{ fontSize:10, fontWeight:600, color:t.textDim, textTransform:"uppercase", letterSpacing:".08em", lineHeight:1.4 }}>{h.name}</div>
                    <div style={{ fontSize:26, fontWeight:800, color:t.accent, fontFamily:"'Space Mono',monospace", lineHeight:1.1 }}>{h.no}</div>
                    <div style={{ fontSize:11, color:t.textDim, marginTop:2 }}>📞 Tap to call</div>
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}