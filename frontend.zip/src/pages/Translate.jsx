import { useState, useRef, useEffect, useCallback } from "react";
import { DARK, LIGHT } from "../styles/theme";
import { Spinner } from "../components/UI";
import { cacheGet, cacheSet } from "../utils/offline";

const LANGS = [
  {code:"ar",name:"Arabic",        native:"العربية"},
  {code:"bn",name:"Bengali",       native:"বাংলা"},
  {code:"zh",name:"Chinese",       native:"中文"},
  {code:"nl",name:"Dutch",         native:"Nederlands"},
  {code:"en",name:"English",       native:"English"},
  {code:"fr",name:"French",        native:"Français"},
  {code:"de",name:"German",        native:"Deutsch"},
  {code:"el",name:"Greek",         native:"Ελληνικά"},
  {code:"gu",name:"Gujarati",      native:"ગુજરાતી"},
  {code:"he",name:"Hebrew",        native:"עברית"},
  {code:"hi",name:"Hindi",         native:"हिंदी"},
  {code:"id",name:"Indonesian",    native:"Bahasa Indonesia"},
  {code:"it",name:"Italian",       native:"Italiano"},
  {code:"ja",name:"Japanese",      native:"日本語"},
  {code:"kn",name:"Kannada",       native:"ಕನ್ನಡ"},
  {code:"ko",name:"Korean",        native:"한국어"},
  {code:"ml",name:"Malayalam",     native:"മലയാളം"},
  {code:"ms",name:"Malay",         native:"Bahasa Melayu"},
  {code:"mr",name:"Marathi",       native:"मराठी"},
  {code:"pl",name:"Polish",        native:"Polski"},
  {code:"pt",name:"Portuguese",    native:"Português"},
  {code:"pa",name:"Punjabi",       native:"ਪੰਜਾਬੀ"},
  {code:"ru",name:"Russian",       native:"Русский"},
  {code:"es",name:"Spanish",       native:"Español"},
  {code:"sw",name:"Swahili",       native:"Kiswahili"},
  {code:"ta",name:"Tamil",         native:"தமிழ்"},
  {code:"te",name:"Telugu",        native:"తెలుగు"},
  {code:"th",name:"Thai",          native:"ภาษาไทย"},
  {code:"tr",name:"Turkish",       native:"Türkçe"},
  {code:"ur",name:"Urdu",          native:"اردو"},
  {code:"vi",name:"Vietnamese",    native:"Tiếng Việt"},
];

const PHRASE_CATEGORIES = {
  "Offline Pack":  ["Hello","Thank you","Please","Where is the station?","How much does this cost?","I need help","Call a taxi","I am allergic to peanuts","Where is the hospital?","I need vegetarian food","Can you show me on the map?","I do not understand","Do you speak English?","Can I pay by card?","I need internet"],
  "Basic":         ["Hello","Thank you very much","I don't understand","Please speak slowly","How much does this cost?","Do you speak English?","Yes","No","Excuse me"],
  "Accommodation": ["Where is the nearest hotel?","Do you have any rooms available?","How much per night?","Is breakfast included?","Can I get a late checkout?","I have a reservation"],
  "Food & Dining": ["Is this food vegetarian?","I am allergic to peanuts","Can I have the bill please?","No spice please","What do you recommend?","Water please"],
  "Transport":     ["I need a taxi","How do I get to the airport?","Stop here please","How much to the city centre?","Is this the right bus?","Train station please"],
  "Emergency":     ["I need a doctor urgently","Please call the police","Call an ambulance","I am lost","I need help","Where is the hospital?"],
  "Money":         ["Where is the nearest ATM?","Can I pay by card?","That is too expensive","Do you have change?","Where is the nearest pharmacy?"],
};

const QUICK_PHRASES = ["Hello","Help","Thank you","How much?","Where?","Sorry"];

async function translateViaGoogle(text, source, target) {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${source}&tl=${target}&dt=t&q=${encodeURIComponent(text)}`;
  const r = await fetch(url);
  if (!r.ok) throw new Error("Google translate failed");
  const d = await r.json();
  if (!d?.[0]) throw new Error("Empty response");
  const translated = d[0].map(chunk => chunk[0] || "").join("").trim();
  if (!translated) throw new Error("Empty translation");
  return translated;
}

async function translateViaMyMemory(text, source, target) {
  const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${source}|${target}`;
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const r = await fetch(url, { signal: controller.signal });
    clearTimeout(timer);
    if (!r.ok) throw new Error("MyMemory error");
    const d = await r.json();
    if (d.responseStatus !== 200) throw new Error(d.responseDetails || "MyMemory failed");
    const tr = d.responseData?.translatedText?.trim();
    if (!tr || tr.toUpperCase() === text.toUpperCase()) throw new Error("Translation echoed");
    const nonLatin = ["hi","ta","te","ml","kn","bn","mr","gu","pa","ur","ja","zh","ko","ar","ru","th","he","el"].includes(target);
    if (nonLatin) {
      const ratio = (tr.match(/[a-zA-Z]/g) || []).length / tr.length;
      if (ratio > 0.7) throw new Error("Romanized output");
    }
    return tr;
  } catch(e) { clearTimeout(timer); throw e; }
}

async function translateText(text, src, tgt) {
  if (!text.trim()) throw new Error("No text provided");
  try { return await translateViaGoogle(text, src, tgt); } catch {}
  try { return await translateViaMyMemory(text, src, tgt); } catch {}
  throw new Error("Translation failed — check your internet connection.");
}

function speak(text, lang) {
  if (!window.speechSynthesis) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = lang; u.rate = 0.88;
  window.speechSynthesis.speak(u);
}

function LoadingBar({ active, color }) {
  return (
    <div style={{
      position:"absolute",top:0,left:0,right:0,height:2,
      overflow:"hidden",borderRadius:"0",
      opacity:active?1:0,transition:"opacity .3s",pointerEvents:"none",zIndex:10,
    }}>
      <div style={{
        width:"35%",height:"100%",background:color,borderRadius:2,
        animation:active?"trBarSlide 1.3s ease-in-out infinite":"none",
      }}/>
    </div>
  );
}

export default function Translate({ dark = true }) {
  const t = dark ? DARK : LIGHT;

  const [leftText,    setLeftText]    = useState("");
  const [rightText,   setRightText]   = useState("");
  const [sourceLang,  setSourceLang]  = useState("en");
  const [lang,        setLang]        = useState("hi");
  const [loadingL,    setLoadingL]    = useState(false); // left→right
  const [loadingR,    setLoadingR]    = useState(false); // right→left
  const [bulkResults, setBulkResults] = useState({});
  const [bulkLoading, setBulkLoading] = useState(false);
  const [bulkCat,     setBulkCat]     = useState("Basic");
  const [tab,         setTab]         = useState("translate");
  const [copiedL,     setCopiedL]     = useState(false);
  const [copiedR,     setCopiedR]     = useState(false);
  const [history,     setHistory]     = useState([]);
  const [listeningL,  setListeningL]  = useState(false);
  const [listeningR,  setListeningR]  = useState(false);
  const [errL,        setErrL]        = useState("");
  const [errR,        setErrR]        = useState("");
  const [phrasebook,  setPhrasebook]  = useState({});
  const [leftVer,     setLeftVer]     = useState(0);
  const [rightVer,    setRightVer]    = useState(0);
  const recRefL     = useRef(null);
  const recRefR     = useRef(null);
  const leftRef     = useRef(null);
  const rightRef    = useRef(null);
  const debLRef     = useRef(null); // debounce timer left→right
  const debRRef     = useRef(null); // debounce timer right→left
  // Keep backward-compat aliases used by phrasebook/history tabs
  const text        = leftText;
  const setText     = setLeftText;
  const result      = rightText;
  const loading     = loadingL;
  const err         = errL;

  useEffect(() => {
    cacheGet("translate_history").then(h => h && setHistory(h));
    cacheGet("translate_phrasebook").then(p => p && setPhrasebook(p));
  }, []);

  const langInfo       = LANGS.find(l => l.code === lang) || LANGS[0];
  const sourceLangInfo = LANGS.find(l => l.code === sourceLang) || LANGS.find(l => l.code === "en");

  const swapLangs = () => {
    const prevSource = sourceLang, prevTarget = lang;
    const prevLeft = leftText, prevRight = rightText;
    setSourceLang(prevTarget);
    setLang(prevTarget === prevSource ? "en" : prevSource);
    setLeftText(prevRight);
    setRightText(prevLeft);
    setErrL(""); setErrR("");
  };

  // Left → Right (sourceLang → lang)
  const translateLeft = useCallback(async (val, src, tgt) => {
    const v = (val ?? leftText).trim();
    if (!v) { setRightText(""); return; }
    setLoadingL(true); setErrL("");
    try {
      const translated = await translateText(v, src ?? sourceLang, tgt ?? lang);
      setRightText(translated);
      setRightVer(n => n + 1);
      const srcLI = LANGS.find(l => l.code === (src ?? sourceLang));
      const tgtLI = LANGS.find(l => l.code === (tgt ?? lang));
      const entry = { src: v, result: translated, from: srcLI?.name, to: tgtLI?.name, fromCode: src ?? sourceLang, toCode: tgt ?? lang, ts: new Date().toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit" }) };
      setHistory(h => { const n = [entry, ...h].slice(0,50); cacheSet("translate_history", n); return n; });
    } catch(ex) { setErrL(ex.message); }
    finally { setLoadingL(false); }
  }, [leftText, sourceLang, lang]);

  // Right → Left (lang → sourceLang)
  const translateRight = useCallback(async (val, src, tgt) => {
    const v = (val ?? rightText).trim();
    if (!v) { setLeftText(""); return; }
    setLoadingR(true); setErrR("");
    try {
      const translated = await translateText(v, src ?? lang, tgt ?? sourceLang);
      setLeftText(translated);
      setLeftVer(n => n + 1);
      const srcLI = LANGS.find(l => l.code === (src ?? lang));
      const tgtLI = LANGS.find(l => l.code === (tgt ?? sourceLang));
      const entry = { src: v, result: translated, from: srcLI?.name, to: tgtLI?.name, fromCode: src ?? lang, toCode: tgt ?? sourceLang, ts: new Date().toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit" }) };
      setHistory(h => { const n = [entry, ...h].slice(0,50); cacheSet("translate_history", n); return n; });
    } catch(ex) { setErrR(ex.message); }
    finally { setLoadingR(false); }
  }, [rightText, lang, sourceLang]);

  // Debounced auto-translate — fires 800ms after last keystroke
  const onLeftChange = (val) => {
    setLeftText(val);
    setRightText(""); setErrL("");
    clearTimeout(debLRef.current);
    if (val.trim()) debLRef.current = setTimeout(() => translateLeft(val), 800);
  };
  const onRightChange = (val) => {
    setRightText(val);
    setLeftText(""); setErrR("");
    clearTimeout(debRRef.current);
    if (val.trim()) debRRef.current = setTimeout(() => translateRight(val), 800);
  };

  // Compat alias for phrasebook/history tabs
  const doTranslate = () => translateLeft();

  const doBulk = async () => {
    setBulkLoading(true);
    const phrases = PHRASE_CATEGORIES[bulkCat] || [];
    const out = { ...bulkResults };
    for (const phrase of phrases) {
      const key = `${bulkCat}||${lang}||${phrase}`;
      if (out[key]) continue;
      try { out[key] = await translateText(phrase, "en", lang); setBulkResults({ ...out }); }
      catch { out[key] = "—"; setBulkResults({ ...out }); }
      await new Promise(r => setTimeout(r, 180));
    }
    const pb = { ...phrasebook, ...out };
    setPhrasebook(pb); cacheSet("translate_phrasebook", pb);
    setBulkLoading(false);
  };

  const startListen = (side) => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { alert("Voice input requires Chrome or Edge"); return; }
    const isLeft = side === "L";
    const langCode = isLeft ? sourceLang : lang;
    const r = new SR();
    r.lang = langCode === "en" ? "en-IN" : langCode === "zh" ? "zh-CN" : langCode;
    r.onstart  = () => isLeft ? setListeningL(true)  : setListeningR(true);
    r.onend    = () => isLeft ? setListeningL(false) : setListeningR(false);
    r.onresult = e => {
      const transcript = e.results[0][0].transcript;
      if (isLeft) { onLeftChange(transcript);  leftRef.current?.focus(); }
      else        { onRightChange(transcript); rightRef.current?.focus(); }
    };
    r.onerror = () => isLeft ? setListeningL(false) : setListeningR(false);
    if (isLeft) recRefL.current = r; else recRefR.current = r;
    r.start();
  };

  const copy = (str, side) => {
    navigator.clipboard?.writeText(str);
    if (side === "L") { setCopiedL(true); setTimeout(() => setCopiedL(false), 1600); }
    else               { setCopiedR(true); setTimeout(() => setCopiedR(false), 1600); }
  };

  const selSt = {
    background: t.surface, border: `1px solid ${t.border}`,
    borderRadius: 8, padding: "8px 13px", color: t.text,
    fontSize: 13, fontFamily: "inherit", outline: "none", cursor: "pointer",
    transition: "border-color .18s",
  };

  const ghostBtn = (active, danger) => ({
    padding: "6px 14px", borderRadius: 7, fontSize: 12, fontWeight: 500,
    cursor: "pointer", fontFamily: "inherit",
    background: active && !danger ? `${t.accent}12` : active && danger ? `${t.red}12` : "transparent",
    color: active && !danger ? t.accent : active && danger ? t.red : t.textSub,
    border: `1px solid ${active && !danger ? t.accent+"44" : active && danger ? t.red+"44" : t.border}`,
    transition: "all .18s",
  });

  const TABS = [
    ["translate", "Translate"],
    ["phrases",   "Phrasebook"],
    ["history",   history.length > 0 ? `History (${history.length})` : "History"],
  ];

  return (
    <div className="translate-page" style={{ display:"flex", flexDirection:"column", minHeight:"calc(100vh - 140px)", overflow:"hidden", position:"relative" }}>
      <style>{`
        @keyframes trBarSlide { 0%{transform:translateX(-200%)} 100%{transform:translateX(400%)} }
        @keyframes trFadeUp { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
        @keyframes trTabLine { from{transform:scaleX(0)} to{transform:scaleX(1)} }
        @keyframes trPulseBar { 0%,100%{transform:scaleY(.6)} 50%{transform:scaleY(1)} }
        /* ── Mobile responsive ── */
        @media (max-width: 640px) {
          .tr-twocol { grid-template-columns: 1fr !important; grid-template-rows: auto auto; }
          .tr-twocol > div:first-child { border-right: none !important; border-bottom: 1px solid var(--border,#241850); }
          .tr-swap-fab { position: relative !important; top: auto !important; left: auto !important; bottom: auto !important; transform: none !important; margin: -16px auto !important; z-index: 50 !important; }
          .tr-header-row { flex-direction: column !important; align-items: flex-start !important; gap: 10px !important; }
          .tr-header-row > div:last-child { width: 100% !important; justify-content: space-between !important; }
          .tr-phrasebook-grid { grid-template-columns: 1fr !important; }
          .tr-phrasebook-sidebar { display: flex !important; flex-direction: row !important; overflow-x: auto !important; border-right: none !important; border-bottom: 1px solid var(--border,#241850) !important; padding: 8px !important; gap: 6px !important; flex-wrap: nowrap !important; }
          .tr-phrasebook-sidebar button { white-space: nowrap !important; flex-shrink: 0 !important; }
          .tr-tab { padding: 10px 12px !important; font-size: 12px !important; }
        }
        .tr-tab { position:relative; padding:14px 20px; border:none; background:transparent; font-family:inherit; cursor:pointer; font-size:13px; letter-spacing:.01em; transition:color .18s; }
        .tr-tab::after { content:''; position:absolute; bottom:-1px; left:20px; right:20px; height:2px; border-radius:2px; background:${t.accent}; transform:scaleX(0); transition:transform .22s cubic-bezier(.16,.84,.44,1); }
        .tr-tab.active::after { transform:scaleX(1); }
        .tr-sel:hover { border-color:${t.accent}66 !important; }
        .tr-swap:hover { background:${t.accent}15 !important; transform:rotate(180deg) !important; color:${t.accent} !important; }
        .tr-chip:hover { border-color:${t.accent}55 !important; color:${t.accent} !important; }
        .tr-ibtn:hover { background:${t.surface} !important; border-color:${t.borderLight} !important; color:${t.text} !important; }
        .tr-phrase:hover { background:${t.cardHover} !important; border-color:${t.borderLight} !important; }
        .tr-hist:hover { background:${t.cardHover} !important; }
        .tr-catbtn:hover { background:${t.accent}0A !important; color:${t.text} !important; }
        .tr-primary { background:${t.accent}; color:#fff; border:none; border-radius:8px; padding:9px 22px; font-size:13px; font-weight:600; font-family:inherit; cursor:pointer; transition:all .18s; letter-spacing:.01em; }
        .tr-primary:hover:not(:disabled) { opacity:.86; transform:translateY(-1px); }
        .tr-primary:active { transform:translateY(0); }
        .tr-primary:disabled { opacity:.4; cursor:not-allowed; transform:none; }
        .tr-danger:hover { background:${t.red}12 !important; color:${t.red} !important; border-color:${t.red}44 !important; }
      `}</style>

      {/* ── Top chrome ── */}
      <div style={{ flexShrink:0, background:t.card, borderBottom:`1px solid ${t.border}` }}>

        {/* Header + language selectors */}
        <div className="tr-header-row" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"18px 28px 16px", flexWrap:"wrap", gap:10 }}>
          <div>
            <div style={{ fontSize:22, fontWeight:700, color:t.text, letterSpacing:"-.02em", lineHeight:1.1 }}>
              Translator
            </div>
            <div style={{ fontSize:12, color:t.textDim, marginTop:3, letterSpacing:".02em" }}>
              30 languages — phrasebook, voice input, offline cache
            </div>
          </div>

          <div style={{ display:"flex", alignItems:"center", gap:10 }}>
            <span style={{ fontSize:12, color:t.textDim }}>
              {sourceLangInfo.name} ⇄ {langInfo.name}
            </span>
            <button onClick={swapLangs} className="tr-swap" title="Swap languages"
              style={{ width:32, height:32, borderRadius:8, background:t.surface, border:`1px solid ${t.border}`, color:t.textSub, cursor:"pointer", fontSize:15, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0, transition:"all .28s cubic-bezier(.16,.84,.44,1)" }}>⇄</button>
          </div>
        </div>

        {/* Tabs */}
        <div className="tr-tabbar" style={{ display:"flex", padding:"0 8px", borderTop:`1px solid ${t.border}`, flexWrap:"wrap", gap:4 }}>
          {TABS.map(([id, label]) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`tr-tab ${tab === id ? "active" : ""}`}
              style={{
                color: tab === id ? t.accent : t.textSub,
                fontWeight: tab === id ? 600 : 400,
              }}
            >
              {label}
              <span style={{ display:"block", position:"absolute", bottom:-1, left:20, right:20, height:2, borderRadius:2, background:t.accent, transform: tab===id ? "scaleX(1)" : "scaleX(0)", transition:"transform .22s cubic-bezier(.16,.84,.44,1)" }}/>
            </button>
          ))}
        </div>
      </div>

      {/* ── TRANSLATE TAB — two-way split ── */}
      {tab === "translate" && (
        <div className="tr-twocol" style={{ flex:1 }}>

          {/* ── LEFT PANE (sourceLang) ── */}
          <div style={{ display:"flex", flexDirection:"column", borderRight:`1px solid ${t.border}`, position:"relative" }}>
            <LoadingBar active={loadingL} color={t.accent} />

            {/* Pane header */}
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 16px", borderBottom:`1px solid ${t.border}`, flexShrink:0, gap:8 }}>
              <select value={sourceLang} onChange={e => { setSourceLang(e.target.value); setErrL(""); setErrR(""); }}
                style={{ ...selSt, fontSize:12, padding:"5px 10px", flex:1 }} className="tr-sel">
                {LANGS.map(l => <option key={l.code} value={l.code}>{l.name} — {l.native}</option>)}
              </select>
              <button
                onClick={listeningL ? () => { recRefL.current?.stop(); setListeningL(false); } : () => startListen("L")}
                style={{ ...ghostBtn(listeningL, listeningL), fontSize:11, padding:"5px 10px", flexShrink:0 }}>
                {listeningL ? "⏹ Stop" : "🎤 Voice"}
              </button>
            </div>

            {/* Textarea */}
            <textarea
              ref={leftRef}
              key={leftVer}
              value={leftText}
              onChange={e => onLeftChange(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && e.ctrlKey) { e.preventDefault(); translateLeft(); } }}
              placeholder={`Type in ${sourceLangInfo.name}…`}
              style={{ flex:1, background:"transparent", border:"none", padding:"18px 20px", color:t.text, fontSize:16, outline:"none", resize:"none", fontFamily:"inherit", lineHeight:1.8, caretColor:t.accent }}
            />

            {/* Listening animation */}
            {listeningL && (
              <div style={{ position:"absolute", bottom:64, left:0, right:0, display:"flex", justifyContent:"center", pointerEvents:"none" }}>
                <div style={{ display:"flex", gap:4, alignItems:"flex-end", background:t.card, padding:"8px 16px", borderRadius:999, border:`1px solid ${t.red}33` }}>
                  {[0,1,2,3,4].map(i => <div key={i} style={{ width:3, borderRadius:2, background:t.red, height:`${10+(i%3)*8}px`, animation:`trPulseBar ${0.6+i*0.08}s ease-in-out ${i*0.06}s infinite` }}/>)}
                  <span style={{ marginLeft:8, fontSize:11, color:t.red, fontWeight:500 }}>Listening</span>
                </div>
              </div>
            )}

            {errL && <div style={{ padding:"8px 20px", fontSize:11, color:t.red, borderTop:`1px solid ${t.red}22`, background:`${t.red}07`, flexShrink:0 }}>{errL}</div>}

            {/* Bottom bar */}
            <div className="tr-bottom-bar" style={{ padding:"8px 16px", borderTop:`1px solid ${t.border}`, display:"flex", justifyContent:"space-between", alignItems:"center", flexShrink:0, gap:8 }}>
              <div className="tr-quick" style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
                {QUICK_PHRASES.map(p => (
                  <button key={p} onClick={() => onLeftChange(p)} className="tr-chip"
                    style={{ padding:"3px 9px", borderRadius:6, background:"transparent", border:`1px solid ${t.border}`, color:t.textDim, cursor:"pointer", fontSize:10, fontFamily:"inherit", transition:"all .15s" }}>
                    {p}
                  </button>
                ))}
              </div>
              <div className="tr-actions" style={{ display:"flex", gap:6, flexShrink:0, alignItems:"center" }}>
                {leftText && <button onClick={() => speak(leftText, sourceLang)} style={{ ...ghostBtn(false), fontSize:11, padding:"4px 10px" }} className="tr-ibtn">▶ Play</button>}
                {leftText && <button onClick={() => copy(leftText, "L")} style={{ ...ghostBtn(copiedL), fontSize:11, padding:"4px 10px" }} className="tr-ibtn">{copiedL ? "✓ Copied" : "Copy"}</button>}
                <span style={{ fontSize:10, color:leftText.length>1800?t.red:t.textDim }}>{leftText.length}</span>
                <button className="tr-primary" onClick={() => translateLeft()} disabled={loadingL || !leftText.trim()} style={{ fontSize:12, padding:"6px 16px" }}>
                  {loadingL ? <span style={{ display:"flex",alignItems:"center",gap:6 }}><span style={{ width:10,height:10,border:"2px solid #fff4",borderTopColor:"#fff",borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite" }}/>…</span> : "→"}
                </button>
              </div>
            </div>
          </div>

          {/* ── SWAP BUTTON (centre) ── */}
          <div className="tr-swap-fab" style={{ position:"absolute", left:"50%", top:"50%", transform:"translate(-50%,-50%)", zIndex:20, pointerEvents:"none", display:"flex", justifyContent:"center" }}>
            <button onClick={swapLangs} className="tr-swap" title="Swap languages"
              style={{ width:32, height:32, borderRadius:"50%", background:t.card, border:`1px solid ${t.accent}55`, color:t.accent, cursor:"pointer", fontSize:14, display:"flex", alignItems:"center", justifyContent:"center", pointerEvents:"all", boxShadow:`0 0 12px ${t.accent}22` }}>
              ⇄
            </button>
          </div>

          {/* ── RIGHT PANE (lang) ── */}
          <div style={{ display:"flex", flexDirection:"column", position:"relative", overflow:"hidden" }}>
            <LoadingBar active={loadingR} color={t.accent} />

            {/* Pane header */}
            <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"10px 16px", borderBottom:`1px solid ${t.border}`, flexShrink:0, gap:8, background: rightText ? `${t.accent}06` : "transparent", transition:"background .4s" }}>
              <select value={lang} onChange={e => { setLang(e.target.value); setBulkResults({}); setErrL(""); setErrR(""); }}
                style={{ ...selSt, fontSize:12, padding:"5px 10px", flex:1, borderColor:`${t.accent}55` }} className="tr-sel">
                {LANGS.filter(l => l.code !== sourceLang).map(l => <option key={l.code} value={l.code}>{l.name} — {l.native}</option>)}
              </select>
              <button
                onClick={listeningR ? () => { recRefR.current?.stop(); setListeningR(false); } : () => startListen("R")}
                style={{ ...ghostBtn(listeningR, listeningR), fontSize:11, padding:"5px 10px", flexShrink:0 }}>
                {listeningR ? "⏹ Stop" : "🎤 Voice"}
              </button>
            </div>

            {/* Editable output textarea */}
            <textarea
              ref={rightRef}
              key={rightVer}
              value={rightText}
              onChange={e => onRightChange(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && e.ctrlKey) { e.preventDefault(); translateRight(); } }}
              placeholder={loadingL ? `Translating to ${langInfo.name}…` : `Or type in ${langInfo.name} to translate back…`}
              style={{ flex:1, background:"transparent", border:"none", padding:"18px 20px", color:t.text, fontSize: rightText ? 20 : 15, outline:"none", resize:"none", fontFamily:"inherit", lineHeight:1.8, caretColor:t.accent, transition:"font-size .2s" }}
            />

            {/* Listening animation */}
            {listeningR && (
              <div style={{ position:"absolute", bottom:64, left:0, right:0, display:"flex", justifyContent:"center", pointerEvents:"none" }}>
                <div style={{ display:"flex", gap:4, alignItems:"flex-end", background:t.card, padding:"8px 16px", borderRadius:999, border:`1px solid ${t.red}33` }}>
                  {[0,1,2,3,4].map(i => <div key={i} style={{ width:3, borderRadius:2, background:t.red, height:`${10+(i%3)*8}px`, animation:`trPulseBar ${0.6+i*0.08}s ease-in-out ${i*0.06}s infinite` }}/>)}
                  <span style={{ marginLeft:8, fontSize:11, color:t.red, fontWeight:500 }}>Listening</span>
                </div>
              </div>
            )}

            {errR && <div style={{ padding:"8px 20px", fontSize:11, color:t.red, borderTop:`1px solid ${t.red}22`, background:`${t.red}07`, flexShrink:0 }}>{errR}</div>}

            {/* Bottom bar */}
            <div className="tr-bottom-bar" style={{ padding:"8px 16px", borderTop:`1px solid ${t.border}`, display:"flex", justifyContent:"space-between", alignItems:"center", flexShrink:0, gap:8 }}>
              <div className="tr-quick" style={{ display:"flex", gap:4, flexWrap:"wrap" }}>
                {QUICK_PHRASES.map(p => (
                  <button key={p} onClick={() => onRightChange(p)} className="tr-chip"
                    style={{ padding:"3px 9px", borderRadius:6, background:"transparent", border:`1px solid ${t.border}`, color:t.textDim, cursor:"pointer", fontSize:10, fontFamily:"inherit", transition:"all .15s" }}>
                    {p}
                  </button>
                ))}
              </div>
              <div className="tr-actions" style={{ display:"flex", gap:6, flexShrink:0, alignItems:"center" }}>
                {rightText && <button onClick={() => speak(rightText, lang)} style={{ ...ghostBtn(false), fontSize:11, padding:"4px 10px" }} className="tr-ibtn">▶ Play</button>}
                {rightText && <button onClick={() => copy(rightText, "R")} style={{ ...ghostBtn(copiedR), fontSize:11, padding:"4px 10px" }} className="tr-ibtn">{copiedR ? "✓ Copied" : "Copy"}</button>}
                <span style={{ fontSize:10, color:rightText.length>1800?t.red:t.textDim }}>{rightText.length}</span>
                <button className="tr-primary" onClick={() => translateRight()} disabled={loadingR || !rightText.trim()} style={{ fontSize:12, padding:"6px 16px" }}>
                  {loadingR ? <span style={{ display:"flex",alignItems:"center",gap:6 }}><span style={{ width:10,height:10,border:"2px solid #fff4",borderTopColor:"#fff",borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite" }}/>…</span> : "←"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ── PHRASEBOOK TAB — sidebar + list ── */}
      {tab === "phrases" && (
        <div className="tr-phrasebook-grid" style={{ flex:1 }}>

          {/* Category nav */}
          <div className="tr-phrasebook-sidebar" style={{ borderRight:`1px solid ${t.border}`, padding:"16px 8px", display:"flex", flexDirection:"column", gap:2, overflowY:"auto" }}>
            <div style={{ fontSize:10, fontWeight:700, color:t.textDim, textTransform:"uppercase", letterSpacing:".1em", padding:"4px 12px", marginBottom:6 }}>
              Categories
            </div>
            {Object.keys(PHRASE_CATEGORIES).map(cat => (
              <button key={cat} onClick={() => setBulkCat(cat)} className="tr-catbtn"
                style={{
                  padding:"9px 14px", borderRadius:8, border:"none",
                  background: bulkCat === cat ? `${t.accent}12` : "transparent",
                  color: bulkCat === cat ? t.accent : t.textSub,
                  cursor:"pointer", fontFamily:"inherit", fontSize:13,
                  fontWeight: bulkCat === cat ? 600 : 400,
                  textAlign:"left", transition:"all .15s",
                  borderLeft: `3px solid ${bulkCat === cat ? t.accent : "transparent"}`,
                }}>
                {cat}
              </button>
            ))}
          </div>

          {/* Phrase list */}
          <div style={{ display:"flex", flexDirection:"column", overflow:"hidden" }}>
            <div style={{ padding:"16px 28px", borderBottom:`1px solid ${t.border}`, display:"flex", justifyContent:"space-between", alignItems:"center", flexShrink:0 }}>
              <div>
                <div style={{ fontSize:16, fontWeight:700, color:t.text }}>{bulkCat}</div>
                <div style={{ fontSize:12, color:t.textDim, marginTop:2 }}>{langInfo.name} — {langInfo.native}</div>
              </div>
              <button className="tr-primary" onClick={doBulk} disabled={bulkLoading}>
                {bulkLoading
                  ? <span style={{ display:"flex", alignItems:"center", gap:8 }}>
                      <span style={{ width:11, height:11, border:"2px solid #ffffff44", borderTopColor:"#fff", borderRadius:"50%", display:"inline-block", animation:"spin .7s linear infinite" }}/>
                      Translating…
                    </span>
                  : "Translate all"}
              </button>
            </div>

            <div style={{ flex:1, overflowY:"auto", padding:"14px 28px", display:"flex", flexDirection:"column", gap:6 }}>
              {(PHRASE_CATEGORIES[bulkCat] || []).map((phrase, i) => {
                const key = `${bulkCat}||${lang}||${phrase}`;
                const tr  = bulkResults[key] || phrasebook[key];
                return (
                  <div key={i} className="tr-phrase"
                    style={{
                      borderRadius:10, padding:"14px 20px",
                      display:"flex", justifyContent:"space-between", alignItems:"center", gap:16,
                      border:`1px solid ${t.border}`, background:t.surface,
                      animation:`trFadeUp .26s cubic-bezier(.16,.84,.44,1) ${Math.min(i,6)*30}ms both`,
                    }}>
                    <div style={{ flex:1, minWidth:0 }}>
                      <div style={{ fontSize:12, fontWeight:500, color:t.textDim, marginBottom:6, letterSpacing:".01em" }}>{phrase}</div>
                      {tr ? (
                        <div style={{ fontSize:16, color:t.text, fontWeight:400, lineHeight:1.55 }}>{tr}</div>
                      ) : bulkLoading ? (
                        <div style={{ height:14, width:"52%", borderRadius:4, background:t.border, animation:"pulse 1.5s ease-in-out infinite" }}/>
                      ) : (
                        <div style={{ fontSize:12, color:t.textDim, fontStyle:"italic" }}>Not yet translated</div>
                      )}
                    </div>
                    {tr && tr !== "—" && (
                      <div style={{ display:"flex", gap:6, flexShrink:0 }}>
                        <button onClick={() => speak(tr, lang)} style={ghostBtn(false)} className="tr-ibtn">Play</button>
                        <button onClick={() => copy(tr)} style={ghostBtn(false)} className="tr-ibtn">Copy</button>
                        <button onClick={() => { setLeftText(phrase); setRightText(""); setSourceLang("en"); setLang(lang); setTab("translate"); }} style={ghostBtn(false)} className="tr-ibtn">Edit</button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* ── HISTORY TAB ── */}
      {tab === "history" && (
        <div style={{ flex:1, display:"flex", flexDirection:"column", overflow:"hidden" }}>
          <div style={{ padding:"16px 28px", borderBottom:`1px solid ${t.border}`, display:"flex", justifyContent:"space-between", alignItems:"center", flexShrink:0 }}>
            <div>
              <div style={{ fontSize:16, fontWeight:700, color:t.text }}>Translation History</div>
              <div style={{ fontSize:12, color:t.textDim, marginTop:2 }}>{history.length} entries</div>
            </div>
            {history.length > 0 && (
              <button className="tr-danger"
                onClick={() => { setHistory([]); cacheSet("translate_history",[]); }}
                style={{
                  padding:"6px 14px", borderRadius:8, fontSize:12, fontWeight:500,
                  cursor:"pointer", fontFamily:"inherit",
                  background:"transparent", color:t.textSub,
                  border:`1px solid ${t.border}`, transition:"all .18s",
                }}>
                Clear all
              </button>
            )}
          </div>

          <div style={{ flex:1, overflowY:"auto", padding:"14px 28px", display:"flex", flexDirection:"column", gap:6 }}>
            {history.length === 0 ? (
              <div style={{ display:"flex", alignItems:"center", justifyContent:"center", height:"100%", flexDirection:"column", gap:10 }}>
                <div style={{ width:56, height:56, borderRadius:14, border:`1.5px solid ${t.border}`, display:"flex", alignItems:"center", justifyContent:"center" }}>
                  <div style={{ width:20, height:20, borderRadius:"50%", border:`1.5px solid ${t.border}` }}/>
                </div>
                <div style={{ fontSize:14, color:t.textSub, fontWeight:500 }}>No translations yet</div>
                <div style={{ fontSize:12, color:t.textDim }}>Your translation history will appear here</div>
              </div>
            ) : (
              history.map((h, i) => (
                <div key={i} className="tr-hist"
                  style={{
                    borderRadius:10, padding:"14px 20px",
                    display:"grid", gridTemplateColumns:"1fr auto",
                    gap:16, alignItems:"start",
                    border:`1px solid ${t.border}`, background:t.surface,
                    animation:`trFadeUp .22s cubic-bezier(.16,.84,.44,1) ${Math.min(i,8)*22}ms both`,
                  }}>
                  <div style={{ minWidth:0 }}>
                    <div style={{ fontSize:11, color:t.textDim, marginBottom:6, display:"flex", gap:12 }}>
                      <span>{h.ts}</span>
                      <span style={{ color:t.border }}>|</span>
                      <span>{h.from} → {h.to}</span>
                    </div>
                    <div style={{ fontSize:13, color:t.textSub, marginBottom:6, overflow:"hidden", textOverflow:"ellipsis", whiteSpace:"nowrap" }}>
                      {h.src}
                    </div>
                    <div style={{ fontSize:17, color:t.text, fontWeight:400, lineHeight:1.55, wordBreak:"break-word" }}>
                      {h.result}
                    </div>
                  </div>
                  <div style={{ display:"flex", gap:6, flexShrink:0 }}>
                    <button onClick={() => speak(h.result, h.toCode || lang)} style={ghostBtn(false)} className="tr-ibtn">Play</button>
                    <button onClick={() => { setLeftText(h.src); setRightText(""); setSourceLang(h.fromCode||"en"); setLang(h.toCode||lang); setTab("translate"); }} style={ghostBtn(false)} className="tr-ibtn">Retranslate</button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
}
