import { useState, useEffect, useMemo, useCallback } from "react";
import { tripsApi, expensesApi } from "../api/client";
import { Spinner } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";

const CAT_COLORS = {
  accommodation: "#FF6B2B", transport: "#00E5FF", food: "#FFD600",
  tickets: "#FF1744", shopping: "#D500F9", activities: "#00E676", other: "#7A869E",
};
const CAT_ICONS = {
  accommodation: "🏨", transport: "🚗", food: "🍽️",
  tickets: "🎟️", shopping: "🛍️", activities: "🎯", other: "📦",
};

function StatCard({ icon, label, value, sub, color, t }) {
  return (
    <div style={{
      background:t.card, border:`1px solid ${t.border}`,
      borderRadius:14, padding:"18px 20px",
      display:"flex", flexDirection:"column", gap:6,
      borderTop:`3px solid ${color}`,
      boxShadow:`0 0 20px ${color}10`,
    }}>
      <div style={{fontSize:26}}>{icon}</div>
      <div style={{fontSize:26,fontWeight:800,color:t.text,letterSpacing:"-.02em"}}>{value}</div>
      <div style={{fontSize:13,fontWeight:600,color:t.textSub}}>{label}</div>
      {sub&&<div style={{fontSize:11,color:t.textDim}}>{sub}</div>}
    </div>
  );
}

function DonutChart({ data, size=160, t }) {
  const total = data.reduce((s,d)=>s+d.value,0);
  if(!total) return <div style={{width:size,height:size,display:"flex",alignItems:"center",justifyContent:"center",color:t.textDim,fontSize:12}}>No data</div>;
  let cum=0;
  const cx=size/2,cy=size/2,r=size*.4,inn=size*.24;
  const slices=data.map(d=>{const s=cum;cum+=d.value/total;return{...d,s,e:cum};});
  const arc=(s,e)=>{
    const a=v=>({x:cx+r*Math.cos(2*Math.PI*v-Math.PI/2),y:cy+r*Math.sin(2*Math.PI*v-Math.PI/2)});
    const b=v=>({x:cx+inn*Math.cos(2*Math.PI*v-Math.PI/2),y:cy+inn*Math.sin(2*Math.PI*v-Math.PI/2)});
    const[p1,p2,p3,p4]=[a(s),a(e),b(e),b(s)];const lg=(e-s)>.5?1:0;
    return `M${p1.x} ${p1.y} A${r} ${r} 0 ${lg} 1 ${p2.x} ${p2.y} L${p3.x} ${p3.y} A${inn} ${inn} 0 ${lg} 0 ${p4.x} ${p4.y}Z`;
  };
  return (
    <svg width={size} height={size}>
      {slices.map((s,i)=><path key={i} d={arc(s.s,s.e)} fill={s.color} opacity=".9"/>)}
      <circle cx={cx} cy={cy} r={inn-2} fill={t.card}/>
      <text x={cx} y={cy-4} textAnchor="middle" fontSize="13" fontWeight="800" fill={t.text}>₹{(total/1000).toFixed(0)}k</text>
      <text x={cx} y={cy+12} textAnchor="middle" fontSize="9" fill={t.textDim}>total</text>
    </svg>
  );
}

export default function StatsPage({ dark=true }) {
  const t = dark ? DARK : LIGHT;
  const [stats, setStats] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadStats = useCallback(() => {
    tripsApi.list().then(async trips => {
      const summaries = {};
      await Promise.all(trips.slice(0,20).map(async tr => {
        try { summaries[tr.id] = await expensesApi.summary(tr.id); } catch {}
      }));

      const totalSpent  = Object.values(summaries).reduce((s,v)=>s+(v?.total_spent||0),0);
      const totalBudget = trips.reduce((s,tr)=>s+(tr.budget||0),0);

      const cats = {};
      Object.values(summaries).forEach(s=>{
        if(s?.by_category) Object.entries(s.by_category).forEach(([k,v])=>{ cats[k]=(cats[k]||0)+v; });
      });

      const monthly = {};
      Object.values(summaries).forEach(s=>{
        if(s?.by_month) Object.entries(s.by_month).forEach(([m,v])=>{ monthly[m]=(monthly[m]||0)+v; });
      });
      const sortedMonthly = Object.fromEntries(Object.entries(monthly).sort(([a],[b])=>a.localeCompare(b)).slice(-6));
      const destinations = [...new Set(trips.map(tr=>tr.destination).filter(Boolean))];

      setStats({
        total_trips: trips.length,
        completed_trips: trips.filter(tr=>tr.status==="completed").length,
        active_trips: trips.filter(tr=>tr.status==="active").length,
        total_spent: totalSpent,
        total_budget: totalBudget,
        savings: Math.max(0,totalBudget-totalSpent),
        avg_trip_budget: trips.length ? totalBudget/trips.length : 0,
        by_category: cats,
        monthly_spending: sortedMonthly,
        destinations,
        destinations_count: destinations.length,
      });
    }).finally(()=>setLoading(false));
  }, []);

  useEffect(() => {
    loadStats();
  }, [loadStats]);

  useEffect(() => {
    const handler = e => {
      const d = e?.detail || {};
      if (d.type === "trips" || d.type === "expenses") {
        setLoading(true);
        loadStats();
      }
    };
    window.addEventListener("tm_data_updated", handler);
    return () => window.removeEventListener("tm_data_updated", handler);
  }, [loadStats]);

  const catData = useMemo(
    () => Object.entries(stats?.by_category||{}).map(([k,v])=>({
      label:`${CAT_ICONS[k]||"??"} ${k}`, value:v, color:CAT_COLORS[k]||"#888",
    })),
    [stats?.by_category]
  );
  const sortedCatData = useMemo(() => [...catData].sort((a,b)=>b.value-a.value), [catData]);
  const monthlyEntries = useMemo(() => Object.entries(stats?.monthly_spending||{}), [stats?.monthly_spending]);
  const maxMonthlyVal = useMemo(() => Math.max(...monthlyEntries.map(([,v])=>v), 1), [monthlyEntries]);
  const budgetPct = useMemo(() => stats?.total_budget>0 ? Math.round((stats.total_spent/stats.total_budget)*100) : 0, [stats?.total_budget, stats?.total_spent]);
  const completedPct = useMemo(() => stats?.total_trips>0 ? Math.round((stats.completed_trips/stats.total_trips)*100) : 0, [stats?.total_trips, stats?.completed_trips]);

  if(loading) return (
    <div style={{display:"flex",justifyContent:"center",alignItems:"center",height:"60vh"}}>
      <Spinner size={40} dark={dark}/>
    </div>
  );

  if(!stats) return null;

  const card = {background:t.card,border:`1px solid ${t.border}`,borderRadius:14,padding:"20px"};

  return (
    <div className="page-enter" style={{paddingBottom:"calc(80px + env(safe-area-inset-bottom, 0px))", height:"calc(100dvh - 56px)"}}>
      <div style={{marginBottom:24}}>
        <h1 style={{fontSize:26,fontWeight:800,color:t.text,margin:0,letterSpacing:"-.01em"}}>📊 Travel Analytics</h1>
        <div style={{color:t.textSub,fontSize:13,marginTop:4}}>Your journey in numbers</div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(140px,1fr))",gap:14,marginBottom:28}}>
        <StatCard icon="🧭" label="Total Trips" value={stats.total_trips} color={t.accent} t={t}/>
        <StatCard icon="✅" label="Completed" value={stats.completed_trips} color={t.green} t={t} sub={`${stats.active_trips} active`}/>
        <StatCard icon="📍" label="Destinations" value={stats.destinations_count} color={t.violet} t={t}/>
        <StatCard icon="💰" label="Total Budget" value={`₹${(stats.total_budget/1000).toFixed(0)}k`} color={t.cyan||t.teal} t={t} sub={`₹${(stats.total_spent/1000).toFixed(0)}k spent`}/>
        <StatCard icon="💸" label="Total Spent" value={`₹${(stats.total_spent/1000).toFixed(0)}k`} color={t.amber} t={t}/>
        <StatCard icon="🪙" label="Saved" value={`₹${(stats.savings/1000).toFixed(0)}k`} color={t.emerald||t.green} t={t}/>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(280px,1fr))",gap:18,marginBottom:24}}>
        <div style={card}>
          <div style={{fontWeight:700,fontSize:14,color:t.text,marginBottom:16}}>📊 Spending by Category</div>
          {catData.length ? (
            <div style={{display:"flex",gap:16,alignItems:"center",flexWrap:"wrap"}}>
              <DonutChart data={catData} t={t}/>
              <div style={{flex:1,display:"flex",flexDirection:"column",gap:8,minWidth:120}}>
                {sortedCatData.map((d,i)=>(
                  <div key={i} style={{display:"flex",alignItems:"center",gap:8}}>
                    <div style={{width:9,height:9,borderRadius:"50%",background:d.color,flexShrink:0,boxShadow:`0 0 6px ${d.color}80`}}/>
                    <span style={{fontSize:11,color:t.textSub,flex:1}}>{d.label}</span>
                    <span style={{fontSize:11,fontWeight:700,color:t.text}}>₹{d.value.toLocaleString("en-IN")}</span>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div style={{color:t.textDim,fontSize:13,padding:20,textAlign:"center"}}>No expenses logged yet</div>
          )}
        </div>

        <div style={card}>
          <div style={{fontWeight:700,fontSize:14,color:t.text,marginBottom:16}}>📅 Monthly Spending</div>
          {monthlyEntries.length ? (
            <div style={{display:"flex",gap:8,alignItems:"flex-end",height:100}}>
              {monthlyEntries.map(([month,val])=>{
                const pct = val/maxMonthlyVal;
                return (
                  <div key={month} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:4}}>
                    <div style={{fontSize:8,color:t.textDim}}>₹{val>=1000?`${(val/1000).toFixed(0)}k`:val}</div>
                    <div style={{width:"100%",background:`linear-gradient(180deg,${t.accent},${t.accent}88)`,borderRadius:"4px 4px 0 0",height:`${Math.max(4,pct*70)}px`,boxShadow:`0 0 8px ${t.accent}40`,transition:"height .6s ease"}}/>
                    <div style={{fontSize:8,color:t.textDim,whiteSpace:"nowrap"}}>{month.slice(5)}</div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{color:t.textDim,fontSize:13,padding:20,textAlign:"center"}}>No spending data yet</div>
          )}
        </div>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(260px,1fr))",gap:18}}>
        <div style={card}>
          <div style={{fontWeight:700,fontSize:14,color:t.text,marginBottom:16}}>💹 Budget Health</div>
          <div style={{display:"flex",flexDirection:"column",gap:14}}>
            {[
              {label:"Budget Used", pct:Math.min(100,budgetPct), color:budgetPct>90?t.red:t.accent},
              {label:"Trips Completed", pct:completedPct, color:t.green},
            ].map(({label,pct,color})=>(
              <div key={label}>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:12,color:t.textSub,marginBottom:5}}>
                  <span>{label}</span><span style={{fontWeight:700,color:t.text}}>{pct}%</span>
                </div>
                <div style={{height:6,background:t.border,borderRadius:999}}>
                  <div style={{height:"100%",width:`${pct}%`,background:color,borderRadius:999,transition:"width 1s ease",boxShadow:`0 0 8px ${color}60`}}/>
                </div>
              </div>
            ))}
          </div>
          <div className="stats-pair-grid">
            {[
              {label:"Saved",value:`₹${(stats.savings/1000).toFixed(1)}k`,color:t.green},
              {label:"Avg Budget",value:`₹${(stats.avg_trip_budget/1000).toFixed(1)}k`,color:t.cyan||t.teal},
            ].map(({label,value,color})=>(
              <div key={label} style={{textAlign:"center",background:t.surface,borderRadius:10,padding:"12px 8px",border:`1px solid ${t.border}`}}>
                <div style={{fontSize:18,fontWeight:800,color}}>{value}</div>
                <div style={{fontSize:10,color:t.textDim,marginTop:2,textTransform:"uppercase",letterSpacing:".06em"}}>{label}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={card}>
          <div style={{fontWeight:700,fontSize:14,color:t.text,marginBottom:16}}>🗺️ Destinations</div>
          {stats.destinations.length ? (
            <>
              <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:16}}>
                {stats.destinations.map((d,i)=>(
                  <div key={i} style={{background:`${t.accent}12`,border:`1px solid ${t.accent}25`,borderRadius:999,padding:"5px 13px",fontSize:12,color:t.accent,fontWeight:600}}>
                    📍 {d}
                  </div>
                ))}
              </div>
              <div style={{textAlign:"center",background:t.surface,borderRadius:10,padding:"14px",border:`1px solid ${t.border}`}}>
                <div style={{fontSize:28,fontWeight:800,color:t.accent}}>{stats.destinations_count}</div>
                <div style={{fontSize:11,color:t.textDim,textTransform:"uppercase",letterSpacing:".06em"}}>Unique Destinations</div>
              </div>
            </>
          ) : (
            <div style={{color:t.textDim,fontSize:13,textAlign:"center",padding:20}}>
              No destinations yet - start planning your first trip!
            </div>
          )}
        </div>
      </div>
    </div>
  );
}