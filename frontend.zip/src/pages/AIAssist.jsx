import { useState, useEffect, useRef } from "react";
import { createPortal } from "react-dom";
import { tripsApi } from "../api/client";
import { aiApi } from "../api/client";
import { Spinner } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";
import useActiveTrip from "../hooks/useActiveTrip";
import { cacheGet, cacheSet } from "../utils/offline";

// Quick prompts removed per UI request.

const FOLLOW_UPS = {
  pack: ["What about toiletries?","Anything for the weather?","Electronics to bring?"],
  budget: ["How to save more?","Best budget food options?","Free things to do?"],
  places: ["Opening hours?","How to get there?","Best time to visit?"],
  food: ["Vegetarian options?","Where to find it?","Any food allergies to note?"],
  safety: ["Emergency numbers?","Safe areas to stay?","Common scams to avoid?"],
  general: ["Tell me more","Any alternatives?","Give me more detail"],
};

const DEFAULT_MESSAGES = [
  { role: "ai", text: "Hi! I am your TravelMate AI. Select a trip and ask me anything - packing, budget, places, local tips and more." },
];

function TypingDots({ color }){
  return(
    <span style={{display:"inline-flex",gap:3,alignItems:"center",padding:"2px 0"}}>
      {[0,1,2].map(i=>(
        <span key={i} style={{width:6,height:6,borderRadius:"50%",background:color||DARK.accent,display:"inline-block",animation:`bounce 1.2s ease-in-out ${i*0.2}s infinite`}}/>
      ))}
      <style>{`@keyframes bounce{0%,80%,100%{transform:scale(0)}40%{transform:scale(1)}}`}</style>
    </span>
  );
}

function renderText(text){
  return text
    .replace(/\*\*(.*?)\*\*/g,"<strong>$1</strong>")
    .replace(/\*(.*?)\*/g,"<em>$1</em>")
    .replace(/`(.*?)`/g,`<code style="background:rgba(255,255,255,0.1);padding:1px 5px;border-radius:4px;font-size:12px">$1</code>`)
    .replace(/^- /gm,"<br/>- ")
    .replace(/^\d+\. /gm,(m)=>`<br/>${m}`)
    .replace(/\n/g,"<br/>");
}

export default function AIAssist({ dark=true, active=true }){
  const t=dark?DARK:LIGHT;
  const [trips,setTrips]=useState([]);
  const [tripId, setTripId] = useActiveTrip();
  const [messages,setMessages]=useState(DEFAULT_MESSAGES);
  const [input,setInput]=useState("");
  const [loading,setLoading]=useState(false);
  const [listening,setListening]=useState(false);
  const [history,setHistory]=useState([]);
  const [suggestedFollowUps,setSuggestedFollowUps]=useState([]);
  const [aiAvailable,setAiAvailable]=useState(null);
  const [aiError,setAiError]=useState("");
  const [isMobile, setIsMobile] = useState(false);
  const [chatLoading, setChatLoading] = useState(true);
  const [moreOpen, setMoreOpen] = useState(false);
  const bottomRef=useRef();
  const inputRef=useRef();
  const recRef=useRef(null);

  const persistChat = async (tripIdVal, nextMessages) => {
    if (tripIdVal === null || tripIdVal === undefined || tripIdVal === "") return;
    const key = String(tripIdVal);
    try { await cacheSet(`ai_chat_${key}`, nextMessages); } catch {}
    if (navigator.onLine) {
      const numId = parseInt(key, 10);
      if (!Number.isNaN(numId)) {
        try { await aiApi.saveChat(numId, nextMessages); } catch {}
      }
    }
  };

  useEffect(()=>{
    tripsApi.list().then(d=>{
      setTrips(d);
      if (!localStorage.getItem("tm_active_trip")) {
        const active = d.find(tr => tr.status === "active") || d[0];
        if (active) {
          setTripId(String(active.id));
          localStorage.setItem("tm_active_trip", String(active.id));
        }
      }
    });
    cacheGet("ai_history").then(h=>h&&setHistory(h));
    aiApi.roadmapStatus().then(r=>{
      if (typeof r?.ai_available === "boolean") setAiAvailable(r.ai_available);
    }).catch(()=>{});
  },[]);

  useEffect(() => {
    const handler = e => {
      const d = e?.detail || {};
      if (d.type === "trips") {
        tripsApi.list().then(setTrips).catch(() => {});
      }
    };
    window.addEventListener("tm_data_updated", handler);
    return () => window.removeEventListener("tm_data_updated", handler);
  }, []);

  useEffect(() => {
    if (!active) return;
    const handler = e => setMoreOpen(!!e.detail);
    window.addEventListener("tm-more-toggle", handler);
    setMoreOpen(typeof document !== "undefined" && document.body.classList.contains("tm-more-open"));
    return () => window.removeEventListener("tm-more-toggle", handler);
  }, [active]);

  useEffect(()=>{
    if (!active) return;
    let cancelled = false;
    setChatLoading(true);
    (async () => {
      if (!tripId || tripId === "0" || tripId === "") {
        let loaded = null;
        let loadedFromCache = false;
        try {
          const res = await aiApi.getChat(0); // 0 means global chat in backend
          if (Array.isArray(res?.messages)) loaded = res.messages;
        } catch {}
        if (!loaded) {
          try {
            const cached = await cacheGet(`ai_chat_0`);
            if (Array.isArray(cached)) { loaded = cached; loadedFromCache = true; }
          } catch {}
        }
        if (!cancelled) {
          setMessages(loaded && loaded.length ? loaded : [{ role: "ai", text: "Hi! I am your TravelMate Global AI. I can help manage all your trips, create new ones, or give generic travel advice. How can I assist?" }]);
          if (loadedFromCache && loaded && loaded.length) persistChat("0", loaded);
          setChatLoading(false);
        }
        return;
      }
      let loaded = null;
      let loadedFromCache = false;
      try {
        const res = await aiApi.getChat(parseInt(tripId));
        if (Array.isArray(res?.messages)) loaded = res.messages;
      } catch {}
      if (!loaded) {
        try {
          const cached = await cacheGet(`ai_chat_${tripId}`);
          if (Array.isArray(cached)) {
            loaded = cached;
            loadedFromCache = true;
          }
        } catch {}
      }
      if (!cancelled) {
        setMessages(loaded && loaded.length ? loaded : DEFAULT_MESSAGES);
        if (loadedFromCache && loaded && loaded.length) {
          persistChat(tripId, loaded);
        }
        setChatLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [tripId, active]);

  useEffect(()=>{
    bottomRef.current?.scrollIntoView({behavior:"smooth"});
  },[messages]);

  useEffect(() => {
    if (typeof window === "undefined" || !window.matchMedia) return;
    const mq = window.matchMedia("(max-width: 640px)");
    const handler = () => setIsMobile(mq.matches);
    handler();
    if (mq.addEventListener) mq.addEventListener("change", handler);
    else mq.addListener(handler);
    return () => {
      if (mq.removeEventListener) mq.removeEventListener("change", handler);
      else mq.removeListener(handler);
    };
  }, []);

  const buildCtx=()=>{
    if (!tripId || tripId === "0" || tripId === "") return "Global conversation. No specific trip selected. Look at ALL TRIPS summary.";
    const trip=trips.find(tr=>String(tr.id)===tripId);
    if(!trip)return "";
    const from=trip.start_location?`${trip.start_location} to `:"";
    const dates=trip.start_date?`, travelling ${trip.start_date}${trip.end_date?` to ${trip.end_date}`:""}`:""
    return `Trip context: ${from}${trip.destination}${dates}, budget INR ${trip.budget||0}, status: ${trip.status}. `;
  };

  const getSuggestions=(msg)=>{
    const m=msg.toLowerCase();
    if(m.includes("pack"))return FOLLOW_UPS.pack;
    if(m.includes("budget")||m.includes("money")||m.includes("cost"))return FOLLOW_UPS.budget;
    if(m.includes("place")||m.includes("visit")||m.includes("see"))return FOLLOW_UPS.places;
    if(m.includes("food")||m.includes("eat")||m.includes("restaurant"))return FOLLOW_UPS.food;
    if(m.includes("safe")||m.includes("emergency")||m.includes("danger"))return FOLLOW_UPS.safety;
    return FOLLOW_UPS.general;
  };

  const sendMsg=async(text,isQuick=false)=>{
    const msg=(text||input).trim();
    if(!msg||loading)return;
    const activeTripId = (!tripId || tripId === "0" || tripId === "") ? 0 : parseInt(tripId);
    if (aiAvailable === false) {
      setMessages(m=>[...m,{role:"ai",text:"AI is not configured on the backend. Add GEMINI_API_KEY or GROK_API_KEY in be/.env and restart the backend."}]);
      return;
    }



    setMessages(m=>{
      const next = [...m,{role:"user",text:msg}];
      persistChat(String(activeTripId), next);
      return next;
    });
    setInput("");
    setLoading(true);
    setSuggestedFollowUps([]);
    setAiError("");

    try{
      const {response}=await aiApi.recommend(activeTripId === 0 ? null : activeTripId,msg);
      const newMsg={role:"ai",text:response};
      setMessages(m=>{
        const next = [...m,newMsg];
        persistChat(String(activeTripId), next);
        return next;
      });
      setSuggestedFollowUps(getSuggestions(msg));
      const newHist=[...history,{role:"user",text:msg},{role:"ai",text:response}].slice(-40);
      setHistory(newHist);
      cacheSet("ai_history",newHist);
    }catch(ex){
      const msgText = ex?.message || "AI request failed.";
      setAiError(msgText);
      setMessages(m=>[...m,{role:"ai",text:`${msgText}`}]);
    }finally{
      setLoading(false);
      inputRef.current?.focus();
    }
  };

  const startVoice=()=>{
    const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
    if(!SR){alert("Voice requires Chrome or Edge");return;}
    const r=new SR();r.lang="en-IN";r.continuous=false;r.interimResults=false;
    r.onstart=()=>setListening(true);
    r.onend=()=>setListening(false);
    r.onresult=e=>setInput(e.results[0][0].transcript);
    r.onerror=()=>setListening(false);
    recRef.current=r;r.start();
  };
  const stopVoice=()=>{recRef.current?.stop();setListening(false);};

  const clearHistory=()=>{
    setHistory([]);
    setMessages(DEFAULT_MESSAGES);
    setSuggestedFollowUps([]);
    cacheSet("ai_history",[]);
    if (tripId) persistChat(tripId, DEFAULT_MESSAGES);
    else persistChat("0", DEFAULT_MESSAGES);
  };

  const exportChat=()=>{
    const content=messages.map(m=>`${m.role==="user"?"You":"AI"}: ${m.text}`).join("\n\n");
    const blob=new Blob([content],{type:"text/plain"});
    const a=document.createElement("a");a.href=URL.createObjectURL(blob);a.download="travelmate-chat.txt";a.click();
  };

  const trip=trips.find(tr=>String(tr.id)===tripId);

  return(
    <div className="page-enter" style={{display:"flex",flexDirection:"column",minHeight:0,flex:1}}>
      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16,flexWrap:"wrap",gap:10}}>
        <div>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>
            AI Travel Assistant
            <span style={{fontSize:10,fontWeight:800,letterSpacing:".08em",color:t.accent,background:`${t.accent}14`,border:`1px solid ${t.accent}33`,padding:"3px 8px",borderRadius:999}}>LIVE</span>
          </h1>
          <div style={{fontSize:12,color:t.textSub}}>
            {aiAvailable === false ? "AI not configured" : aiAvailable === true ? "AI enabled" : "AI status unknown"} - Context-aware, personalized advice
          </div>
        </div>
        <div className="ai-header-controls" style={{display:"flex",gap:8,alignItems:"center",flexWrap:"wrap"}}>
          <select value={tripId} onChange={e => {
            const val = e.target.value;
            setTripId(val);
            if(val) localStorage.setItem("tm_active_trip", val);
          }}
            style={{background:t.surface,border:`1px solid ${t.border}`,borderRadius:9,padding:"7px 11px",color:t.text,fontSize:13,fontFamily:"inherit",outline:"none",cursor:"pointer"}}>
            <option value="">🌎 Global Assistant (All Trips)</option>
            {trips.map(tr=><option key={tr.id} value={String(tr.id)}>{tr.cover_emoji} {tr.name}</option>)}
          </select>
          <button onClick={exportChat} title="Export chat"
            style={{padding:"7px 12px",borderRadius:9,background:t.surface,border:`1px solid ${t.border}`,color:t.textSub,cursor:"pointer",fontSize:12,fontFamily:"inherit",transition:"all .15s"}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=`${t.accent}55`;e.currentTarget.style.color=t.accent;}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor=t.border;e.currentTarget.style.color=t.textSub;}}>
            Export
          </button>
          <button onClick={clearHistory}
            style={{padding:"7px 12px",borderRadius:9,background:t.surface,border:`1px solid ${t.border}`,color:t.textSub,cursor:"pointer",fontSize:12,fontFamily:"inherit",transition:"all .15s"}}
            onMouseEnter={e=>{e.currentTarget.style.borderColor=`${t.red}55`;e.currentTarget.style.color=t.red;}}
            onMouseLeave={e=>{e.currentTarget.style.borderColor=t.border;e.currentTarget.style.color=t.textSub;}}>
            Clear
          </button>
        </div>
      </div>

      {(aiAvailable === false || aiError) && (
        <div style={{background:`${t.red}12`,border:`1px solid ${t.red}44`,borderRadius:10,padding:"8px 12px",marginBottom:12,fontSize:12,color:t.textSub}}>
          {aiError || "AI is not configured. Add GEMINI_API_KEY or GROK_API_KEY in be/.env and restart the backend."}
        </div>
      )}

      {/* Trip context banner */}
      {trip&&(
        <div style={{background:`linear-gradient(135deg,${t.accent}1A,${t.violet||t.accent}0D)`,border:`1px solid ${t.accent}35`,borderRadius:14,padding:"10px 14px",marginBottom:12,display:"flex",alignItems:"center",gap:10,fontSize:12,color:t.textSub,boxShadow:`0 8px 26px ${t.accent}14`}}>
          <span style={{fontSize:18}}>{trip.cover_emoji}</span>
          <span><strong style={{color:t.text}}>{trip.name}</strong> - {trip.destination}{trip.start_date?` - ${trip.start_date}`:""}{trip.budget?` - INR ${trip.budget.toLocaleString("en-IN")} budget`:""}</span>
        </div>
      )}

      {/* Messages */}
      <div style={{flex:1,overflowY:"auto",display:"flex",flexDirection:"column",gap:10,padding:"14px 14px 16px",borderRadius:18,background:dark?"rgba(12,10,24,0.55)":"rgba(250,248,255,0.65)",border:`1px solid ${dark?"rgba(144,96,240,0.18)":t.border}`,boxShadow:dark?"0 12px 36px rgba(0,0,0,.35)":"0 12px 30px rgba(106,62,200,.08)",minHeight:0,paddingBottom:isMobile ? "calc(170px + env(safe-area-inset-bottom, 0px))" : 16}}>
        {chatLoading ? (
          <div style={{flex:1,display:"flex",alignItems:"center",justifyContent:"center",padding:"40px 0"}}>
            <Spinner size={24} dark={dark}/>
          </div>
        ) : messages.map((m,i)=>(
          <div key={i} style={{display:"flex",justifyContent:m.role==="user"?"flex-end":"flex-start",gap:8,alignItems:"flex-end"}}>
            {m.role==="ai"&&<div style={{width:30,height:30,borderRadius:10,background:`linear-gradient(135deg,${t.accent}55,${t.violet||t.accent}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800,color:dark?"#0b0716":"#fff",flexShrink:0,boxShadow:`0 6px 14px ${t.accent}35`}}>AI</div>}
            <div style={{maxWidth:"80%",position:"relative"}}>
              <div style={{background:m.role==="user"?`linear-gradient(135deg,${t.accent},${t.violet||"#7C3AED"})`:`linear-gradient(135deg,${t.card},${dark?"rgba(20,14,40,0.9)":"#fff"})`,border:m.role==="user"?"none":`1px solid ${dark?"rgba(144,96,240,0.25)":t.border}`,borderRadius:m.role==="user"?"18px 18px 6px 18px":"18px 18px 18px 6px",padding:"12px 14px",color:m.role==="user"?"#fff":t.text,fontSize:13,lineHeight:1.7,boxShadow:m.role==="user"?"0 10px 24px rgba(124,58,237,.25)":"0 10px 24px rgba(0,0,0,.12)"}}>
                {m.role==="ai"
                  ?<div dangerouslySetInnerHTML={{__html:renderText(m.text)}}/>
                  :<div>{m.text}</div>
                }
              </div>
            </div>
            {m.role==="user"&&<div style={{width:30,height:30,borderRadius:10,background:`${t.accent}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:10,fontWeight:800,flexShrink:0,color:"#fff",boxShadow:`0 6px 14px ${t.accent}35`}}>You</div>}
          </div>
        ))}
        {loading&&(
          <div style={{display:"flex",gap:8,alignItems:"flex-end"}}>
            <div style={{width:28,height:28,borderRadius:8,background:`${t.accent}20`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11}}>AI</div>
            <div style={{background:t.card,border:`1px solid ${t.border}`,borderRadius:"16px 16px 16px 4px",padding:"12px 16px"}}>
              <TypingDots color={t.accent}/>
            </div>
          </div>
        )}
        <div ref={bottomRef}/>
      </div>

      {/* Follow-up suggestions */}
      {suggestedFollowUps.length>0&&!loading&&(
        <div style={{display:"flex",gap:6,padding:"8px 0",overflowX:"auto",flexShrink:0}}>
          <span style={{fontSize:11,color:t.textSub,flexShrink:0,alignSelf:"center"}}>Ask:</span>
          {suggestedFollowUps.map((q,i)=>(
            <button key={i} onClick={()=>sendMsg(q)}
              style={{padding:"4px 11px",borderRadius:16,background:t.surface,border:`1px solid ${t.accent}33`,color:t.accent,cursor:"pointer",fontSize:11,whiteSpace:"nowrap",fontFamily:"inherit",transition:"all .15s"}}
              onMouseEnter={e=>e.currentTarget.style.background=`${t.accent}15`}
              onMouseLeave={e=>e.currentTarget.style.background=t.surface}>
              {q}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      {(isMobile && active && !moreOpen
        ? createPortal(
            <div className="ai-input-bar" style={{display:"flex",gap:8,alignItems:"flex-end",position:"fixed",left:12,right:12,bottom:"calc(54px + env(safe-area-inset-bottom, 0px))",zIndex:320,background:t.bg,padding:"8px 0 6px",backdropFilter:"blur(12px)"}}>
              <div style={{flex:1,position:"relative"}}>
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={e=>setInput(e.target.value)}
                  onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMsg();}}}
                  placeholder={tripId?"Ask anything about your trip...":"Command me to create a trip or ask travel advice..."}
                  rows={2}
                  style={{width:"100%",background:t.card,border:`1px solid ${t.border}`,borderRadius:14,padding:"11px 14px",color:t.text,fontSize:13,outline:"none",resize:"none",fontFamily:"inherit",lineHeight:1.6,boxSizing:"border-box",transition:"border-color .2s"}}
                  onFocus={e=>e.target.style.borderColor=`${t.accent}55`}
                  onBlur={e=>e.target.style.borderColor=t.border}
                />
              </div>
              <div style={{display:"flex",gap:6}}>
                <button
                  onClick={listening ? stopVoice : startVoice}
                  style={{
                    width: 42,
                    height: 42,
                    borderRadius: 12,
                    background: listening ? `${t.red}18` : t.surface,
                    border: `1px solid ${listening ? t.red + "55" : t.border}`,
                    color: listening ? t.red : t.textSub,
                    cursor: "pointer",
                    fontSize: 17,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all .2s",
                    position: "relative",
                    overflow: "visible",
                  }}
                  title={listening ? "Stop listening" : "Voice input"}
                >
                  <span style={{ width: 14, height: 18, borderRadius: 7, border: `2px solid ${listening ? t.red : t.textSub}`, boxSizing: "border-box", position: "relative" }}>
                    <span style={{ position: "absolute", left: "50%", bottom: -6, width: 2, height: 6, background: listening ? t.red : t.textSub, transform: "translateX(-50%)" }} />
                    <span style={{ position: "absolute", left: "50%", bottom: -9, width: 10, height: 2, background: listening ? t.red : t.textSub, transform: "translateX(-50%)", borderRadius: 2 }} />
                  </span>
                  {listening && (
                    <span
                      style={{
                        position: "absolute",
                        inset: -6,
                        borderRadius: 14,
                        border: `1px solid ${t.red}66`,
                        animation: "tmPulse 1.2s ease-in-out infinite",
                      }}
                    />
                  )}
                </button>
                <button onClick={()=>sendMsg()} disabled={loading||!input.trim() || aiAvailable === false}
                  style={{width:42,height:42,borderRadius:12,background:loading||!input.trim() || aiAvailable === false?t.surface:`linear-gradient(135deg,${t.accent},${t.violet||"#7C3AED"})`,border:`1px solid ${loading||!input.trim() || aiAvailable === false?t.border:"transparent"}`,color:loading||!input.trim() || aiAvailable === false?t.textDim:"#fff",cursor:loading||!input.trim() || aiAvailable === false?"not-allowed":"pointer",fontSize:11,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s"}}>
                  {loading?<Spinner size={16} dark={dark}/>:"Send"}
                </button>
              </div>
            </div>,
            document.body
          )
        : (
            <div className="ai-input-bar" style={{display:"flex",gap:8,alignItems:"flex-end",marginTop:10,flexShrink:0}}>
              <div style={{flex:1,position:"relative"}}>
                <textarea
                  ref={inputRef}
                  value={input}
                  onChange={e=>setInput(e.target.value)}
                  onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMsg();}}}
                  placeholder={tripId?"Ask anything about your trip...":"Command me to create a trip or ask travel advice..."}
                  rows={2}
                  style={{width:"100%",background:t.card,border:`1px solid ${t.border}`,borderRadius:14,padding:"11px 14px",color:t.text,fontSize:13,outline:"none",resize:"none",fontFamily:"inherit",lineHeight:1.6,boxSizing:"border-box",transition:"border-color .2s"}}
                  onFocus={e=>e.target.style.borderColor=`${t.accent}55`}
                  onBlur={e=>e.target.style.borderColor=t.border}
                />
              </div>
              <div style={{display:"flex",gap:6}}>
                <button
                  onClick={listening ? stopVoice : startVoice}
                  style={{
                    width: 42,
                    height: 42,
                    borderRadius: 12,
                    background: listening ? `${t.red}18` : t.surface,
                    border: `1px solid ${listening ? t.red + "55" : t.border}`,
                    color: listening ? t.red : t.textSub,
                    cursor: "pointer",
                    fontSize: 17,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    transition: "all .2s",
                    position: "relative",
                    overflow: "visible",
                  }}
                  title={listening ? "Stop listening" : "Voice input"}
                >
                  <span style={{ width: 14, height: 18, borderRadius: 7, border: `2px solid ${listening ? t.red : t.textSub}`, boxSizing: "border-box", position: "relative" }}>
                    <span style={{ position: "absolute", left: "50%", bottom: -6, width: 2, height: 6, background: listening ? t.red : t.textSub, transform: "translateX(-50%)" }} />
                    <span style={{ position: "absolute", left: "50%", bottom: -9, width: 10, height: 2, background: listening ? t.red : t.textSub, transform: "translateX(-50%)", borderRadius: 2 }} />
                  </span>
                  {listening && (
                    <span
                      style={{
                        position: "absolute",
                        inset: -6,
                        borderRadius: 14,
                        border: `1px solid ${t.red}66`,
                        animation: "tmPulse 1.2s ease-in-out infinite",
                      }}
                    />
                  )}
                </button>
                <button onClick={()=>sendMsg()} disabled={loading||!input.trim() || aiAvailable === false}
                  style={{width:42,height:42,borderRadius:12,background:loading||!input.trim() || aiAvailable === false?t.surface:`linear-gradient(135deg,${t.accent},${t.violet||"#7C3AED"})`,border:`1px solid ${loading||!input.trim() || aiAvailable === false?t.border:"transparent"}`,color:loading||!input.trim() || aiAvailable === false?t.textDim:"#fff",cursor:loading||!input.trim() || aiAvailable === false?"not-allowed":"pointer",fontSize:11,display:"flex",alignItems:"center",justifyContent:"center",transition:"all .2s"}}>
                  {loading?<Spinner size={16} dark={dark}/>:"Send"}
                </button>
              </div>
            </div>
          )
      )}
      <style>{`
        @keyframes tmPulse {
          0% { transform: scale(0.9); opacity: 0.2; }
          50% { transform: scale(1.05); opacity: 0.6; }
          100% { transform: scale(0.9); opacity: 0.2; }
        }
      `}</style>
    </div>
  );
}