import { useState, useEffect } from "react";
import { tripsApi, notesApi } from "../api/client";
import { Btn, Spinner, Empty, Modal, Input } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";
import useActiveTrip from "../hooks/useActiveTrip";

const NOTE_COLORS = ["#00D4FF","#34D399","#FBBF24","#F43F5E","#818CF8","#FB923C","#EC4899","#10B981"];
const BL = { title: "", content: "", color: "#00D4FF", pinned: false };

function NoteCard({ note, t, onEdit, onDelete, onTogglePin, deleting, pinning }) {
  const [hov, setHov] = useState(false);
  return (
    <div
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        background: t.card,
        border: `1.5px solid ${note.pinned ? note.color : t.border}`,
        borderRadius: 14,
        padding: "16px 18px",
        position: "relative",
        cursor: "pointer",
        transition: "all .18s ease",
        transform: hov ? "translateY(-3px)" : "none",
        boxShadow: hov ? `0 8px 24px ${note.color}22` : "none",
        borderLeft: `4px solid ${note.color}`,
      }}
    >
      {note.pinned && (
        <div style={{ position: "absolute", top: 10, right: 12, fontSize: 14 }}>📌</div>
      )}
      <div style={{ fontWeight: 700, fontSize: 15, color: t.text, marginBottom: 8, paddingRight: 24 }}>
        {note.title}
      </div>
      <div style={{
        fontSize: 13, color: t.textSub, lineHeight: 1.6,
        whiteSpace: "pre-wrap", wordBreak: "break-word",
        maxHeight: 120, overflow: "hidden",
        maskImage: "linear-gradient(to bottom, black 70%, transparent 100%)",
      }}>
        {note.content}
      </div>
      <div style={{ marginTop: 12, display: "flex", gap: 8, justifyContent: "flex-end" }}>
        <span style={{ fontSize: 11, color: t.textDim, flex: 1 }}>
          {new Date(note.updated_at).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
        </span>
        <button onClick={() => onTogglePin(note)} title="Pin" disabled={pinning || deleting}
          style={{ background: "none", border: "none", cursor: pinning || deleting ? "wait" : "pointer", fontSize: 14, opacity: pinning || deleting ? .5 : .7 }}>
          {pinning ? <span style={{width:12,height:12,border:`2px solid ${t.border}`,borderTopColor:t.accent,borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite"}}/> : (note.pinned ? "📌" : "📍")}
        </button>
        <button onClick={() => onEdit(note)} disabled={deleting}
          style={{ background: "none", border: "none", cursor: deleting ? "not-allowed" : "pointer", fontSize: 14, opacity: deleting ? .4 : .7 }}>✏️</button>
        <button onClick={() => onDelete(note.id)} disabled={deleting}
          style={{ background: "none", border: "none", cursor: deleting ? "wait" : "pointer", fontSize: 14, opacity: deleting ? .5 : .7 }}>
          {deleting ? <span style={{width:12,height:12,border:`2px solid ${t.red}55`,borderTopColor:t.red,borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite"}}/> : "🗑️"}
        </button>
      </div>
    </div>
  );
}

export default function Notes({ dark = true }) {
  const t = dark ? DARK : LIGHT;
  const [trips, setTrips] = useState([]);
  const [tripId, setTripId] = useActiveTrip();
  const [notes, setNotes] = useState([]);
  const [loading, setLoading] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(BL);
  const [saving, setSaving] = useState(false);
  const [deletingId, setDeletingId] = useState(null);
  const [pinningId, setPinningId] = useState(null);
  const [search, setSearch] = useState("");

  useEffect(() => {
    tripsApi.list().then(d => { setTrips(d); if (!localStorage.getItem("tm_active_trip") && d.length) setTripId(String(d[0].id)); });
  }, []);

  useEffect(() => {
    if (!tripId) return;
    setLoading(true);
    notesApi.list(tripId).then(setNotes).finally(() => setLoading(false));
  }, [tripId]);

  useEffect(() => {
    const handler = e => {
      const d = e?.detail || {};
      if (d.type === "notes" && String(d.tripId) === String(tripId)) {
        notesApi.list(tripId).then(setNotes).catch(() => {});
      }
      if (d.type === "trips") {
        tripsApi.list().then(setTrips).catch(() => {});
      }
    };
    window.addEventListener("tm_data_updated", handler);
    return () => window.removeEventListener("tm_data_updated", handler);
  }, [tripId]);

  const openAdd = () => { setEditing(null); setForm(BL); setShowModal(true); };
  const openEdit = note => { setEditing(note); setForm({ title: note.title, content: note.content, color: note.color, pinned: note.pinned }); setShowModal(true); };

  const handleSave = async () => {
    if (!form.title.trim() || !form.content.trim()) return;
    setSaving(true);
    try {
      if (editing) {
        const updated = await notesApi.update(tripId, editing.id, form);
        setNotes(n => n.map(x => x.id === updated.id ? updated : x));
      } else {
        const created = await notesApi.create(tripId, form);
        setNotes(n => [created, ...n]);
      }
      setShowModal(false);
    } finally { setSaving(false); }
  };

  const handleDelete = async id => {
    setDeletingId(id);
    try {
      await notesApi.delete(tripId, id);
      setNotes(n => n.filter(x => x.id !== id));
    } finally {
      setDeletingId(null);
    }
  };

  const handleTogglePin = async note => {
    setPinningId(note.id);
    try {
      const updated = await notesApi.update(tripId, note.id, { pinned: !note.pinned });
      setNotes(n => n.map(x => x.id === updated.id ? updated : x));
    } finally {
      setPinningId(null);
    }
  };

  const filtered = notes.filter(n =>
    !search || n.title.toLowerCase().includes(search.toLowerCase()) || n.content.toLowerCase().includes(search.toLowerCase())
  );

  const pinned = filtered.filter(n => n.pinned);
  const unpinned = filtered.filter(n => !n.pinned);

  return (
    <div className="page-enter">
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontSize: 26, fontWeight: 800, color: t.text, margin: 0 }}>📝 Trip Notes</h1>
          <div style={{ color: t.textSub, fontSize: 13, marginTop: 4 }}>Capture ideas, memories & important info</div>
        </div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <select
            value={tripId}
            onChange={e => setTripId(e.target.value)}
            style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 8, color: t.text, padding: "8px 12px", fontSize: 13, cursor: "pointer" }}
          >
            {trips.map(tr => <option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name}</option>)}
          </select>
          <input
            placeholder="🔍 Search notes..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="notes-search" style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 8, color: t.text, padding: "8px 12px", fontSize: 13, outline: "none", width: 180 }}
          />
          <Btn onClick={openAdd} dark={dark}>+ New Note</Btn>
        </div>
      </div>

      {loading ? (
        <div style={{ display: "flex", justifyContent: "center", padding: 60 }}><Spinner size={36} dark={dark} /></div>
      ) : notes.length === 0 ? (
        <Empty icon="📝" title="No notes yet" subtitle="Start capturing trip ideas, addresses, and memories" dark={dark} />
      ) : (
        <>
          {pinned.length > 0 && (
            <>
              <div style={{ fontSize: 12, fontWeight: 700, color: t.textDim, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 10 }}>📌 PINNED</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(260px,1fr))", gap: 16, marginBottom: 24 }}>
                {pinned.map(n => <NoteCard key={n.id} note={n} t={t} onEdit={openEdit} onDelete={handleDelete} onTogglePin={handleTogglePin} deleting={deletingId === n.id} pinning={pinningId === n.id} />)}
              </div>
            </>
          )}
          {unpinned.length > 0 && (
            <>
              {pinned.length > 0 && <div style={{ fontSize: 12, fontWeight: 700, color: t.textDim, letterSpacing: ".1em", textTransform: "uppercase", marginBottom: 10 }}>ALL NOTES</div>}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(260px,1fr))", gap: 16 }}>
                {unpinned.map(n => <NoteCard key={n.id} note={n} t={t} onEdit={openEdit} onDelete={handleDelete} onTogglePin={handleTogglePin} deleting={deletingId === n.id} pinning={pinningId === n.id} />)}
              </div>
            </>
          )}
        </>
      )}

      {/* Modal */}
      {showModal && (
        <Modal title={editing ? "Edit Note" : "New Note"} onClose={() => setShowModal(false)} dark={dark}>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <Input label="Title" value={form.title} onChange={e => setForm(f => ({ ...f, title: e.target.value }))} placeholder="Note title..." dark={dark} />
            <div>
              <label style={{ fontSize: 12, color: t.textDim, marginBottom: 6, display: "block" }}>Content</label>
              <textarea
                value={form.content}
                onChange={e => setForm(f => ({ ...f, content: e.target.value }))}
                placeholder="Write your note here..."
                rows={6}
                style={{
                  width: "100%", background: t.surface, border: `1px solid ${t.border}`,
                  borderRadius: 8, color: t.text, padding: "10px 12px", fontSize: 13,
                  outline: "none", resize: "vertical", fontFamily: "inherit", boxSizing: "border-box",
                }}
              />
            </div>
            <div>
              <label style={{ fontSize: 12, color: t.textDim, marginBottom: 8, display: "block" }}>Color</label>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {NOTE_COLORS.map(c => (
                  <div
                    key={c}
                    onClick={() => setForm(f => ({ ...f, color: c }))}
                    style={{
                      width: 28, height: 28, borderRadius: "50%", background: c,
                      cursor: "pointer", border: form.color === c ? `3px solid ${t.text}` : "3px solid transparent",
                      transition: "all .15s", transform: form.color === c ? "scale(1.15)" : "scale(1)",
                    }}
                  />
                ))}
              </div>
            </div>
            <label style={{ display: "flex", alignItems: "center", gap: 10, cursor: "pointer", color: t.text, fontSize: 13 }}>
              <input type="checkbox" checked={form.pinned} onChange={e => setForm(f => ({ ...f, pinned: e.target.checked }))} />
              📌 Pin this note
            </label>
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <Btn variant="ghost" onClick={() => setShowModal(false)} dark={dark}>Cancel</Btn>
              <Btn onClick={handleSave} loading={saving} dark={dark}>
                {editing ? "Save Changes" : "Create Note"}
              </Btn>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
