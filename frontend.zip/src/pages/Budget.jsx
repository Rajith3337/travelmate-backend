import { useState, useEffect, useMemo, useCallback } from "react";
import { tripsApi, expensesApi } from "../api/client";
import { Badge, ProgressBar, Btn, Spinner, Empty, Modal } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";
import useActiveTrip from "../hooks/useActiveTrip";

const CI  = {accommodation:"🏨",transport:"🚗",food:"🍽️",tickets:"🎟️",shopping:"🛍️",activities:"🎠",other:"💡"};
const CATS = Object.keys(CI).map(k=>({value:k,label:`${CI[k]} ${k.charAt(0).toUpperCase()+k.slice(1)}`}));
const BL   = {title:"",amount:"",category:"food",notes:""};

function DonutChart({data,size=140,t}) {
  const total = data.reduce((s,d)=>s+d.value,0);
  if(!total) return <div style={{width:size,height:size,borderRadius:"50%",background:t.border,display:"flex",alignItems:"center",justifyContent:"center",color:t.textDim,fontSize:11}}>No data</div>;
  let cum=0;
  const cx=size/2,cy=size/2,r=size*.42,inn=size*.26;
  const sl=data.map(d=>{const s=cum;cum+=d.value/total;return{...d,s,e:cum};});
  const arc=(s,e)=>{
    const a=v=>({x:cx+r*Math.cos(2*Math.PI*v-Math.PI/2),y:cy+r*Math.sin(2*Math.PI*v-Math.PI/2)});
    const b=v=>({x:cx+inn*Math.cos(2*Math.PI*v-Math.PI/2),y:cy+inn*Math.sin(2*Math.PI*v-Math.PI/2)});
    const [p1,p2,p3,p4]=[a(s),a(e),b(e),b(s)];const lg=(e-s)>.5?1:0;
    return`M${p1.x} ${p1.y} A${r} ${r} 0 ${lg} 1 ${p2.x} ${p2.y} L${p3.x} ${p3.y} A${inn} ${inn} 0 ${lg} 0 ${p4.x} ${p4.y}Z`;
  };
  return(
    <svg width={size} height={size}>
      {sl.map((s,i)=><path key={i} d={arc(s.s,s.e)} fill={s.color} opacity={.9}/>)}
      <circle cx={cx} cy={cy} r={inn-3} fill={t.card}/>
    </svg>
  );
}

function getCC(t) {
  return {accommodation:t.accent,transport:t.green,food:t.amber,tickets:t.violet,shopping:t.rose,activities:t.teal,other:t.textSub};
}

export default function Budget({ dark=true }) {
  const t = dark ? DARK : LIGHT;
  const CC = getCC(t);
  const [trips,    setTrips]    = useState([]);
  const [tripId,   setTripId]   = useActiveTrip();
  const [expenses, setExpenses] = useState([]);
  const [summary,  setSummary]  = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [showModal,setShowModal]= useState(false);
  const [editing,  setEditing]  = useState(null);
  const [form,     setForm]     = useState(BL);
  const [err,      setErr]      = useState("");
  const [saving,   setSaving]   = useState(false);
  const [filterCat,setFilterCat]= useState("all");
  const [sortBy,   setSortBy]   = useState("newest");
  const [focusField,setFocusField]=useState("");

  useEffect(()=>{tripsApi.list().then(d=>{setTrips(d);if(!localStorage.getItem("tm_active_trip")&&d.length){setTripId(String(d[0].id));localStorage.setItem("tm_active_trip",d[0].id);}});},[]);

  const load = useCallback(async id => {
    if(!id) return;
    setLoading(true);
    try {
      const [exp, sum] = await Promise.all([expensesApi.list(id), expensesApi.summary(id).catch(()=>null)]);
      setExpenses(exp);
      setSummary(sum);
    } catch (e) {
      console.warn("Ghost trip ID ignored:", e.message);
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(()=>{load(tripId);},[tripId, load]);

  useEffect(() => {
    const handler = e => {
      const d = e?.detail || {};
      if (d.type === "expenses" && String(d.tripId) === String(tripId)) {
        load(tripId);
      }
      if (d.type === "trips") {
        tripsApi.list().then(setTrips).catch(() => {});
      }
    };
    window.addEventListener("tm_data_updated", handler);
    return () => window.removeEventListener("tm_data_updated", handler);
  }, [tripId, load]);

  const sf=k=>e=>setForm(f=>({...f,[k]:e.target.value}));
  const openAdd=()=>{setEditing(null);setForm(BL);setErr("");setShowModal(true);};
  const openEdit=ex=>{setEditing(ex);setForm({title:ex.title,amount:ex.amount,category:ex.category,notes:ex.notes||""});setErr("");setShowModal(true);};
  const save=async e=>{e.preventDefault();setErr("");setSaving(true);try{const p={...form,amount:parseFloat(form.amount)};if(editing)await expensesApi.update(tripId,editing.id,p);else await expensesApi.create(tripId,p);setShowModal(false);await load(tripId);}catch(ex){setErr(ex.message);}finally{setSaving(false);}};
  const remove=async id=>{if(!confirm("Delete this expense?"))return;await expensesApi.delete(tripId,id);await load(tripId);};

  const trip = useMemo(
    () => trips.find(tr=>String(tr.id)===tripId),
    [trips, tripId]
  );
  const filtered = useMemo(() => {
    const list = filterCat==="all" ? [...expenses] : expenses.filter(e=>e.category===filterCat);
    if(sortBy==="newest") list.sort((a,b)=>new Date(b.spent_at)-new Date(a.spent_at));
    if(sortBy==="oldest") list.sort((a,b)=>new Date(a.spent_at)-new Date(b.spent_at));
    if(sortBy==="highest") list.sort((a,b)=>b.amount-a.amount);
    if(sortBy==="lowest") list.sort((a,b)=>a.amount-b.amount);
    return list;
  }, [expenses, filterCat, sortBy]);

  const byCat = useMemo(() => {
    const totals = {};
    expenses.forEach(e=>{ totals[e.category]=(totals[e.category]||0)+e.amount; });
    return totals;
  }, [expenses]);
  const donut = useMemo(
    () => Object.entries(byCat).sort((a,b)=>b[1]-a[1]).map(([cat,value])=>({label:cat,value,color:CC[cat]||t.textSub})),
    [byCat, CC, t.textSub]
  );
  const totalSpent=summary?.total_spent||0;
  const budget=trip?.budget||0;
  const remaining=budget-totalSpent;
  const progress=budget>0?Math.min((totalSpent/budget)*100,100):0;
  const over=remaining<0;
  const quickStats = useMemo(() => {
    if (!expenses.length) return [];
    const amounts = expenses.map(e => e.amount);
    return [
      ["Largest",   `₹${Math.max(...amounts).toLocaleString("en-IN")}`,t.rose],
      ["Smallest",  `₹${Math.min(...amounts).toLocaleString("en-IN")}`,t.green],
      ["Average",   `₹${Math.round(totalSpent/expenses.length).toLocaleString("en-IN")}`,t.accent],
      ["Top cat",   `${CI[donut[0]?.label]||""} ${donut[0]?.label||"—"}`,t.amber],
      ["Categories",`${Object.keys(byCat).length} of 7`,t.violet],
    ];
  }, [expenses, totalSpent, donut, byCat, t.rose, t.green, t.accent, t.amber, t.violet]);

  const cardStyle={background:t.card,border:`1px solid ${t.border}`,borderRadius:16,padding:"18px 20px",boxShadow:dark?"0 2px 10px rgba(0,0,0,.3)":"0 1px 5px rgba(0,0,0,.06)"};
  const selectStyle={background:t.surface,border:`1px solid ${t.border}`,borderRadius:8,padding:"7px 11px",color:t.text,fontSize:12,fontFamily:"inherit",outline:"none",cursor:"pointer"};
  const inpStyle=(f)=>({background:f?`${t.accent}08`:t.surface,border:`1px solid ${f?t.accent+"77":t.border}`,borderRadius:10,padding:"9px 12px",color:t.text,fontSize:13,outline:"none",fontFamily:"inherit",width:"100%",boxSizing:"border-box",boxShadow:f?`0 0 0 3px ${t.accent}14`:""});

  return (
    <div className="fade-up">
      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:20,flexWrap:"wrap",gap:10}}>
        <div>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>Budget Tracker</div>
          <div style={{color:t.textSub,fontSize:13,marginTop:3}}>{trip?`${trip.cover_emoji} ${trip.name} · ${expenses.length} expenses`:"Select a trip to view expenses"}</div>
        </div>
        <div style={{display:"flex",gap:10,alignItems:"center",flexWrap:"wrap"}}>
          <select value={tripId} onChange={setTripId} style={{...selectStyle,fontSize:13,padding:"8px 12px"}}>
            {trips.map(tr=><option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name}</option>)}
          </select>
          {tripId&&<Btn onClick={openAdd} dark={dark}>+ Add Expense</Btn>}
        </div>
      </div>

      {loading ? <div style={{display:"flex",justifyContent:"center",padding:60}}><Spinner dark={dark}/></div>
      : !tripId ? <Empty icon="💳" text="Select a trip to track expenses" dark={dark}/>
      : (<>
        {/* Stat cards */}
        <div className="budget-stats-grid">
          {[
            {label:"Budget",     value:`₹${budget.toLocaleString("en-IN")}`,        icon:"💰",color:t.accent},
            {label:"Spent",      value:`₹${totalSpent.toLocaleString("en-IN")}`,    icon:"💳",color:t.amber},
            {label:over?"Over!":"Remaining",value:`₹${Math.abs(remaining).toLocaleString("en-IN")}`,icon:over?"🚨":"🏦",color:over?t.red:t.green},
            {label:"Expenses",   value:expenses.length,                              icon:"🧾",color:t.violet},
          ].map((s,i)=>(
            <div key={s.label} className={`fade-up s${i+1}`} style={{...cardStyle,padding:"14px 16px"}}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                <div>
                  <div style={{fontSize:10,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".07em",marginBottom:5}}>{s.label}</div>
                  <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>{s.value}</div>
                </div>
                <span style={{fontSize:22}}>{s.icon}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Progress bar */}
        {budget>0&&(
          <div style={{...cardStyle,marginBottom:14}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:9}}>
              <div style={{fontWeight:600,fontSize:14,color:t.text}}>Budget Progress</div>
              <span style={{color:over?t.red:progress>80?t.amber:t.green,fontWeight:700,fontSize:14}}>{progress.toFixed(1)}%</span>
            </div>
            <ProgressBar value={progress} color={over?t.red:progress>80?t.amber:t.green} height={10} dark={dark}/>
            <div style={{display:"flex",justifyContent:"space-between",fontSize:12,color:t.textSub,marginTop:7}}>
              <span>₹{totalSpent.toLocaleString("en-IN")} spent</span>
              <span style={{color:over?t.red:t.textSub}}>{over?`⚠️ ₹${Math.abs(remaining).toLocaleString("en-IN")} over budget`:`₹${remaining.toLocaleString("en-IN")} remaining`}</span>
            </div>
          </div>
        )}

        {/* Charts row */}
        <div className="budget-charts-grid">
          <div style={cardStyle}>
            <div style={{fontWeight:600,fontSize:14,marginBottom:14,color:t.text}}>Spending by Category</div>
            {donut.length===0 ? <Empty icon="💰" text="No expenses yet" dark={dark}/> : (
              <div style={{display:"flex",gap:20,alignItems:"center",flexWrap:"wrap",justifyContent:"center"}}>
                <DonutChart data={donut} size={140} t={t}/>
                <div style={{flex:1,display:"flex",flexDirection:"column",gap:8}}>
                  {donut.map(d=>(
                    <div key={d.label}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:4}}>
                        <div style={{display:"flex",alignItems:"center",gap:6}}>
                          <span style={{fontSize:14}}>{CI[d.label]||"💡"}</span>
                          <span style={{fontSize:12,color:t.textSub,textTransform:"capitalize"}}>{d.label}</span>
                        </div>
                        <div style={{fontSize:12,fontWeight:700,color:t.text}}>₹{d.value.toLocaleString("en-IN")}</div>
                      </div>
                      <ProgressBar value={totalSpent>0?(d.value/totalSpent)*100:0} color={d.color} height={4} dark={dark}/>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div style={cardStyle}>
            <div style={{fontWeight:600,fontSize:14,marginBottom:14,color:t.text}}>Quick Stats</div>
            {expenses.length===0 ? <Empty icon="📊" text="No data yet" dark={dark}/> : (
              <div style={{display:"flex",flexDirection:"column",gap:8}}>
                {quickStats.map(([l,v,c])=>(
                  <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"7px 11px",background:t.surface,borderRadius:8,border:`1px solid ${t.border}`}}>
                    <span style={{fontSize:12,color:t.textSub}}>{l}</span>
                    <span style={{fontSize:12,fontWeight:700,color:c}}>{v}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Expenses list */}
        <div style={cardStyle}>
          <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14,flexWrap:"wrap",gap:8}}>
            <div style={{fontWeight:600,fontSize:14,color:t.text}}>All Expenses ({filtered.length})</div>
            <div style={{display:"flex",gap:8}}>
              <select value={filterCat} onChange={e=>setFilterCat(e.target.value)} style={selectStyle}>
                <option value="all">All Categories</option>
                {CATS.map(c=><option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
              <select value={sortBy} onChange={e=>setSortBy(e.target.value)} style={selectStyle}>
                <option value="newest">Newest</option>
                <option value="oldest">Oldest</option>
                <option value="highest">Highest ₹</option>
                <option value="lowest">Lowest ₹</option>
              </select>
            </div>
          </div>
          {filtered.length===0 ? <Empty icon="🧾" text="No expenses match filter" dark={dark}/> : (
            <div style={{display:"flex",flexDirection:"column",gap:6}}>
              {filtered.map(ex=>(
                <div key={ex.id} className="fade-in"
                  style={{display:"flex",flexDirection:"column",gap:12,padding:"14px",background:t.surface,borderRadius:12,border:`1px solid ${t.border}`,transition:"border-color .14s"}}
                  onMouseEnter={e=>e.currentTarget.style.borderColor=t.borderLight}
                  onMouseLeave={e=>e.currentTarget.style.borderColor=t.border}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:10}}>
                    <div style={{display:"flex",gap:12,minWidth:0}}>
                      <div style={{width:40,height:40,borderRadius:10,background:`${CC[ex.category]}20`,border:`1px solid ${CC[ex.category]}40`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:18,flexShrink:0}}>
                        {CI[ex.category]||"💡"}
                      </div>
                      <div style={{flex:1,minWidth:0}}>
                        <div style={{fontWeight:700,fontSize:14,color:t.text,marginBottom:3,wordBreak:"break-word"}}>{ex.title}</div>
                        <div style={{display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
                          <Badge color={CC[ex.category]} dark={dark}>{ex.category}</Badge>
                          <span style={{fontSize:11,color:t.textSub}}>{new Date(ex.spent_at).toLocaleDateString("en-IN",{day:"numeric",month:"short"})}</span>
                        </div>
                      </div>
                    </div>
                    <div style={{fontSize:16,fontWeight:900,color:t.amber,flexShrink:0,textAlign:"right"}}>₹{ex.amount.toLocaleString("en-IN")}</div>
                  </div>
                  {ex.notes && <div style={{fontSize:12,color:t.textSub,fontStyle:"italic",paddingLeft:52}}>"{ex.notes}"</div>}
                  <div style={{display:"flex",justifyContent:"flex-end",gap:8,marginTop:2}}>
                    <button onClick={()=>openEdit(ex)}
                      style={{padding:"6px 12px",borderRadius:8,border:`1px solid ${t.border}`,background:"transparent",color:t.textSub,cursor:"pointer",fontSize:11,fontWeight:600,transition:"all .15s"}}
                      onMouseEnter={e=>{e.currentTarget.style.borderColor=t.accent;e.currentTarget.style.color=t.accent;e.currentTarget.style.background=t.accentSoft;}}
                      onMouseLeave={e=>{e.currentTarget.style.borderColor=t.border;e.currentTarget.style.color=t.textSub;e.currentTarget.style.background="transparent";}}>✏️ Edit</button>
                    <button onClick={()=>remove(ex.id)}
                      style={{padding:"6px 12px",borderRadius:8,border:`1px solid ${t.red}33`,background:`${t.red}10`,color:t.red,cursor:"pointer",fontSize:11,fontWeight:600}}>🗑️ Delete</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </>)}

      {/* Modal */}
      {showModal && (
        <Modal title={editing?"✏️ Edit Expense":"➕ Add Expense"} width={420} dark={dark} onClose={()=>setShowModal(false)}>
          <div style={{display:"flex",flexDirection:"column",gap:12}}>
            <form onSubmit={save} style={{display:"flex",flexDirection:"column",gap:12}}>
              <div>
                <label style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",display:"block",marginBottom:4}}>Description *</label>
                <input value={form.title} onChange={sf("title")} placeholder="Dinner at local dhaba" autoFocus required
                  style={inpStyle(focusField==="title")} onFocus={()=>setFocusField("title")} onBlur={()=>setFocusField("")}/>
              </div>
              <div>
                <label style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",display:"block",marginBottom:4}}>Amount (₹) *</label>
                <input type="number" value={form.amount} onChange={sf("amount")} placeholder="850" required
                  style={inpStyle(focusField==="amount")} onFocus={()=>setFocusField("amount")} onBlur={()=>setFocusField("")}/>
              </div>
              <div>
                <label style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",display:"block",marginBottom:4}}>Category</label>
                <select value={form.category} onChange={sf("category")} style={inpStyle(focusField==="category")} onFocus={()=>setFocusField("category")} onBlur={()=>setFocusField("")}>
                  {CATS.map(c=><option key={c.value} value={c.value}>{c.label}</option>)}
                </select>
              </div>
              <div>
                <label style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",display:"block",marginBottom:4}}>Notes</label>
                <input value={form.notes} onChange={sf("notes")} placeholder="Optional note…"
                  style={inpStyle(focusField==="notes")} onFocus={()=>setFocusField("notes")} onBlur={()=>setFocusField("")}/>
              </div>
              {err&&<div style={{color:t.red,fontSize:12,padding:"8px 12px",background:`${t.red}12`,borderRadius:8,border:`1px solid ${t.red}33`}}>{err}</div>}
              <Btn type="submit" loading={saving} style={{width:"100%",justifyContent:"center",marginTop:8,height:44}}>
                {editing?"Save Changes":"Add Expense"}
              </Btn>
            </form>
          </div>
        </Modal>
      )}
    </div>
  );
}
