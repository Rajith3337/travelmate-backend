import { useState, useEffect, useMemo, useCallback } from "react";
import { Spinner, Empty } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";
import { useOfflineSync } from "../hooks/useOfflineSync";
import {
  getCachedTrips, getCachedSummary, fetchTrips, fetchSummary, subscribeToStore
} from "../cache/dataStore";

function greet() {
  const h = new Date().getHours();
  return h<5?"Good night":h<12?"Good morning":h<17?"Good afternoon":h<21?"Good evening":"Good night";
}

function nav(page) {
  window.dispatchEvent(new CustomEvent("navigate", { detail: page }));
}

const QUICK_ACTIONS = [
  { label:"New Trip",    icon:"✈️", page:"trips",   color:"#3B82F6" },
  { label:"Map",         icon:"🗺️", page:"map",     color:"#10B981" },
  { label:"Budget",      icon:"💳", page:"budget",  color:"#F59E0B" },
  { label:"AI",          icon:"🤖", page:"ai",      color:"#8B5CF6" },
  { label:"Planner",     icon:"📅", page:"planner", color:"#EC4899" },
  { label:"Translate",   icon:"🌐", page:"translate",color:"#F97316" },
];

function QuickAction({ item, t }) {
  return (
    <button onClick={() => nav(item.page)}
      style={{
        display:"flex", flexDirection:"column", alignItems:"center", gap:8,
        padding:"14px 8px", borderRadius:14,
        background:t.card, border:`1.5px solid ${t.border}`,
        cursor:"pointer", fontFamily:"inherit",
        transition:"all .18s cubic-bezier(.16,.84,.44,1)",
        WebkitTapHighlightColor:"transparent",
        touchAction:"manipulation",
      }}
      onMouseEnter={e=>{e.currentTarget.style.borderColor=item.color;e.currentTarget.style.transform="translateY(-2px)";e.currentTarget.style.boxShadow=`0 8px 20px ${item.color}22`;}}
      onMouseLeave={e=>{e.currentTarget.style.borderColor=t.border;e.currentTarget.style.transform="";e.currentTarget.style.boxShadow="";}}>
      <div style={{width:44,height:44,borderRadius:12,background:`${item.color}15`,border:`1.5px solid ${item.color}33`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22}}>
        {item.icon}
      </div>
      <span style={{fontSize:11,fontWeight:600,color:t.textSub,letterSpacing:".01em",whiteSpace:"nowrap"}}>{item.label}</span>
    </button>
  );
}

function TripCard({ tr, spent, t, dark }) {
  const pr = tr.budget > 0 ? Math.min(100, (spent / tr.budget) * 100) : 0;
  const barColor = pr > 85 ? "#EF4444" : pr > 65 ? "#F59E0B" : t.accent;
  const days = tr.start_date ? Math.ceil((new Date(tr.start_date) - new Date()) / 86400000) : null;
  const statusColor = tr.status==="active" ? "#10B981" : tr.status==="completed" ? t.textDim : t.accent;

  return (
    <div onClick={() => nav("trips")}
      style={{
        background:t.card, border:`1.5px solid ${t.border}`,
        borderRadius:16, padding:"16px", cursor:"pointer",
        transition:"all .18s", WebkitTapHighlightColor:"transparent",
        touchAction:"manipulation",
        boxShadow: dark ? "0 2px 8px rgba(0,0,0,.2)" : "0 2px 8px rgba(30,60,120,0.06)",
      }}
      onMouseEnter={e=>{e.currentTarget.style.borderColor=`${t.accent}55`;e.currentTarget.style.transform="translateY(-1px)";}}
      onMouseLeave={e=>{e.currentTarget.style.borderColor=t.border;e.currentTarget.style.transform="";}}>
      <div style={{display:"flex",alignItems:"flex-start",gap:12,marginBottom:pr>0?12:0}}>
        <div style={{width:44,height:44,borderRadius:12,background:`${tr.cover_color||t.accent}18`,border:`1.5px solid ${tr.cover_color||t.accent}33`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0}}>
          {tr.cover_emoji}
        </div>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:15,fontWeight:700,color:t.text,marginBottom:2,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{tr.name}</div>
          <div style={{fontSize:12,color:t.textSub,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>📍 {tr.destination}</div>
        </div>
        <div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:4,flexShrink:0}}>
          <span style={{fontSize:10,fontWeight:700,color:statusColor,background:`${statusColor}15`,padding:"2px 8px",borderRadius:99,textTransform:"capitalize"}}>
            {tr.status||"planned"}
          </span>
          {days !== null && days >= 0 && (
            <span style={{fontSize:11,fontWeight:700,color:days<=3?t.rose:days<=7?t.amber:t.accent}}>
              {days===0?"Today":`${days}d`}
            </span>
          )}
        </div>
      </div>
      {tr.budget > 0 && (
        <div>
          <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:t.textSub,marginBottom:5}}>
            <span>₹{spent.toLocaleString("en-IN")} spent</span>
            <span style={{fontWeight:600}}>₹{Math.max(0,tr.budget-spent).toLocaleString("en-IN")} left</span>
          </div>
          <div style={{height:4,background:t.border,borderRadius:99,overflow:"hidden"}}>
            <div style={{height:"100%",width:`${pr}%`,background:barColor,borderRadius:99,transition:"width 1s cubic-bezier(.16,.84,.44,1)"}}/>
          </div>
        </div>
      )}
    </div>
  );
}

function StatPill({ label, value, color, t }) {
  return (
    <div style={{
      background:t.card, border:`1.5px solid ${t.border}`,
      borderRadius:14, padding:"14px 16px",
      display:"flex", flexDirection:"column", gap:4,
    }}>
      <div style={{fontSize:22,fontWeight:800,color,fontVariantNumeric:"tabular-nums"}}>{value}</div>
      <div style={{fontSize:11,color:t.textSub,fontWeight:600,letterSpacing:".04em"}}>{label}</div>
    </div>
  );
}

export default function Dashboard({ dark = true }) {
  const t = dark ? DARK : LIGHT;
  const { online, pendingCount } = useOfflineSync();
  // Read from cache immediately — no loading delay if already prefetched
  const [trips, setTrips] = useState(() => getCachedTrips() || []);
  const [summaries, setSummaries] = useState(() => {
    const cached = getCachedTrips() || [];
    const s = {};
    cached.forEach(tr => { const sum = getCachedSummary(tr.id); if (sum) s[tr.id] = sum; });
    return s;
  });
  // Only show spinner on very first load when cache is completely empty
  const [loading, setLoading] = useState(() => !getCachedTrips());

  const refresh = useCallback(async (force = false) => {
    try {
      const data = await fetchTrips(force);
      setTrips(data);
      // Fetch ALL summaries in parallel — no await chain, fully non-blocking
      data.slice(0, 10).forEach(async tr => {
        try {
          const s = await fetchSummary(tr.id, force);
          if (s) setSummaries(prev => ({ ...prev, [tr.id]: s }));
        } catch {}
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh(false); // shows cache immediately, background refresh
    const unsub = subscribeToStore(() => {
      const cached = getCachedTrips();
      if (cached) setTrips(cached);
    });
    const onUpdated = () => refresh(true);
    window.addEventListener("tm_trips_updated", onUpdated);
    window.addEventListener("tm_data_updated", onUpdated);
    return () => { unsub(); window.removeEventListener("tm_trips_updated", onUpdated); window.removeEventListener("tm_data_updated", onUpdated); };
  }, [refresh]);

  const active = useMemo(
    () => trips.find(tr => tr.status==="active") || trips[0],
    [trips]
  );
  const totalBudget = useMemo(
    () => trips.reduce((s,tr) => s+(tr.budget||0), 0),
    [trips]
  );
  const totalSpent = useMemo(
    () => Object.values(summaries).reduce((s,v) => s+(v?.total_spent||0), 0),
    [summaries]
  );
  const upcoming = useMemo(
    () => trips.filter(tr => tr.start_date && tr.status!=="completed" && tr.status!=="active"),
    [trips]
  );
  const completedCount = useMemo(
    () => trips.filter(tr=>tr.status==="completed").length,
    [trips]
  );
  const upcomingTop = useMemo(() => upcoming.slice(0,4), [upcoming]);

  if (loading) return (
    <div style={{display:"flex",alignItems:"center",justifyContent:"center",height:"70vh",flexDirection:"column",gap:14}}>
      <Spinner size={36} dark={dark}/>
      <div style={{fontSize:13,color:t.textSub}}>Loading your travels…</div>
    </div>
  );

  return (
    <div className="page-enter" style={{paddingBottom:"calc(80px + env(safe-area-inset-bottom, 0px))"}}>

      {/* Header */}
      <div style={{marginBottom:20}}>
        <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:8}}>
          <span style={{width:7,height:7,borderRadius:"50%",background:online?"#10B981":"#F59E0B",display:"inline-block",boxShadow:online?"0 0 0 3px #10B98122":"0 0 0 3px #F59E0B22"}}/>
          <span style={{fontSize:12,color:t.textSub}}>{online?"Connected":`Offline · ${pendingCount} queued`}</span>
        </div>
        <h1 style={{fontSize:28,fontWeight:800,color:t.text,letterSpacing:"-.02em",marginBottom:4}}>{greet()} 👋</h1>
        <p style={{fontSize:13,color:t.textSub}}>
          {new Date().toLocaleDateString("en-IN",{weekday:"long",day:"numeric",month:"long"})}
        </p>
      </div>

      {/* Active trip hero */}
      {active && (() => {
        const sp = summaries[active.id]?.total_spent || 0;
        const pr = active.budget > 0 ? Math.min(100,(sp/active.budget)*100) : 0;
        const daysLeft = active.end_date ? Math.ceil((new Date(active.end_date)-new Date())/86400000) : null;
        return (
          <div onClick={() => nav("trips")}
            style={{
              background:`linear-gradient(135deg,${active.cover_color||t.accent}18,${active.cover_color||t.accent}08)`,
              border:`1.5px solid ${active.cover_color||t.accent}44`,
              borderRadius:20, padding:"18px 20px", marginBottom:20,
              cursor:"pointer", position:"relative", overflow:"hidden",
              WebkitTapHighlightColor:"transparent",
            }}>
            <div style={{position:"absolute",top:-30,right:-30,width:120,height:120,borderRadius:"50%",background:`${active.cover_color||t.accent}18`,pointerEvents:"none"}}/>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
              <div style={{flex:1,minWidth:0}}>
                <div style={{fontSize:10,fontWeight:700,color:active.cover_color||t.accent,textTransform:"uppercase",letterSpacing:".1em",marginBottom:4}}>Active Trip</div>
                <div style={{fontSize:20,fontWeight:800,color:t.text,letterSpacing:"-.01em",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                  {active.cover_emoji} {active.name}
                </div>
                <div style={{fontSize:13,color:t.textSub,marginTop:3}}>📍 {active.destination}</div>
              </div>
              {daysLeft !== null && daysLeft >= 0 && (
                <div style={{textAlign:"center",flexShrink:0,marginLeft:12}}>
                  <div style={{fontSize:28,fontWeight:800,color:active.cover_color||t.accent,lineHeight:1}}>{daysLeft===0?"Today":daysLeft}</div>
                  {daysLeft > 0 && <div style={{fontSize:10,color:t.textSub}}>days left</div>}
                </div>
              )}
            </div>
            {active.budget > 0 && (
              <>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:12,color:t.textSub,marginBottom:6}}>
                  <span>₹{sp.toLocaleString("en-IN")} spent</span>
                  <span style={{fontWeight:600,color:pr>85?"#EF4444":pr>65?"#F59E0B":active.cover_color||t.accent}}>
                    {pr.toFixed(0)}%
                  </span>
                </div>
                <div style={{height:5,background:`${active.cover_color||t.accent}22`,borderRadius:99,overflow:"hidden"}}>
                  <div style={{height:"100%",width:`${pr}%`,background:active.cover_color||t.accent,borderRadius:99,transition:"width 1s cubic-bezier(.16,.84,.44,1)"}}/>
                </div>
              </>
            )}
          </div>
        );
      })()}

      {/* Stats */}
      <div className="dashboard-stats-grid">
        <StatPill label="Total Trips"  value={trips.length} color={t.accent} t={t}/>
        <StatPill label="Completed"    value={completedCount} color="#10B981" t={t}/>
        <StatPill label="Total Budget" value={totalBudget?`₹${Math.round(totalBudget/1000)}K`:"₹0"} color="#F59E0B" t={t}/>
        <StatPill label="Total Spent"  value={totalSpent?`₹${Math.round(totalSpent/1000)}K`:"₹0"} color={totalSpent>totalBudget*0.9?"#EF4444":t.violet} t={t}/>
      </div>

      {/* Quick actions */}
      <div style={{marginBottom:20}}>
        <div style={{fontSize:12,fontWeight:700,color:t.textDim,textTransform:"uppercase",letterSpacing:".08em",marginBottom:12}}>Quick Access</div>
        <div className="dashboard-actions-grid">
          {QUICK_ACTIONS.map(item => <QuickAction key={item.page} item={item} t={t}/>)}
        </div>
      </div>

      {/* All trips */}
      <div style={{marginBottom:20}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
          <div style={{fontSize:16,fontWeight:700,color:t.text}}>My Trips</div>
          <button onClick={()=>nav("trips")} style={{fontSize:13,color:t.accent,background:"none",border:"none",cursor:"pointer",fontFamily:"inherit",fontWeight:600}}>See all →</button>
        </div>
        {trips.length === 0
          ? <Empty icon="✈️" text="No trips yet" sub="Create your first trip to get started" dark={dark}/>
          : <div style={{display:"flex",flexDirection:"column",gap:10}}>
              {trips.slice(0,4).map(tr => (
                <TripCard key={tr.id} tr={tr} spent={summaries[tr.id]?.total_spent||0} t={t} dark={dark}/>
              ))}
            </div>
        }
      </div>

      {/* Upcoming */}
      {upcomingTop.length > 0 && (
        <div style={{marginBottom:20}}>
          <div style={{fontSize:16,fontWeight:700,color:t.text,marginBottom:12}}>Upcoming</div>
          <div style={{background:t.card,border:`1.5px solid ${t.border}`,borderRadius:16,overflow:"hidden",boxShadow:dark?"0 2px 8px rgba(0,0,0,.2)":"0 2px 8px rgba(30,60,120,0.06)"}}>
            {upcomingTop.map((tr,i) => {
              const days = Math.ceil((new Date(tr.start_date)-new Date())/86400000);
              return (
                <div key={tr.id} style={{display:"flex",alignItems:"center",gap:12,padding:"14px 16px",borderBottom:i<upcomingTop.length-1?`1px solid ${t.border}`:"none"}}>
                  <span style={{fontSize:22,flexShrink:0}}>{tr.cover_emoji}</span>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{fontSize:14,fontWeight:600,color:t.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{tr.name}</div>
                    <div style={{fontSize:12,color:t.textSub}}>{tr.destination} · {tr.start_date}</div>
                  </div>
                  <div style={{fontSize:13,fontWeight:800,color:days<=0?"#10B981":days<=3?t.rose:days<=7?t.amber:t.accent,flexShrink:0,background:days<=3?`${t.rose}12`:`${t.accent}10`,padding:"4px 10px",borderRadius:99}}>
                    {days<=0?"Now":`${days}d`}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}