import { useState, useEffect, useMemo, useCallback } from "react";
import { createPortal } from "react-dom";
import { tripsApi, shareApi } from "../api/client";
import { Badge, ProgressBar, Btn, Spinner, Empty } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";
import LocationInput from "../components/LocationInput";

const statusColor = (s, t) => ({ upcoming:t.amber, completed:t.green, active:t.accent, ongoing:t.accent, planning:t.violet })[s] || t.textSub;
const EMOJIS = [
  "\u2708\uFE0F",
  "\u{1F3D6}\uFE0F",
  "\u{1F3D4}\uFE0F",
  "\u{1F3DC}\uFE0F",
  "\u{1F334}",
  "\u{1F5FA}\uFE0F",
  "\u{1F3D5}\uFE0F",
  "\u{1F682}",
  "\u{1F6F3}\uFE0F",
  "\u2615",
  "\u{1F30B}",
  "\u{1F3DB}\uFE0F",
  "\u{1F3A1}",
  "\u{1F30F}",
  "\u{1F3C4}",
  "\u{1F3BF}"
];
const COLORS  = ["#38BDF8","#34D399","#FBBF24","#F43F5E","#818CF8","#FB923C","#A78BFA","#6EE7B7"];
const STATUSES = [{value:"planning",label:"Planning"},{value:"upcoming",label:"Upcoming"},{value:"active",label:"Active"},{value:"completed",label:"Completed"}];
const BLANK = {name:"",destination:"",start_location:"",description:"",cover_emoji:"\u2708\uFE0F",cover_color:"#38BDF8",start_date:"",end_date:"",status:"planning",budget:""};

const getNormalizedEmoji = (val) => {
  if (!val) return "\u2708\uFE0F";
  if (val.toUpperCase() === "DESERT") return "\u{1F42B}";
  if (val.toUpperCase() === "SNOW") return "\u{1F3D4}\uFE0F";
  if (val.length > 5) return "\u2708\uFE0F";
  return val;
};

function InlineInput({label,value,onChange,type="text",placeholder,required,t}) {
  const [foc,setFoc]=useState(false);
  return (
    <div>
      {label&&<label style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",display:"block",marginBottom:4}}>{label}</label>}
      <input type={type} value={value} onChange={onChange} placeholder={placeholder} required={required}
        onFocus={()=>setFoc(true)} onBlur={()=>setFoc(false)}
        style={{width:"100%",background:t.surface,border:`1px solid ${foc?t.accent+"77":t.border}`,borderRadius:9,padding:"8px 11px",color:t.text,fontSize:13,outline:"none",fontFamily:"inherit",boxSizing:"border-box",boxShadow:foc?`0 0 0 3px ${t.accent}14`:""}}/>
    </div>
  );
}

export default function MyTrips({ dark = true }) {
  const t = dark ? DARK : LIGHT;
  const [trips,     setTrips]     = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [filter,    setFilter]    = useState("all");
  const [showModal, setShowModal] = useState(false);
  const [showShare, setShowShare] = useState(null);
  const [shareLink, setShareLink] = useState("");
  const [shareCopied,setShareCopied]=useState(false);
  const [sharing,   setSharing]   = useState(false);
  const [editing,   setEditing]   = useState(null);
  const [form,      setForm]      = useState(BLANK);
  const [err,       setErr]       = useState("");
  const [saving,    setSaving]    = useState(false);
  // Per-card loading states — keyed by trip ID so only that card is affected
  const [deletingId, setDeletingId] = useState(null); // ID currently being deleted
  const [confirmDeleteId, setConfirmDeleteId] = useState(null); // ID awaiting confirmation
  const [editingLoadId, setEditingLoadId] = useState(null); // ID whose edit is saving

  const load = useCallback(
    () => tripsApi.list().then(setTrips).catch(console.error).finally(()=>setLoading(false)),
    []
  );
  useEffect(()=>{
    load();
    const handler = () => load();
    window.addEventListener("tm_trips_updated", handler);
    window.addEventListener("tm_data_updated", handler);
    return () => {
      window.removeEventListener("tm_trips_updated", handler);
      window.removeEventListener("tm_data_updated", handler);
    };
  },[load]);

  const set = k => e => setForm(f=>({...f,[k]:e.target.value}));

  const openCreate = () => { setEditing(null);setForm(BLANK);setErr("");setShowModal(true); };
  const openEdit   = tr => { setEditing(tr);setForm({name:tr.name,destination:tr.destination,start_location:tr.start_location||"",description:tr.description||"",cover_emoji:tr.cover_emoji||"\u2708\uFE0F",cover_color:tr.cover_color,start_date:tr.start_date||"",end_date:tr.end_date||"",status:tr.status,budget:tr.budget});setErr("");setShowModal(true); };

  const openShare = async tr => {
    setShowShare(tr);setShareLink("");setShareCopied(false);setSharing(true);
    try { const {share_url}=await shareApi.create(tr.id); setShareLink(window.location.origin+share_url); }
    catch(ex) { setShareLink("Error: "+ex.message); }
    finally { setSharing(false); }
  };

  const copyLink = () => { navigator.clipboard.writeText(shareLink).then(()=>{setShareCopied(true);setTimeout(()=>setShareCopied(false),2000);}); };
  const revokeShare = async () => { await shareApi.revoke(showShare.id);setShareLink("");setShowShare(null); };

  const save = async e => {
    e.preventDefault();setErr("");setSaving(true);
    if(editing) setEditingLoadId(editing.id);
    try {
      const payload={...form,budget:parseFloat(form.budget)||0};
      if(editing) await tripsApi.update(editing.id,payload);
      else        await tripsApi.create(payload);
      await load();setShowModal(false);
    } catch(ex){setErr(ex.message);}
    finally{setSaving(false);setEditingLoadId(null);}
  };

  const confirmDelete = (id) => setConfirmDeleteId(id);

  const remove = async id => {
    setConfirmDeleteId(null);
    setDeletingId(id);
    try { await tripsApi.delete(id); await load(); }
    catch(ex){ console.error(ex); }
    finally { setDeletingId(null); }
  };

  const filtered = useMemo(
    () => filter==="all" ? trips : trips.filter(tr=>tr.status===filter),
    [filter, trips]
  );
  const activeTripsCount = useMemo(
    () => trips.filter(tr=>tr.status==="active"||tr.status==="ongoing").length,
    [trips]
  );

  const inputStyle = (foc=false) => ({width:"100%",background:t.surface,border:`1px solid ${foc?t.accent+"77":t.border}`,borderRadius:9,padding:"8px 11px",color:t.text,fontSize:13,outline:"none",fontFamily:"inherit",boxSizing:"border-box"});
  const modalTitle = editing ? `\u270F\uFE0F Edit Trip` : `\u2708\uFE0F New Trip`;
  const shareTitle = `\u{1F517} Share Trip`;

  return (
    <div className="fade-up">
      {/* Header */}
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22,flexWrap:"wrap",gap:12}}>
        <div>
          <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>My Trips</div>
          <div style={{color:t.textSub,fontSize:13,marginTop:3}}>{trips.length} trip{trips.length!==1?"s":""} {"\u00B7"} {activeTripsCount} active</div>
        </div>
        <Btn onClick={openCreate} dark={dark}>+ New Trip</Btn>
      </div>

      {/* Filter pills */}
      <div style={{display:"flex",gap:6,marginBottom:22,flexWrap:"wrap"}}>
        {["all","planning","upcoming","active","completed"].map(s=>(
          <button key={s} onClick={()=>setFilter(s)}
            style={{padding:"6px 15px",borderRadius:99,fontSize:12,fontWeight:600,cursor:"pointer",fontFamily:"inherit",textTransform:"capitalize",
              background:filter===s?t.accent:"transparent",
              color:filter===s?"#fff":t.textSub,
              border:`1px solid ${filter===s?t.accent:t.border}`,
              transition:"all .16s",
            }}>{s==="all"?`All (${trips.length})`:s}</button>
        ))}
      </div>

      {loading ? (
        <div style={{display:"flex",justifyContent:"center",padding:60}}><Spinner dark={dark}/></div>
      ) : (
        <div className="mytrips-grid">
          {filtered.length===0 ? (
            <div style={{gridColumn:"1/-1"}}><Empty icon="✈️" text={filter==="all"?"No trips yet - create your first one!":`No ${filter} trips`} dark={dark}/></div>
          ) : filtered.map(tr=>{
            const pct = tr.budget>0 ? Math.min((tr.spent||0)/tr.budget*100,100) : 0;
            const sc  = statusColor(tr.status,t);
            return (
              <div key={tr.id} className="fade-up"
                style={{background:t.card,border:`1px solid ${
                  deletingId===tr.id ? t.red+"55" :
                  editingLoadId===tr.id ? t.accent+"55" : t.border
                }`,borderRadius:16,overflow:"hidden",display:"flex",flexDirection:"column",position:"relative",
                  transition:"all .22s cubic-bezier(.22,.68,0,1.2)",
                  opacity: deletingId===tr.id ? 0.6 : 1,
                  transform: deletingId===tr.id ? "scale(0.97)" : "",
                  boxShadow:dark?"0 2px 10px rgba(0,0,0,.3)":"0 1px 5px rgba(0,0,0,.07)"}}
                onMouseEnter={e=>{ if(deletingId===tr.id||editingLoadId===tr.id) return; e.currentTarget.style.transform="translateY(-3px)";e.currentTarget.style.boxShadow=`0 14px 36px ${tr.cover_color}20`;e.currentTarget.style.borderColor=tr.cover_color+"44";}}
                onMouseLeave={e=>{ if(deletingId===tr.id||editingLoadId===tr.id) return; e.currentTarget.style.transform="";e.currentTarget.style.boxShadow=dark?"0 2px 10px rgba(0,0,0,.3)":"0 1px 5px rgba(0,0,0,.07)";e.currentTarget.style.borderColor=t.border;}}>

                {/* Per-card loading overlay */}
                {(deletingId===tr.id || editingLoadId===tr.id) && (
                  <div style={{position:"absolute",inset:0,zIndex:10,borderRadius:16,
                    background: deletingId===tr.id ? `${t.red}18` : `${t.accent}12`,
                    backdropFilter:"blur(2px)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:8,pointerEvents:"all"}}>
                    <div style={{width:28,height:28,borderRadius:"50%",
                      border:`3px solid ${deletingId===tr.id ? t.red : t.accent}22`,
                      borderTopColor: deletingId===tr.id ? t.red : t.accent,
                      animation:"spin .8s linear infinite"}} />
                    <div style={{fontSize:11,fontWeight:600,color: deletingId===tr.id ? t.red : t.accent,letterSpacing:".04em"}}>
                      {deletingId===tr.id ? "Deleting…" : "Saving…"}
                    </div>
                  </div>
                )}

                {/* Delete confirmation inline popup */}
                {confirmDeleteId===tr.id && (
                  <div style={{position:"absolute",inset:0,zIndex:11,borderRadius:16,
                    background:dark?"rgba(10,6,22,.88)":"rgba(255,255,255,.92)",
                    backdropFilter:"blur(6px)",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",gap:10,padding:"16px",pointerEvents:"all"}}>
                    <div style={{fontSize:26}}>🗑️</div>
                    <div style={{fontSize:13,fontWeight:700,color:t.text,textAlign:"center",lineHeight:1.4}}>Delete this trip?</div>
                    <div style={{fontSize:11,color:t.textSub,textAlign:"center"}}>All data will be permanently removed.</div>
                    <div style={{display:"flex",gap:8,marginTop:4}}>
                      <button onClick={()=>setConfirmDeleteId(null)}
                        style={{padding:"7px 16px",borderRadius:8,border:`1px solid ${t.border}`,background:t.surface,color:t.textSub,cursor:"pointer",fontSize:12,fontWeight:600,fontFamily:"inherit",transition:"all .14s"}}
                        onMouseEnter={e=>e.currentTarget.style.background=t.card}
                        onMouseLeave={e=>e.currentTarget.style.background=t.surface}>
                        Cancel
                      </button>
                      <button onClick={()=>remove(tr.id)}
                        style={{padding:"7px 16px",borderRadius:8,border:"none",background:`linear-gradient(135deg,${t.red},#b91c1c)`,color:"#fff",cursor:"pointer",fontSize:12,fontWeight:700,fontFamily:"inherit",boxShadow:`0 4px 14px ${t.red}44`,transition:"all .14s"}}
                        onMouseEnter={e=>e.currentTarget.style.opacity="0.88"}
                        onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
                        Delete
                      </button>
                    </div>
                  </div>
                )}

                {/* Cover */}
                <div style={{height:72,background:`linear-gradient(135deg,${tr.cover_color}28,${tr.cover_color}0A)`,borderBottom:`1px solid ${tr.cover_color}22`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:38,flexShrink:0}}>
                  {getNormalizedEmoji(tr.cover_emoji)}
                </div>
                <div style={{padding:"14px 16px",flex:1,display:"flex",flexDirection:"column"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                    <div style={{fontFamily:"'Playfair Display',serif",fontWeight:700,fontSize:15,flex:1,marginRight:8,color:t.text,lineHeight:1.3}}>{tr.name}</div>
                    <Badge color={sc} dark={dark}>{tr.status}</Badge>
                  </div>
                  <div style={{color:t.textSub,fontSize:12,marginBottom:3}}>
                    {tr.start_location
                      ? <span>{"\u{1F4CD}"} <b style={{color:t.text}}>{tr.start_location}</b> {"\u2192"} <span style={{color:t.accent}}>{tr.destination}</span></span>
                      : <span>{"\u{1F4CD}"} <span style={{color:t.accent}}>{tr.destination}</span></span>}
                  </div>
                  {tr.start_date&&<div style={{color:t.textDim,fontSize:11,marginBottom:10,whiteSpace:"normal",wordBreak:"break-word",lineHeight:1.4}}>{"\u{1F5D3}\uFE0F"} {tr.start_date}{tr.end_date?` \u2192 ${tr.end_date}`:""}</div>}
                  <div style={{flex:1}}/>
                  {tr.budget>0&&<>
                    <div style={{marginBottom:5}}><ProgressBar value={pct} color={pct>85?t.red:pct>65?t.amber:tr.cover_color||t.accent} height={4} dark={dark}/></div>
                    <div style={{display:"flex",justifyContent:"space-between",fontSize:11,color:t.textSub,marginBottom:12}}>
                      <span>{"\u20B9"}{(tr.spent||0).toLocaleString("en-IN")} spent</span>
                      <span>{pct.toFixed(0)}% of {"\u20B9"}{tr.budget.toLocaleString("en-IN")}</span>
                    </div>
                  </>}
                  <div className="trip-actions-row">
                    <button onClick={()=>openEdit(tr)} disabled={deletingId===tr.id||editingLoadId===tr.id}
                      style={{padding:"7px",borderRadius:8,border:`1px solid ${t.border}`,background:"transparent",color:t.textSub,cursor:deletingId===tr.id||editingLoadId===tr.id?"not-allowed":"pointer",fontSize:12,transition:"all .14s",opacity:deletingId===tr.id?0.4:1}}
                      onMouseEnter={e=>{if(!deletingId&&!editingLoadId){e.currentTarget.style.background=t.surface;e.currentTarget.style.color=t.text;}}}
                      onMouseLeave={e=>{e.currentTarget.style.background="transparent";e.currentTarget.style.color=t.textSub;}}>
                      ✏️ Edit
                    </button>
                    <button onClick={()=>openShare(tr)} disabled={deletingId===tr.id}
                      style={{padding:"7px",borderRadius:8,border:`1px solid ${t.accent}33`,background:t.accentSoft,color:t.accent,cursor:deletingId===tr.id?"not-allowed":"pointer",fontSize:12,transition:"all .14s",opacity:deletingId===tr.id?0.4:1}}
                      onMouseEnter={e=>{if(!deletingId)e.currentTarget.style.opacity="0.8";}}
                      onMouseLeave={e=>e.currentTarget.style.opacity="1"}>
                      🔗 Share
                    </button>
                    <button onClick={()=>confirmDelete(tr.id)} disabled={deletingId===tr.id||editingLoadId===tr.id}
                      style={{padding:"7px",borderRadius:8,border:`1px solid ${t.red}33`,background:`${t.red}10`,color:t.red,cursor:deletingId===tr.id||editingLoadId===tr.id?"not-allowed":"pointer",fontSize:12,transition:"all .14s",opacity:deletingId===tr.id?0.4:1}}
                      onMouseEnter={e=>{if(!deletingId&&!editingLoadId){e.currentTarget.style.background=`${t.red}20`;e.currentTarget.style.borderColor=t.red+"66";}}}
                      onMouseLeave={e=>{e.currentTarget.style.background=`${t.red}10`;e.currentTarget.style.borderColor=t.red+"33";}}>
                      🗑️
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Trip form modal */}
      {showModal && createPortal(
        <div onClick={e=>e.target===e.currentTarget&&setShowModal(false)}
          style={{position:"fixed",inset:0,zIndex:9999,background:"rgba(0,0,0,.7)",backdropFilter:"blur(12px)",display:"flex",flexDirection:"column",alignItems:"center",padding:"20px 16px",overflowY:"auto"}}>
          <div className="pop" onClick={e=>e.stopPropagation()} style={{margin:"auto",background:t.card,border:`1px solid ${t.border}`,borderRadius:18,width:"100%",maxWidth:560,flexShrink:0,boxShadow:"0 32px 80px rgba(0,0,0,.5)"}}>
            <div style={{height:3,background:`linear-gradient(90deg,transparent,${t.accent},${t.violet},transparent)`,borderRadius:"18px 18px 0 0",flexShrink:0}}/>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 18px 12px",borderBottom:`1px solid ${t.border}`,flexShrink:0}}>
              <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>{modalTitle}</div>
              <button onClick={()=>setShowModal(false)} style={{width:28,height:28,borderRadius:8,background:t.surface,border:`1px solid ${t.border}`,color:t.textSub,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}
                onMouseEnter={e=>{e.currentTarget.style.background=`${t.red}15`;e.currentTarget.style.color=t.red;}}
                onMouseLeave={e=>{e.currentTarget.style.background=t.surface;e.currentTarget.style.color=t.textSub;}}>{"\u2716"}</button>
            </div>
            <div style={{padding:"16px 18px 18px",flex:1,overflowY:"auto"}}>
              <form onSubmit={save}>
                <div style={{display:"flex",flexDirection:"column",gap:12}}>
                  <InlineInput label="Trip Name *" value={form.name} onChange={set("name")} placeholder="Rajasthan Desert Trail" required t={t}/>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 28px 1fr",gap:6,alignItems:"flex-end"}}>
                    <LocationInput label="From" value={form.start_location} onChange={v => setForm(f=>({...f,start_location:v}))} onSelect={s => setForm(f=>({...f,start_location:s.label.split(",")[0].trim()}))} placeholder="Chennai, TN"  dark={dark} />
                    <div style={{textAlign:"center",color:t.textSub,fontSize:16,paddingBottom:7}}>{"\u2192"}</div>
                    <LocationInput label="To (Destination)" value={form.destination} onChange={v => setForm(f=>({...f,destination:v}))} onSelect={s => setForm(f=>({...f,destination:s.label.split(",")[0].trim()}))} placeholder="Jaisalmer, RJ"  dark={dark} required />
                  </div>
                  <div className="modal-4col">
                    <InlineInput label="Start Date" type="date" value={form.start_date} onChange={set("start_date")} t={t}/>
                    <InlineInput label="End Date" type="date" value={form.end_date} onChange={set("end_date")} t={t}/>
                    <InlineInput label={`Budget (${"\u20B9"})`} type="number" value={form.budget} onChange={set("budget")} placeholder="28000" t={t}/>
                    <div>
                      <label style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",display:"block",marginBottom:4}}>Status</label>
                      <select value={form.status} onChange={set("status")} style={{...inputStyle(),width:"100%"}}>
                        {STATUSES.map(s=><option key={s.value} value={s.value}>{s.label}</option>)}
                      </select>
                    </div>
                  </div>
                  <div className="modal-emoji-color">
                    <div>
                      <label style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",display:"block",marginBottom:6}}>Cover Emoji</label>
                      <div style={{display:"flex",gap:5,flexWrap:"wrap"}}>
                        {EMOJIS.map(em=>(
                          <button key={em} type="button" onClick={()=>setForm(f=>({...f,cover_emoji:em}))}
                            style={{fontSize:17,padding:"4px 5px",borderRadius:7,border:`2px solid ${form.cover_emoji===em?t.accent:t.border}`,background:form.cover_emoji===em?t.accentSoft:"transparent",cursor:"pointer",lineHeight:1,transition:"all .12s"}}>
                            {em}
                          </button>
                        ))}
                      </div>
                    </div>
                    <div style={{display:"flex",flexDirection:"column",gap:10}}>
                      <div>
                        <label style={{fontSize:11,color:t.textSub,fontWeight:600,textTransform:"uppercase",letterSpacing:".06em",display:"block",marginBottom:6}}>Accent Color</label>
                        <div style={{display:"flex",gap:7,flexWrap:"wrap"}}>
                          {COLORS.map(c=>(
                            <button key={c} type="button" onClick={()=>setForm(f=>({...f,cover_color:c}))}
                              style={{width:22,height:22,borderRadius:"50%",background:c,border:`3px solid ${form.cover_color===c?"#fff":"transparent"}`,cursor:"pointer",boxShadow:form.cover_color===c?`0 0 8px ${c}88`:"none",transition:"all .12s",flexShrink:0}}/>
                          ))}
                        </div>
                      </div>
                      <InlineInput label="Notes" value={form.description} onChange={set("description")} placeholder="Optional notes..." t={t}/>
                    </div>
                  </div>
                  {/* Preview */}
                  <div style={{background:`linear-gradient(135deg,${form.cover_color}18,${form.cover_color}06)`,border:`1px solid ${form.cover_color}33`,borderRadius:10,padding:"8px 13px",display:"flex",alignItems:"center",gap:10}}>
                    <span style={{fontSize:20}}>{getNormalizedEmoji(form.cover_emoji)}</span>
                    <div style={{flex:1,minWidth:0}}>
                      <div style={{fontSize:13,fontWeight:700,color:t.text,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{form.name||"Trip Name"}</div>
                      <div style={{fontSize:11,color:t.textSub}}>{form.start_location?`${form.start_location} \u2192 `:""}{form.destination||"Destination"}</div>
                    </div>
                    <div style={{width:8,height:8,borderRadius:"50%",background:form.cover_color,boxShadow:`0 0 6px ${form.cover_color}`,flexShrink:0}}/>
                  </div>
                  {err&&<div style={{color:t.red,fontSize:12,padding:"7px 10px",background:`${t.red}12`,borderRadius:7,border:`1px solid ${t.red}33`}}>{err}</div>}
                  <button type="submit" disabled={saving}
                    style={{width:"100%",padding:"10px",borderRadius:10,border:"none",background:`linear-gradient(135deg,${t.accent},${t.violet})`,color:"#fff",fontWeight:700,fontSize:14,cursor:saving?"not-allowed":"pointer",fontFamily:"inherit",opacity:saving?0.7:1,transition:"opacity .2s"}}>
                    {saving?"Saving...":editing?"Save Changes":`Create Trip ${"\u2708\uFE0F"}`}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>,document.body
      )}

      {/* Share modal */}
      {showShare && createPortal(
        <div onClick={e=>e.target===e.currentTarget&&setShowShare(null)}
          style={{position:"fixed",inset:0,zIndex:9999,background:"rgba(0,0,0,.7)",backdropFilter:"blur(12px)",display:"flex",flexDirection:"column",alignItems:"center",overflowY:"auto",padding:"20px 16px"}}>
          <div className="pop" onClick={e=>e.stopPropagation()} style={{margin:"auto",flexShrink:0,background:t.card,border:`1px solid ${t.border}`,borderRadius:18,width:"100%",maxWidth:400,boxShadow:"0 32px 80px rgba(0,0,0,.5)",overflow:"hidden"}}>
            <div style={{height:3,background:`linear-gradient(90deg,transparent,${t.accent},${t.teal},transparent)`,borderRadius:"18px 18px 0 0"}}/>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 18px 12px",borderBottom:`1px solid ${t.border}`}}>
              <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>{shareTitle}</div>
              <button onClick={()=>setShowShare(null)} style={{width:28,height:28,borderRadius:8,background:t.surface,border:`1px solid ${t.border}`,color:t.textSub,fontSize:14,cursor:"pointer",display:"flex",alignItems:"center",justifyContent:"center"}}>{"\u2716"}</button>
            </div>
            <div style={{padding:"20px 18px 22px"}}>
              <div style={{textAlign:"center",marginBottom:16}}>
                <div style={{fontSize:44,marginBottom:8}}>{getNormalizedEmoji(showShare.cover_emoji)}</div>
                <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>{showShare.name}</div>
                <div style={{color:t.textSub,fontSize:12,marginTop:4}}>{"\u{1F4CD}"} {showShare.destination}</div>
              </div>
              {sharing ? <div style={{display:"flex",justifyContent:"center",padding:20}}><Spinner dark={dark}/></div>
              : shareLink ? (<>
                  <div style={{background:t.surface,border:`1px solid ${t.border}`,borderRadius:10,padding:"10px 12px",fontSize:11,color:t.textSub,wordBreak:"break-all",marginBottom:12,lineHeight:1.6,fontFamily:"monospace"}}>{shareLink}</div>
                  <div className="modal-2col" style={{marginBottom:12}}>
                    <button onClick={copyLink}
                      style={{padding:"9px",borderRadius:9,border:"none",background:shareCopied?`linear-gradient(135deg,${t.green},#059669)`:`linear-gradient(135deg,${t.accent},${t.teal})`,color:"#fff",fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"inherit",transition:"all .2s"}}>
                      {shareCopied?`${"\u2713"} Copied!`:`${"\u{1F4CB}"} Copy Link`}
                    </button>
                    <button onClick={revokeShare}
                      style={{padding:"9px",borderRadius:9,border:`1px solid ${t.red}33`,background:`${t.red}15`,color:t.red,fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"inherit"}}>
                      {"\u{1F6AB}"} Revoke
                    </button>
                  </div>
                  <div style={{fontSize:11,color:t.textDim,textAlign:"center",lineHeight:1.6}}>Anyone with this link can view places, itinerary and budget.</div>
                </>) : null}
            </div>
          </div>
        </div>,document.body
      )}
    </div>
  );
}
