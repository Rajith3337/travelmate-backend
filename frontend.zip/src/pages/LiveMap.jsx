// TravelMate LiveMap v12 — User-Centric Redesign
// Core philosophy: GPS · Nearby · Route · My Places — nothing else.
import { useState, useEffect, useRef, useCallback, useMemo } from "react";
import { tripsApi, placesApi, itineraryApi, settingsApi } from "../api/client";
import PlaceSearchInput from "../components/PlaceSearchInput";
import { Btn, Spinner, Empty, Modal, Input, Select, ErrorMsg } from "../components/UI";
import LocationInput from "../components/LocationInput";
import { DARK, LIGHT } from "../styles/theme";
import useActiveTrip from "../hooks/useActiveTrip";
import { isNativePlatform, readTileDataUrl } from "../utils/offline";

// ── Constants ──────────────────────────────────────────────────────────────────
const BACKEND_BASE = (() => {
  const b = import.meta.env.VITE_API_URL || "http://localhost:8000";
  return b.replace(/\/+$/, "") + "/api/v1";
})();

const OVERPASS_MIRRORS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
];

const NEARBY_CATS = [
  { key: "food",    emoji: "🍽️", color: "#FFB800", label: "Food",    q: `node["amenity"~"restaurant|cafe|fast_food|food_court|bar|pub|biergarten|fast_food|ice_cream|drinking_water"]` },
  { key: "hotel",   emoji: "🏨", color: "#A855F7", label: "Stay",    q: `node["tourism"~"hotel|hostel|motel|guest_house|chalet|apartment|camp_site|caravan_site"]` },
  { key: "medical", emoji: "🏥", color: "#FF4E6A", label: "Medical", q: `node["amenity"~"hospital|clinic|pharmacy|doctors|dentist|veterinary"]` },
  { key: "atm",     emoji: "🏧", color: "#00D4FF", label: "ATM",     q: `node["amenity"="atm"]` },
  { key: "fuel",    emoji: "⛽", color: "#39FF6A", label: "Fuel",    q: `node["amenity"~"fuel|charging_station"]` },
  { key: "transit", emoji: "🚌", color: "#FF8A00", label: "Transit", q: `node["highway"~"bus_stop|railway_station"]` },
  { key: "sights",  emoji: "🏛️", color: "#00FFCC", label: "Sights", q: `node["tourism"~"attraction|museum|viewpoint|artwork|theme_park|zoo|aquarium"]` },
  { key: "police",  emoji: "🚨", color: "#FF6ECC", label: "Safety", q: `node["amenity"~"police|fire_station|embassy|consulate"]` },
];

const AMENITY_ROUTE_KEYS = ["food", "atm", "police", "transit"];
const AMENITY_ROUTE_SET = new Set(AMENITY_ROUTE_KEYS);


const TILES = {
  standard: {
    url: "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
    label: "🗺 Map",
    attribution: "© OpenStreetMap contributors",
  },
  satellite: {
    url: "https://services.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}",
    overlayUrl: "https://services.arcgisonline.com/ArcGIS/rest/services/Reference/World_Boundaries_and_Places/MapServer/tile/{z}/{y}/{x}",
    label: "🛰 Satellite",
    attribution: "© Esri, Maxar, Earthstar Geographics, and the GIS User Community",
  },
  topo: {
    url: "https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png",
    label: "⛰ Terrain",
    attribution: "© OpenTopoMap (CC-BY-SA)",
  },
};

const TILE_OPTIONS = {
  maxZoom: 19,
  updateWhenZooming: false,
  updateWhenIdle: true,
  keepBuffer: 2,
  crossOrigin: true,
};

const STATUS_COLOR = { planned: "#4D6285", upcoming: "#FBBF24", visited: "#34D399", skipped: "#F43F5E" };
const STATUSES     = [{ value: "planned", label: "📋 Planned" }, { value: "upcoming", label: "🔜 Upcoming" }, { value: "visited", label: "✅ Visited" }, { value: "skipped", label: "⏭ Skipped" }];
const PLACE_TYPES  = [{ value: "Attraction", label: "🏛️ Attraction" }, { value: "Hotel", label: "🏨 Hotel" }, { value: "Restaurant", label: "🍽️ Restaurant" }, { value: "Hospital", label: "🏥 Hospital" }, { value: "Transport", label: "🚉 Transport" }, { value: "Nature", label: "🌿 Nature" }, { value: "Shopping", label: "🛍️ Shopping" }, { value: "Other", label: "📍 Other" }];

const ROUTE_COLORS = ["#34D399", "#FBBF24", "#F472B6", "#818CF8"];
const ROUTE_LABELS = ["🏆 Fastest", "🛣️ Alt 1", "🌿 Alt 2", "🔄 Alt 3"];

const MAP_CACHE_KEY = "tm_livemap_cache_v1";
const LIVE_MAP_REMOTE_CACHE_PREFIX = "livemap_cache_trip_";
const GPS_GOOD_ACCURACY_M = 150;

// ── Utilities ────────────────────────────────────────────────────────────────

function injectLeafletCSS(t) {
  if (document.getElementById("leaflet-css")) return;
  const link = document.createElement("link");
  link.id = "leaflet-css";
  link.rel = "stylesheet";
  link.href = "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.css";
  document.head.appendChild(link);

  const style = document.createElement("style");
  style.innerHTML = `
    .leaflet-container { font-family: inherit; background: ${t?.bg || '#111'}; }
    .leaflet-control-zoom a { background: ${t?.surface || '#222'} !important; color: ${t?.text || '#fff'} !important; border-color: ${t?.border || '#333'} !important; }
    .leaflet-popup-content-wrapper { background: ${t?.card || '#1a1a1a'}; color: ${t?.text || '#fff'}; border-radius: 12px; box-shadow: 0 4px 20px rgba(0,0,0,0.3); }
    .leaflet-popup-tip { background: ${t?.card || '#1a1a1a'}; }
  `;
  document.head.appendChild(style);
}

function loadLeaflet() {
  return new Promise((resolve, reject) => {
    if (window.L && window.L.MarkerClusterGroup) return resolve(window.L);
    const finish = () => {
      // Load markercluster CSS
      if (!document.getElementById("leaflet-cluster-css")) {
        const css = document.createElement("link");
        css.id = "leaflet-cluster-css";
        css.rel = "stylesheet";
        css.href = "https://cdn.jsdelivr.net/npm/leaflet.markercluster@1.5.3/dist/MarkerCluster.Default.css";
        document.head.appendChild(css);
        const css2 = document.createElement("link");
        css2.rel = "stylesheet";
        css2.href = "https://cdn.jsdelivr.net/npm/leaflet.markercluster@1.5.3/dist/MarkerCluster.css";
        document.head.appendChild(css2);
      }
      // Load markercluster JS
      if (window.L.MarkerClusterGroup) return resolve(window.L);
      const s2 = document.createElement("script");
      s2.src = "https://cdn.jsdelivr.net/npm/leaflet.markercluster@1.5.3/dist/leaflet.markercluster.js";
      s2.onload = () => resolve(window.L);
      s2.onerror = () => resolve(window.L); // fallback — non-fatal
      document.head.appendChild(s2);
    };
    if (window.L) { finish(); return; }
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js";
    script.onload = finish;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}

// Ramer-Douglas-Peucker polyline simplification
function simplifyCoords(coords, tolerance = 0.0001) {
  if (coords.length <= 2) return coords;
  const sqDist = (p, a, b) => {
    let dx = b[0] - a[0], dy = b[1] - a[1];
    if (dx || dy) { const t = ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / (dx * dx + dy * dy); if (t > 1) { a = b; } else if (t > 0) { a = [a[0] + dx * t, a[1] + dy * t]; } }
    dx = p[0] - a[0]; dy = p[1] - a[1];
    return dx * dx + dy * dy;
  };
  const simplify = (pts, tol) => {
    const sq = tol * tol;
    let maxSq = 0, idx = 0;
    for (let i = 1; i < pts.length - 1; i++) { const d = sqDist(pts[i], pts[0], pts[pts.length - 1]); if (d > maxSq) { maxSq = d; idx = i; } }
    if (maxSq > sq) { const l = simplify(pts.slice(0, idx + 1), tol); const r = simplify(pts.slice(idx), tol); return [...l.slice(0, -1), ...r]; }
    return [pts[0], pts[pts.length - 1]];
  };
  return simplify(coords, tolerance);
}

function createTileLayer(url, options) {
  const L = window.L;
  if (!L) return null;
  if (!isNativePlatform()) return L.tileLayer(url, options);
  const OfflineTileLayer = L.TileLayer.extend({
    createTile(coords, done) {
      const tile = document.createElement("img");
      tile.alt = "";
      tile.setAttribute("role", "presentation");
      const finish = () => done && done(null, tile);
      (async () => {
        const cached = await readTileDataUrl(coords.z, coords.x, coords.y);
        if (cached) {
          tile.src = cached;
          finish();
          return;
        }
        tile.onload = finish;
        tile.onerror = finish;
        tile.src = this.getTileUrl(coords);
      })();
      return tile;
    }
  });
  return new OfflineTileLayer(url, options);
}

function applyTileLayers(map, key, baseRef, overlayRef) {
  if (!map) return;
  const cfg = TILES[key] || TILES.standard;
  if (baseRef.current) map.removeLayer(baseRef.current);
  if (overlayRef.current) {
    map.removeLayer(overlayRef.current);
    overlayRef.current = null;
  }
  baseRef.current = createTileLayer(cfg.url, { ...TILE_OPTIONS, attribution: cfg.attribution })?.addTo(map);
  if (cfg.overlayUrl) {
    overlayRef.current = createTileLayer(cfg.overlayUrl, { ...TILE_OPTIONS, attribution: cfg.attribution, opacity: 0.9 })?.addTo(map);
  }
}

function pinIcon(color, text) {
  return window.L.divIcon({
    className: "custom-pin",
    html: `<div style="background:${color};width:24px;height:24px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);position:relative;border:2px solid #fff;box-shadow:0 3px 6px rgba(0,0,0,.3);display:flex;align-items:center;justify-content:center;"><div style="transform:rotate(45deg);color:#fff;font-size:11px;font-weight:bold;text-align:center;">${text || ''}</div></div>`,
    iconSize: [24, 24],
    iconAnchor: [12, 24],
    popupAnchor: [0, -24]
  });
}

function nearbyDot(color, zoom) {
  const size = zoom > 14 ? 22 : Math.max(16, zoom * 1.5);
  return window.L.divIcon({
    className: "nearby-dot",
    html: `<div style="background:${color};width:${size}px;height:${size}px;border-radius:50%;border:3px solid #fff;box-shadow:0 2px 8px rgba(0,0,0,0.6);cursor:pointer;transition:all 0.2s ease;transform:scale(1);"></div>`,
    iconSize: [size, size],
    iconAnchor: [size/2, size/2],
    popupAnchor: [0, -size/2 - 8]
  });
}

function gpsIcon(isNavigating) {
  return window.L.divIcon({
    className: "gps-marker",
    html: `<div style="background:${isNavigating ? '#34D399' : '#38BDF8'};width:18px;height:18px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 10px rgba(0,0,0,.4);"></div>`,
    iconSize: [18, 18],
    iconAnchor: [9, 9]
  });
}

function headingIcon(deg = 0) {
  return window.L.divIcon({
    className: "gps-heading-marker",
    html: `<div style="transform: rotate(${deg}deg); font-size: 20px; color: #22D3EE; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.55)); line-height: 1;">➤</div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10],
  });
}

function parseOverpassElements(elements) {
  return (elements || [])
    .filter(e => {
      const lat = parseFloat(e.lat);
      const lon = parseFloat(e.lon);
      return e.lat && e.lon && !isNaN(lat) && !isNaN(lon) && lat >= -90 && lat <= 90 && lon >= -180 && lon <= 180;
    })
    .map(e => {
      const lat = parseFloat(e.lat);
      const lon = parseFloat(e.lon);
      return {
        id:    String(e.id),
        lat:   lat,
        lng:   lon,
        name:  e.tags?.name || e.tags?.["name:en"] || e.tags?.amenity || e.tags?.tourism || e.tags?.highway || "Unnamed",
        type:  e.tags?.amenity || e.tags?.tourism || e.tags?.highway || "",
        phone: e.tags?.phone  || e.tags?.["contact:phone"] || null,
        hours: e.tags?.opening_hours || null,
        addr:  [e.tags?.["addr:street"], e.tags?.["addr:city"]].filter(Boolean).join(", ") || null,
      };
    });
}

async function overpassQuery(q) {
  try {
    const token = localStorage.getItem("tm_token");
    const ctrl  = new AbortController();
    const tid   = setTimeout(() => ctrl.abort(), 65000);
    const res = await fetch(`${BACKEND_BASE}/ai/overpass`, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json", 
        ...(token ? { Authorization: `Bearer ${token}` } : {}) 
      },
      body: JSON.stringify({ query: q }),
      signal: ctrl.signal,
    });
    clearTimeout(tid);
    if (!res.ok) throw new Error(`Overpass proxy failed: ${res.status}`);
    const data = await res.json();
    const elements = Array.isArray(data) ? data : data?.elements || [];
    const parsed = parseOverpassElements(elements);
    if (parsed.length) return parsed;
  } catch (error) {
    console.error("Overpass proxy error:", error);
  }
  for (const mirror of OVERPASS_MIRRORS) {
    try {
      const body = new URLSearchParams({ data: q });
      const res = await fetch(mirror, {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body,
      });
      if (!res.ok) continue;
      const data = await res.json();
      const elements = data?.elements || [];
      const parsed = parseOverpassElements(elements);
      if (parsed.length) return parsed;
    } catch (e) {
      console.warn("Overpass mirror failed:", mirror, e);
    }
  }
  return [];
}

async function geocode(q) {
  const key = normText(q);
  if (!geocode.cache) geocode.cache = new Map();
  if (geocode.cache.has(key)) return geocode.cache.get(key);
  const r = await fetch(
    `https://nominatim.openstreetmap.org/search?q=${encodeURIComponent(q)}&format=json&limit=5&addressdetails=1`,
    { signal: AbortSignal.timeout(6000) }
  );
  const data = await r.json();
  geocode.cache.set(key, data);
  return data;
}

function parseLatLngInput(v) {
  const m = String(v || "").trim().match(/^(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)$/);
  if (!m) return null;
  const lat = parseFloat(m[1]);
  const lng = parseFloat(m[2]);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  if (Math.abs(lat) > 90 || Math.abs(lng) > 180) return null;
  return { lat, lng };
}

function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371000, dL = (lat2 - lat1) * Math.PI / 180, dG = (lng2 - lng1) * Math.PI / 180;
  const a = Math.sin(dL / 2) ** 2 + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dG / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function splitRouteByDistance(coords, segmentKm = 10) {
  if (!Array.isArray(coords) || coords.length < 2) return [];
  const segments = [];
  let seg = [coords[0]];
  let dist = 0;
  for (let i = 1; i < coords.length; i++) {
    const prev = coords[i - 1];
    const cur = coords[i];
    dist += haversine(prev[0], prev[1], cur[0], cur[1]);
    seg.push(cur);
    if (dist >= segmentKm * 1000) {
      segments.push(seg);
      seg = [cur];
      dist = 0;
    }
  }
  if (seg.length > 1) segments.push(seg);
  return segments;
}

function bboxForCoords(coords, pad = 0.06) {
  if (!Array.isArray(coords) || !coords.length) return null;
  let minLat = Infinity, maxLat = -Infinity, minLng = Infinity, maxLng = -Infinity;
  for (const [la, ln] of coords) {
    if (la < minLat) minLat = la;
    if (la > maxLat) maxLat = la;
    if (ln < minLng) minLng = ln;
    if (ln > maxLng) maxLng = ln;
  }
  if (!Number.isFinite(minLat) || !Number.isFinite(minLng)) return null;
  return { minLat: minLat - pad, maxLat: maxLat + pad, minLng: minLng - pad, maxLng: maxLng + pad };
}

function parseLatLngText(text) {
  if (!text) return null;
  const m = String(text).match(/(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)/);
  if (!m) return null;
  const lat = parseFloat(m[1]);
  const lng = parseFloat(m[2]);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) return null;
  return { lat, lng };
}

function nearestPointOnCoords(coords, lat, lng) {
  if (!Array.isArray(coords) || !coords.length) return { point: null, dist: Infinity };
  let best = null;
  let bestDist = Infinity;
  for (const [la, ln] of coords) {
    const d = haversine(lat, lng, la, ln);
    if (d < bestDist) {
      bestDist = d;
      best = [la, ln];
    }
  }
  return { point: best, dist: bestDist };
}

function normText(v) {
  return String(v || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function greatCircleArc(lat1, lng1, lat2, lng2, steps = 80) {
  const toRad = d => d * Math.PI / 180;
  const toDeg = r => r * 180 / Math.PI;
  const φ1 = toRad(lat1), λ1 = toRad(lng1);
  const φ2 = toRad(lat2), λ2 = toRad(lng2);
  const d = 2 * Math.asin(Math.sqrt(Math.sin((φ2 - φ1) / 2) ** 2 + Math.cos(φ1) * Math.cos(φ2) * Math.sin((λ2 - λ1) / 2) ** 2));
  if (d < 0.0001) return [[lat1, lng1], [lat2, lng2]];
  const pts = [];
  for (let i = 0; i <= steps; i++) {
    const f = i / steps;
    const A = Math.sin((1 - f) * d) / Math.sin(d);
    const B = Math.sin(f * d) / Math.sin(d);
    const x = A * Math.cos(φ1) * Math.cos(λ1) + B * Math.cos(φ2) * Math.cos(λ2);
    const y = A * Math.cos(φ1) * Math.sin(λ1) + B * Math.cos(φ2) * Math.sin(λ2);
    const z = A * Math.sin(φ1) + B * Math.sin(φ2);
    pts.push([toDeg(Math.atan2(z, Math.sqrt(x * x + y * y))), toDeg(Math.atan2(y, x))]);
  }
  return pts;
}

async function findNearestHub(lat, lng, type = "air") {
  const r = 0.8;
  const bbox = `${lat - r},${lng - r},${lat + r},${lng + r}`;
  const q = type === "air"
    ? `[out:json][timeout:20];(node["aeroway"="aerodrome"][bbox:${bbox}];way["aeroway"="aerodrome"][bbox:${bbox}];);out center 5;`
    : `[out:json][timeout:20];(node["harbour"="yes"][bbox:${bbox}];node["seamark:type"="harbour"][bbox:${bbox}];node["amenity"="ferry_terminal"][bbox:${bbox}];way["amenity"="ferry_terminal"][bbox:${bbox}];);out center 5;`;
  try {
    const token = localStorage.getItem("tm_token");
    const res = await fetch(`${BACKEND_BASE}/ai/overpass`, {
      method: "POST",
      headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: JSON.stringify({ query: q }),
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) return null;
    const data = await res.json();
    const els = Array.isArray(data) ? data : data?.elements || [];
    for (const e of els) {
      const elat = e.lat ?? e.center?.lat;
      const elng = e.lon ?? e.center?.lon;
      if (elat && elng) {
        return {
          lat: elat, lng: elng,
          name: e.tags?.name || e.tags?.["iata"] || (type === "air" ? "Airport" : "Harbour"),
          iata: e.tags?.iata || null,
        };
      }
    }
  } catch {}
  return null;
}

async function detectRouteType(fLat, fLng, tLat, tLng) {
  const distKm = haversine(fLat, fLng, tLat, tLng) / 1000;
  try {
    const url = `https://router.project-osrm.org/route/v1/driving/${fLng},${fLat};${tLng},${tLat}?overview=false`;
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), 7000);
    const res = await fetch(url, { signal: ctrl.signal });
    clearTimeout(tid);
    const data = await res.json();
    if (data.routes?.length) {
      const roadKm = data.routes[0].distance / 1000;
      if (roadKm > distKm * 3.5 || roadKm > 5000) return "air";
      return null;
    }
    return distKm > 800 ? "air" : "sea";
  } catch {
    return distKm > 800 ? "air" : "sea";
  }
}

// ════════════════════════════════════════════════════════════════════════════
// IMPROVED ROUTING FUNCTIONS - Added for multi-segment routing support
// ════════════════════════════════════════════════════════════════════════════

async function findBestAirport(lat, lng, BACKEND_BASE, minRadius = 0.3, maxRadius = 2.5) {
  for (let r = minRadius; r <= maxRadius; r += 0.5) {
    const bbox = `${lat - r},${lng - r},${lat + r},${lng + r}`;
    const q = `[out:json][timeout:20];(
      node["aeroway"="aerodrome"]["iata"]["icao"][bbox:${bbox}];
      way["aeroway"="aerodrome"]["iata"]["icao"][bbox:${bbox}];
      node["aeroway"="aerodrome"]["iata"][bbox:${bbox}];
      way["aeroway"="aerodrome"]["iata"][bbox:${bbox}];
      node["aeroway"="aerodrome"][bbox:${bbox}];
      way["aeroway"="aerodrome"][bbox:${bbox}];
    );out center 15;`;
    
    try {
      const token = localStorage.getItem("tm_token");
      const res = await fetch(`${BACKEND_BASE}/ai/overpass`, {
        method: "POST",
        headers: { "Content-Type": "application/json", ...(token ? { Authorization: `Bearer ${token}` } : {}) },
        body: JSON.stringify({ query: q }),
        signal: AbortSignal.timeout(15000),
      });
      if (!res.ok) continue;
      const data = await res.json();
      const els = Array.isArray(data) ? data : data?.elements || [];
      
      const airports = els
        .map(e => {
          const elat = e.lat ?? e.center?.lat;
          const elng = e.lon ?? e.center?.lon;
          if (!elat || !elng) return null;
          const dist = haversine(lat, lng, elat, elng);
          const hasIATA = !!e.tags?.iata;
          const hasICAO = !!e.tags?.icao;
          const hasName = !!e.tags?.name;
          const score = (hasIATA ? 100000 : 0) + (hasICAO ? 50000 : 0) + (hasName ? 10000 : 0) - dist;
          return {
            lat: elat, lng: elng,
            name: e.tags?.name || e.tags?.iata || "Airport",
            iata: e.tags?.iata || null,
            icao: e.tags?.icao || null,
            distance: dist, score: score
          };
        })
        .filter(Boolean)
        .sort((a, b) => b.score - a.score);
      
      if (airports.length > 0) return airports[0];
    } catch (e) { console.warn(`Airport search failed:`, e); }
  }
  return null;
}

async function getRoadRoute(fromLat, fromLng, toLat, toLng, mode = "driving") {
  const OSRM_ENDPOINTS = {
    driving: "https://router.project-osrm.org/route/v1/driving",
    cycling: "https://routing.openstreetmap.de/routed-bike/route/v1/driving",
    walking: "https://routing.openstreetmap.de/routed-foot/route/v1/driving",
  };
  const base = OSRM_ENDPOINTS[mode] || OSRM_ENDPOINTS.driving;
  const url = `${base}/${fromLng},${fromLat};${toLng},${toLat}?overview=full&geometries=geojson&steps=true`;
  
  try {
    const ctrl = new AbortController();
    const tid = setTimeout(() => ctrl.abort(), 8500);
    const res = await fetch(url, { signal: ctrl.signal });
    clearTimeout(tid);
    const data = await res.json();
    if (!data.routes?.length) return null;
    const route = data.routes[0];
    return {
      coords: route.geometry.coordinates.map(([ln, la]) => [la, ln]),
      distance: route.distance,
      duration: route.duration,
      steps: route.legs?.[0]?.steps || []
    };
  } catch (e) { return null; }
}

async function buildMultiSegmentRoute(fromLat, fromLng, toLat, toLng, routeMode, BACKEND_BASE) {
  const segments = [];
  const distKm = haversine(fromLat, fromLng, toLat, toLng) / 1000;
  const HYBRID_THRESHOLD_KM = 300;
  const useHybrid = distKm > HYBRID_THRESHOLD_KM;
  
  if (!useHybrid) {
    const roadRoute = await getRoadRoute(fromLat, fromLng, toLat, toLng, routeMode);
    if (roadRoute) {
      return {
        type: 'road',
        segments: [{ type: 'road', label: 'Direct Route', coords: roadRoute.coords, distance: roadRoute.distance, duration: roadRoute.duration, steps: roadRoute.steps, color: '#22c55e' }],
        totalDistance: roadRoute.distance / 1000,
        totalDuration: Math.round(roadRoute.duration / 60)
      };
    }
  }
  
  const [fromAirport, toAirport] = await Promise.all([
    findBestAirport(fromLat, fromLng, BACKEND_BASE),
    findBestAirport(toLat, toLng, BACKEND_BASE)
  ]);
  
  if (!fromAirport || !toAirport) {
    const arcCoords = greatCircleArc(fromLat, fromLng, toLat, toLng, 100);
    return {
      type: 'air',
      segments: [{ type: 'air', label: '✈ Direct Flight', coords: arcCoords, distance: distKm * 1000, duration: Math.round((distKm / 850) * 60 * 60), color: '#818CF8', dashArray: '14,6' }],
      totalDistance: distKm,
      totalDuration: Math.round((distKm / 850) * 60)
    };
  }
  
  const roadToAirport = await getRoadRoute(fromLat, fromLng, fromAirport.lat, fromAirport.lng, routeMode);
  if (roadToAirport) {
    segments.push({ type: 'road', label: `To ${fromAirport.name}`, coords: roadToAirport.coords, distance: roadToAirport.distance, duration: roadToAirport.duration, steps: roadToAirport.steps, color: '#38BDF8', dashArray: '6,6', hub: fromAirport });
  } else {
    segments.push({ type: 'transfer', label: `Transfer to ${fromAirport.name}`, coords: [[fromLat, fromLng], [fromAirport.lat, fromAirport.lng]], distance: haversine(fromLat, fromLng, fromAirport.lat, fromAirport.lng), duration: 1800, color: '#38BDF8', dashArray: '6,6', hub: fromAirport });
  }
  
  const airArc = greatCircleArc(fromAirport.lat, fromAirport.lng, toAirport.lat, toAirport.lng, 100);
  const airDistKm = haversine(fromAirport.lat, fromAirport.lng, toAirport.lat, toAirport.lng) / 1000;
  const airDurMin = Math.round((airDistKm / 850) * 60);
  segments.push({ type: 'air', label: `Flight: ${fromAirport.iata || fromAirport.name} → ${toAirport.iata || toAirport.name}`, coords: airArc, distance: airDistKm * 1000, duration: airDurMin * 60, color: '#818CF8', dashArray: '14,6', fromHub: fromAirport, toHub: toAirport });
  
  const roadFromAirport = await getRoadRoute(toAirport.lat, toAirport.lng, toLat, toLng, routeMode);
  if (roadFromAirport) {
    segments.push({ type: 'road', label: `From ${toAirport.name}`, coords: roadFromAirport.coords, distance: roadFromAirport.distance, duration: roadFromAirport.duration, steps: roadFromAirport.steps, color: '#38BDF8', dashArray: '6,6', hub: toAirport });
  } else {
    segments.push({ type: 'transfer', label: `Transfer from ${toAirport.name}`, coords: [[toAirport.lat, toAirport.lng], [toLat, toLng]], distance: haversine(toAirport.lat, toAirport.lng, toLat, toLng), duration: 1800, color: '#38BDF8', dashArray: '6,6', hub: toAirport });
  }
  
  const totalDistance = segments.reduce((sum, s) => sum + s.distance, 0) / 1000;
  const totalDuration = Math.round(segments.reduce((sum, s) => sum + s.duration, 0) / 60);
  return { type: 'hybrid', segments, totalDistance, totalDuration, fromAirport, toAirport };
}

function renderMultiSegmentRoute(L, routeLay, multiRoute, fromLabel, toLabel, pinIcon, t) {
  const { segments, fromAirport, toAirport } = multiRoute;
  routeLay.clearLayers();
  
  segments.forEach((segment) => {
    const { coords, color, dashArray, type, label, fromHub, toHub } = segment;
    L.polyline(coords, { color: '#000', weight: type === 'air' ? 7 : 5, opacity: type === 'air' ? 0.25 : 0.3, lineCap: 'round', lineJoin: 'round' }).addTo(routeLay);
    const mainLine = L.polyline(coords, { color: color, weight: type === 'air' ? 4 : 3, opacity: type === 'air' ? 0.95 : 0.8, lineCap: 'round', lineJoin: 'round', dashArray: dashArray || null });
    
    const distKm = (segment.distance / 1000).toFixed(1);
    const durMin = Math.round(segment.duration / 60);
    const durStr = durMin < 60 ? `${durMin} min` : `${Math.floor(durMin / 60)}h ${durMin % 60}m`;
    let popupHTML = `<div style="padding:6px 2px"><b style="color:${color};font-size:13px">${label || type.toUpperCase()}</b><br><span style="font-size:12px;color:${t?.text || '#fff'}">📏 ${distKm} km · ⏱ ${durStr}</span>`;
    if (fromHub || toHub) {
      if (fromHub) popupHTML += `<br><span style="font-size:11px;color:#94A3B8">From: ${fromHub.name}${fromHub.iata ? ' (' + fromHub.iata + ')' : ''}</span>`;
      if (toHub) popupHTML += `<br><span style="font-size:11px;color:#94A3B8">To: ${toHub.name}${toHub.iata ? ' (' + toHub.iata + ')' : ''}</span>`;
    }
    popupHTML += '</div>';
    mainLine.bindPopup(popupHTML).addTo(routeLay);
    
    if (type === 'air' && coords.length > 2) {
      const midIdx = Math.floor(coords.length / 2);
      const [mLat, mLng] = coords[midIdx];
      L.marker([mLat, mLng], { icon: L.divIcon({ className: "", html: `<div style="font-size:28px;filter:drop-shadow(0 2px 6px rgba(0,0,0,.6));animation:tmFloat 2s ease-in-out infinite alternate;">✈</div>`, iconSize: [36, 36], iconAnchor: [18, 18] }), zIndexOffset: 800 }).bindPopup(label || 'Flight').addTo(routeLay);
    }
  });
  
  const firstCoord = segments[0].coords[0];
  const lastSegment = segments[segments.length - 1];
  const lastCoord = lastSegment.coords[lastSegment.coords.length - 1];
  L.marker(firstCoord, { icon: pinIcon('#38BDF8', 'A'), zIndexOffset: 600 }).bindPopup(`<b>From:</b> ${fromLabel || 'Origin'}`).addTo(routeLay);
  L.marker(lastCoord, { icon: pinIcon('#34D399', 'B'), zIndexOffset: 600 }).bindPopup(`<b>To:</b> ${toLabel || 'Destination'}`).addTo(routeLay);
  
  if (fromAirport) {
    L.marker([fromAirport.lat, fromAirport.lng], { icon: L.divIcon({ className: "", html: `<div style="font-size:20px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.5));">🛫</div>`, iconSize: [24, 24], iconAnchor: [12, 12] }), zIndexOffset: 700 }).bindPopup(`<b>${fromAirport.name}</b>${fromAirport.iata ? '<br>IATA: ' + fromAirport.iata : ''}${fromAirport.icao ? '<br>ICAO: ' + fromAirport.icao : ''}`).addTo(routeLay);
  }
  if (toAirport && toAirport !== fromAirport) {
    L.marker([toAirport.lat, toAirport.lng], { icon: L.divIcon({ className: "", html: `<div style="font-size:20px;filter:drop-shadow(0 2px 4px rgba(0,0,0,.5));">🛬</div>`, iconSize: [24, 24], iconAnchor: [12, 12] }), zIndexOffset: 700 }).bindPopup(`<b>${toAirport.name}</b>${toAirport.iata ? '<br>IATA: ' + toAirport.iata : ''}${toAirport.icao ? '<br>ICAO: ' + toAirport.icao : ''}`).addTo(routeLay);
  }
  
  if (!document.getElementById("tm-airways-css")) {
    const s = document.createElement("style");
    s.id = "tm-airways-css";
    s.innerHTML = `@keyframes tmFloat { from { transform: translateY(0); } to { transform: translateY(-6px); } }
      .tm-airway-line { animation: tmDash 1.8s linear infinite; }
      @keyframes tmDash { to { stroke-dashoffset: -40; } }`;
    document.head.appendChild(s);
  }
}

// ── Main ──────────────────────────────────────────────────────────────────────
function SectionHeader({ t, icon, label, count, color, action }) {
  const accent = color || t.accent;
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, marginBottom: 8 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 7, minWidth: 0 }}>
        <span style={{ fontSize: 12, lineHeight: 1 }}>{icon || "•"}</span>
        <span style={{ fontSize: 11, fontWeight: 800, color: accent, letterSpacing: ".03em", textTransform: "uppercase", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {label}
        </span>
        {typeof count === "number" && (
          <span style={{ fontSize: 9, fontWeight: 700, color: t.textDim, background: t.surface, border: `1px solid ${t.border}`, borderRadius: 99, padding: "2px 7px", flexShrink: 0 }}>
            {count}
          </span>
        )}
      </div>
      {action ? <div style={{ flexShrink: 0 }}>{action}</div> : null}
    </div>
  );
}

export default function LiveMap({ dark = true }) {
  const t = dark ? DARK : LIGHT;
  useEffect(() => { injectLeafletCSS(t); }, [dark]); // eslint-disable-line react-hooks/exhaustive-deps

  // Map state
  const [ready,         setReady]         = useState(false);
  const [mapError,      setMapError]       = useState(false);
  const [tile,          setTile]           = useState("standard");
  const [isFullMap,     setIsFullMap]      = useState(false);

  // Trip / places
  const [trips,         setTrips]          = useState([]);
  const [tripId,        setTripId]         = useActiveTrip();
  const [places,        setPlaces]         = useState([]);
  const [placesLoading, setPlacesLoading]  = useState(false);
  const [optimizing,    setOptimizing]     = useState(false);
  const [activePlace,   setActivePlace]    = useState(null);
  const missingGeoRef = useRef(new Map());
  const geocodeBusyRef = useRef(false);

  // ── Data Caching System ───────────────────────────────────────────────────
  const dataCacheRef = useRef({
    data: {},
    lastFetch: {},
    expiry: 5 * 60 * 1000,
  });

  const fetchCachedData = useCallback(async (cacheKey, fetchFn) => {
    const cache = dataCacheRef.current;
    const now = Date.now();
    const last = cache.lastFetch[cacheKey] || 0;
    const cached = cache.data[cacheKey];

    if (cached && (now - last) < cache.expiry) {
      return cached;
    }

    try {
      const fresh = await fetchFn();
      cache.data[cacheKey] = fresh;
      cache.lastFetch[cacheKey] = now;
      return fresh;
    } catch (error) {
      if (cached) return cached;
      throw error;
    }
  }, []);

  const invalidateCache = useCallback((cacheKey) => {
    delete dataCacheRef.current.data[cacheKey];
    delete dataCacheRef.current.lastFetch[cacheKey];
  }, []);

  // GPS
  const [gpsOn,         setGpsOn]          = useState(false);
  const gpsOnRef        = useRef(false);
  const [gpsCoords,     setGpsCoords]      = useState(null);
  const [gpsHeading,    setGpsHeading]     = useState(null);

  // Nearby
  const [activeCat,     setActiveCat]      = useState(null);
  const [nearbyItems,   setNearbyItems]    = useState([]);
  const [nearbyBusy,    setNearbyBusy]     = useState(false);
  const [nearbyProgress,setNearbyProgress] = useState("");
  const [nearbyFilters, setNearbyFilters]  = useState({ openNow: false, budget: false });
  const [activeItem,    setActiveItem]     = useState(null);
  const activeCatRef    = useRef(null);

  // Route
  const [routeFrom,     setRouteFrom]      = useState("");
  const [routeMode,     setRouteMode]      = useState("driving");
  const [voiceEnabled,  setVoiceEnabled]   = useState(true);
  const [navDistToStep, setNavDistToStep]  = useState(0);
  const [navCurStep,    setNavCurStep]     = useState(null);
  const spokenStepRef   = useRef(-1);
  const [routeTo,       setRouteTo]        = useState("");
  const [routeBusy,     setRouteBusy]      = useState(false);
  const [routeResult,   setRouteResult]    = useState(null);
  const [altRoutes,     setAltRoutes]      = useState([]);
  const [activeAlt,     setActiveAlt]      = useState(0);
  const [routeMeta,     setRouteMeta]      = useState({ fromLabel: "", toLabel: "" });
  const canStartNav = useMemo(
    () => !!(routeTo.trim() || routeResult?.to || routeMeta?.toLabel),
    [routeTo, routeResult, routeMeta]
  );
  const [liveNav,       setLiveNav]        = useState(false);
  const [navStarting,   setNavStarting]    = useState(false);
  const navStartingRef  = useRef(false);
  const [navETA,        setNavETA]         = useState(null);
  const [gpsLastTs,     setGpsLastTs]      = useState(null);
  const [placesRouteBusy, setPlacesRouteBusy] = useState(false);
  const [placesRouteError, setPlacesRouteError] = useState("");
  const [placesRouteFetched, setPlacesRouteFetched] = useState(false);
  const placesRouteFetchedRef = useRef(false);
  const placesRouteTripRef = useRef(null);
  const [activity, setActivity] = useState({ type: "idle", text: "" });

  // Location search
  const [locQuery,      setLocQuery]       = useState("");

  // Add place modal
  const [showModal,     setShowModal]      = useState(false);
  const [clickCoords,   setClickCoords]    = useState(null);
  const [pinForm,       setPinForm]        = useState({ name: "", place_type: "Attraction", visit_time: "", status: "planned", notes: "" });
  const [pinVerified,   setPinVerified]    = useState(false);
  const [pinErr,        setPinErr]         = useState("");
  const [pinSaving,     setPinSaving]      = useState(false);
  const [editingPlaceId,setEditingPlaceId] = useState(null);

  // Sidebar tab
  const [tab,           setTab]            = useState("nearby");

  // Refs
  const mapRef    = useRef(null);
  const lmap      = useRef(null);
  const tileLay   = useRef(null);
  const tileOverlayLay = useRef(null);
  const routeSvgRef = useRef(null);
  const placesRouteSvgRef = useRef(null);
  const nearbyLay = useRef(null);
  const routeLay       = useRef(null);
  const placesRouteLay = useRef(null);
  const navLay         = useRef(null);
  const navRouteLineRef = useRef(null);
  const navUserMarkerRef = useRef(null);
  const navDestMarkerRef = useRef(null);
  const navViewInitializedRef = useRef(false);
  const routeCoordsRef  = useRef([]);
  const pinLay    = useRef(null);
  const placesHashRef  = useRef("");
  const gpsMark   = useRef(null);
  const gpsHeadMark = useRef(null);
  const gpsCirc   = useRef(null);
  const gpsWatch  = useRef(null);
  const updateNavRef = useRef(null);
  const drawRouteCoordsRef = useRef(null);
  const gpsHeadingRef = useRef(null);
  const orientationHandlerRef = useRef(null);
  const routeModeRef = useRef(routeMode);
  const voiceEnabledRef = useRef(voiceEnabled);
  const gpsPos    = useRef(null);
  const navDest   = useRef(null);
  const lastNavUpdateTsRef = useRef(0);
  const lastNavPosRef = useRef(null);
  const navAbortRef = useRef(null);
  const navReqSeqRef = useRef(0);
  const navAwaitingGpsRef = useRef(false);
  const activeTripRef = useRef(null);
  const remoteCacheLoadedRef = useRef({});
  const remoteSaveTimerRef = useRef(null);
  const placesRouteSigRef = useRef("");
  const placesRouteDrawSeqRef = useRef(0);
  const placesRouteDrawnRef = useRef(false);
  const placesRouteZoomPendingRef = useRef(false);
  const placesRouteZoomTimerRef = useRef(null);
  const placesRouteFocusTimerRef = useRef(null);
  const placesRoutePreviewTimerRef = useRef(null);
  const placesRouteDoneMsgRef = useRef("");
  const placesRouteCacheRef = useRef(new Map());
  const activityTimerRef = useRef(null);
  const autoFitLockRef = useRef(false);

  useEffect(() => { routeModeRef.current = routeMode; }, [routeMode]);
  useEffect(() => { voiceEnabledRef.current = voiceEnabled; }, [voiceEnabled]);

  const showBusy = useCallback((text) => {
    if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    setActivity({ type: "busy", text });
  }, []);

  const showDone = useCallback((text) => {
    if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
    setActivity({ type: "done", text });
    activityTimerRef.current = setTimeout(() => setActivity({ type: "idle", text: "" }), 2200);
  }, []);

  const fitBoundsSafe = useCallback((bounds, opts = {}, force = false) => {
    const map = lmap.current;
    if (!map || !bounds || !bounds.isValid || !bounds.isValid()) return;
    if (!force && autoFitLockRef.current) return;
    map.fitBounds(bounds, opts);
  }, []);

  const finishRouteBusy = useCallback(() => {
    let tries = 0;
    const tick = () => {
      const ready = routeLay.current && routeLay.current.getLayers().length > 0;
      if (ready || tries >= 12) {
        setRouteBusy(false);
        return;
      }
      tries += 1;
      setTimeout(tick, 80);
    };
    tick();
  }, []);

  const finishPlacesRouteBusy = useCallback(() => {
    let tries = 0;
    const tick = () => {
      const ready = placesRouteLay.current && placesRouteLay.current.getLayers().length > 0;
      if (ready || tries >= 12) {
        setPlacesRouteBusy(false);
        if (placesRouteDoneMsgRef.current) {
          showDone(placesRouteDoneMsgRef.current);
          placesRouteDoneMsgRef.current = "";
        }
        return;
      }
      tries += 1;
      setTimeout(tick, 80);
    };
    tick();
  }, [showDone]);

  useEffect(() => () => {
    if (activityTimerRef.current) clearTimeout(activityTimerRef.current);
  }, []);

  const persistRouteToTrip = useCallback(async (routes, selectedIdx, fromLabel, toLabel) => {
    if (!tripId || !Array.isArray(routes) || !routes.length) return;
    const compact = routes.map(r => ({
      idx: r.idx,
      dist: r.dist,
      dur: r.dur,
      label: r.label,
      color: r.color,
      coords: r.coords,
      steps: (r.steps || []).slice(0, 60),
      // Preserve airway/seaway metadata so drawStoredRoutes can restore correctly
      isAirway: r.isAirway || false,
      routeType: r.routeType || null,
      fromHub: r.fromHub || null,
      toHub: r.toHub || null,
      segments: r.segments || null,
    }));
    const payload = {
      fromLabel,
      toLabel,
      selectedIdx,
      routeMode,
      routes: compact,
      savedAt: new Date().toISOString(),
      // Top-level airway flag for quick detection on restore
      isAirway: routes.some(r => r.isAirway),
    };
    try {
      await tripsApi.update(tripId, { active_route: JSON.stringify(payload) });
      setTrips(prev => prev.map(tr => String(tr.id) === String(tripId) ? { ...tr, active_route: JSON.stringify(payload) } : tr));
    } catch {}
  }, [tripId, routeMode]);


  const getCachedPlacesRoute = useCallback((tripIdValue, currentTripValue) => {
    if (!tripIdValue) return null;
    const mem = placesRouteCacheRef.current.get(String(tripIdValue));
    if (mem?.coords?.length) return mem;
    try {
      const raw = localStorage.getItem(`tm_places_route_${tripIdValue}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (parsed?.coords?.length) return parsed;
      }
    } catch {}
    if (currentTripValue?.places_route) {
      try {
        const pr = typeof currentTripValue.places_route === "string"
          ? JSON.parse(currentTripValue.places_route)
          : currentTripValue.places_route;
        if (pr?.sig && pr?.coords?.length) return pr;
      } catch {}
    }
    return null;
  }, []);

  const cachePlacesRoute = useCallback((tripIdValue, payload) => {
    if (!tripIdValue || !payload) return;
    try { placesRouteCacheRef.current.set(String(tripIdValue), payload); } catch {}
    try { localStorage.setItem(`tm_places_route_${tripIdValue}`, JSON.stringify(payload)); } catch {}
  }, []);

  const persistPlacesRouteToTrip = useCallback(async (payload) => {
    if (!tripId || !payload) return;
    try {
      await tripsApi.update(tripId, { places_route: payload });
      setTrips(prev => prev.map(tr => String(tr.id) === String(tripId) ? { ...tr, places_route: payload } : tr));
      cachePlacesRoute(tripId, payload);
    } catch {}
  }, [tripId, cachePlacesRoute]);

  const fillMissingPlaceCoords = useCallback(async (list) => {
    if (!tripId || geocodeBusyRef.current || !Array.isArray(list)) return;
    const trip = trips.find(tr => String(tr.id) === String(tripId));
    const dest = (trip?.destination || "").trim();
    const start = (trip?.start_location || "").trim();
    const missing = list.filter(p => !Number.isFinite(p.latitude) || !Number.isFinite(p.longitude));
    if (!missing.length) return;

    // Detect if trip is international (crossing country boundaries) — if so,
    // do NOT bias geocoding toward the destination to avoid snapping Indian places to wrong coords.
    const COUNTRY_HINTS = {
      india: ["india", "delhi", "mumbai", "chennai", "bangalore", "kolkata", "hyderabad", "pune", "ahmedabad", "jaipur", "kerala", "gujarat", "rajasthan"],
      japan: ["japan", "tokyo", "osaka", "kyoto", "nagoya", "sapporo", "fukuoka"],
      usa: ["usa", "new york", "los angeles", "chicago", "houston", "miami", "san francisco"],
      uk: ["uk", "london", "manchester", "birmingham", "edinburgh", "glasgow"],
      france: ["france", "paris", "lyon", "marseille", "nice", "bordeaux"],
      thailand: ["thailand", "bangkok", "chiang mai", "phuket", "pattaya"],
      uae: ["uae", "dubai", "abu dhabi", "sharjah"],
      singapore: ["singapore"],
      malaysia: ["malaysia", "kuala lumpur"],
    };
    const detectCountry = (loc) => {
      const l = loc.toLowerCase();
      for (const [c, kw] of Object.entries(COUNTRY_HINTS)) {
        if (kw.some(k => l.includes(k))) return c;
      }
      return null;
    };
    const startCountry = detectCountry(start + " " + dest);
    const destCountry = detectCountry(dest);
    const isInternational = startCountry && destCountry && startCountry !== destCountry;

    geocodeBusyRef.current = true;
    try {
      for (const p of missing.slice(0, 3)) {
        const base = (p.address || p.name || "").trim();
        if (!base) continue;
        const key = `${base}|${dest}`;
        if (missingGeoRef.current.get(p.id) === key) continue;
        missingGeoRef.current.set(p.id, key);

        // For international trips, use the place's own address without injecting destination country
        // (a place named "Meiji Shrine" should geocode to Japan even if the trip is from Chennai)
        // For domestic trips, appending destination city helps disambiguate (e.g. "Elliot's Beach, Chennai")
        const query = isInternational ? base : (dest ? `${base}, ${dest}` : base);

        const res = await geocode(query).catch(() => []);
        if (!res?.[0]) continue;
        const lat = parseFloat(res[0].lat);
        const lng = parseFloat(res[0].lon);
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) continue;
        try { await placesApi.update(tripId, p.id, { latitude: lat, longitude: lng }); } catch {}
        setPlaces(prev => prev.map(x => x.id === p.id ? { ...x, latitude: lat, longitude: lng } : x));
      }
    } finally {
      geocodeBusyRef.current = false;
    }
  }, [tripId, trips]);

  const renderAltRoutes = useCallback((routes, selectedIdx = 0, fromLabel = "", toLabel = "", opts = {}) => {
    const L = window.L, map = lmap.current;
    if (!L || !map || !routeLay.current || !Array.isArray(routes) || !routes.length) return;
    routeLay.current.clearLayers();
    const zoom = map.getZoom ? map.getZoom() : 12;
    const selRoute = routes[selectedIdx] || routes[0];
    if (selRoute?.coords?.length) {
      const r = selRoute;
      const mainW = Math.max(7, Math.round(zoom * 0.7));
      const caseW = mainW + 3;
      L.polyline(r.coords, {
        color: "#0B1220", weight: caseW, opacity: 0.7,
        lineCap: "round", lineJoin: "round", smoothFactor: 1,
        renderer: routeSvgRef.current,
      }).addTo(routeLay.current);
      L.polyline(r.coords, {
        color: r.color, weight: mainW, opacity: 0.96,
        lineCap: "round", lineJoin: "round", smoothFactor: 1,
        renderer: routeSvgRef.current,
      }).bindPopup(`<div style="padding:4px"><b style="color:${r.color};font-size:13px">${r.label}</b><br><span style="font-size:12px;color:${t.text}">🛣️ ${r.dist} km · ⏱ ${r.dur < 60 ? r.dur + "min" : Math.floor(r.dur / 60) + "h " + r.dur % 60 + "m"}</span></div>`).addTo(routeLay.current);
    }
    const sel = routes[selectedIdx] || routes[0];
    const first = sel?.coords?.[0];
    const last = sel?.coords?.[sel?.coords?.length - 1];
    if (first && last) {
      L.marker(first, { icon: pinIcon("#38BDF8", "A"), zIndexOffset: 600 }).bindPopup(`<b>From:</b> ${fromLabel || "Origin"}`).addTo(routeLay.current);
      L.marker(last, { icon: pinIcon("#34D399", "B"), zIndexOffset: 600 }).bindPopup(`<b>To:</b> ${toLabel || "Destination"}`).addTo(routeLay.current);
      if (opts.fit) fitBoundsSafe(L.latLngBounds([first, last]), { padding: [70, 70] });
    }
  }, [t.text, fitBoundsSafe]);

  const drawStoredRoutes = useCallback((stored) => {
    const L = window.L, map = lmap.current;
    if (!L || !map || !stored?.routes?.length) return false;
    routeLay.current?.clearLayers();
    const routes = stored.routes.map((r, i) => ({
      idx: r.idx ?? i,
      dist: r.dist,
      dur: r.dur,
      coords: r.coords || [],
      label: r.label || ROUTE_LABELS[i] || `Route ${i + 1}`,
      color: r.color || ROUTE_COLORS[i] || "#A5B4FC",
      steps: r.steps || [],
      isAirway: r.isAirway || false,
      routeType: r.routeType || null,
      fromHub: r.fromHub || null,
      toHub: r.toHub || null,
      segments: r.segments || null
    }));
    
    const selectedIdx = Math.max(0, Math.min(stored.selectedIdx || 0, routes.length - 1));
    const sel = routes[selectedIdx] || routes[0];

    if (sel.isAirway && sel.segments) {
      const multiRoute = {
        type: sel.routeType,
        segments: sel.segments,
        totalDistance: sel.dist,
        totalDuration: sel.dur,
        fromAirport: sel.fromHub,
        toAirport: sel.toHub
      };
      renderMultiSegmentRoute(L, routeLay.current, multiRoute, stored.fromLabel || "", stored.toLabel || "", pinIcon, t);
      const bounds = L.latLngBounds(sel.coords);
      if (bounds.isValid()) {
         fitBoundsSafe(bounds, { padding: [70, 70] }, true);
      }
    } else {
      renderAltRoutes(routes, selectedIdx, stored.fromLabel || "", stored.toLabel || "", { fit: true });
    }

    setAltRoutes(routes);
    setActiveAlt(selectedIdx);
    setRouteMeta({ fromLabel: stored.fromLabel || "", toLabel: stored.toLabel || "" });
    setRouteResult(sel ? { dist: sel.dist, dur: sel.dur, from: stored.fromLabel || "", to: stored.toLabel || "", steps: sel.steps || [] } : null);
    routeCoordsRef.current = sel?.coords || [];
    return true;
  }, [routeMode, showBusy, renderAltRoutes, fitBoundsSafe, t]);

  // ── Bootstrap ────────────────────────────────────────────────────────────
  useEffect(() => {
    loadLeaflet().then(() => setReady(true)).catch(() => setMapError(true));
  }, []);

  useEffect(() => {
    if (!localStorage.getItem("tm_token")) return;
    fetchCachedData('trips', () => tripsApi.list())
      .then(d => {
        setTrips(d);
        if (!localStorage.getItem("tm_active_trip") && d.length) setTripId(String(d[0].id));
      })
      .catch(() => {});
  }, [fetchCachedData]);

  useEffect(() => {
    if (!tripId) return;
    setPlacesLoading(true);
    fetchCachedData(`places_${tripId}`, () => placesApi.list(tripId))
      .then(setPlaces)
      .catch(() => {})
      .finally(() => setPlacesLoading(false));
  }, [tripId, fetchCachedData]);

  useEffect(() => {
    const handler = e => {
      const d = e?.detail || {};
      if (d.type === "places" && String(d.tripId) === String(tripId)) {
        placesApi.list(tripId).then(setPlaces).catch(() => {});
      }
      if (d.type === "trips") {
        tripsApi.list().then(setTrips).catch(() => {});
      }
    };
    window.addEventListener("tm_data_updated", handler);
    return () => window.removeEventListener("tm_data_updated", handler);
  }, [tripId]);

  useEffect(() => {
    if (!tripId || !places.length) return;
    fillMissingPlaceCoords(places);
  }, [tripId, places, fillMissingPlaceCoords]);

  // ── Map init ──────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!ready || !mapRef.current || lmap.current) return;
    const L = window.L;
    lmap.current = L.map(mapRef.current, { zoomControl: false, preferCanvas: true }).setView([20.5937, 78.9629], 5);
    routeSvgRef.current = L.svg({ padding: 0.5 }).addTo(lmap.current);
    placesRouteSvgRef.current = L.svg({ padding: 0.5 }).addTo(lmap.current);
    applyTileLayers(lmap.current, "standard", tileLay, tileOverlayLay);
    nearbyLay.current = (L.markerClusterGroup
      ? L.markerClusterGroup({ maxClusterRadius: 60, disableClusteringAtZoom: 16, spiderfyOnMaxZoom: true, showCoverageOnHover: false, chunkedLoading: true })
      : L.layerGroup()
    ).addTo(lmap.current);
    routeLay.current  = L.layerGroup().addTo(lmap.current);
    placesRouteLay.current = L.layerGroup().addTo(lmap.current);
    navLay.current    = L.layerGroup().addTo(lmap.current);
    pinLay.current    = L.layerGroup().addTo(lmap.current);

    lmap.current.on("click", e => {
      setEditingPlaceId(null);
      setClickCoords({ lat: e.latlng.lat.toFixed(6), lng: e.latlng.lng.toFixed(6) });
      setPinForm({ name: "", place_type: "Attraction", visit_time: "", status: "planned", notes: "" });
      setPinVerified(false); setPinErr("");
      setShowModal(true);
    });
  }, [ready]);

  // Call invalidateSize whenever the map container gains real dimensions
  // (covers: initial mount, tab switch back to map, window resize)
  useEffect(() => {
    if (!ready) return;
    const el = mapRef.current;
    if (!el) return;
    // Immediate call in case the element already has a size
    const tryFix = () => {
      if (lmap.current && el.offsetWidth > 0 && el.offsetHeight > 0) {
        lmap.current.invalidateSize({ animate: false });
      }
    };
    tryFix();
    const ro = new ResizeObserver(tryFix);
    ro.observe(el);
    return () => ro.disconnect();
  }, [ready]);

  // ── Tile switch ───────────────────────────────────────────────────────────
  useEffect(() => {
    const L = window.L, map = lmap.current;
    if (!L || !map) return;
    applyTileLayers(map, tile, tileLay, tileOverlayLay);
  }, [tile]);

  // ── Draw places ───────────────────────────────────────────────────────────
  useEffect(() => {
    const L = window.L, map = lmap.current;
    if (!L || !map) return;
    // Skip redraw if places data hasn't actually changed
    const hash = places.map(p => `${p.id}:${p.status}:${p.latitude}:${p.longitude}`).join("|");
    if (hash === placesHashRef.current) return;
    placesHashRef.current = hash;
    pinLay.current.clearLayers();
    const geo = places.filter(p => Number.isFinite(p.latitude) && Number.isFinite(p.longitude));
    if (!geo.length) return;
    const bounds = [];
    const pinMarkers = [];
    geo.forEach((p, i) => {
      const col = STATUS_COLOR[p.status] || STATUS_COLOR.planned;
      const m = L.marker([p.latitude, p.longitude], { icon: pinIcon(col, p.status === "visited" ? "✓" : String(i + 1)) })
        .bindPopup(`<div style="padding:2px"><b style="font-size:13px;color:${t.text}">${p.name}</b><br><span style="color:${t.textDim};font-size:11px">${p.place_type}</span><br><span style="color:${col};font-size:11px;font-weight:700">${p.status.toUpperCase()}</span></div>`)
        .on("click", () => { setActivePlace(p.id); setTab("places"); });
      pinMarkers.push(m);
      bounds.push([p.latitude, p.longitude]);
    });
    // Batch add all pin markers at once
    pinMarkers.forEach(m => m.addTo(pinLay.current));
    if (bounds.length > 1) {
      lmap.current.fitBounds(L.latLngBounds(bounds), { padding: [50, 50] });
    }
  }, [places, ready]);

  // ── FIX 3: Clear ALL map layers + evict BOTH memory and localStorage caches on trip switch ──
  useEffect(() => {
    placesRouteLay.current?.clearLayers();
    placesRouteSigRef.current = "";
    placesRouteDrawnRef.current = false;
    placesRouteTripRef.current = null;
    placesRouteFetchedRef.current = false;
    setPlacesRouteFetched(false);
    if (tripId) {
      // Evict in-memory cache
      placesRouteCacheRef.current.delete(String(tripId));
      // Evict localStorage cache so getCachedPlacesRoute never returns stale geometry
      try { localStorage.removeItem(`tm_places_route_${tripId}`); } catch {}
    }
    routeLay.current?.clearLayers();
    nearbyLay.current?.clearLayers();
    pinLay.current?.clearLayers();
    routeCoordsRef.current = [];
    // Reset route UI state so previous trip's airway route doesn't bleed in
    setRouteResult(null);
    setAltRoutes([]);
    setActiveAlt(0);
    setRouteMeta({ fromLabel: "", toLabel: "" });
    setNearbyItems([]);
    setActiveCat(null);
    activeCatRef.current = null;
  }, [tripId]); // eslint-disable-line react-hooks/exhaustive-deps


  // Auto-fill route from trip
  useEffect(() => {
    let cancelled = false;
    placesRouteLay.current?.clearLayers();
    placesRouteSigRef.current = "";
    placesRouteDrawnRef.current = false;
    placesRouteTripRef.current = null;
    placesRouteFetchedRef.current = false;
    setPlacesRouteFetched(false);
    const run = async () => {
      const trip = trips.find(tr => String(tr.id) === tripId);
      if (!trip || cancelled) return;
      activeTripRef.current = trip;

      const from = trip.start_location?.trim();
      const to   = trip.destination?.trim();

      if (from) setRouteFrom(from);
      if (to)   setRouteTo(to);

      if (trip.active_route) {
        try {
          const stored = JSON.parse(trip.active_route);
          if (drawStoredRoutes(stored)) return;
        } catch {}
      }

      if (!remoteCacheLoadedRef.current[String(tripId)] && localStorage.getItem("tm_token")) {
        remoteCacheLoadedRef.current[String(tripId)] = true;
        try {
          const row = await settingsApi.get(`${LIVE_MAP_REMOTE_CACHE_PREFIX}${tripId}`);
          const remote = row?.value_text ? JSON.parse(row.value_text) : null;
          if (!cancelled && remote) {
            if (remote.tab) setTab(remote.tab);
            if (remote.routeFrom) setRouteFrom(remote.routeFrom);
            if (remote.routeTo) setRouteTo(remote.routeTo);
            if (Array.isArray(remote.nearbyItems) && remote.nearbyItems.length) setNearbyItems(remote.nearbyItems);
            if (remote.storedRoute && drawStoredRoutes(remote.storedRoute)) return;
          }
        } catch {}
      }

      try {
        const cache = JSON.parse(localStorage.getItem(MAP_CACHE_KEY) || "{}");
        const cached = cache?.[String(tripId)];
        if (cached) {
          if (cached.tab) setTab(cached.tab);
          if (cached.routeFrom) setRouteFrom(cached.routeFrom);
          if (cached.routeTo) setRouteTo(cached.routeTo);
          if (Array.isArray(cached.nearbyItems) && cached.nearbyItems.length) setNearbyItems(cached.nearbyItems);
        }
        if (cached?.storedRoute && drawStoredRoutes(cached.storedRoute)) return;
      } catch {}

      if (from && to) {
        const doAutoRoute = async () => {
          let waited = 0;
          // Wait for map to be ready AND container to have real dimensions
          while (waited < 4000) {
            if (lmap.current && mapRef.current && mapRef.current.offsetHeight > 50) break;
            await new Promise(r => setTimeout(r, 120));
            waited += 120;
          }
          if (!lmap.current || cancelled) return;
          // Trigger invalidateSize so tiles fill the full container before routing
          lmap.current.invalidateSize({ animate: false });
          await new Promise(r => setTimeout(r, 80));
          setRouteBusy(true);
          setRouteResult(null); setAltRoutes([]); setActiveAlt(0);
          routeLay.current?.clearLayers();
          try {
            const fLL = parseLatLngInput(from);
            const tLL = parseLatLngInput(to);
            const [fr, tr] = await Promise.all([
              fLL ? Promise.resolve([{ lat: String(fLL.lat), lon: String(fLL.lng) }]) : geocode(from),
              tLL ? Promise.resolve([{ lat: String(tLL.lat), lon: String(tLL.lng) }]) : geocode(to),
            ]);
            if (!fr[0] || !tr[0]) { setRouteBusy(false); return; }
            await drawRouteCoordsRef.current(
              parseFloat(fr[0].lat), parseFloat(fr[0].lon),
              parseFloat(tr[0].lat), parseFloat(tr[0].lon),
              from, to
            );
          } catch (e) { console.error("Auto-route:", e); setRouteBusy(false); }
        };
        doAutoRoute();
      } else if (to && lmap.current) {
        const ll = parseLatLngInput(to);
        if (ll) {
          lmap.current.flyTo([ll.lat, ll.lng], 11, { animate: true, duration: 1.2 });
        } else {
          geocode(to).then(res => {
            if (!res[0] || cancelled) return;
            lmap.current.flyTo([parseFloat(res[0].lat), parseFloat(res[0].lon)], 11, { animate: true, duration: 1.2 });
          }).catch(() => {});
        }
      }
    };
    run();
    return () => { cancelled = true; };
  }, [tripId, trips, drawStoredRoutes]);



  const drawNearbyMarkers = useCallback((items, cat) => {
    const L = window.L, map = lmap.current;
    if (!L || !map || !nearbyLay.current) {
      console.warn('Map or nearbyLay not ready');
      return;
    }
    
    if (!items || items.length === 0) {
      return;
    }
    
    nearbyLay.current.clearLayers();

    const toRender = (items || []).slice(0, 500);
    const markers = [];

    toRender.forEach((r, index) => {
      const dl = r.dist < 1000 ? `${Math.round(r.dist)}m` : `${(r.dist / 1000).toFixed(1)}km`;
      const popup = `<div style="padding:6px;min-width:220px;font-family:system-ui,-apple-system,sans-serif">` +
        `<b style="font-size:14px;color:#000;font-weight:600;margin-bottom:4px">${r.name || 'Unknown'}</b><br>` +
        `<span style="color:${r.catColor || cat.color};font-size:12px;font-weight:500">${r.catEmoji || cat.emoji} ${r.type || r.catLabel || cat.label}</span><br>` +
        `<span style="float:right;font-size:11px;color:#333;font-weight:400">📍 ${dl}</span><br>` +
        (r.addr  ? `<div style="font-size:11px;color:#666;margin-top:3px">${r.addr}</div>` : "") +
        (r.hours ? `<div style="font-size:11px;color:#666;margin-top:2px">⏰ ${r.hours}</div>` : "") +
        (r.phone ? `<a href="tel:${r.phone}" style="color:#00D4FF;font-size:12px;display:block;margin-top:3px;font-weight:500">📞 ${r.phone}</a>` : "") +
        `</div>`;

      const lat = parseFloat(r.lat);
      const lng = parseFloat(r.lng);
      
      if (!r.lat || !r.lng || isNaN(lat) || isNaN(lng) || lat < -90 || lat > 90 || lng < -180 || lng > 180) {
        return;
      }

      try {
        const marker = L.marker([lat, lng], { 
          icon: nearbyDot(r.catColor || cat.color, map.getZoom()),
          zIndexOffset: 1000
        });
        if (marker && marker.bindPopup) {
          marker.bindPopup(popup);
          markers.push(marker);
        }
      } catch (error) {
        console.error('Error creating marker:', error, 'for item:', r);
      }
    });

    // Batch add — much faster than individual .addTo() calls
    if (nearbyLay.current.addLayers) {
      nearbyLay.current.addLayers(markers);
    } else {
      markers.forEach(m => m.addTo(nearbyLay.current));
    }
  }, [tripId, trips]);

  const persistFacilitiesToTrip = useCallback(async (items) => {
    if (!tripId || !Array.isArray(items) || !items.length) return;
    try {
      const currentTrip = trips.find(tr => String(tr.id) === String(tripId));
      const existing = currentTrip?.preloaded_facilities ? JSON.parse(currentTrip.preloaded_facilities) : [];
      const byId = new Map();
      (Array.isArray(existing) ? existing : []).forEach(it => byId.set(String(it.id), it));
      items.forEach(it => byId.set(String(it.id), it));
      const merged = [...byId.values()];
      const serialized = JSON.stringify(merged);
      await tripsApi.update(tripId, { preloaded_facilities: serialized });
      setTrips(prev => prev.map(tr => String(tr.id) === String(tripId) ? { ...tr, preloaded_facilities: serialized } : tr));
    } catch {}
  }, [tripId, trips]);

  const fetchAllAlongRouteOptimized = useCallback(async () => {
    const map = lmap.current, L = window.L;
    if (!L || !map) return;
    const coords = routeCoordsRef.current;
    if (!coords || coords.length < 2) return;

    if (activeCatRef.current === "all") {
      nearbyLay.current?.clearLayers();
      activeCatRef.current = null;
      setActiveCat(null); setNearbyItems([]); setActiveItem(null); setNearbyProgress("");
      return;
    }

    showBusy("Loading amenities every 10km...");

    autoFitLockRef.current = true;
    activeCatRef.current = "all";
    setActiveCat("all"); setNearbyBusy(true); setNearbyItems([]); setActiveItem(null); setNearbyProgress("");
    nearbyLay.current.clearLayers();

    const seen = new Set();
    const allResults = [];

    const currentTrip = trips.find(tr => String(tr.id) === String(tripId));
    if (currentTrip?.preloaded_facilities) {
      try {
        const cachedResults = JSON.parse(currentTrip.preloaded_facilities);
        const filtered = (Array.isArray(cachedResults) ? cachedResults : []).filter(r => AMENITY_ROUTE_SET.has(r.catKey));
        if (filtered.length > 0) {
          filtered.forEach(r => {
            seen.add(String(r.id));
            allResults.push(r);
          });
          drawNearbyMarkers(filtered, NEARBY_CATS[0]);
          setNearbyItems(filtered);
        }
      } catch {}
    }

    const segments = splitRouteByDistance(coords, 5);
    if (!segments.length) {
      setNearbyBusy(false);
      autoFitLockRef.current = false;
      return;
    }

    let cancelled = false;
    for (let seg = 0; seg < segments.length; seg++) {
      if (activeCatRef.current !== "all") { cancelled = true; break; }
      const bbox = bboxForCoords(segments[seg], 0.06);
      if (!bbox) continue;

      for (const catKey of AMENITY_ROUTE_KEYS) {
        if (activeCatRef.current !== "all") { cancelled = true; break; }
        const cat = NEARBY_CATS.find(c => c.key === catKey);
        if (!cat) continue;
        setNearbyProgress(`${seg + 1}/${segments.length} - ${cat.label}`);
        const q = `[out:json][timeout:25];(${cat.q}(${bbox.minLat},${bbox.minLng},${bbox.maxLat},${bbox.maxLng}););out body 20;`;
        try {
          const results = await overpassQuery(q);
          for (const r of results.slice(0, 20)) {
            const rid = String(r.id);
            if (seen.has(rid)) continue;
            seen.add(rid);
            const distFromStart = haversine(coords[0][0], coords[0][1], r.lat, r.lng);
            allResults.push({
              ...r,
              dist: distFromStart,
              catKey: cat.key,
              catEmoji: cat.emoji,
              catLabel: cat.label,
              catColor: cat.color,
            });
          }
        } catch (e) { console.error(`Route segment ${seg} (${catKey}):`, e); }
        await new Promise(r => setTimeout(r, 120));
      }

      const sortedPartial = [...allResults].sort((a, b) => a.dist - b.dist);
      if (sortedPartial.length > 0) {
        await persistFacilitiesToTrip(sortedPartial);
        drawNearbyMarkers(sortedPartial, NEARBY_CATS[0]);
        setNearbyItems(sortedPartial);
      }
    }

    setNearbyProgress("");
    setNearbyBusy(false);
    if (!cancelled) {
      const sorted = [...allResults].sort((a, b) => a.dist - b.dist);
      if (sorted.length > 0) {
        await persistFacilitiesToTrip(sorted);
        drawNearbyMarkers(sorted, NEARBY_CATS[0]);
        setNearbyItems(sorted);
      }
      showDone(sorted.length ? `Loaded ${sorted.length} amenities` : "No amenities found");
    }
    autoFitLockRef.current = false;
  }, [trips, tripId, showBusy, showDone, persistFacilitiesToTrip, drawNearbyMarkers]);

  // ── GPS ───────────────────────────────────────────────────────────────────
  const startGPS = useCallback(() => {
    if (!navigator.geolocation || !lmap.current) return;
    setGpsOn(true);
    gpsOnRef.current = true;

    const onDeviceOrientation = (e) => {
      const h = typeof e.webkitCompassHeading === "number"
        ? e.webkitCompassHeading
        : (typeof e.alpha === "number" ? (360 - e.alpha) % 360 : null);
      if (h == null || Number.isNaN(h)) return;
      const hh = Math.round(h);
      gpsHeadingRef.current = hh;
      setGpsHeading(hh);
      const L = window.L;
      if (!L || !lmap.current || !gpsPos.current) return;
      if (gpsHeadMark.current) {
        gpsHeadMark.current.setLatLng([gpsPos.current.lat, gpsPos.current.lng]);
        gpsHeadMark.current.setIcon(headingIcon(hh));
      } else {
        gpsHeadMark.current = L.marker([gpsPos.current.lat, gpsPos.current.lng], { icon: headingIcon(hh), interactive: false, zIndexOffset: 1200 }).addTo(lmap.current);
      }
    };
    orientationHandlerRef.current = onDeviceOrientation;
    if (window.DeviceOrientationEvent) {
      if (typeof DeviceOrientationEvent.requestPermission === "function") {
        DeviceOrientationEvent.requestPermission().then(state => {
          if (state === "granted" && orientationHandlerRef.current) {
            window.addEventListener("deviceorientation", orientationHandlerRef.current, true);
          }
        }).catch(() => {});
      } else {
        window.addEventListener("deviceorientation", onDeviceOrientation, true);
      }
    }

    gpsWatch.current = navigator.geolocation.watchPosition(pos => {
      const { latitude: la, longitude: ln, accuracy: ac, heading } = pos.coords;
      gpsPos.current = { lat: la, lng: ln };
      setGpsLastTs(Date.now());
      setGpsCoords({ lat: la.toFixed(5), lng: ln.toFixed(5), acc: Math.round(ac) });
      if (Number.isFinite(heading) && heading >= 0) {
        const hh = Math.round(heading);
        gpsHeadingRef.current = hh;
        setGpsHeading(hh);
      }
      const L = window.L, map = lmap.current;
      if (!L || !map) return;
      if (gpsMark.current) {
        gpsMark.current.setLatLng([la, ln]);
        gpsMark.current.setIcon(gpsIcon(navDest.current != null));
      } else {
        gpsMark.current = L.marker([la, ln], { icon: gpsIcon(false), zIndexOffset: 1000 })
          .bindPopup("📍 You are here").addTo(map);
        map.setView([la, ln], 14, { animate: true });
      }
      if (gpsHeadingRef.current != null) {
        if (gpsHeadMark.current) {
          gpsHeadMark.current.setLatLng([la, ln]);
          gpsHeadMark.current.setIcon(headingIcon(gpsHeadingRef.current));
        } else {
          gpsHeadMark.current = L.marker([la, ln], { icon: headingIcon(gpsHeadingRef.current), interactive: false, zIndexOffset: 1200 }).addTo(map);
        }
      } else if (navDest.current && !gpsHeadMark.current) {
        gpsHeadMark.current = L.marker([la, ln], { icon: headingIcon(0), interactive: false, zIndexOffset: 1200 }).addTo(map);
      }
      if (gpsCirc.current) gpsCirc.current.setLatLng([la, ln]).setRadius(ac);
      else gpsCirc.current = L.circle([la, ln], { radius: ac, color: "#00D4FF", fillColor: "#38BDF8", fillOpacity: 0.06, weight: 1 }).addTo(map);

      if (navStartingRef.current && navAwaitingGpsRef.current && ac <= GPS_GOOD_ACCURACY_M) {
        navAwaitingGpsRef.current = false;
        navStartingRef.current = false;
        setNavStarting(false);
        showDone("GPS locked");
        if (navDest.current) updateNavRef.current?.(la, ln, navDest.current);
      }

      if (navDest.current) {
        const now = Date.now();
        const last = lastNavPosRef.current;
        const moved = last ? haversine(last.lat, last.lng, la, ln) : Infinity;
        if (now - lastNavUpdateTsRef.current >= 1000 || moved >= 6) {
          lastNavUpdateTsRef.current = now;
          lastNavPosRef.current = { lat: la, lng: ln };
          updateNavRef.current?.(la, ln, navDest.current);
        }
      }
    }, (err) => {
      console.error("GPS watchPosition error:", err);
      setGpsCoords(prev => prev); // keep showing last known
    }, { enableHighAccuracy: true, maximumAge: 0, timeout: 10000 });
  }, []);

  const stopGPS = useCallback(() => {
    if (gpsWatch.current) navigator.geolocation.clearWatch(gpsWatch.current);
    if (gpsMark.current) { lmap.current?.removeLayer(gpsMark.current); gpsMark.current = null; }
    if (gpsHeadMark.current) { lmap.current?.removeLayer(gpsHeadMark.current); gpsHeadMark.current = null; }
    if (gpsCirc.current) { lmap.current?.removeLayer(gpsCirc.current); gpsCirc.current = null; }
    if (orientationHandlerRef.current) {
      window.removeEventListener("deviceorientation", orientationHandlerRef.current, true);
      orientationHandlerRef.current = null;
    }
    gpsHeadingRef.current = null;
    setGpsOn(false); gpsOnRef.current = false; setGpsCoords(null); setGpsLastTs(null); setGpsHeading(null); gpsPos.current = null;
  }, []);

  useEffect(() => {
    if (gpsHeadMark.current && gpsHeadingRef.current != null) {
      gpsHeadMark.current.setIcon(headingIcon(gpsHeadingRef.current));
    }
  }, [gpsHeading]);

  // ── Nearby ────────────────────────────────────────────────────────────────
  const fetchNearby = useCallback(async (catKey, retryCount = 0) => {
    const map = lmap.current, L = window.L;
    if (!L || !map) return;
    if (activeCatRef.current === catKey) {
      nearbyLay.current?.clearLayers();
      activeCatRef.current = null;
      setActiveCat(null); setNearbyItems([]); setActiveItem(null);
      return;
    }
    const cat = NEARBY_CATS.find(c => c.key === catKey);
    if (!cat) return;
    activeCatRef.current = catKey;
    setActiveCat(catKey); setNearbyBusy(true); setNearbyItems([]); setActiveItem(null);
    nearbyLay.current.clearLayers();
    const center = routeCoordsRef.current?.length > 0 
      ? { lat: routeCoordsRef.current[0][0], lng: routeCoordsRef.current[0][1] } 
      : gpsPos.current || map.getCenter();
    const lat = center.lat, lng = center.lng;
    const query = `[out:json][timeout:15];(${cat.q}(around:5000,${lat},${lng}););out body 60;`;
    let sorted = [];
    try {
      const results = await overpassQuery(query);
      if (activeCatRef.current !== catKey) return;
      sorted = results
        .map(r => ({ ...r, dist: haversine(lat, lng, r.lat, r.lng) }))
        .sort((a, b) => a.dist - b.dist)
        .slice(0, 40);
      
      if (sorted.length === 0 && retryCount === 0) {
        setTimeout(() => fetchNearby(catKey, 1), 1000);
        return;
      }
      
      setNearbyItems(sorted);
      drawNearbyMarkers(sorted, cat);
    } catch (e) { 
      console.error("Nearby:", e); 
      if (activeCatRef.current === catKey && (!sorted || sorted.length === 0)) {
        showDone(`No ${cat.label.toLowerCase()} found nearby. Try again?`);
      }
    }
    finally { setNearbyBusy(false); }
  }, [drawNearbyMarkers, showDone]);

  const clearNearby = () => {
    nearbyLay.current?.clearLayers();
    activeCatRef.current = null;
    setActiveCat(null); setNearbyItems([]); setActiveItem(null);
  };

  const fetchAllAlongRoute = useCallback(async () => {
    return fetchAllAlongRouteOptimized();
  }, [fetchAllAlongRouteOptimized]);

  // ── Facilities along route — sectioned bbox fetch ───────────────────────────
  const fetchAlongRouteOptimized = useCallback(async (catKey, overrideCoords = null) => {
    const map = lmap.current, L = window.L;
    if (!L || !map) return;
    const primaryCoords = altRoutes?.[0]?.coords;
    const coords = overrideCoords || primaryCoords || routeCoordsRef.current;
    if (!coords || coords.length < 2) { fetchNearby(catKey); return; }

    const cat = NEARBY_CATS.find(c => c.key === catKey);
    if (!cat) return;
    if (AMENITY_ROUTE_SET.has(catKey)) {
      showBusy(`Loading ${cat.label} every 10km...`);

      if (!overrideCoords && activeCatRef.current === catKey) {
        nearbyLay.current?.clearLayers();
        activeCatRef.current = null;
        setActiveCat(null); setNearbyItems([]); setActiveItem(null); setNearbyProgress("");
        return;
      }

      autoFitLockRef.current = true;
      let cancelled = false;
      const thisCat = catKey;
      activeCatRef.current = catKey;
      setActiveCat(catKey); setNearbyBusy(true); setNearbyItems([]); setActiveItem(null); setNearbyProgress("");
      nearbyLay.current.clearLayers();

      const seen = new Set();
      const allResults = [];

      const currentTrip = trips.find(tr => String(tr.id) === String(tripId));
      if (currentTrip?.preloaded_facilities) {
        try {
          const cachedResults = JSON.parse(currentTrip.preloaded_facilities);
          const filtered = (Array.isArray(cachedResults) ? cachedResults : []).filter(r => r.catKey === catKey);
          if (filtered.length > 0) {
            filtered.forEach(r => {
              seen.add(String(r.id));
              allResults.push(r);
            });
            drawNearbyMarkers(filtered, cat);
            setNearbyItems(filtered);
          }
        } catch {}
      }

      const segments = splitRouteByDistance(coords, 5);
      if (!segments.length) {
        setNearbyBusy(false);
        autoFitLockRef.current = false;
        return;
      }

      for (let seg = 0; seg < segments.length; seg++) {
        if (activeCatRef.current !== thisCat) { cancelled = true; break; }
        const bbox = bboxForCoords(segments[seg], 0.06);
        if (!bbox) continue;
        setNearbyProgress(`${seg + 1}/${segments.length}`);
        const q = `[out:json][timeout:25];(${cat.q}(${bbox.minLat},${bbox.minLng},${bbox.maxLat},${bbox.maxLng}););out body 20;`;
        try {
          const results = await overpassQuery(q);
          for (const r of results.slice(0, 20)) {
            const rid = String(r.id);
            if (seen.has(rid)) continue;
            seen.add(rid);
            const distFromStart = haversine(coords[0][0], coords[0][1], r.lat, r.lng);
            allResults.push({
              ...r,
              dist: distFromStart,
              catKey: cat.key,
              catEmoji: cat.emoji,
              catLabel: cat.label,
              catColor: cat.color,
            });
          }
        } catch (e) { console.error(`Route segment ${seg} (${catKey}):`, e); }

        const sortedPartial = [...allResults].sort((a, b) => a.dist - b.dist);
        if (sortedPartial.length > 0) {
          await persistFacilitiesToTrip(sortedPartial);
          drawNearbyMarkers(sortedPartial, cat);
          setNearbyItems(sortedPartial);
        }

        if (seg < segments.length - 1) {
          await new Promise(r => setTimeout(r, 150));
        }
      }

      setNearbyProgress("");
      if (!cancelled) {
        const sorted = [...allResults].sort((a, b) => a.dist - b.dist);
        if (sorted.length > 0) {
          await persistFacilitiesToTrip(sorted);
          drawNearbyMarkers(sorted, cat);
          setNearbyItems(sorted);
        }
        setNearbyBusy(false);
        showDone(sorted.length ? `Loaded ${sorted.length} ${cat.label.toLowerCase()}` : `No ${cat.label.toLowerCase()} found`);
      } else {
        setNearbyBusy(false);
      }
      autoFitLockRef.current = false;
      return;
    }

    showBusy(`Loading ${cat.label} along route...`);

    if (!overrideCoords && activeCatRef.current === catKey) {
      nearbyLay.current?.clearLayers();
      activeCatRef.current = null;
      setActiveCat(null); setNearbyItems([]); setActiveItem(null); setNearbyProgress("");
      return;
    }

    autoFitLockRef.current = true;
    let cancelled = false;
    const thisCat = catKey;
    activeCatRef.current = catKey;
    setActiveCat(catKey); setNearbyBusy(true); setNearbyItems([]); setActiveItem(null);
    nearbyLay.current.clearLayers();

    const seen = new Set();
    const allResults = [];
    const totalDist = coords.reduce((sum, c, i) =>
      i === 0 ? 0 : sum + haversine(coords[i-1][0], coords[i-1][1], c[0], c[1]), 0);
    const N = Math.max(1, Math.round(totalDist / 5000));
    const step = Math.max(2, Math.floor(coords.length / N));
    const PAD = 0.09;

    for (let seg = 0; seg < N; seg++) {
      if (activeCatRef.current !== thisCat) { cancelled = true; break; }
      setNearbyProgress(`${seg + 1} / ${N}`);

      const segStart = seg * step;
      const segEnd   = Math.min(segStart + step, coords.length - 1);
      const slice    = coords.slice(segStart, segEnd + 1);

      let minLat = Infinity, maxLat = -Infinity, minLng = Infinity, maxLng = -Infinity;
      for (const [la, ln] of slice) {
        if (la < minLat) minLat = la; if (la > maxLat) maxLat = la;
        if (ln < minLng) minLng = ln; if (ln > maxLng) maxLng = ln;
      }
      minLat -= PAD; maxLat += PAD; minLng -= PAD; maxLng += PAD;

      const q = `[out:json][timeout:25];(${cat.q}(${minLat},${minLng},${maxLat},${maxLng}););out body 20;`;
      try {
        const results = await overpassQuery(q);
        for (const r of results) {
          if (seen.has(r.id)) continue;
          seen.add(r.id);
          const distFromStart = haversine(coords[0][0], coords[0][1], r.lat, r.lng);
          allResults.push({
            ...r,
            dist: distFromStart,
            catKey: cat.key,
            catEmoji: cat.emoji,
            catLabel: cat.label,
            catColor: cat.color,
          });
        }

        const sortedPartial = [...allResults].sort((a, b) => a.dist - b.dist);
        if (sortedPartial.length > 0) {
          await persistFacilitiesToTrip(sortedPartial);
          drawNearbyMarkers(sortedPartial, cat);
          setNearbyItems(sortedPartial);
        }

        if (seg < N - 1) {
          await new Promise(r => setTimeout(r, 200));
        }
      } catch (e) { console.error(`Route segment ${seg}:`, e); }
    }

    setNearbyProgress("");
    if (!cancelled) {
      const sorted = [...allResults].sort((a, b) => a.dist - b.dist);
      if (sorted.length > 0) {
        await persistFacilitiesToTrip(sorted);
        drawNearbyMarkers(sorted, cat);
        setNearbyItems(sorted);
      }
      setNearbyBusy(false);
      showDone(sorted.length ? `Loaded ${sorted.length} ${cat.label.toLowerCase()}` : `No ${cat.label.toLowerCase()} found`);
    } else {
      setNearbyBusy(false);
    }
    autoFitLockRef.current = false;
  }, [trips, tripId, showBusy, showDone, persistFacilitiesToTrip, drawNearbyMarkers]);

  const fetchAlongRoute = useCallback(async (catKey, overrideCoords = null) => {
    return fetchAlongRouteOptimized(catKey, overrideCoords);
  }, [fetchAlongRouteOptimized]);
  

  // ── FIX 4: Guard uses ref so button click is seen immediately without waiting for re-render ──
  const drawPlacesTraversalRoute = useCallback(async () => {
    // Only proceed if the user has explicitly clicked "Fetch Route" for this trip
    if (!placesRouteFetchedRef.current && placesRouteTripRef.current !== String(tripId)) return;

    const L = window.L, map = lmap.current;
    if (!L || !map) return;
    const mapped = places
      .filter(p => Number.isFinite(p.latitude) && Number.isFinite(p.longitude))
      .sort((a, b) => (a.order_idx ?? 0) - (b.order_idx ?? 0) || Number(a.id) - Number(b.id));

    const currentTrip = trips.find(tr => String(tr.id) === String(tripId));

    let tripStart = null;
    let tripEnd = null;

    const tryGeocode = async (locText) => {
      if (!locText?.trim()) return null;
      const ll = parseLatLngInput(locText);
      if (ll) return { latitude: ll.lat, longitude: ll.lng };
      try {
        const res = await geocode(locText.trim());
        if (res?.[0]) return { latitude: parseFloat(res[0].lat), longitude: parseFloat(res[0].lon) };
      } catch {}
      return null;
    };

    if (currentTrip?.start_location || currentTrip?.destination) {
      [tripStart, tripEnd] = await Promise.all([
        tryGeocode(currentTrip?.start_location),
        tryGeocode(currentTrip?.destination),
      ]);
    }

    if ((!tripStart || !tripEnd) && currentTrip?.active_route) {
      try {
        const routeData = JSON.parse(currentTrip.active_route);
        const pr = routeData?.routes?.[0];
        if (pr?.coords?.length) {
          if (!tripStart) tripStart = { latitude: pr.coords[0][0], longitude: pr.coords[0][1], id: "start" };
          if (!tripEnd) tripEnd = { latitude: pr.coords[pr.coords.length - 1][0], longitude: pr.coords[pr.coords.length - 1][1], id: "end" };
        }
      } catch {}
    }

    let osrmPoints = [];
    if (tripStart) osrmPoints.push({ ...tripStart, id: "start" });
    osrmPoints = osrmPoints.concat(mapped);
    if (tripEnd) osrmPoints.push({ ...tripEnd, id: "end" });

    if (osrmPoints.length < 2 || mapped.length < 1) {
      placesRouteLay.current?.clearLayers();
      placesRouteSigRef.current = "";
      placesRouteDrawnRef.current = false;
      if (placesRouteZoomTimerRef.current) {
        clearTimeout(placesRouteZoomTimerRef.current);
        placesRouteZoomTimerRef.current = null;
      }
      if (placesRoutePreviewTimerRef.current) {
        clearTimeout(placesRoutePreviewTimerRef.current);
        placesRoutePreviewTimerRef.current = null;
      }
      placesRouteZoomPendingRef.current = false;
      setPlacesRouteBusy(false);
      showDone("Pin at least 1 place to generate a route");
      return;
    }

    const sigStart = tripStart ? `${(+tripStart.latitude).toFixed(4)},${(+tripStart.longitude).toFixed(4)}` : "nostart";
    const sigEnd   = tripEnd   ? `${(+tripEnd.latitude).toFixed(4)},${(+tripEnd.longitude).toFixed(4)}`   : "noend";
    const sig = `${sigStart}|${sigEnd}|` + mapped.map(p => `${p.id}:${p.latitude}:${p.longitude}:${p.order_idx ?? 0}`).join("|");
    if (placesRouteSigRef.current === sig) return;
    placesRouteSigRef.current = sig;

    const drawSeq = ++placesRouteDrawSeqRef.current;
    placesRouteDrawnRef.current = false;

    setPlacesRouteError("");
    placesRouteDoneMsgRef.current = "";
    setPlacesRouteBusy(true);
    showBusy("Drawing places visit route...");
    let usedCached = false;
    if (placesRoutePreviewTimerRef.current) {
      clearTimeout(placesRoutePreviewTimerRef.current);
      placesRoutePreviewTimerRef.current = null;
    }
    let routeDrawn = false;

    const previewCoords = osrmPoints.map(p => [p.latitude, p.longitude]).filter(([la, ln]) => Number.isFinite(la) && Number.isFinite(ln));
    placesRoutePreviewTimerRef.current = setTimeout(() => {
      if (placesRouteDrawSeqRef.current !== drawSeq) return;
      if (placesRouteDrawnRef.current || routeDrawn) return;
      if (!previewCoords.length || !placesRouteLay.current) return;
      placesRouteLay.current.clearLayers();
      L.polyline(previewCoords, {
        color: "#94A3B8",
        weight: 3,
        opacity: 0.5,
        lineCap: "round",
        lineJoin: "round",
        dashArray: "6 10",
        className: "tm-places-preview",
        smoothFactor: 1,
        renderer: placesRouteSvgRef.current,
      }).addTo(placesRouteLay.current);
      mapped.forEach((p, i) => {
        L.marker([p.latitude, p.longitude], { icon: pinIcon("#94A3B8", String(i + 1)), zIndexOffset: 640 })
          .bindPopup(`<b>${p.name}</b><br><span style="font-size:11px;color:${t.textDim}">${p.place_type || "Place"}</span>`)
          .addTo(placesRouteLay.current);
      });
    }, 3500);

    const renderPlacesRoute = (coords, dist, dur, label = "Pinned Places Route", color = "#FF6B35") => {
      if (!coords?.length) return;
      if (placesRouteDrawSeqRef.current !== drawSeq) return;
      if (placesRoutePreviewTimerRef.current) {
        clearTimeout(placesRoutePreviewTimerRef.current);
        placesRoutePreviewTimerRef.current = null;
      }
      placesRouteLay.current?.clearLayers();
      placesRouteDrawnRef.current = true;
      const routeObj = { idx: 0, dist, dur, coords, label, color };

      L.polyline(coords, { color: routeObj.color, weight: 5, opacity: 0.9, lineCap: "round", lineJoin: "round", smoothFactor: 1, renderer: placesRouteSvgRef.current }).addTo(placesRouteLay.current);
      if (tripStart?.latitude && tripStart?.longitude) {
        L.marker([tripStart.latitude, tripStart.longitude], { icon: pinIcon("#38BDF8", "A"), zIndexOffset: 700 })
          .bindPopup(`<b>Trip Start</b><br><span style="font-size:11px;color:${t.textDim}">${currentTrip?.start_location || "Origin"}</span>`)
          .addTo(placesRouteLay.current);
      }
      mapped.forEach((p, i) => {
        L.marker([p.latitude, p.longitude], { icon: pinIcon("#A78BFA", String(i + 1)), zIndexOffset: 650 })
          .bindPopup(`<b>${p.name}</b><br><span style="font-size:11px;color:${t.textDim}">${p.place_type || "Place"}</span>`)
          .addTo(placesRouteLay.current);
      });
      if (tripEnd?.latitude && tripEnd?.longitude) {
        L.marker([tripEnd.latitude, tripEnd.longitude], { icon: pinIcon("#34D399", "B"), zIndexOffset: 700 })
          .bindPopup(`<b>Trip End</b><br><span style="font-size:11px;color:${t.textDim}">${currentTrip?.destination || "Destination"}</span>`)
          .addTo(placesRouteLay.current);
      }

      const bounds = L.latLngBounds(coords);
      if (bounds.isValid()) {
        const map = lmap.current;
        if (placesRouteZoomTimerRef.current) {
          clearTimeout(placesRouteZoomTimerRef.current);
          placesRouteZoomTimerRef.current = null;
        }
        placesRouteZoomPendingRef.current = true;
        if (map?.once) {
          map.once("moveend", () => {
            if (!placesRouteZoomPendingRef.current) return;
            placesRouteZoomPendingRef.current = false;
            finishPlacesRouteBusy();
          });
        }
        placesRouteZoomTimerRef.current = setTimeout(() => {
          placesRouteZoomPendingRef.current = false;
          finishPlacesRouteBusy();
        }, 1600);
        fitBoundsSafe(bounds, { padding: [70, 70], maxZoom: 14, animate: true, duration: 1.2 }, true);
      }
      routeDrawn = true;
    };

    const cachedLocal = getCachedPlacesRoute(tripId, currentTrip);
    // Only use cache if sig matches exactly — prevents stale route from a different set of waypoints
    if (cachedLocal?.coords?.length && cachedLocal.sig === sig) {
      renderPlacesRoute(cachedLocal.coords, cachedLocal.dist, cachedLocal.dur, cachedLocal.label || "Pinned Places Route", cachedLocal.color || "#FF6B35");
      setPlacesRouteError("");
      placesRouteTripRef.current = String(tripId);
      placesRouteDoneMsgRef.current = `Places route ready · ${cachedLocal.dist} km`;
      usedCached = true;
      finishPlacesRouteBusy();
      return;
    }
    usedCached = false;

    // Always clear before fresh fetch
    placesRouteLay.current?.clearLayers();

    try {
      const maxOsrmPoints = 90;
      let finalPoints = osrmPoints;
      if (osrmPoints.length > maxOsrmPoints) {
        const step = Math.ceil(osrmPoints.length / maxOsrmPoints);
        finalPoints = osrmPoints.filter((_, i) => i % step === 0 || i === osrmPoints.length - 1);
      }
      const coordStr = finalPoints.map(p => `${p.longitude},${p.latitude}`).join(";");
      const url = `https://router.project-osrm.org/route/v1/driving/${coordStr}?overview=full&geometries=geojson&steps=true`;
      const ctrl = new AbortController();
      const tid = setTimeout(() => ctrl.abort(), 25000);
      const res = await fetch(url, { signal: ctrl.signal });
      clearTimeout(tid);
      const data = await res.json();
      const route = data?.routes?.[0];
      if (!route?.geometry?.coordinates?.length) {
        setPlacesRouteError("Places route unavailable — OSRM returned no geometry.");
        showDone("Could not draw places route");
      } else {
        const coords = route.geometry.coordinates.map(([ln, la]) => [la, ln]);
        const dist = +(route.distance / 1000).toFixed(1);
        const dur = Math.round(route.duration / 60);
        renderPlacesRoute(coords, dist, dur);
        placesRouteTripRef.current = String(tripId);
        setPlacesRouteError("");
        placesRouteDoneMsgRef.current = `Places route ready · ${dist} km`;
        persistPlacesRouteToTrip({
          sig,
          coords,
          dist,
          dur,
          label: "Pinned Places Route",
          color: "#FF6B35",
          place_ids: mapped.map(p => p.id),
          savedAt: new Date().toISOString(),
        });
      }
    } catch (e) {
      console.error("drawPlacesTraversalRoute:", e);
      setPlacesRouteError("Places route unavailable — check internet or try again.");
      showDone("Could not draw places route");
    } finally {
      if (placesRouteDrawSeqRef.current !== drawSeq) return;
      if (placesRouteZoomPendingRef.current) return;
      if (routeDrawn || placesRouteDrawnRef.current) finishPlacesRouteBusy();
      else setPlacesRouteBusy(false);
    }
  }, [places, t.textDim, showBusy, showDone, trips, tripId, drawStoredRoutes, finishPlacesRouteBusy, persistPlacesRouteToTrip, getCachedPlacesRoute, cachePlacesRoute]);

  const focusPlacesRoute = useCallback(() => {
    const L = window.L, map = lmap.current;
    if (!L || !map) return;
    const layer = placesRouteLay.current;
    if (!layer || layer.getLayers().length === 0) {
      // Only re-draw if user has already fetched for this trip
      if (placesRouteFetched && placesRouteTripRef.current === String(tripId)) {
        placesRouteSigRef.current = "";
        drawPlacesTraversalRoute();
      }
      return;
    }
    const bounds = L.latLngBounds();
    layer.eachLayer(l => {
      if (l.getLatLng) {
        bounds.extend(l.getLatLng());
      } else if (l.getLatLngs) {
        l.getLatLngs().forEach(ll => bounds.extend(ll));
      }
    });
    if (bounds.isValid()) {
      fitBoundsSafe(bounds, { padding: [70, 70], maxZoom: 14, animate: true, duration: 1.2 }, true);
    }
  }, [drawPlacesTraversalRoute, fitBoundsSafe, placesRouteFetched, tripId]);

  const focusPlacesRouteAfterDraw = useCallback(() => {
    const L = window.L, map = lmap.current;
    if (!L || !map) return;
    if (placesRouteFocusTimerRef.current) {
      clearTimeout(placesRouteFocusTimerRef.current);
      placesRouteFocusTimerRef.current = null;
    }
    placesRouteSigRef.current = "";
    drawPlacesTraversalRoute();
    let tries = 0;
    const tick = () => {
      const layer = placesRouteLay.current;
      if (!layer) return;
      const bounds = L.latLngBounds();
      let has = false;

      layer.eachLayer(l => {
        if (l.getLatLng) {
          bounds.extend(l.getLatLng());
          has = true;
        } else if (l.getLatLngs) {
          l.getLatLngs().forEach(ll => { bounds.extend(ll); });
          if (l.getLatLngs().length) has = true;
        }
      });
      if (has && bounds.isValid()) {
        fitBoundsSafe(bounds, { padding: [70, 70], maxZoom: 14, animate: true, duration: 1.2 }, true);
        return;
      }
      if (tries < 30) {
        tries += 1;
        placesRouteFocusTimerRef.current = setTimeout(tick, 350);
      }
    };
    tick();
  }, [drawPlacesTraversalRoute, fitBoundsSafe]);


  // Tab-change effect — each tab shows only its own layers
  useEffect(() => {
    const L = window.L, map = lmap.current;
    const currentTrip = trips.find(tr => String(tr.id) === String(tripId));

    if (tab === "places") {
      if (mapError) { setPlacesRouteBusy(false); showDone("Map failed to load"); return; }
      if (!ready || !L || !map) { setPlacesRouteBusy(true); showBusy("Preparing map..."); return; }

      // Clear stale places route from a different trip
      if (placesRouteTripRef.current && placesRouteTripRef.current !== String(tripId)) {
        placesRouteLay.current?.clearLayers();
        placesRouteSigRef.current = "";
        placesRouteDrawnRef.current = false;
        placesRouteTripRef.current = null;
        placesRouteFetchedRef.current = false;
        setPlacesRouteFetched(false);
      }

      // Hide blue route so orange route shows clearly
      routeLay.current?.clearLayers();
      // Also clear amenities — they belong to the Nearby tab
      nearbyLay.current?.clearLayers();

      // Auto-trigger orange places route every time Places tab is opened
      const geoPlaces = places.filter(p => Number.isFinite(p.latitude) && Number.isFinite(p.longitude));
      if (geoPlaces.length > 0) {
        placesRouteFetchedRef.current = true;
        setPlacesRouteFetched(true);
        placesRouteTripRef.current = String(tripId);
        // Only redraw if sig has changed (avoids redundant fetches)
        drawPlacesTraversalRoute();
      }
      return;
    }

    if (tab === "route") {
      // Hide orange places route and amenities
      placesRouteLay.current?.clearLayers();
      placesRouteSigRef.current = "";
      nearbyLay.current?.clearLayers();
      activeCatRef.current = null;
      setActiveCat(null);
      setNearbyItems([]);

      // Restore blue road route
      if (currentTrip?.active_route && routeLay.current?.getLayers().length === 0) {
        try { drawStoredRoutes(JSON.parse(currentTrip.active_route)); } catch {}
      }
      if (L && map) {
        let bounds = null;
        if (routeLay.current && routeLay.current.getLayers().length > 0) {
          bounds = L.latLngBounds();
          routeLay.current.eachLayer(layer => {
            if (layer.getLatLng) bounds.extend(layer.getLatLng());
            else if (layer.getLatLngs) layer.getLatLngs().forEach(ll => bounds.extend(ll));
          });
        } else if (routeCoordsRef.current?.length > 1) {
          bounds = L.latLngBounds(routeCoordsRef.current);
        }
        if (bounds && bounds.isValid()) {
          fitBoundsSafe(bounds, { padding: [70, 70], maxZoom: 14, animate: true, duration: 1.2 }, true);
        }
      }
    }

    if (tab === "nearby") {
      // Hide orange places route; keep blue route visible; clear old amenity markers
      placesRouteLay.current?.clearLayers();
      placesRouteSigRef.current = "";
      nearbyLay.current?.clearLayers();
      activeCatRef.current = null;
      setActiveCat(null);
      setNearbyItems([]);

      if (currentTrip?.active_route && routeLay.current?.getLayers().length === 0) {
        try { drawStoredRoutes(JSON.parse(currentTrip.active_route)); } catch {}
      }
      if (L && map && routeCoordsRef.current?.length > 1) {
        fitBoundsSafe(L.latLngBounds(routeCoordsRef.current), { padding: [70, 70], maxZoom: 14, animate: true, duration: 1.2 }, true);
      }
    }
  }, [tab, ready, mapError, drawPlacesTraversalRoute, trips, tripId, places, drawStoredRoutes, fitBoundsSafe, showBusy, showDone]);

  const planRouteFromLabels = useCallback(async (fromLabel, toLabel, modeOverride = null) => {
    const from = String(fromLabel || "").trim();
    const to = String(toLabel || "").trim();
    if (!from || !to) { setRouteBusy(false); return; }
    setRouteFrom(from);
    setRouteTo(to);
    if (modeOverride && modeOverride !== routeMode) setRouteMode(modeOverride);
    showBusy("Generating route...");
    setRouteBusy(true); setRouteResult(null); setAltRoutes([]); setActiveAlt(0);
    routeLay.current?.clearLayers();
    try {
      const fLL = parseLatLngInput(from);
      const tLL = parseLatLngInput(to);
      const [fr, tr] = await Promise.all([
        fLL ? Promise.resolve([{ lat: String(fLL.lat), lon: String(fLL.lng) }]) : geocode(from),
        tLL ? Promise.resolve([{ lat: String(tLL.lat), lon: String(tLL.lng) }]) : geocode(to),
      ]);
      if (!fr[0] || !tr[0]) { setRouteBusy(false); return; }
      await drawRouteCoordsRef.current(
        parseFloat(fr[0].lat), parseFloat(fr[0].lon),
        parseFloat(tr[0].lat), parseFloat(tr[0].lon),
        from, to,
        modeOverride || routeMode
      );
    } catch (e) { console.error("Route:", e); setRouteBusy(false); }
  }, [routeMode, showBusy]);

  const planRoute = async () => {
    const from = routeFrom.trim(), to = routeTo.trim();
    if (!from || !to) return;
    showBusy("Generating route...");

    // Always generate a fresh route — saved routes are auto-loaded when tabs open
    setRouteBusy(true); setRouteResult(null); setAltRoutes([]); setActiveAlt(0);
    routeLay.current?.clearLayers();
    try {
      const fLL = parseLatLngInput(from);
      const tLL = parseLatLngInput(to);
      const [fr, tr] = await Promise.all([
        fLL ? Promise.resolve([{ lat: String(fLL.lat), lon: String(fLL.lng) }]) : geocode(from),
        tLL ? Promise.resolve([{ lat: String(tLL.lat), lon: String(tLL.lng) }]) : geocode(to),
      ]);
      if (!fr[0] || !tr[0]) { alert("Could not find one or both locations"); setRouteBusy(false); return; }
      await drawRouteCoordsRef.current(
        parseFloat(fr[0].lat), parseFloat(fr[0].lon),
        parseFloat(tr[0].lat), parseFloat(tr[0].lon),
        from, to
      );
    } catch (e) { console.error("Route:", e); alert("Routing failed — check your connection and try again."); setRouteBusy(false); }
  };

  const drawRouteCoords = useCallback(async (fLat, fLng, tLat, tLng, fromLabel, toLabel, modeOverride = null) => {
    const L = window.L, map = lmap.current;
    if (!L || !map) { setRouteBusy(false); return; }
    routeLay.current.clearLayers();

    const mode = modeOverride || routeMode;
    try {
      const modeMapping = { driving: "driving", walking: "foot", cycling: "bike" };
      const osrmMode = modeMapping[mode] || "driving";
      const baseUrl = mode === "driving" ? "https://router.project-osrm.org/route/v1" : "https://routing.openstreetmap.de/routed-" + osrmMode + "/route/v1";
      const res = await fetch(`${baseUrl}/driving/${fLng},${fLat};${tLng},${tLat}?overview=full&geometries=geojson&alternatives=true&steps=true`);
      const data = await res.json();

      if (!data.routes || !data.routes.length) {
        showDone("No route found for this trip");
        finishRouteBusy();
        return;
      }

      const routes = data.routes.map((r, i) => {
        const distKm = +(r.distance / 1000).toFixed(1);
        const durMin = Math.round(r.duration / 60);
        return {
          idx: i,
          dist: distKm,
          dur: durMin,
          coords: r.geometry.coordinates.map(([ln, la]) => [la, ln]),
          label: i === 0 ? "Fastest Route" : `Alternative ${i}`,
          color: i === 0 ? "#34D399" : "#9ca3af",
          steps: r.legs?.[0]?.steps || [],
          isAirway: false,
          routeType: "road",
        };
      });

      renderAltRoutes(routes, 0, fromLabel, toLabel, { fit: true });

      setAltRoutes(routes);
      setRouteResult({ dist: routes[0].dist, dur: routes[0].dur, from: fromLabel, to: toLabel, steps: routes[0].steps });
      setRouteMeta({ fromLabel, toLabel });
      setActiveAlt(0);
      setNavDistToStep(0); setNavCurStep(routes[0].steps?.[0] || null);
      spokenStepRef.current = -1;
      routeCoordsRef.current = routes[0].coords;
      showDone(`Route ready · ${routes[0].dist} km`);
      persistRouteToTrip(routes, 0, fromLabel, toLabel);
      finishRouteBusy();

      if (tripId) {
        try {
          await tripsApi.update(tripId, { preloaded_facilities: null });
          setTrips(prev => prev.map(tr => String(tr.id) === String(tripId) ? { ...tr, preloaded_facilities: null } : tr));
        } catch (e) {}
      }
    } catch (e) {
      console.error("drawRouteCoords error:", e);
      showDone("Error calculating route");
      finishRouteBusy();
    }
  }, [routeMode, t, tripId, renderAltRoutes, fitBoundsSafe, showBusy, showDone, persistRouteToTrip, finishRouteBusy]);
  drawRouteCoordsRef.current = drawRouteCoords;

  const highlightAlt = (idx) => {
    if (!Array.isArray(altRoutes) || !altRoutes.length) return;
    const safeIdx = Math.max(0, Math.min(idx, altRoutes.length - 1));
    setActiveAlt(safeIdx);
    const fromLabel = routeMeta.fromLabel || routeResult?.from || "";
    const toLabel = routeMeta.toLabel || routeResult?.to || "";
    renderAltRoutes(altRoutes, safeIdx, fromLabel, toLabel, { fit: false });
    const selected = altRoutes[safeIdx];
    if (selected) {
      setRouteResult({
        dist: selected.dist,
        dur: selected.dur,
        from: fromLabel,
        to: toLabel,
        steps: selected.steps || [],
      });
      routeCoordsRef.current = selected.coords || [];
      persistRouteToTrip(altRoutes, safeIdx, fromLabel, toLabel);
    }
  };

  const clearRoute = () => {
    routeLay.current?.clearLayers();
    navLay.current?.clearLayers();
    routeCoordsRef.current = [];
    setRouteResult(null); setAltRoutes([]); setActiveAlt(0);
    setRouteMeta({ fromLabel: "", toLabel: "" });
    if (tripId) {
      tripsApi.update(tripId, { active_route: null }).catch(() => {});
      setTrips(prev => prev.map(tr => String(tr.id) === String(tripId) ? { ...tr, active_route: null } : tr));
    }
    stopNav();
  };

  // ── Live navigation ───────────────────────────────────────────────────────
  const startNav = async () => {
    const to = routeTo.trim() || routeResult?.to || routeMeta?.toLabel || "";
    if (!to) { alert("Enter a destination first"); return; }
    showBusy("Starting live navigation...");
    setNavStarting(true);
    navStartingRef.current = true;
    navViewInitializedRef.current = false;
    lastNavUpdateTsRef.current = 0;
    lastNavPosRef.current = null;
    navAwaitingGpsRef.current = false;

    let started = false;
    let previewMode = false;
    try {
      let destLatLng = null;
      if (routeCoordsRef.current?.length) {
        const last = routeCoordsRef.current[routeCoordsRef.current.length - 1];
        if (Array.isArray(last) && last.length >= 2) {
          destLatLng = { lat: last[0], lng: last[1] };
        }
      }
      if (!destLatLng) {
        const res = await geocode(to).catch(() => []);
        if (res[0]) destLatLng = { lat: parseFloat(res[0].lat), lng: parseFloat(res[0].lon) };
      }
      if (!destLatLng) { alert("Destination not found"); return; }
      navDest.current = { lat: destLatLng.lat, lng: destLatLng.lng, label: to };
      if (!routeTo.trim()) setRouteTo(to);

      setLiveNav(true); setTab("route");

    const tryGps = () => new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error("GPS not available"));
      navigator.geolocation.getCurrentPosition(resolve, reject,
        { enableHighAccuracy: true, timeout: 8000, maximumAge: 0 });
    });
    const tryLastKnown = () => new Promise((resolve, reject) => {
      if (!navigator.geolocation) return reject(new Error("GPS not available"));
      navigator.geolocation.getCurrentPosition(resolve, reject,
        { enableHighAccuracy: false, timeout: 1500, maximumAge: 10 * 60 * 1000 });
    });

      let origin = null;
      try {
        const quick = await tryLastKnown();
        const { latitude: la, longitude: ln } = quick.coords;
        origin = { lat: la, lng: ln };
        gpsPos.current = origin;
        if (!gpsOnRef.current) startGPS();
      } catch {}
      try {
        const pos = await tryGps();
        const { latitude: la, longitude: ln } = pos.coords;
        origin = { lat: la, lng: ln };
        gpsPos.current = origin;
        if (!gpsOnRef.current) startGPS();
        if (pos.coords?.accuracy > GPS_GOOD_ACCURACY_M) {
          navAwaitingGpsRef.current = true;
          showBusy("Waiting for accurate GPS...");
        }
      } catch {
        const parsed = parseLatLngText(routeFrom);
        if (parsed) {
          origin = parsed;
          previewMode = true;
        } else if (routeFrom.trim()) {
          const res = await geocode(routeFrom).catch(() => []);
          if (res[0]) {
            origin = { lat: parseFloat(res[0].lat), lng: parseFloat(res[0].lon) };
            previewMode = true;
          }
        }
        if (!origin && lmap.current) {
          const c = lmap.current.getCenter();
          origin = { lat: c.lat, lng: c.lng };
          previewMode = true;
        }
      }

      if (origin) {
        gpsPos.current = origin;
        await updateNavRef.current(origin.lat, origin.lng, navDest.current);
        started = true;
        if (!previewMode && !navAwaitingGpsRef.current) {
          navStartingRef.current = false;
          setNavStarting(false);
          showDone("Navigation started");
        }
      }
    } catch {
      if (!gpsOnRef.current && navigator.geolocation) startGPS();
      else if (gpsPos.current) {
        updateNavRef.current(gpsPos.current.lat, gpsPos.current.lng, navDest.current);
        started = true;
      }
    } finally {
      if (!started) {
        navStartingRef.current = false;
        setNavStarting(false);
        showDone("Waiting for GPS...");
      } else if (previewMode) {
        navStartingRef.current = false;
        setNavStarting(false);
        showDone("Navigation started (preview mode)");
      }
    }
  };

  const lastJourneyFacLat = useRef(null);
  const lastJourneyFacLng = useRef(null);

  const stopNav = () => {
    navDest.current = null;
    navReqSeqRef.current += 1;
    if (navAbortRef.current) {
      navAbortRef.current.abort();
      navAbortRef.current = null;
    }
    lastJourneyFacLat.current = null; lastJourneyFacLng.current = null;
    navAwaitingGpsRef.current = false;
    navLay.current?.clearLayers();
    navRouteLineRef.current = null;
    navUserMarkerRef.current = null;
    navDestMarkerRef.current = null;
    navViewInitializedRef.current = false;
    lastNavUpdateTsRef.current = 0;
    lastNavPosRef.current = null;
    setLiveNav(false); setNavETA(null); setNavStarting(false); navStartingRef.current = false;
    if (gpsOnRef.current) stopGPS();
    if (gpsMark.current) gpsMark.current.setIcon(gpsIcon(false));
  };

  const fetchUpcoming5km = async (lat, lng, coords) => {
    const cat = NEARBY_CATS.find(c => c.key === activeCatRef.current);
    if (!cat || !nearbyLay.current || !window.L) return;

    const ahead5km = [coords[0]];
    let cumDist = 0;
    for (let i = 0; i < coords.length - 1; i++) {
      const d = haversine(coords[i][0], coords[i][1], coords[i+1][0], coords[i+1][1]);
      cumDist += d;
      ahead5km.push(coords[i+1]);
      if (cumDist >= 5000) break;
    }

    let minLat = Infinity, maxLat = -Infinity, minLng = Infinity, maxLng = -Infinity;
    for (const [la, ln] of ahead5km) {
      if (la < minLat) minLat = la; if (la > maxLat) maxLat = la;
      if (ln < minLng) minLng = ln; if (ln > maxLng) maxLng = ln;
    }
    const PAD = 0.025;
    minLat -= PAD; maxLat += PAD; minLng -= PAD; maxLng += PAD;

    const q = `[out:json][timeout:12];(${cat.q}(${minLat},${minLng},${maxLat},${maxLng}););out body 80;`;
    const results = await overpassQuery(q).catch(() => []);
    if (activeCatRef.current !== cat.key) return;

    const L = window.L, map = lmap.current;
    if (!L || !map) return;

    nearbyLay.current.clearLayers();
    const fresh = [];
    const seen = new Set();
    for (const r of results) {
      if (seen.has(r.id)) continue;
      seen.add(r.id);
      const distAhead = haversine(lat, lng, r.lat, r.lng);
      fresh.push({ ...r, dist: distAhead });
      const dl = distAhead < 1000 ? `${Math.round(distAhead)}m` : `${(distAhead/1000).toFixed(1)}km`;
      const popup =
        `<div style="padding:2px;min-width:180px">` +
        `<b style="font-size:13px">${r.name}</b><br>` +
        `<span style="color:${cat.color};font-size:11px">${cat.emoji} ${r.type || cat.label}</span>` +
        `<span style="float:right;font-size:10px;opacity:.7">⬆ ${dl} ahead</span>` +
        (r.addr  ? `<div style="font-size:10px;opacity:.7;margin-top:2px">${r.addr}</div>` : "") +
        (r.hours ? `<div style="font-size:10px;opacity:.7">⏰ ${r.hours}</div>` : "") +
        (r.phone ? `<a href="tel:${r.phone}" style="color:#00D4FF;font-size:11px;display:block;margin-top:2px">📞 ${r.phone}</a>` : "") +
        `</div>`;
      L.marker([r.lat, r.lng], { icon: nearbyDot(cat.color, map.getZoom()) })
        .bindPopup(popup).addTo(nearbyLay.current);
    }
    setNearbyItems([...fresh].sort((a, b) => a.dist - b.dist));
    setTab("nearby");
  };

  const updateNav = useCallback(async (lat, lng, dest) => {
    if (!dest) return;
    const reqSeq = ++navReqSeqRef.current;
    if (navAbortRef.current) navAbortRef.current.abort();
    const ctrl = new AbortController();
    navAbortRef.current = ctrl;
    const tid = setTimeout(() => ctrl.abort(), 9000);
    try {
      const url = routeModeRef.current === "driving"
        ? `https://router.project-osrm.org/route/v1/driving/${lng},${lat};${dest.lng},${dest.lat}?overview=full&geometries=geojson&steps=true`
        : routeModeRef.current === "cycling"
          ? `https://routing.openstreetmap.de/routed-bike/route/v1/driving/${lng},${lat};${dest.lng},${dest.lat}?overview=full&geometries=geojson&steps=true`
          : `https://routing.openstreetmap.de/routed-foot/route/v1/driving/${lng},${lat};${dest.lng},${dest.lat}?overview=full&geometries=geojson&steps=true`;
      const res  = await fetch(url, { signal: ctrl.signal });
      if (reqSeq !== navReqSeqRef.current) return;
      const data = await res.json();
      if (reqSeq !== navReqSeqRef.current) return;

      let coords, distKm, durMin;
      let isFallback = false;
      let targetLat = dest.lat;
      let targetLng = dest.lng;
      let targetLabel = dest.label;

      if (!data.routes?.[0]) {
        coords = [[lat, lng], [targetLat, targetLng]];
        distKm = +(haversine(lat, lng, targetLat, targetLng) / 1000).toFixed(1);
        durMin = Math.round((distKm / 60) * 60);
        isFallback = true;
      } else {
        const route = data.routes[0];
        coords = route.geometry.coordinates.map(([ln2, la2]) => [la2, ln2]);
        distKm = +(route.distance / 1000).toFixed(1);
        durMin = Math.round(route.duration / 60);

        const steps = route.legs?.[0]?.steps || [];
        if (steps.length > 1) {
          const nextStep = steps[1];
          const distToTurn = nextStep.distance || 0;
          setNavCurStep(nextStep);
          setNavDistToStep(distToTurn);

          if (voiceEnabledRef.current && distToTurn > 0 && distToTurn < 250) {
            const stepName = nextStep.name || "the road";
            const modifier = nextStep.maneuver?.modifier || "turn";
            const instruction = `In ${Math.round(distToTurn / 10) * 10} meters, ${modifier.replace("-", " ")} onto ${stepName}`;
            const stepId = `${nextStep.maneuver.location[0]},${nextStep.maneuver.location[1]}`;
            if (spokenStepRef.current !== stepId) {
              spokenStepRef.current = stepId;
              if (window.speechSynthesis) {
                const utterance = new SpeechSynthesisUtterance(instruction);
                utterance.rate = 1.0;
                window.speechSynthesis.speak(utterance);
              }
            }
          }
        } else if (steps.length === 1 && distKm < 0.1) {
          setNavCurStep(steps[0]); setNavDistToStep(0);
          if (voiceEnabledRef.current && spokenStepRef.current !== 'arrived') {
            spokenStepRef.current = 'arrived';
            if (window.speechSynthesis) window.speechSynthesis.speak(new SpeechSynthesisUtterance("You have arrived at your destination."));
          }
        }
      }

      setNavETA({ distKm, durMin });

      const L = window.L, map = lmap.current;
      if (!L || !map) return;
      if (navRouteLineRef.current) {
        navRouteLineRef.current.setLatLngs(coords);
        navRouteLineRef.current.setStyle({ dashArray: isFallback ? "10, 10" : null });
      } else {
        navRouteLineRef.current = L.polyline(coords, { color: "#38BDF8", weight: 6, opacity: 0.9, dashArray: isFallback ? "10, 10" : null }).addTo(navLay.current);
      }

      if (navUserMarkerRef.current) {
        navUserMarkerRef.current.setLatLng([lat, lng]);
      } else {
        navUserMarkerRef.current = L.marker([lat, lng], { icon: gpsIcon(true), zIndexOffset: 700 })
          .bindPopup("📍 You are here")
          .addTo(navLay.current);
      }

      const destLatLng = isFallback ? [targetLat, targetLng] : [dest.lat, dest.lng];
      const destPopup = isFallback ? `<b>To:</b> ${targetLabel}` : `<b>Destination:</b> ${dest.label}`;
      if (navDestMarkerRef.current) {
        navDestMarkerRef.current.setLatLng(destLatLng);
        navDestMarkerRef.current.setPopupContent(destPopup);
      } else {
        navDestMarkerRef.current = L.marker(destLatLng, { icon: pinIcon("#38BDF8", isFallback ? "T" : "Dest"), zIndexOffset: 600 })
          .bindPopup(destPopup)
          .addTo(navLay.current);
      }

      if (!navViewInitializedRef.current) {
        const ahead = coords[Math.min(Math.floor(coords.length * 0.15), coords.length - 1)];
        try { map.fitBounds(L.latLngBounds([[lat, lng], ahead]), { padding: [80, 80], maxZoom: 16, animate: true }); } catch {}
        navViewInitializedRef.current = true;
      }

      const movedKm = lastJourneyFacLat.current != null
        ? haversine(lat, lng, lastJourneyFacLat.current, lastJourneyFacLng.current) / 1000
        : 999;

      if (movedKm >= 1 && activeCatRef.current) {
        lastJourneyFacLat.current = lat;
        lastJourneyFacLng.current = lng;
        fetchUpcoming5km(lat, lng, coords).catch(() => {});
      }
    } catch (e) {
      if (e?.name !== "AbortError") console.error("updateNav:", e);
    } finally {
      clearTimeout(tid);
      if (navAbortRef.current === ctrl) navAbortRef.current = null;
    }
  }, []);
  // Keep ref in sync so watchPosition callback always calls the latest version
  updateNavRef.current = updateNav;

  // ── Location search ───────────────────────────────────────────────────────
  const onMapSearchSelect = useCallback((s) => {
    if (!s?.lat || !s?.lng) return;
    lmap.current?.setView([s.lat, s.lng], 14, { animate: true });
    setLocQuery(s.label.split(",")[0].trim());
    if (activeCat) setTimeout(() => fetchNearby(activeCat), 400);
  }, [activeCat, fetchNearby]);

  // ── Save place ────────────────────────────────────────────────────────────
  const savePlace = async (e) => {
    e.preventDefault(); setPinErr("");
    if (!pinVerified && !pinForm.name.trim()) { 
      setPinErr("Please enter a place name or select from suggestions."); 
      return; 
    }
    setPinSaving(true);
    try {
      await placesApi.create(tripId, {
        ...pinForm,
        latitude:  pinForm.latitude  || parseFloat(clickCoords.lat),
        longitude: pinForm.longitude || parseFloat(clickCoords.lng),
      });
      setShowModal(false);
      setPlaces(await placesApi.list(tripId));
      invalidateCache(`places_${tripId}`);
    } catch (ex) { 
      setPinErr(ex.message); 
    }
    finally { 
      setPinSaving(false); 
    }
  };

  const quickSetPlaceStatus = async (place, status) => {
    if (!tripId || !place?.id) return;
    try {
      await placesApi.update(tripId, place.id, { status });
      setPlaces(await placesApi.list(tripId));
      invalidateCache(`places_${tripId}`);
    } catch {}
  };

  const doOptimizeRoute = async () => {
    if (!tripId) return;
    showBusy("Optimizing places order...");
    setOptimizing(true);
    try {
      const sorted = await placesApi.optimize(tripId);
      setPlaces(sorted);
      showDone("Places optimized");
      alert("Places have been reordered for the optimal driving route!");
    } catch (err) {
      showDone("Could not optimize places");
      alert(err.message || "Failed to optimize route");
    } finally {
      setOptimizing(false);
    }
  };

  const openEditPlace = (place) => {
    setEditingPlaceId(place.id);
    setClickCoords({ lat: String(place.latitude || ""), lng: String(place.longitude || "") });
    setPinForm({
      name: place.name || "",
      place_type: place.place_type || "Attraction",
      visit_time: place.visit_time || "",
      status: place.status || "planned",
      notes: place.notes || "",
      latitude: place.latitude || "",
      longitude: place.longitude || "",
    });
    setPinVerified(true);
    setPinErr("");
    setShowModal(true);
  };

  const saveEditedPlace = async (e) => {
    e.preventDefault();
    if (!editingPlaceId) return savePlace(e);
    setPinSaving(true); setPinErr("");
    try {
      await placesApi.update(tripId, editingPlaceId, {
        ...pinForm,
        latitude: pinForm.latitude ? parseFloat(pinForm.latitude) : null,
        longitude: pinForm.longitude ? parseFloat(pinForm.longitude) : null,
      });
      setShowModal(false);
      setEditingPlaceId(null);
      setPlaces(await placesApi.list(tripId));
      invalidateCache(`places_${tripId}`);
    } catch (ex) {
      setPinErr(ex.message);
    } finally {
      setPinSaving(false);
    }
  };

  const addPlaceToItinerary = async (place) => {
    if (!tripId || !place?.name) return;
    try {
      const days = await itineraryApi.list(tripId);
      const maxDay = days.length ? Math.max(...days.map(d => d.day_number || 0)) : 0;
      await itineraryApi.create(tripId, {
        day_number: maxDay + 1,
        date_label: "",
        title: `Visit ${place.name}`,
        notes: "Added from Live Map",
        place_names: place.name,
      });
      setTab("route");
    } catch {}
  };

  // ── Render ────────────────────────────────────────────────────────────────

  const geo = useMemo(
    () => places.filter(p => p.latitude && p.longitude),
    [places]
  );
  const visitedCount = useMemo(
    () => places.filter(p => p.status === "visited").length,
    [places]
  );
  const currentTrip = useMemo(
    () => trips.find(tr => String(tr.id) === tripId),
    [trips, tripId]
  );
  const cat = useMemo(
    () => NEARBY_CATS.find(c => c.key === activeCat),
    [activeCat]
  );

  const noSignal = gpsOn && gpsLastTs && (Date.now() - gpsLastTs > 15000);
  const poorGpsAccuracy = gpsOn && gpsCoords && Number(gpsCoords.acc) > 120;
  const nightDriveCaution = (() => {
    const h = new Date().getHours();
    return liveNav && routeMode === "driving" && (h >= 22 || h <= 5);
  })();

  useEffect(() => {
    if (!tripId) return;
    try {
      const cache = JSON.parse(localStorage.getItem(MAP_CACHE_KEY) || "{}");
      const payload = {
        tab,
        activeCat,
        nearbyItems: nearbyItems.slice(0, 200),
        routeFrom,
        routeTo,
        routeMode,
        routeResult,
        routeMeta,
        activeAlt,
        storedRoute: altRoutes.length ? {
          fromLabel: routeMeta.fromLabel || routeResult?.from || "",
          toLabel: routeMeta.toLabel || routeResult?.to || "",
          selectedIdx: activeAlt,
          routeMode,
          routes: altRoutes,
        } : null,
        updatedAt: Date.now(),
      };
      cache[String(tripId)] = payload;
      localStorage.setItem(MAP_CACHE_KEY, JSON.stringify(cache));

      if (localStorage.getItem("tm_token")) {
        if (remoteSaveTimerRef.current) clearTimeout(remoteSaveTimerRef.current);
        remoteSaveTimerRef.current = setTimeout(() => {
          settingsApi.put(`${LIVE_MAP_REMOTE_CACHE_PREFIX}${tripId}`, JSON.stringify(payload)).catch(() => {});
        }, 1400);
      }
    } catch {}
    return () => {
      if (remoteSaveTimerRef.current) {
        clearTimeout(remoteSaveTimerRef.current);
        remoteSaveTimerRef.current = null;
      }
    };
  }, [tripId, tab, activeCat, nearbyItems, routeFrom, routeTo, routeMode, routeResult, routeMeta, activeAlt, altRoutes]);

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "calc(100vh - 72px)", gap: 10, overflow: "hidden" }}>
      <style>{`
        @keyframes spin  { to { transform: rotate(360deg); } }
        .lm-spin  { animation: spin .7s linear infinite; display: inline-block; }
        @keyframes fadeIn { from { opacity:0; transform:translateY(4px); } to { opacity:1; transform:none; } }
        .lm-fade  { animation: fadeIn .18s ease; }
        @keyframes pulseGlow { 0%,100% { box-shadow: 0 0 0 0 rgba(59,130,246,.35);} 50% { box-shadow: 0 0 0 8px rgba(59,130,246,0);} }
        .lm-pulse { animation: pulseGlow 1.3s infinite; }
        @keyframes shimmer { 0% { background-position: -200px 0; } 100% { background-position: calc(200px + 100%) 0; } }
        .lm-shimmer {
          background: linear-gradient(90deg, rgba(255,255,255,0.03) 25%, rgba(255,255,255,0.1) 37%, rgba(255,255,255,0.03) 63%);
          background-size: 420px 100%;
          animation: shimmer 1.1s ease-in-out infinite;
        }
        @keyframes slideInRight { from { transform: translateX(100px); opacity: 0; } to { transform: translateX(0); opacity: 1; } }
        @keyframes fadeOut { from { opacity: 1; } to { opacity: 0; transform: translateX(50px); } }
        @media (max-width:700px) {
          .lm-layout { flex-direction:column !important; }
          .lm-map:not(.is-full) { height:52vw !important; min-height:240px !important; }
          .lm-panel  { width:auto !important; max-height:340px !important; }
        }
      `}</style>

      {/* ── Top bar ── */}
      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", flexShrink: 0 }}>
        <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>
          <span style={{ background: `linear-gradient(135deg,${t.accent},${t.cyan})`, WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent", backgroundClip: "text" }}>Live</span>
          {" "}<span style={{ color: t.text }}>Map</span>
        </div>

        {/* Location search */}
        <div style={{ flex: "1 1 220px", minWidth: 0 }}>
          <LocationInput
            value={locQuery}
            onChange={setLocQuery}
            onSelect={onMapSearchSelect}
            placeholder="Search any place..."
            icon="🔎"
            dark={dark}
            zIndex={9000}
            style={{ width: "100%" }}
          />
        </div>

        {/* Tile switcher */}
        <div style={{ display: "flex", gap: 2, background: t.card, border: `1px solid ${t.border}`, borderRadius: 9, overflow: "hidden", flexShrink: 0 }}>
          {Object.entries(TILES).map(([k, v]) => (
            <button key={k} onClick={() => setTile(k)}
              style={{ padding: "6px 9px", fontSize: 11, fontFamily: "inherit", cursor: "pointer", border: "none", transition: "all .15s", whiteSpace: "nowrap",
                background: tile === k ? t.accent + "22" : "transparent",
                color: tile === k ? t.accent : t.textDim,
                fontWeight: tile === k ? 700 : 400 }}>
              {v.label}
            </button>
          ))}
          <button onClick={() => { setIsFullMap(!isFullMap); setTimeout(() => lmap.current?.invalidateSize(), 150); }}
            style={{ padding: "6px 9px", fontSize: 11, fontFamily: "inherit", cursor: "pointer", border: "none", transition: "all .15s", whiteSpace: "nowrap", background: isFullMap ? t.accent + "22" : "transparent", color: isFullMap ? t.accent : t.textDim, fontWeight: 700 }}>
            {isFullMap ? "📉 Exit Full Map" : "📈 Full Map"}
          </button>
        </div>

        {/* Trip selector */}
        <select value={tripId} onChange={e => setTripId(e.target.value)}
          style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 9, padding: "7px 10px", color: t.text, fontSize: 12, fontFamily: "inherit", outline: "none", flexShrink: 0, maxWidth: 175 }}>
          <option value="">No trip</option>
          {trips.map(tr => <option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name}</option>)}
        </select>

      </div>
      {/* Activity Popup */}
      {activity.type !== "idle" && (
        <div className="lm-fade" style={{ 
          position: "fixed", 
          top: "20px", 
          right: "20px", 
          zIndex: 10000,
          background: activity.type === "busy" ? "rgba(30,41,59,0.95)" : "rgba(6,78,59,0.95)", 
          border: `1px solid ${activity.type === "busy" ? "#3B82F655" : "#34D39966"}`, 
          borderRadius: 12, 
          padding: "12px 16px", 
          fontSize: 12, 
          color: activity.type === "busy" ? "#BFDBFE" : "#A7F3D0", 
          boxShadow: "0 8px 32px rgba(0,0,0,0.3), 0 0 0 1px rgba(255,255,255,0.1) inset",
          backdropFilter: "blur(12px)",
          animation: activity.type === "busy"
            ? "slideInRight 0.3s ease-out"
            : "slideInRight 0.3s ease-out, fadeOut 0.3s ease-out 2.5s forwards",
          maxWidth: "300px"
        }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            {activity.type === "busy" ? (
              <span className="lm-spin lm-pulse" style={{ width: 12, height: 12, border: "2px solid #3B82F644", borderTopColor: "#60A5FA", borderRadius: "50%" }} />
            ) : (
              <span style={{ fontSize: 14 }}>✅</span>
            )}
            <span style={{ fontWeight: 700, letterSpacing: ".02em" }}>{activity.text}</span>
          </div>
        </div>
      )}

      {/* Navigation GPS lock popup */}
      {navStarting && (
        <div className="lm-fade" style={{
          position: "fixed",
          inset: 0,
          zIndex: 10001,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          pointerEvents: "none",
          background: "transparent",
        }}>
          <div style={{
            background: "rgba(15,23,42,0.92)",
            border: "1px solid rgba(59,130,246,0.45)",
            borderRadius: 14,
            padding: "14px 18px",
            color: "#BFDBFE",
            fontSize: 12,
            fontWeight: 700,
            letterSpacing: ".02em",
            display: "flex",
            alignItems: "center",
            gap: 10,
            boxShadow: "0 10px 36px rgba(0,0,0,0.35)",
          }}>
            <span className="lm-spin" style={{ width: 14, height: 14, border: "2px solid rgba(59,130,246,0.35)", borderTopColor: "#60A5FA", borderRadius: "50%" }} />
            Locating GPS and locking heading...
          </div>
        </div>
      )}
      <style>{`
        .lm-map.is-full { position: fixed !important; top: 0 !important; left: 0 !important; width: 100vw !important; height: 100dvh !important; max-height: none !important; z-index: 99999 !important; border-radius: 0 !important; }
        @keyframes tmSpin { to { transform: rotate(360deg); } }
        .lm-spin { animation: tmSpin 0.8s linear infinite; }
        .lm-pulse { animation: tmPulse 1.2s ease-in-out infinite; }
        @keyframes tmPulse { 0%,100% { opacity: .6; } 50% { opacity: 1; } }
        .tm-places-preview { opacity: 0.55; }
      `}</style>

      {/* ── GPS live bar ── */}
      {gpsCoords && (
        <div className="lm-fade" style={{ display: "flex", alignItems: "center", gap: 10, background: liveNav ? "#041A10" : t.card, border: `1px solid ${liveNav ? "#34D39955" : t.border}`, borderRadius: 9, padding: "6px 14px", flexShrink: 0, flexWrap: "wrap", zIndex: 10 }}>
          <div style={{ width: 8, height: 8, borderRadius: "50%", background: liveNav ? "#34D399" : "#38BDF8", boxShadow: `0 0 0 4px ${liveNav ? "#34D39930" : "#38BDF830"}`, flexShrink: 0 }} />
          <span style={{ fontSize: 10, fontWeight: 700, color: liveNav ? "#34D399" : "#38BDF8" }}>{liveNav ? "NAVIGATING" : "LIVE GPS"}</span>
          <span style={{ fontSize: 10, color: t.textDim }}>{gpsCoords.lat}, {gpsCoords.lng} · ±{gpsCoords.acc}m</span>
          {gpsHeading != null && (
            <span style={{ fontSize: 10, color: "#67E8F9", fontWeight: 700 }}>
              Heading {gpsHeading}°
            </span>
          )}

          {liveNav && (
            <button onClick={() => setVoiceEnabled(!voiceEnabled)} style={{ padding: "4px 10px", borderRadius: 99, fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", background: voiceEnabled ? "rgba(52,211,153,0.15)" : t.surface, color: voiceEnabled ? "#34D399" : t.textDim, border: `1px solid ${voiceEnabled ? "#34D39966" : t.border}` }}>
              {voiceEnabled ? "🔊 Voice On" : "🔇 Voice Off"}
            </button>
          )}

          {liveNav && navETA && (
            <>
              <div style={{ width: 1, height: 14, background: t.border }} />
              <span style={{ fontSize: 13, fontWeight: 800, color: "#CEE5FF" }}>{navETA.distKm} km</span>
              <span style={{ fontSize: 10, color: t.textDim }}>|</span>
              <span style={{ fontSize: 13, fontWeight: 800, color: "#CEE5FF" }}>
                {navETA.durMin < 60 ? `${navETA.durMin}m` : `${Math.floor(navETA.durMin / 60)}h ${navETA.durMin % 60}m`}
              </span>
              <span style={{ fontSize: 9, color: "#4D7DAE" }}>→ {navDest.current?.label}</span>
              {navCurStep && (
                <span style={{ fontSize: 9, color: "#93C5FD" }}>
                  Next: {(navCurStep.maneuver?.modifier || "continue").replace("-", " ")}
                </span>
              )}
              <button onClick={stopNav} style={{ marginLeft: "auto", padding: "3px 12px", borderRadius: 99, fontSize: 10, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", background: "#F43F5E", color: "#fff", border: "none" }}>
                End
              </button>
            </>
          )}
          {noSignal && (
            <span style={{ fontSize: 10, fontWeight: 700, color: "#F43F5E", background: "#F43F5E22", border: "1px solid #F43F5E55", borderRadius: 99, padding: "2px 8px" }}>
              No GPS signal
            </span>
          )}
          {poorGpsAccuracy && (
            <span style={{ fontSize: 10, fontWeight: 700, color: "#F59E0B", background: "#F59E0B22", border: "1px solid #F59E0B55", borderRadius: 99, padding: "2px 8px" }}>
              Low GPS accuracy
            </span>
          )}
          {nightDriveCaution && (
            <span style={{ fontSize: 10, fontWeight: 700, color: "#FBBF24", background: "#FBBF2422", border: "1px solid #FBBF2455", borderRadius: 99, padding: "2px 8px" }}>
              Night drive caution
            </span>
          )}
        </div>
      )}

      {/* ── Turn-by-Turn Overlay Banner ── */}
      {liveNav && navCurStep && (
        <div className="lm-fade" style={{ position: "absolute", top: 110, left: "50%", transform: "translateX(-50%)", background: "rgba(4,26,16,0.95)", backdropFilter: "blur(12px)", border: "1px solid #34D39944", borderRadius: 16, padding: "14px 20px", zIndex: 99999, display: "flex", gap: 16, alignItems: "center", boxShadow: "0 12px 40px rgba(0,0,0,0.5), 0 0 0 1px rgba(52,211,153,0.1) inset", minWidth: 280 }}>
          <div style={{ fontSize: 32, paddingRight: 16, borderRight: "1px solid rgba(255,255,255,0.15)", color: "#34D399", filter: "drop-shadow(0 2px 8px rgba(52,211,153,0.4))", lineHeight: 1 }}>
            {navCurStep.maneuver?.type === "arrive" ? "🏁" : navCurStep.maneuver?.modifier === "left" || navCurStep.maneuver?.modifier === "slight left" ? "↖" : navCurStep.maneuver?.modifier === "right" || navCurStep.maneuver?.modifier === "slight right" ? "↗" : navCurStep.maneuver?.modifier === "uturn" ? "↩" : "⬆"}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
            <div style={{ fontSize: 24, fontWeight: 900, color: "#fff", fontFamily: "'Space Mono', monospace", letterSpacing: "-0.5px" }}>
              {Math.round(navDistToStep)}<span style={{ fontSize: 14, color: "#A7F3D0", marginLeft: 3, fontWeight: 600 }}>m</span>
            </div>
            <div style={{ fontSize: 13, color: "#6EE7B7", fontWeight: 700, lineHeight: 1.2 }}>
              {navCurStep.maneuver.type === "arrive" ? "Destination ahead" : `${(navCurStep.maneuver.modifier || "Continue").replace("-", " ")} onto ${navCurStep.name || "the road"}`}
            </div>
          </div>
        </div>
      )}

      {/* ── Map + sidebar ── */}
      <div className="lm-layout" style={{ display: "flex", gap: 10, flex: 1, minHeight: 0, position: "relative" }}>

        {/* Route-busy pill — rendered here (outside map overflow:hidden) so it is never clipped */}
        {(routeBusy || placesRouteBusy) && (
          <div className="lm-fade" style={{ position: "absolute", bottom: 64, left: "50%", transform: "translateX(-50%)", zIndex: 9999, pointerEvents: "none", display: "flex", alignItems: "center", gap: 10, padding: "9px 18px", borderRadius: 99, border: `1px solid ${t.accent}55`, background: "rgba(6,11,22,0.92)", color: t.text, boxShadow: "0 4px 24px rgba(0,0,0,0.5)", backdropFilter: "blur(12px)", whiteSpace: "nowrap" }}>
            <span className="lm-spin" style={{ width: 12, height: 12, border: `2px solid ${t.accent}44`, borderTopColor: t.accent, borderRadius: "50%", flexShrink: 0 }} />
            <span style={{ fontSize: 12, fontWeight: 700, color: t.accent }}>
              {placesRouteBusy ? "Drawing places route…" : "Plotting route…"}
            </span>
            <span style={{ fontSize: 10, color: t.textDim }}>Map still interactive</span>
          </div>
        )}

        {/* MAP */}
        <div className={`lm-map ${isFullMap ? "is-full" : ""}`} style={isFullMap ? { position: "fixed", top: 0, left: 0, width: "100vw", height: "100dvh", zIndex: 9999, background: t.card, borderRadius: 0, border: "none" } : { flex: 1, borderRadius: 14, overflow: "hidden", border: `1px solid ${t.border}`, position: "relative", minWidth: 0 }}>
          {tab === "places" && placesRouteError && (
            <div style={{ position: "absolute", top: 12, right: 12, zIndex: 40, background: "rgba(18, 7, 7, 0.92)", color: "#FCA5A5", border: "1px solid rgba(239,68,68,0.5)", borderRadius: 10, padding: "8px 10px", display: "flex", alignItems: "center", gap: 8, boxShadow: "0 8px 24px rgba(0,0,0,0.4)" }}>
              <div style={{ fontSize: 12, fontWeight: 700 }}>Places route failed</div>
              <div style={{ fontSize: 11, color: "#FECACA" }}>{placesRouteError}</div>
              <button
                onClick={() => {
                  placesRouteFetchedRef.current = true;
                  setPlacesRouteFetched(true);
                  placesRouteTripRef.current = String(tripId);
                  placesRouteSigRef.current = "";
                  drawPlacesTraversalRoute();
                }}
                style={{ marginLeft: 6, padding: "6px 10px", borderRadius: 8, border: "1px solid rgba(239,68,68,0.6)", background: "rgba(239,68,68,0.15)", color: "#FEE2E2", fontSize: 11, fontWeight: 700, cursor: "pointer" }}
              >
                Retry
              </button>
            </div>
          )}
          {mapError && (
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: t.card, zIndex: 30 }}>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 10, textAlign: "center", maxWidth: 320 }}>
                <div style={{ fontSize: 44 }}>🗺️</div>
                <div style={{ fontWeight: 800, fontSize: 15, color: t.text }}>Map failed to load</div>
                <div style={{ fontSize: 12, color: t.textDim }}>Check your internet connection and reload.</div>
                <button onClick={() => window.location.reload()}
                  style={{ padding: "8px 20px", borderRadius: 10, background: t.accent, color: "#fff", border: "none", cursor: "pointer", fontWeight: 700, fontSize: 12 }}>
                  Reload
                </button>
              </div>
            </div>
          )}
          {!mapError && !ready && (
            <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center", background: t.card, zIndex: 10 }}>
              <Spinner />
            </div>
          )}
          {(routeBusy || placesRouteBusy) && null /* moved outside map div below */}
          {isFullMap && (
            <button onClick={() => { setIsFullMap(false); setTimeout(() => lmap.current?.invalidateSize(), 150); }}
              style={{ position: "absolute", top: 12, right: 12, zIndex: 9999, background: t.red, color: "#fff", border: "none", borderRadius: 8, padding: "8px 14px", fontSize: 13, fontWeight: 700, cursor: "pointer", boxShadow: "0 4px 12px rgba(0,0,0,0.4)" }}>
              ❌ Exit Full Map
            </button>
          )}
          <div ref={mapRef} style={{ height: "100%", width: "100%" }} />

          {/* Map stats top-left */}
          <div style={{ position: "absolute", top: 10, left: 10, background: "rgba(4,13,28,.88)", borderRadius: 8, padding: "4px 10px", fontSize: 10, color: t.textDim, zIndex: 500, backdropFilter: "blur(10px)", border: `1px solid ${t.border}` }}>
            {geo.length} pinned · {visitedCount} visited
            {nearbyItems.length > 0 ? ` · ${nearbyItems.length} nearby` : ""}
          </div>

          {/* ── Floating Navigate Button ── */}
          {!liveNav && (
            <div style={{ position: "absolute", bottom: 54, right: 14, zIndex: 600, display: "flex", flexDirection: "column", gap: 8 }}>
              {/* Google Maps open button */}
              {gpsCoords && (
                <button
                  title="Open in Google Maps"
                  onClick={() => {
                    const dest = routeTo.trim() || routeResult?.to || routeMeta?.toLabel || currentTrip?.destination || "";
                    const from = `${gpsCoords.lat},${gpsCoords.lng}`;
                    if (dest) {
                      window.open(`https://www.google.com/maps/dir/${encodeURIComponent(from)}/${encodeURIComponent(dest)}`, "_blank");
                    } else {
                      window.open(`https://www.google.com/maps/@${gpsCoords.lat},${gpsCoords.lng},15z`, "_blank");
                    }
                  }}
                  style={{
                    width: 44, height: 44, borderRadius: "50%", border: "2px solid rgba(66,133,244,0.6)",
                    background: "rgba(15,23,42,0.92)", color: "#fff", fontSize: 20, cursor: "pointer",
                    display: "flex", alignItems: "center", justifyContent: "center",
                    boxShadow: "0 4px 16px rgba(0,0,0,0.45)", backdropFilter: "blur(10px)",
                    transition: "all .2s",
                  }}
                  onMouseEnter={e => { e.currentTarget.style.transform = "scale(1.12)"; e.currentTarget.style.borderColor = "rgba(66,133,244,0.9)"; }}
                  onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.borderColor = "rgba(66,133,244,0.6)"; }}
                >
                  🗺️
                </button>
              )}
              {/* Live Navigate button */}
              <button
                title={canStartNav ? "Start Live Navigation" : "Set a destination in Route tab first"}
                onClick={() => { if (canStartNav) { startNav(); setTab("route"); } else { setTab("route"); } }}
                style={{
                  width: 54, height: 54, borderRadius: "50%",
                  background: canStartNav
                    ? "linear-gradient(135deg,#F59E0B,#D97706)"
                    : "rgba(15,23,42,0.7)",
                  border: `2px solid ${canStartNav ? "rgba(245,158,11,0.8)" : "rgba(255,255,255,0.15)"}`,
                  color: canStartNav ? "#fff" : "rgba(255,255,255,0.35)",
                  fontSize: 22, cursor: canStartNav ? "pointer" : "default",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  boxShadow: canStartNav ? "0 6px 24px rgba(245,158,11,0.45)" : "0 4px 12px rgba(0,0,0,0.3)",
                  backdropFilter: "blur(10px)",
                  transition: "all .2s",
                }}
                onMouseEnter={e => { if (canStartNav) { e.currentTarget.style.transform = "scale(1.1)"; } }}
                onMouseLeave={e => { e.currentTarget.style.transform = ""; }}
              >
                🧭
              </button>
              {!canStartNav && (
                <div style={{
                  position: "absolute", right: 60, bottom: 4,
                  background: "rgba(15,23,42,0.92)", color: t.textDim, fontSize: 9, fontWeight: 700,
                  borderRadius: 6, padding: "3px 7px", whiteSpace: "nowrap", pointerEvents: "none",
                  border: `1px solid ${t.border}`, backdropFilter: "blur(8px)",
                }}>
                  Set destination first
                </div>
              )}
            </div>
          )}
          {liveNav && (
            <div style={{ position: "absolute", bottom: 54, right: 14, zIndex: 600 }}>
              <button
                title="End Navigation"
                onClick={stopNav}
                style={{
                  width: 54, height: 54, borderRadius: "50%",
                  background: "linear-gradient(135deg,#F43F5E,#BE123C)",
                  border: "2px solid rgba(244,63,94,0.7)",
                  color: "#fff", fontSize: 18, cursor: "pointer",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  boxShadow: "0 6px 24px rgba(244,63,94,0.45)",
                  backdropFilter: "blur(10px)",
                }}
              >
                ✖
              </button>
            </div>
          )}

        </div>
        {/* SIDEBAR */}
        <div className="lm-panel" style={{ width: 286, display: "flex", flexDirection: "column", background: t.card, border: `1px solid ${t.border}`, borderRadius: 14, overflow: "hidden", flexShrink: 0 }}>

          {/* Tab bar with trip context */}
          <div style={{ display: "flex", flexDirection: "column", borderBottom: `1px solid ${t.border}`, flexShrink: 0 }}>
            {/* Trip info header */}
            {currentTrip ? (
              <div style={{ padding: "8px 12px", background: t.surface, borderBottom: `1px solid ${t.border}` }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: t.text, display: "flex", alignItems: "center", gap: 6 }}>
                  <span>{currentTrip.cover_emoji || "🌍"}</span>
                  <span>{currentTrip.name}</span>
                </div>
                <div style={{ fontSize: 10, color: t.textDim, marginTop: 2 }}>
                  {places.length} places · {visitedCount} visited
                  {currentTrip.destination && ` · ${currentTrip.destination}`}
                </div>
              </div>
            ) : (
              <div style={{ padding: "8px 12px", background: t.surface, borderBottom: `1px solid ${t.border}` }}>
                <div style={{ fontSize: 11, color: t.textDim }}>No trip selected</div>
              </div>
            )}

            {/* Tab buttons */}
            <div style={{ display: "flex" }}>
            {[
              { id: "nearby", label: "Nearby",  icon: "📍", subtitle: nearbyItems.length > 0 ? `${nearbyItems.length} found` : "Pick amenity" },
              { id: "route",  label: "Route",   icon: "🗺️", subtitle: routeResult ? `${routeResult.dist} km` : "Plan route" },
              { id: "places", label: "Places",  icon: "📌", subtitle: `${places.length} pinned` },
            ].map(tb => (
              <button key={tb.id} onClick={() => setTab(tb.id)}
                style={{ flex: 1, padding: "8px 4px", fontSize: 10, fontWeight: tab === tb.id ? 800 : 400, cursor: "pointer", border: "none", fontFamily: "inherit", transition: "all .15s",
                  background: "transparent", color: tab === tb.id ? t.accent : t.textDim,
                  borderBottom: tab === tb.id ? `2px solid ${t.accent}` : "2px solid transparent" }}>
                <div>{tb.icon}</div>
                <div style={{ fontSize: 9, fontWeight: 600 }}>{tb.label}</div>
                <div style={{ fontSize: 8, opacity: 0.7 }}>{tb.subtitle}</div>
              </button>
            ))}
            </div>
          </div>

          {/* Tab content */}
          <div style={{ flex: 1, overflowY: "auto", padding: 12 }}>

            {/* ── NEARBY TAB ── */}
            {tab === "nearby" && (
              <div className="lm-fade">
                {currentTrip && (
                  <div style={{ marginBottom: 10, background: t.surface, border: `1px solid ${t.border}`, borderRadius: 10, padding: "8px 9px" }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: t.text, marginBottom: 4 }}>🔍 Search Near {currentTrip.destination || "Trip"}</div>
                    <div style={{ fontSize: 10, color: t.textDim }}>
                      {gpsCoords ? "📍 Current location" : "📍 Set location to search nearby"}
                      {routeResult && " · 🗺️ Along route"}
                    </div>
                  </div>
                )}

                {/* Filters */}
                <div style={{ display: "flex", gap: 10, padding: "0 8px 10px", margin: "0 4px", borderBottom: `1px solid ${t.border}`, flexWrap: "wrap" }}>
                  <label style={{ fontSize: 11, display: "flex", alignItems: "center", gap: 5, color: t.textDim, cursor: "pointer" }}>
                    <input type="checkbox" checked={nearbyFilters.openNow} onChange={e => setNearbyFilters(f => ({ ...f, openNow: e.target.checked }))} /> Open Now
                  </label>
                  <label style={{ fontSize: 11, display: "flex", alignItems: "center", gap: 5, color: t.textDim, cursor: "pointer" }}>
                    <input type="checkbox" checked={nearbyFilters.budget} onChange={e => setNearbyFilters(f => ({ ...f, budget: e.target.checked }))} /> Budget Friendly
                  </label>
                </div>

                <div style={{ display: "flex", gap: 6, flexWrap: "wrap", margin: "10px 0 12px" }}>
                  {NEARBY_CATS.map(c => {
                    const isActive = activeCat === c.key;
                    const isBusy = nearbyBusy && activeCat === c.key;
                    return (
                      <button
                        key={c.key}
                        onClick={() => {
                          const coords = routeCoordsRef.current;
                          if (!coords || coords.length < 2) {
                            showDone("Generate a route first to find amenities along it");
                            return;
                          }
                          fetchAlongRouteOptimized(c.key, altRoutes?.[0]?.coords || coords);
                        }}
                        style={{
                          padding: "5px 10px",
                          borderRadius: 99,
                          fontSize: 11,
                          fontWeight: 700,
                          cursor: "pointer",
                          fontFamily: "inherit",
                          border: `1px solid ${isActive ? c.color + "88" : t.border}`,
                          background: isActive ? c.color + "22" : t.surface,
                          color: isActive ? c.color : t.textDim,
                          whiteSpace: "nowrap",
                        }}
                      >
                        {isBusy ? <span className="lm-spin" style={{ width: 8, height: 8, border: `2px solid ${c.color}44`, borderTopColor: c.color, borderRadius: "50%", marginRight: 5 }} /> : null}
                        {c.emoji} {c.label}
                      </button>
                    );
                  })}
                  {activeCat && (
                    <button onClick={clearNearby} style={{ padding: "5px 10px", borderRadius: 99, fontSize: 11, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", border: "1px solid #F43F5E55", background: "#F43F5E22", color: "#F43F5E" }}>
                      Clear
                    </button>
                  )}
                </div>

                {!activeCat && !nearbyBusy && (
                  <div style={{ textAlign: "center", padding: "28px 12px" }}>
                    <div style={{ fontSize: 30, marginBottom: 8 }}>📍</div>
                    <div style={{ fontSize: 11, color: t.textDim, lineHeight: 1.7 }}>
                      {routeCoordsRef.current.length > 1
                        ? "Pick an amenity category above to show it along the route."
                        : <><strong style={{ color: t.accent }}>Generate a route first</strong> (Route tab), then pick an amenity to see stops along the way.</>}
                    </div>
                  </div>
                )}
                {activeCat && !nearbyBusy && nearbyItems.length === 0 && (
                  <div style={{ textAlign: "center", padding: 24 }}>
                    <div style={{ fontSize: 26, marginBottom: 6 }}>🔍</div>
                    <div style={{ fontSize: 11, color: t.textDim }}>No {cat?.label} within 5 km. Pan the map and try again.</div>
                  </div>
                )}
                {nearbyItems.length > 0 && (
                  <>
                    <SectionHeader t={t} icon={cat?.emoji}
                      label={routeCoordsRef.current.length > 1 ? `${cat?.label} along route` : `${cat?.label} nearby`}
                      count={nearbyItems.length} color={cat?.color}
                      action={<button onClick={clearNearby} style={{ fontSize: 9, padding: "2px 8px", borderRadius: 99, background: "#F43F5E15", color: "#FF4E6A", border: "1px solid #F43F5E33", cursor: "pointer", fontFamily: "inherit" }}>Clear</button>} />
                    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
                      {nearbyItems
                        .filter(item => {
                          if (nearbyFilters.budget && !["fast_food", "hostel", "guest_house", "motel", "bus_stop"].includes(item.type)) return false;
                          if (nearbyFilters.openNow && !item.hours) return false;
                          return true;
                        })
                        .map((item, i) => (
                        <div key={item.id}
                          onClick={() => { setActiveItem(item.id); lmap.current?.setView([item.lat, item.lng], 17, { animate: true }); }}
                          style={{ background: activeItem === item.id ? t.accentSoft : t.surface, border: `1px solid ${activeItem === item.id ? t.accent + "44" : "transparent"}`, borderRadius: 9, padding: "8px 10px", cursor: "pointer", transition: "all .13s" }}
                          onMouseEnter={e => e.currentTarget.style.background = t.cardHover}
                          onMouseLeave={e => e.currentTarget.style.background = activeItem === item.id ? t.accentSoft : t.surface}>
                          <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                            <span style={{ fontSize: 10, color: item.catColor || cat?.color, fontWeight: 800, minWidth: 16, marginTop: 1 }}>{i + 1}</span>
                            <div style={{ flex: 1, minWidth: 0 }}>
                              <div style={{ fontSize: 11, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: t.text }}>{item.name}</div>
                              <div style={{ display: "flex", justifyContent: "space-between", marginTop: 1 }}>
                                <span style={{ fontSize: 9, color: t.textDim, textTransform: "capitalize" }}>{item.catEmoji || ""} {item.type || item.catLabel || cat?.label}</span>
                                <span style={{ fontSize: 9, color: item.catColor || cat?.color, fontWeight: 600 }}>
                                  {item.dist < 1000 ? `${Math.round(item.dist)}m` : `${(item.dist / 1000).toFixed(1)}km`}
                                  {routeCoordsRef.current.length > 1 && <span style={{ color: t.textDim, fontWeight: 400 }}> from start</span>}
                                </span>
                              </div>
                              {item.phone && <div style={{ fontSize: 9, color: "#00D4FF", marginTop: 1 }}>📞 {item.phone}</div>}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            )}

            {/* ── ROUTE TAB ── */}
            {tab === "route" && (
              <div className="lm-fade" style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                {currentTrip && (
                  <div style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: 10, padding: "8px 9px" }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: t.text, marginBottom: 4 }}>🗺️ Route for {currentTrip.name}</div>
                    <div style={{ fontSize: 10, color: t.textDim }}>
                      {currentTrip.start_location && `From: ${currentTrip.start_location}`}
                      {currentTrip.destination && ` · To: ${currentTrip.destination}`}
                      {places.length > 0 && ` · ${places.length} stops`}
                    </div>
                  </div>
                )}

                <SectionHeader t={t} icon="🧭" label="Route Planner" color={t.accent} />

                {/* Vertical route inputs with timeline visual */}
                <div style={{ position: "relative", display: "flex", flexDirection: "column", gap: 8, background: dark ? "rgba(0,0,0,0.2)" : "rgba(0,0,0,0.02)", padding: 12, borderRadius: 12, border: `1px solid ${t.border}` }}>
                  <div style={{ position: "absolute", top: 32, bottom: 32, left: 24, width: 2, background: t.border, zIndex: 0 }} />
                  <div style={{ position: "absolute", top: 28, left: 21, width: 8, height: 8, borderRadius: "50%", background: "#38BDF8", border: "2px solid #080510", zIndex: 1 }} />
                  <div style={{ position: "absolute", bottom: 28, left: 21, width: 8, height: 8, borderRadius: "50%", background: "#34D399", border: "2px solid #080510", zIndex: 1 }} />

                  <LocationInput
                    value={routeFrom}
                    onChange={setRouteFrom}
                    onSelect={s => setRouteFrom((s?.label || "").trim())}
                    placeholder="Origin Hub"
                    icon=" "
                    dark={dark}
                    zIndex={7000}
                    style={{ background: "transparent", border: "none", paddingLeft: 40 }}
                  />
                  <div style={{ pointerEvents: "none", userSelect: "none", opacity: 0 }}>__SPACE__</div>
                  <LocationInput
                    value={routeTo}
                    onChange={setRouteTo}
                    onSelect={s => setRouteTo((s?.label || "").trim())}
                    placeholder="Final Destination"
                    icon=" "
                    dark={dark}
                    zIndex={6999}
                    style={{ background: "transparent", border: "none", paddingLeft: 40 }}
                  />

                  {gpsCoords && (
                    <button onClick={() => setRouteFrom(`${gpsCoords.lat},${gpsCoords.lng}`)}
                      style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", padding: "6px 8px", borderRadius: 8, fontSize: 13, cursor: "pointer", background: "rgba(56,189,248,0.15)", color: "#38BDF8", border: "1px solid rgba(56,189,248,0.3)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 7000 }}
                      title="Use live GPS location">
                      📍
                    </button>
                  )}
                </div>

                {/* Primary Action Button */}
                <button onClick={planRoute} disabled={routeBusy || !routeFrom.trim() || !routeTo.trim()}
                  style={{ padding: "12px", borderRadius: 10, fontSize: 13, fontWeight: 700, cursor: routeBusy || !routeFrom.trim() || !routeTo.trim() ? "not-allowed" : "pointer", border: "none", fontFamily: "inherit", transition: "all .2s",
                    background: (routeBusy || !routeFrom.trim() || !routeTo.trim()) ? "rgba(255,255,255,0.05)" : `linear-gradient(135deg,${t.accent},${t.accentDeep})`,
                    color: (routeBusy || !routeFrom.trim() || !routeTo.trim()) ? "rgba(255,255,255,0.3)" : "#fff",
                    boxShadow: (routeBusy || !routeFrom.trim() || !routeTo.trim()) ? "none" : `0 4px 16px ${t.accent}40` }}>
                  {routeBusy
                    ? <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                        <span className="lm-spin" style={{ width: 14, height: 14, border: `2px solid ${t.accent}44`, borderTopColor: "#fff", borderRadius: "50%" }} /> Tracing Routes…
                      </span>
                    : "Generate Route"}
                </button>

                {/* Navigation Status / Actions */}
                <div style={{ display: "flex", gap: 8 }}>
                  {!liveNav
                    ? <button onClick={startNav} disabled={!canStartNav || navStarting}
                        style={{ flex: 1, padding: "10px", borderRadius: 10, fontSize: 12, fontWeight: 700, cursor: (canStartNav && !navStarting) ? "pointer" : "not-allowed", border: `1px solid ${(canStartNav && !navStarting) ? "#F59E0B" : "rgba(255,255,255,0.1)"}`, fontFamily: "inherit", whiteSpace: "nowrap", transition: "all .2s",
                          background: (canStartNav && !navStarting) ? "rgba(245,158,11,0.1)" : "transparent", color: (canStartNav && !navStarting) ? "#FCD34D" : "rgba(255,255,255,0.3)", display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
                        {navStarting ? (
                          <>
                            <span className="lm-spin" style={{ width: 12, height: 12, border: "2px solid rgba(245,158,11,0.3)", borderTopColor: "#FCD34D", borderRadius: "50%" }} />
                            Starting Navigation...
                          </>
                        ) : (
                          <>🧭 Live Navigate</>
                        )}
                      </button>
                    : <button onClick={stopNav}
                        style={{ flex: 1, padding: "10px", borderRadius: 10, fontSize: 12, fontWeight: 700, cursor: "pointer", border: "none", fontFamily: "inherit", whiteSpace: "nowrap", background: "#F43F5E", color: "#fff", boxShadow: "0 4px 16px rgba(244,63,94,0.3)" }}>
                        ✖ End Navigation
                      </button>
                  }
                  {routeResult && <button onClick={clearRoute} style={{ flex: 0.3, fontSize: 12, fontWeight: 600, color: t.textDim, background: "rgba(255,255,255,0.05)", border: `1px solid ${t.border}`, cursor: "pointer", borderRadius: 10 }}>Reset</button>}
                </div>

                {/* Route insights premium card with Cost Estimation */}
                {routeResult && (
                  <div className="lm-fade" style={{ background: `linear-gradient(145deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01))`, border: `1px solid ${routeResult.isAirway ? (routeResult.routeType === "air" ? "rgba(129,140,248,0.35)" : "rgba(6,182,212,0.35)") : "rgba(255,255,255,0.06)"}`, borderRadius: 12, padding: "14px 16px", boxShadow: "0 8px 32px rgba(0,0,0,0.2)", position: "relative", overflow: "hidden" }}>
                    <div style={{ position: "absolute", top: -20, right: -20, width: 80, height: 80, background: `radial-gradient(circle, ${routeResult.isAirway ? (routeResult.routeType === "air" ? "#818CF8" : "#06B6D4") : t.accent}20, transparent 70%)` }} />
                    {routeResult.isAirway ? (
                      <>
                        <div style={{ fontSize: 10, fontWeight: 800, color: routeResult.routeType === "air" ? "#818CF8" : "#06B6D4", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 8, display: "flex", alignItems: "center", gap: 6 }}>
                          {routeResult.routeType === "air" ? "✈" : "⛴"} {routeResult.routeType === "air" ? "Airway Route" : "Seaway Route"}
                          <span style={{ fontSize: 9, background: routeResult.routeType === "air" ? "#818CF822" : "#06B6D422", border: `1px solid ${routeResult.routeType === "air" ? "#818CF844" : "#06B6D444"}`, borderRadius: 99, padding: "1px 7px", fontWeight: 700 }}>NO ROAD</span>
                        </div>
                        {routeResult.fromHub && <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 3 }}>🛫 Departs: <strong style={{ color: "#E2E8F0" }}>{routeResult.fromHub}</strong></div>}
                        {routeResult.toHub   && <div style={{ fontSize: 11, color: "#94A3B8", marginBottom: 10 }}>🛬 Arrives: <strong style={{ color: "#E2E8F0" }}>{routeResult.toHub}</strong></div>}
                        <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
                          <div>
                            <div style={{ fontSize: 24, fontWeight: 900, color: "#E2E8F0", fontFamily: "'Space Mono', monospace", letterSpacing: "-1px" }}>{routeResult.dist.toLocaleString()}<span style={{ fontSize: 12, color: "#94A3B8", marginLeft: 2, fontWeight: 500, letterSpacing: "0" }}>km</span></div>
                            <div style={{ fontSize: 9, color: "#94A3B8", textTransform: "uppercase", letterSpacing: ".06em", marginTop: 2 }}>GREAT-CIRCLE DIST</div>
                          </div>
                          <div style={{ width: 1, background: "rgba(255,255,255,0.1)" }} />
                          <div>
                            <div style={{ fontSize: 24, fontWeight: 900, color: "#E2E8F0", fontFamily: "'Space Mono', monospace", letterSpacing: "-1px" }}>
                              {routeResult.dur < 60 ? `${routeResult.dur}` : `${Math.floor(routeResult.dur / 60)}`}<span style={{ fontSize: 12, color: "#94A3B8", marginLeft: 2, fontWeight: 500, letterSpacing: "0" }}>{routeResult.dur < 60 ? 'm' : 'h'}</span>
                              {routeResult.dur >= 60 && <>{` ${routeResult.dur % 60}`}<span style={{ fontSize: 12, color: "#94A3B8", marginLeft: 2, fontWeight: 500, letterSpacing: "0" }}>m</span></>}
                            </div>
                            <div style={{ fontSize: 9, color: "#94A3B8", textTransform: "uppercase", letterSpacing: ".06em", marginTop: 2 }}>{routeResult.routeType === "air" ? "FLIGHT TIME" : "VOYAGE TIME"}</div>
                          </div>
                        </div>
                        <div style={{ marginTop: 10, fontSize: 11, color: "#64748B", fontStyle: "italic", lineHeight: 1.5 }}>
                          {routeResult.routeType === "air" ? "🛫 No drivable road found. Showing estimated airway route via nearest airports." : "⛴ No drivable road found. Showing estimated seaway route via nearest harbours."}
                        </div>
                      </>
                    ) : (
                      <>
                        <div style={{ fontSize: 10, fontWeight: 800, color: t.accent, textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: 12 }}>Trip Manifest</div>
                        <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
                          <div>
                            <div style={{ fontSize: 24, fontWeight: 900, color: t.text, fontFamily: "'Space Mono', monospace", letterSpacing: "-1px" }}>{routeResult.dist}<span style={{ fontSize: 12, color: t.textDim, marginLeft: 2, fontWeight: 500, letterSpacing: "0" }}>km</span></div>
                            <div style={{ fontSize: 9, color: t.textDim, textTransform: "uppercase", letterSpacing: ".06em", marginTop: 2 }}>EST. DISTANCE</div>
                          </div>
                          <div style={{ width: 1, background: "rgba(255,255,255,0.1)" }} />
                          <div>
                            <div style={{ fontSize: 24, fontWeight: 900, color: t.text, fontFamily: "'Space Mono', monospace", letterSpacing: "-1px" }}>
                              {routeResult.dur < 60 ? `${routeResult.dur}` : `${Math.floor(routeResult.dur / 60)}`}<span style={{ fontSize: 12, color: t.textDim, marginLeft: 2, fontWeight: 500, letterSpacing: "0" }}>{routeResult.dur < 60 ? 'm' : 'h'}</span>
                              {routeResult.dur >= 60 && <>{` ${routeResult.dur % 60}`}<span style={{ fontSize: 12, color: t.textDim, marginLeft: 2, fontWeight: 500, letterSpacing: "0" }}>m</span></>}
                            </div>
                            <div style={{ fontSize: 9, color: t.textDim, textTransform: "uppercase", letterSpacing: ".06em", marginTop: 2 }}>DRIVE TIME</div>
                          </div>
                          <div style={{ width: 1, background: "rgba(255,255,255,0.1)" }} />
                          <div>
                            <div style={{ fontSize: 24, fontWeight: 900, color: "#34D399", fontFamily: "'Space Mono', monospace", letterSpacing: "-1px" }}>
                              {routeMode === "driving" ? `₹${Math.round(routeResult.dist * 15 + 50)}` : "Free"}
                            </div>
                            <div style={{ fontSize: 9, color: "#6EE7B7", textTransform: "uppercase", letterSpacing: ".06em", marginTop: 2 }}>EST. COST</div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                )}


              </div>
            )}

            {/* ── PLACES TAB ── */}
            {tab === "places" && (
              <div className="lm-fade">
                {currentTrip && (
                  <div style={{ marginBottom: 10, background: t.surface, border: `1px solid ${t.border}`, borderRadius: 10, padding: "8px 9px" }}>
                    <div style={{ fontSize: 11, fontWeight: 700, color: t.text, marginBottom: 4 }}>📌 Places for {currentTrip.name}</div>
                    <div style={{ fontSize: 10, color: t.textDim }}>
                      {visitedCount} visited · {places.filter(p => p.status === 'planned').length} planned
                      {currentTrip.destination && ` · Destination: ${currentTrip.destination}`}
                    </div>
                  </div>
                )}

                {/* Places Route Actions */}
                <div style={{ display: "flex", gap: 6, marginBottom: 10, flexWrap: "wrap" }}>
                  <button
                    onClick={() => {
                      placesRouteFetchedRef.current = true;
                      setPlacesRouteFetched(true);
                      placesRouteTripRef.current = String(tripId);
                      placesRouteSigRef.current = "";
                      placesRouteDrawnRef.current = false;
                      placesRouteLay.current?.clearLayers();
                      // Evict both memory and localStorage cache to always get fresh OSRM route
                      placesRouteCacheRef.current.delete(String(tripId));
                      try { localStorage.removeItem(`tm_places_route_${tripId}`); } catch {}
                      drawPlacesTraversalRoute();
                    }}
                    disabled={placesRouteBusy || places.filter(p => p.latitude && p.longitude).length === 0}
                    style={{
                      flex: 1, padding: "8px 10px", borderRadius: 9, fontSize: 11, fontWeight: 700,
                      cursor: (placesRouteBusy || places.filter(p => p.latitude && p.longitude).length === 0) ? "not-allowed" : "pointer",
                      border: "none", fontFamily: "inherit",
                      background: placesRouteBusy ? t.surface : `linear-gradient(135deg,${t.accent},${t.accentDeep})`,
                      color: placesRouteBusy ? t.textDim : "#fff",
                      display: "flex", alignItems: "center", justifyContent: "center", gap: 6,
                    }}>
                    {placesRouteBusy
                      ? <><span className="lm-spin" style={{ width: 10, height: 10, border: `2px solid ${t.accent}44`, borderTopColor: t.accent, borderRadius: "50%" }} /> Drawing…</>
                      : "🗺️ Fetch Route"}
                  </button>
                  {places.filter(p => p.latitude && p.longitude).length > 2 && (
                    <button
                      disabled={optimizing}
                      onClick={doOptimizeRoute}
                      style={{
                        padding: "8px 10px", borderRadius: 9, fontSize: 11, fontWeight: 700,
                        background: optimizing ? t.surface : "linear-gradient(135deg,#A855F7,#7E22CE)",
                        color: optimizing ? t.textDim : "#fff", border: "none",
                        cursor: optimizing ? "not-allowed" : "pointer", fontFamily: "inherit",
                        display: "flex", alignItems: "center", gap: 5,
                      }}>
                      {optimizing ? "…" : "✨ Optimize"}
                    </button>
                  )}
                  {placesRouteFetched && placesRouteTripRef.current === String(tripId) && placesRouteLay.current?.getLayers().length > 0 && (
                    <button
                      onClick={() => {
                        placesRouteLay.current?.clearLayers();
                        placesRouteSigRef.current = "";
                        placesRouteDrawnRef.current = false;
                        placesRouteFetchedRef.current = false;
                        setPlacesRouteFetched(false);
                        placesRouteTripRef.current = null;
                      }}
                      style={{
                        padding: "8px 10px", borderRadius: 9, fontSize: 11, fontWeight: 600,
                        background: "#F43F5E22", color: "#F43F5E", border: "1px solid #F43F5E44",
                        cursor: "pointer", fontFamily: "inherit",
                      }}>
                      ✕ Clear
                    </button>
                  )}
                </div>

                <SectionHeader t={t} icon="📌" label="My Places" count={places.length} color={t.accent} />

                {/* Status legend */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4, marginBottom: 10 }}>
                  {Object.entries(STATUS_COLOR).map(([s, c]) => (
                    <div key={s} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                      <div style={{ width: 8, height: 8, borderRadius: "50%", background: c, boxShadow: `0 0 5px ${c}55`, flexShrink: 0 }} />
                      <span style={{ fontSize: 10, textTransform: "capitalize", color: t.text, fontWeight: 500 }}>{s}</span>
                    </div>
                  ))}
                </div>

                {placesLoading ? (
                  <div style={{ textAlign: "center", padding: 24 }}>
                    <Spinner />
                  </div>
                ) : places.length === 0 ? (
                    <div style={{ textAlign: "center", padding: 24 }}>
                      <div style={{ fontSize: 28, marginBottom: 6 }}>📌</div>
                      <div style={{ fontSize: 11, color: t.textDim }}>
                        {tripId ? "Tap anywhere on the map to pin a place." : "Select a trip first, then pin places on the map."}
                      </div>
                    </div>
                  ) : (
                    <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                      {places.map((p, i) => {
                        const col = STATUS_COLOR[p.status] || STATUS_COLOR.planned;
                        const isActive = activePlace === p.id;
                        return (
                          <div key={p.id}
                            onClick={() => { if (!p.latitude) return; setActivePlace(p.id); lmap.current?.setView([p.latitude, p.longitude], 16, { animate: true, duration: 1.5 }); }}
                            style={{ background: isActive ? t.accentSoft : t.surface, border: `1px solid ${isActive ? t.accent + "44" : t.border}`, borderRadius: 9, padding: "8px 10px", cursor: p.latitude ? "pointer" : "default", transition: "all .13s" }}
                            onMouseEnter={e => { if (!isActive) e.currentTarget.style.background = t.cardHover; }}
                            onMouseLeave={e => { if (!isActive) e.currentTarget.style.background = isActive ? t.accentSoft : t.surface; }}>
                            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                              <div style={{ width: 20, height: 20, borderRadius: "50%", background: col + "22", border: `2px solid ${col}`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: col, fontWeight: 900, flexShrink: 0 }}>
                                {p.status === "visited" ? "✓" : i + 1}
                              </div>
                              <div style={{ flex: 1, minWidth: 0 }}>
                                <div style={{ fontSize: 11, fontWeight: 600, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", color: t.text }}>{p.name}</div>
                                <div style={{ fontSize: 9, color: t.textDim }}>{p.place_type}{p.visit_time ? ` · ${p.visit_time}` : ""}</div>
                                <div style={{ display: "flex", gap: 5, marginTop: 5, flexWrap: "wrap" }}>
                                  <button onClick={(e) => { e.stopPropagation(); quickSetPlaceStatus(p, p.status === "visited" ? "planned" : "visited"); }}
                                    style={{ fontSize: 9, borderRadius: 99, border: "none", padding: "2px 7px", cursor: "pointer", fontFamily: "inherit", background: "#34D39922", color: "#34D399" }}>
                                    {p.status === "visited" ? "Unvisit" : "Visited"}
                                  </button>
                                  <button onClick={(e) => { e.stopPropagation(); quickSetPlaceStatus(p, "skipped"); }}
                                    style={{ fontSize: 9, borderRadius: 99, border: "none", padding: "2px 7px", cursor: "pointer", fontFamily: "inherit", background: "#F43F5E22", color: "#F43F5E" }}>
                                    Skip
                                  </button>
                                  <button onClick={(e) => { e.stopPropagation(); addPlaceToItinerary(p); }}
                                    style={{ fontSize: 9, borderRadius: 99, border: "none", padding: "2px 7px", cursor: "pointer", fontFamily: "inherit", background: t.accent + "22", color: t.accent }}>
                                    Itinerary
                                  </button>
                                  <button onClick={(e) => { e.stopPropagation(); openEditPlace(p); }}
                                    style={{ fontSize: 9, borderRadius: 99, border: "none", padding: "2px 7px", cursor: "pointer", fontFamily: "inherit", background: t.surface, color: t.textDim }}>
                                    Edit
                                  </button>
                                </div>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* ── Add place modal ── */}
      {showModal && clickCoords && (
        <Modal title={editingPlaceId ? "✏️ Edit Place" : "📍 Pin a Place"} onClose={() => { setShowModal(false); setEditingPlaceId(null); }}>
          <div style={{ background: t.accentSoft, border: `1px solid ${t.accent}33`, borderRadius: 8, padding: "6px 12px", marginBottom: 12, fontSize: 11, color: t.accent, fontFamily: "monospace" }}>
            📡 {clickCoords.lat}, {clickCoords.lng}
          </div>
          <form onSubmit={saveEditedPlace} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <div>
              <div style={{ fontSize: 10, fontWeight: 700, color: t.textDim, textTransform: "uppercase", letterSpacing: ".06em", marginBottom: 5 }}>Place Name *</div>
              <PlaceSearchInput
                value={pinForm.name}
                onChange={v => setPinForm(f => ({ ...f, name: v }))}
                onSelect={place => {
                  if (!place) { setPinVerified(false); return; }
                  setPinForm(f => ({ ...f, name: place.name, place_type: place.type || f.place_type, latitude: place.lat, longitude: place.lng }));
                  setPinVerified(true);
                }}
                contextCity={currentTrip?.destination || ""}
                placeholder="Search e.g. restaurant, landmark…"
                dark={dark} required tripId={tripId}
              />
            </div>
            <Select label="Type" value={pinForm.place_type} onChange={e => setPinForm(f => ({ ...f, place_type: e.target.value }))} options={PLACE_TYPES} />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <Input label="Visit Time" value={pinForm.visit_time} onChange={e => setPinForm(f => ({ ...f, visit_time: e.target.value }))} placeholder="09:30 AM" />
              <Select label="Status" value={pinForm.status} onChange={e => setPinForm(f => ({ ...f, status: e.target.value }))} options={STATUSES} />
            </div>
            <Input label="Notes" value={pinForm.notes} onChange={e => setPinForm(f => ({ ...f, notes: e.target.value }))} placeholder="Any notes..." />
            <ErrorMsg msg={pinErr} />
            <Btn type="submit" size="lg" loading={pinSaving} style={{ justifyContent: "center" }}>{editingPlaceId ? "Save Place" : "Add to Map"}</Btn>
          </form>
        </Modal>
      )}
    </div>
  );
}
