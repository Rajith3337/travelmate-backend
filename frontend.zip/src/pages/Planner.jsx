import { useState, useEffect, useCallback, useRef, useMemo } from "react";
import { tripsApi, placesApi, itineraryApi, expensesApi, checklistApi, notesApi, aiApi } from "../api/client";
import PlaceSearchInput from "../components/PlaceSearchInput";
import { Card, Badge, Btn, Modal, Input, Select, Tabs, Spinner, Empty, ErrorMsg } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";
import LocationInput from "../components/LocationInput";
import useActiveTrip from "../hooks/useActiveTrip";

// â”€â”€ Worker-based roadmap generation â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const PLANNER_API_BASE = (import.meta.env.VITE_API_URL || "http://localhost:8000").replace(/\/+$/, "") + "/api/v1";

function normSig(v) {
  return String(v || "").trim().toLowerCase().replace(/\s+/g, " ");
}

function roadmapSignature(trip, routeStart = "", routeDestination = "") {
  return JSON.stringify({
    name: normSig(trip?.name),
    start: normSig(routeStart || trip?.start_location),
    destination: normSig(routeDestination || trip?.destination),
    start_date: normSig(trip?.start_date),
    end_date: normSig(trip?.end_date),
    budget: Number(trip?.budget || 0),
    description: normSig(trip?.description),
  });
}

function safeJson(v, fallback = null) {
  try { return JSON.parse(v); } catch { return fallback; }
}

function extractFirstJsonObject(text) {
  const src = String(text || "").trim();
  const start = src.indexOf("{");
  const end = src.lastIndexOf("}");
  if (start === -1 || end === -1 || end <= start) return null;
  return src.slice(start, end + 1);
}

function repairTruncatedJson(text) {
  // Attempt to close an incomplete JSON object that was cut off mid-stream
  let s = String(text || "").trim();
  if (!s.startsWith("{")) {
    const i = s.indexOf("{");
    if (i === -1) return null;
    s = s.slice(i);
  }
  // Count open braces/brackets to determine how many closers we need
  let braces = 0, brackets = 0, inString = false, escape = false;
  for (const ch of s) {
    if (escape) { escape = false; continue; }
    if (ch === "\\" && inString) { escape = true; continue; }
    if (ch === '"') { inString = !inString; continue; }
    if (inString) continue;
    if (ch === "{") braces++;
    else if (ch === "}") braces--;
    else if (ch === "[") brackets++;
    else if (ch === "]") brackets--;
  }
  // Trim trailing comma/colon that caused truncation
  let repaired = s.replace(/,\s*$/, "").replace(/:\s*$/, ": null");
  // Close open string
  if (inString) repaired += '"';
  // Close open arrays/objects
  for (let i = 0; i < brackets; i++) repaired += "]";
  for (let i = 0; i < braces; i++) repaired += "}";
  try { return JSON.parse(repaired); } catch { return null; }
}

function parseTravelInsightJson(text) {
  const cleaned = String(text || "").replace(/```json|```/gi, "").trim();
  if (!cleaned) return null;
  // 1) Try clean parse
  try { return JSON.parse(cleaned); } catch {}
  // 2) Try extracting outermost object
  const block = extractFirstJsonObject(cleaned);
  if (block) {
    try { return JSON.parse(block); } catch {}
    // 3) Try repairing truncated JSON
    const repaired = repairTruncatedJson(block);
    if (repaired && typeof repaired === "object") return repaired;
  }
  // 4) Repair from full cleaned text
  const repaired2 = repairTruncatedJson(cleaned);
  if (repaired2 && typeof repaired2 === "object") return repaired2;
  return null;
}

function classifyRoadmapAiError(ex) {
  const msg = String(ex?.message || "");
  if (/AI not configured|No AI API key|Gemini API key not configured|Grok API key not configured/i.test(msg)) return "not_configured";
  if (/timeout|timed out/i.test(msg)) return "timeout";
  if (/invalid roadmap format|non-JSON|empty response/i.test(msg)) return "bad_response";
  return "failed";
}

function roadmapErrorMessage(ex) {
  const type = classifyRoadmapAiError(ex);
  const raw = String(ex?.message || "");
  if (type === "not_configured") return "AI not configured. Add Gemini or Grok key to generate a roadmap.";
  if (type === "timeout") return "AI roadmap timed out. Please tap Generate Plan again.";
  if (type === "bad_response") return "AI returned an invalid roadmap format. Please regenerate.";
  // Surface the actual backend error instead of a generic message
  return raw ? `AI request failed: ${raw}` : "AI roadmap failed. Please try again.";
}

// â”€â”€ AI trip analysis â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
async function analyzeTrip(trip, distKm, durH, daySegments = [], extraData = {}) {
  const tripDays = Math.max(
    1,
    trip.end_date && trip.start_date
      ? Math.ceil((new Date(trip.end_date) - new Date(trip.start_date)) / 86400000)
      : Math.ceil(distKm / 400) + 1
  );

  const { places = [], expenses = [], days: itinDays = [], checklist = [], notes = [] } = extraData;
  const trunc = (s, n = 140) => {
    const v = String(s || "").replace(/\s+/g, " ").trim();
    return v.length > n ? v.slice(0, n - 1) + "…" : v;
  };

  // Build rich data blocks from full trip data
  const placesBlock = places.length
    ? places.map(p => `  - [${p.status?.toUpperCase()}] ${p.name} (${p.place_type})${p.address ? " @ " + p.address : ""}${p.visit_time ? " — " + p.visit_time : ""}${p.rating ? " ★" + p.rating : ""}${p.notes ? " | " + p.notes : ""}`).join("\n")
    : "  None added yet.";

  const totalSpent = expenses.reduce((s, e) => s + (e.amount || 0), 0);
  const byCategory = expenses.reduce((acc, e) => { acc[e.category] = (acc[e.category] || 0) + e.amount; return acc; }, {});
  const expensesBlock = expenses.length
    ? `  Total spent: Rs.${totalSpent.toLocaleString("en-IN")} / Rs.${(trip.budget||0).toLocaleString("en-IN")} budget\n` +
      Object.entries(byCategory).map(([c, a]) => `  - ${c}: Rs.${a.toLocaleString("en-IN")}`).join("\n")
    : "  No expenses recorded yet.";

  const itinBlock = itinDays.length
    ? itinDays.map(d => `  Day ${d.day_number}: ${d.title}${d.date_label ? " (" + d.date_label + ")" : ""}${d.place_names ? " — " + d.place_names : ""}${d.notes ? " | " + d.notes : ""}`).join("\n")
    : "  No itinerary days yet.";

  const isPacked = (c) => Boolean(c?.checked ?? c?.done ?? false);
  const packText = (c) => String(c?.item ?? c?.text ?? "").trim();
  const packingDone = checklist.filter(isPacked).map(packText).filter(Boolean).join(", ") || "None";
  const packingTodo = checklist.filter(c => !isPacked(c)).map(packText).filter(Boolean).join(", ") || "None";

  const notesBlock = notes.length
    ? notes
        .slice(0, 12)
        .map(n => `  - ${n.pinned ? "📌 " : ""}${trunc(n.title || "Note", 60)}: ${trunc(n.content || "", 160)}`)
        .join("\n")
    : "  No saved notes yet.";

  const segmentsBlock = daySegments.length
    ? daySegments.map((segment, idx) => {
        const fromKm = Math.round((segment.distStart || 0) / 1000);
        const toKm = Math.round((segment.distEnd || 0) / 1000);
        return `  Day ${idx + 1}: ${fromKm}km - ${toKm}km`;
      }).join("\n")
    : "  Day 1: full journey";

  const routeType = (() => {
    const start = (trip.start_location || "").toLowerCase();
    const dest = (trip.destination || "").toLowerCase();
    const indiaKw = ["india", "delhi", "mumbai", "chennai", "bangalore", "kolkata", "hyderabad", "pune", "ahmedabad", "thoothukudi", "madurai", "coimbatore", "kochi", "kerala", "tamil", "karnataka"];
    const japanKw = ["japan", "tokyo", "osaka", "kyoto", "hiroshima", "nagoya", "sapporo", "fukuoka"];
    const seaKw = ["thailand", "bangkok", "singapore", "malaysia", "vietnam", "indonesia", "bali", "myanmar", "cambodia", "philippines", "laos"];
    const chinaKw = ["china", "beijing", "shanghai", "guangzhou", "shenzhen", "chengdu"];
    const europeKw = ["paris", "london", "rome", "berlin", "amsterdam", "barcelona", "madrid", "vienna", "prague", "europe", "uk", "france", "germany", "italy", "spain"];
    const usKw = ["new york", "los angeles", "chicago", "usa", "united states", "san francisco", "seattle", "miami", "boston", "washington dc"];
    const gulfKw = ["dubai", "abu dhabi", "doha", "riyadh", "uae", "qatar", "saudi", "bahrain", "kuwait", "oman", "muscat"];

    const match = (text, kws) => kws.some(k => text.includes(k));
    const startIndia = match(start, indiaKw);
    const destIndia = match(dest, indiaKw);
    const isInternational = !startIndia || !destIndia;

    // Detect ocean crossings (no road route possible)
    const needsOcean = (match(start, indiaKw) && match(dest, japanKw)) ||
      (match(dest, indiaKw) && match(start, japanKw)) ||
      (match(start, [...indiaKw, ...seaKw, ...chinaKw]) && match(dest, [...europeKw, ...usKw])) ||
      (match(start, [...europeKw, ...usKw]) && match(dest, [...indiaKw, ...seaKw, ...chinaKw])) ||
      (distKm > 5000);

    // Modal hint for impossible routes
    let modalHint = "";
    if (needsOcean) {
      if (startIndia && match(dest, japanKw)) {
        modalHint = `\n⚠️ IMPOSSIBLE ROAD ROUTE: Chennai/India to Tokyo cannot be driven. Design a MULTI-MODAL plan:\n- Option A (fastest): Direct flight Chennai → Tokyo Narita (~8h, ~$400-600). Then explore Japan by rail (JR Pass).\n- Option B (adventurous): Drive to Kolkata → overland Myanmar/China → ferry/flight from Shanghai to Japan.\n- Car shipping India→Japan: ~$3,000-5,000 USD, 4-6 weeks sea freight.\nDO NOT pretend this can be driven. Be honest and specific about flights/trains/ferries.`;
      } else if (distKm > 5000) {
        modalHint = `\n⚠️ LONG-DISTANCE MULTI-MODAL ROUTE (${Math.round(distKm)}km): This trip cannot be completed by road alone. Design a realistic plan using flights, trains, ferries, and road segments. Name real airports, stations, and border crossings.`;
      }
    }

    // Currency
    let currency = "USD";
    if (startIndia && destIndia) currency = "INR (₹)";
    else if (match(dest, japanKw) || match(start, japanKw)) currency = "JPY (¥) for Japan, INR (₹) for India";
    else if (match(start + dest, gulfKw)) currency = "AED/USD";
    else if (match(start + dest, europeKw)) currency = "EUR (€)";
    else if (match(start + dest, usKw)) currency = "USD ($)";

    return { isInternational, needsOcean, modalHint, currency };
  })();
  const { isInternational, needsOcean, modalHint, currency } = routeType;

  const daysPlaceholder = Array.from({length: tripDays}, (_, i) =>
    `{"day":${i+1},"title":"","journeyMode":"","morningTip":"","eveningTip":"","stayRecommendation":"","meals":["","",""],"highlights":["","",""],"routeItems":[{"category":"sight|food|stay|fuel","name":"","note":""}]}`
  ).join(",");
  const prompt = `Trip: ${trip.start_location||"?"}->${trip.destination}, ${tripDays} days, ${trip.start_date||"?"} to ${trip.end_date||"?"}, budget ${currency} ${(trip.budget||0).toLocaleString()}, ${trip.travel_mode||"Road"}.${modalHint}${trip.notes||trip.description ? " Notes: "+(trip.notes||trip.description) : ""}${places.length ? " Places: "+places.slice(0,5).map(p=>p.name).join(", ") : ""}\nReply ONLY with this exact JSON filled in for ALL ${tripDays} days:\n{"tripInsight":"","bestTimeToLeave":"","weatherNote":"","budgetAlert":"","travelTips":["",""],"days":[${daysPlaceholder}]}\nCRITICAL: days array MUST have exactly ${tripDays} objects (day 1 through ${tripDays}). Fill every field.\nRules: Real place/hotel/restaurant names. meals=3 strings. highlights=3 strings. ${currency} prices.`;

  const response = await aiApi.travelInsights({ prompt });
  const rawText = String(response?.text || "").trim();
  if (!rawText) throw new Error("AI returned empty response.");

  const parsed = parseTravelInsightJson(rawText);
  if (parsed && typeof parsed === "object") {
    // Only accept the roadmap if the AI returned ALL requested days.
    const parsedDays = Array.isArray(parsed?.days) ? parsed.days : null;
    if (!parsedDays || parsedDays.length !== tripDays) {
      throw new Error(`Invalid roadmap format: expected ${tripDays} days, got ${parsedDays ? parsedDays.length : 0}`);
    }
    const daySet = new Set(parsedDays.map(d => Number(d?.day)).filter(n => Number.isFinite(n)));
    for (let d = 1; d <= tripDays; d++) {
      if (!daySet.has(d)) throw new Error(`Invalid roadmap format: missing day ${d}`);
    }
    if (typeof response.ai_used === "boolean") parsed.__ai_used = response.ai_used;
    if (response.ai_provider) parsed.__ai_provider = response.ai_provider;
    return parsed;
  }

  const travelTips = rawText
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(line => /^[-*•]\s+/.test(line))
    .map(line => line.replace(/^[-*•]\s+/, ""))
    .filter(Boolean)
    .slice(0, 6);

  return {
    tripInsight: rawText,
    travelTips,
    days: [],
    __ai_used: typeof response.ai_used === "boolean" ? response.ai_used : undefined,
    __ai_provider: response.ai_provider || undefined,
  };
}

// â”€â”€ Constants â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
const SC = (s, t) => ({ planned: t.textDim, upcoming: t.amber, visited: t.green, skipped: t.red })[s] || t.textDim;
const STATUSES = [{ value: "planned", label: "Planned" }, { value: "upcoming", label: "Upcoming" }, { value: "visited", label: "Visited" }, { value: "skipped", label: "Skipped" }];
const PLACE_TYPES = [{ value: "Attraction", label: "Attraction" }, { value: "Restaurant", label: "Restaurant" }, { value: "Hotel", label: "Hotel/Stay" }, { value: "Nature", label: "Nature" }, { value: "Shopping", label: "Shopping" }, { value: "Transport", label: "Transport" }, { value: "Hospital", label: "Hospital" }, { value: "Other", label: "Other" }];
const BP = { name: "", place_type: "Attraction", address: "", visit_time: "", rating: "", status: "planned", notes: "", latitude: "", longitude: "" };
const BD = { day_number: 1, date_label: "", title: "", place_names: "", notes: "" };

const CAT_ICONS = { stay: "\u{1F3E8}", food: "\u{1F37D}\uFE0F", sight: "\u{1F3DB}\uFE0F", hospital: "\u{1F3E5}", fuel: "\u26FD" };
const CAT_LABEL = { stay: "Hotel", food: "Food", sight: "Sight", hospital: "Hospital", fuel: "Fuel" };

function normalizeCategory(value) {
  const key = String(value || "").trim().toLowerCase();
  if (["hotel", "stay", "stays", "resort", "accommodation"].includes(key)) return "stay";
  if (["food", "meal", "meals", "restaurant", "cafe"].includes(key)) return "food";
  if (["visit", "visits", "sight", "sights", "attraction"].includes(key)) return "sight";
  if (["hospital", "clinic", "medical"].includes(key)) return "hospital";
  if (["fuel", "petrol", "diesel", "gas"].includes(key)) return "fuel";
  if (["transport", "transit", "journey", "travel"].includes(key)) return "sight";
  return "sight";
}

function categoryToPlaceType(category) {
  const cat = normalizeCategory(category);
  if (cat === "stay") return "Hotel";
  if (cat === "food") return "Restaurant";
  if (cat === "hospital") return "Hospital";
  if (cat === "fuel") return "Transport";
  return "Attraction";
}

function toRouteItem(rawItem, distM, fallbackMode = "") {
  const category = normalizeCategory(rawItem?.category);
  return {
    category,
    placeType: categoryToPlaceType(category),
    name: String(rawItem?.name || "").trim(),
    addr: String(rawItem?.address || rawItem?.addr || "").trim() || null,
    note: String(rawItem?.note || "").trim() || null,
    journeyMode: String(rawItem?.journeyMode || fallbackMode || "").trim() || null,
    distM,
    lat: null,
    lng: null,
    hours: null,
    phone: null,
  };
}

function buildPlanFromInsight(basePlan, insight) {
  const baseDays = Array.isArray(basePlan?.days) && basePlan.days.length
    ? basePlan.days
    : [{ day: 1, distStart: 0, distEnd: Math.max(1, Math.round((basePlan?.distKm || 1) * 1000)), items: [] }];
  const aiDays = Array.isArray(insight?.days) ? insight.days : [];

  const planDays = baseDays.map((segment, index) => {
    const dayNo = Number(segment?.day || index + 1);
    const aiDay = aiDays.find(d => Number(d?.day) === dayNo) || {};
    const span = Math.max(1, (segment?.distEnd || 0) - (segment?.distStart || 0));
    const rawRouteItems = Array.isArray(aiDay?.routeItems) ? aiDay.routeItems : [];

    let items = rawRouteItems
      .map((rawItem, itemIndex) => {
        const ratio = (itemIndex + 1) / (rawRouteItems.length + 1);
        const distM = Math.round((segment?.distStart || 0) + span * ratio);
        return toRouteItem(rawItem, distM, aiDay?.journeyMode);
      })
      .filter(item => item.name);

    if (!items.length) {
      const seed = [];
      if (Array.isArray(aiDay?.highlights)) {
        aiDay.highlights.forEach(name => seed.push({ category: "sight", name }));
      }
      if (Array.isArray(aiDay?.meals)) {
        aiDay.meals.forEach(name => seed.push({ category: "food", name }));
      }
      if (aiDay?.stayRecommendation) {
        seed.push({ category: "stay", name: aiDay.stayRecommendation });
      }
      items = seed
        .map((rawItem, itemIndex) => {
          const ratio = (itemIndex + 1) / (seed.length + 1 || 2);
          const distM = Math.round((segment?.distStart || 0) + span * ratio);
          return toRouteItem(rawItem, distM, aiDay?.journeyMode);
        })
        .filter(item => item.name);
    }

    return {
      ...segment,
      day: dayNo,
      items,
    };
  });

  const milestones = planDays
    .flatMap(day => Array.isArray(day.items) ? day.items : [])
    .sort((a, b) => (a.distM || 0) - (b.distM || 0));

  return {
    ...(basePlan || {}),
    days: planDays,
    milestones,
  };
}

function getCatStyle(cat, dark) {
  return (dark !== false ? {
    stay: { color: "#A78BFA", bg: "#A78BFA18", border: "#A78BFA40" },
    food: { color: "#FCD34D", bg: "#FCD34D18", border: "#FCD34D40" },
    sight: { color: "#34D399", bg: "#34D39918", border: "#34D39940" },
    hospital: { color: "#F87171", bg: "#F8717118", border: "#F8717140" },
    fuel: { color: "#6EE7B7", bg: "#6EE7B718", border: "#6EE7B740" },
  } : {
    stay: { color: "#7C3AED", bg: "#7C3AED0D", border: "#7C3AED33" },
    food: { color: "#92400E", bg: "#92400E0D", border: "#92400E33" },
    sight: { color: "#065F46", bg: "#065F460D", border: "#065F4633" },
    hospital: { color: "#991B1B", bg: "#991B1B0D", border: "#991B1B33" },
    fuel: { color: "#064E3B", bg: "#064E3B0D", border: "#064E3B33" },
  })[cat] || (dark !== false ? { color: "#34D399", bg: "#34D39918", border: "#34D39940" } : { color: "#065F46", bg: "#065F460D", border: "#065F4633" });
}

// â”€â”€ Main Component â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
export default function Planner({ dark = true }) {
  const t = dark ? DARK : LIGHT;

  const [trips, setTrips] = useState([]);
  const [tripId, setTripId] = useActiveTrip();
  const [places, setPlaces] = useState([]);
  const [days, setDays] = useState([]);
  const [loading, setLoading] = useState(false);
  const [tab, setTab] = useState("places");
  const [filterStatus, setFilterStatus] = useState("all");
  const [showPlace, setShowPlace] = useState(false);
  const [showDay, setShowDay] = useState(false);
  const [editingPlace, setEditingPlace] = useState(null);
  const [editingDay, setEditingDay] = useState(null);
  const [pf, setPf] = useState(BP);
  const [placeVerified, setPlaceVerified] = useState(false);
  const [df, setDf] = useState(BD);
  const [err, setErr] = useState("");
  const [saving, setSaving] = useState(false);
  const [deletingPlaceId, setDeletingPlaceId] = useState(null);
  const [deletingDayId, setDeletingDayId] = useState(null);
  const [togglingPlaceId, setTogglingPlaceId] = useState(null);

  const [plan, setPlan] = useState(null);
  const [aiInsight, setAiInsight] = useState(null);
  const [planLoading, setPlanLoading] = useState(false);
  const [planErr, setPlanErr] = useState("");
  const [planProgress, setPlanProgress] = useState("");
  const [adding, setAdding] = useState(false);
  const [warmItem, setWarmItem] = useState(null);
  const [warmStatusLoading, setWarmStatusLoading] = useState(false);
  const [aiAvailable, setAiAvailable] = useState(null);
  const [expenses, setExpenses] = useState([]);
  const [checklist, setChecklist] = useState([]);
  const [notes, setNotes] = useState([]);
  const planFetchedRef = useRef("");
  const workerRef = useRef(null);

  // Cleanup worker on unmount
  useEffect(() => { return () => { if (workerRef.current) { workerRef.current.terminate(); } }; }, []);

  useEffect(() => {
    tripsApi.list().then(d => {
      setTrips(d);
      if (!localStorage.getItem("tm_active_trip") && d.length) {
        setTripId(String(d[0].id));
        localStorage.setItem("tm_active_trip", d[0].id);
      }
    });
  }, []);



  useEffect(() => {
    if (!tripId) return;
    setLoading(true);
    Promise.all([
      placesApi.list(tripId),
      itineraryApi.list(tripId),
      expensesApi.list(tripId).catch(() => []),
      checklistApi.list(tripId).catch(() => []),
      notesApi.list(tripId).catch(() => []),
    ])
      .then(([p, d, ex, ck, nt]) => { setPlaces(p); setDays(d); setExpenses(ex); setChecklist(ck); setNotes(nt); })
      .finally(() => setLoading(false));
  }, [tripId]);

  useEffect(() => {
    const handler = e => {
      const d = e?.detail || {};
      const matchTrip = String(d.tripId) === String(tripId);
      if ((d.type === "places" || d.type === "itinerary" || d.type === "expenses" || d.type === "checklist" || d.type === "notes") && matchTrip) {
        reload();
      }
      if (d.type === "trips") {
        tripsApi.list().then(setTrips).catch(() => {});
      }
    };
    window.addEventListener("tm_data_updated", handler);
    return () => window.removeEventListener("tm_data_updated", handler);
  }, [tripId]);

  const reload = async () => {
    const [p, d, ex, ck, nt] = await Promise.all([
      placesApi.list(tripId),
      itineraryApi.list(tripId),
      expensesApi.list(tripId).catch(() => []),
      checklistApi.list(tripId).catch(() => []),
      notesApi.list(tripId).catch(() => []),
    ]);
    setPlaces(p); setDays(d); setExpenses(ex); setChecklist(ck); setNotes(nt);
  };

  const sp = k => e => setPf(f => ({ ...f, [k]: e.target.value }));
  const sd = k => e => setDf(f => ({ ...f, [k]: e.target.value }));

  const openAdd = () => { setEditingPlace(null); setPf(BP); setErr(""); setPlaceVerified(false); setShowPlace(true); };
  const openEdit = p => { setEditingPlace(p); setPlaceVerified(true); setPf({ name: p.name, place_type: p.place_type, address: p.address || "", visit_time: p.visit_time || "", rating: p.rating || "", status: p.status, notes: p.notes || "", latitude: p.latitude || "", longitude: p.longitude || "" }); setErr(""); setShowPlace(true); };
  const openAddDay = () => { setEditingDay(null); setDf({ ...BD, day_number: days.length + 1 }); setErr(""); setShowDay(true); };
  const openEditDay = d => { setEditingDay(d); setDf({ day_number: d.day_number, date_label: d.date_label || "", title: d.title, place_names: d.place_names || "", notes: d.notes || "" }); setErr(""); setShowDay(true); };

  const savePlace = async e => {
    e.preventDefault(); setErr("");
    if (!editingPlace && !placeVerified) { setErr("Please select a verified place."); return; }
    setSaving(true);
    try {
      const pay = { ...pf, rating: pf.rating ? parseFloat(pf.rating) : null, latitude: pf.latitude ? parseFloat(pf.latitude) : null, longitude: pf.longitude ? parseFloat(pf.longitude) : null };
      if (editingPlace) await placesApi.update(tripId, editingPlace.id, pay);
      else await placesApi.create(tripId, pay);
      setShowPlace(false); await reload();
    } catch (ex) { setErr(ex.message); } finally { setSaving(false); }
  };

  const saveDay = async e => {
    e.preventDefault(); setErr(""); setSaving(true);
    try {
      const pay = { ...df, day_number: parseInt(df.day_number) };
      if (editingDay) await itineraryApi.update(tripId, editingDay.id, pay);
      else await itineraryApi.create(tripId, pay);
      setShowDay(false); await reload();
    } catch (ex) { setErr(ex.message); } finally { setSaving(false); }
  };

  const markVisited = async p => {
    setTogglingPlaceId(p.id);
    try {
      await placesApi.update(tripId, p.id, { status: p.status === "visited" ? "planned" : "visited" });
      await reload();
    } finally {
      setTogglingPlaceId(null);
    }
  };
  const rmPlace = async id => {
    if (!confirm("Delete this place?")) return;
    setDeletingPlaceId(id);
    try {
      await placesApi.delete(tripId, id);
      await reload();
    } finally {
      setDeletingPlaceId(null);
    }
  };
  const rmDay = async id => {
    if (!confirm("Delete this day?")) return;
    setDeletingDayId(id);
    try {
      await itineraryApi.delete(tripId, id);
      await reload();
    } finally {
      setDeletingDayId(null);
    }
  };

  const trip = trips.find(tr => String(tr.id) === tripId);
  const cachedActiveRoute = useMemo(() => safeJson(trip?.active_route, null), [trip?.active_route]);
  const cachedRoadmap = useMemo(() => safeJson(trip?.ai_roadmap, null), [trip?.ai_roadmap]);
  const routeStart = useMemo(() => (
    (trip?.start_location || "").trim() ||
    (cachedActiveRoute?.fromLabel || "").trim() ||
    (cachedRoadmap?.start || "").trim()
  ), [trip?.start_location, cachedActiveRoute?.fromLabel, cachedRoadmap?.start]);
  const routeDestination = useMemo(() => (
    (trip?.destination || "").trim() ||
    (cachedActiveRoute?.toLabel || "").trim() ||
    (cachedRoadmap?.destination || "").trim()
  ), [trip?.destination, cachedActiveRoute?.toLabel, cachedRoadmap?.destination]);

  // â”€â”€ Generate milestone plan via Web Worker (background, survives tab switch) â”€â”€
  // ── Detect routes that cannot be driven (ocean crossings)
  const isImpossibleRoute = useCallback((start, dest) => {
    const s = (start || "").toLowerCase();
    const d = (dest || "").toLowerCase();
    const indiaKw = ["india", "delhi", "mumbai", "chennai", "bangalore", "kolkata", "hyderabad", "pune", "thoothukudi", "madurai", "kochi", "kerala", "tamil", "karnataka", "coimbatore"];
    const japanKw = ["japan", "tokyo", "osaka", "kyoto", "hiroshima", "nagoya", "sapporo", "fukuoka"];
    const seaKw = ["thailand", "bangkok", "singapore", "malaysia", "vietnam", "indonesia", "bali", "myanmar", "cambodia", "philippines"];
    const chinaKw = ["china", "beijing", "shanghai", "guangzhou", "shenzhen"];
    const europeKw = ["paris", "london", "rome", "berlin", "amsterdam", "barcelona", "madrid", "europe", "uk", "france", "germany", "italy", "spain"];
    const usKw = ["new york", "los angeles", "chicago", "usa", "united states", "san francisco", "seattle", "miami", "washington"];
    const match = (text, kws) => kws.some(k => text.includes(k));
    return (
      (match(s, indiaKw) && match(d, japanKw)) ||
      (match(d, indiaKw) && match(s, japanKw)) ||
      (match(s, [...indiaKw, ...seaKw, ...chinaKw]) && match(d, [...europeKw, ...usKw])) ||
      (match(s, [...europeKw, ...usKw]) && match(d, [...indiaKw, ...seaKw, ...chinaKw])) ||
      (match(s, japanKw) && match(d, [...europeKw, ...usKw])) ||
      (match(s, [...europeKw, ...usKw]) && match(d, japanKw))
    );
  }, []);

  const generatePlan = useCallback((start, destination, forceRefresh = false) => {
    if (aiAvailable === false) {
      setPlanErr("AI not configured. Add Gemini or Grok key to generate a roadmap.");
      setPlan(null);
      setAiInsight(null);
      return;
    }
    const key = `${start}||${destination}`;
    if (!forceRefresh && planFetchedRef.current === key) return;
    planFetchedRef.current = key;

    setPlanLoading(true); setPlanErr(""); setPlan(null); setAiInsight(null);

    // ── Impossible routes (ocean crossings): skip worker, go straight to AI ──
    if (isImpossibleRoute(start, destination)) {
      if (workerRef.current) { workerRef.current.terminate(); workerRef.current = null; }
      setPlanProgress("Designing multi-modal itinerary with AI...");
      (async () => {
        try {
          const freshTrip = await tripsApi.get(trip?.id).catch(() => trip);
          const tripDays = freshTrip?.end_date && freshTrip?.start_date
            ? Math.max(1, Math.ceil((new Date(freshTrip.end_date) - new Date(freshTrip.start_date)) / 86400000))
            : 7;
          const syntheticPlan = {
            distKm: 0,
            durH: 0,
            days: Array.from({ length: tripDays }, (_, i) => ({
              day: i + 1,
              distStart: i * 1000,
              distEnd: (i + 1) * 1000,
              items: [],
            })),
            milestones: [],
            destination,
            start,
            multiModal: true,
          };
          const insight = await analyzeTrip(freshTrip, 0, 0, syntheticPlan.days, { places, expenses, days, checklist, notes });
          const mergedPlan = buildPlanFromInsight(syntheticPlan, insight);
          setPlan(mergedPlan);
          setAiInsight(insight);
          try {
            const sig = roadmapSignature(freshTrip, start, destination);
            await tripsApi.update(freshTrip.id, {
              ai_roadmap: JSON.stringify({
                plan: mergedPlan,
                insight: insight || {},
                start,
                destination,
                generated_at: new Date().toISOString(),
                signature: sig,
              })
            });
          } catch (e) { console.error("Cache save failed", e); }
        } catch (ex) {
          setPlanErr(roadmapErrorMessage(ex));
          setPlan(null);
          setAiInsight(null);
          planFetchedRef.current = "";
        } finally {
          setPlanLoading(false);
          setPlanProgress("");
        }
      })();
      return;
    }

    // Terminate any previous worker
    if (workerRef.current) { workerRef.current.terminate(); workerRef.current = null; }

    const worker = new Worker("/roadmap.worker.js");
    workerRef.current = worker;

    worker.onmessage = async ({ data }) => {
      if (data.type === "progress") {
        setPlanProgress(data.msg);
      } else if (data.type === "error") {
        setPlanErr(data.msg);
        planFetchedRef.current = "";
        setPlanLoading(false);
        setPlanProgress("");
        worker.terminate();
        workerRef.current = null;
      } else if (data.type === "done") {
        worker.terminate();
        workerRef.current = null;
        // AI analysis runs on main thread after route metrics are ready.
        if (trip) {
          setPlanProgress("Asking AI for a full trip plan...");
          try {
            const freshTrip = await tripsApi.get(trip.id).catch(() => trip);
            const insight = await analyzeTrip(freshTrip, data.plan.distKm, data.plan.durH, data.plan.days, { places, expenses, days, checklist, notes });
            const mergedPlan = buildPlanFromInsight(data.plan, insight);
            setPlan(mergedPlan);
            setAiInsight(insight);
            try {
              const sig = roadmapSignature(freshTrip, start, destination);
              await tripsApi.update(freshTrip.id, {
                ai_roadmap: JSON.stringify({
                  plan: mergedPlan,
                  insight: insight || {},
                  start,
                  destination,
                  generated_at: new Date().toISOString(),
                  signature: sig,
                })
              });
            } catch (e) { console.error("Cache save failed", e); }
          } catch (ex) {
            setPlanErr(roadmapErrorMessage(ex));
            setPlan(null);
            setAiInsight(null);
            planFetchedRef.current = "";
          }
        }
        setPlanLoading(false);
        setPlanProgress("");
      }
    };

    worker.onerror = (e) => {
      setPlanErr("Worker error: " + e.message);
      planFetchedRef.current = "";
      setPlanLoading(false);
      setPlanProgress("");
      workerRef.current = null;
    };

    worker.postMessage({
      start,
      destination,
      apiBase: PLANNER_API_BASE,
      token: localStorage.getItem("tm_token"),
      tripDays: (trip?.start_date && trip?.end_date)
        ? Math.max(1, Math.ceil((new Date(trip.end_date) - new Date(trip.start_date)) / 86400000))
        : null,
    });
  }, [aiAvailable, trip, tripId, places, expenses, days, checklist, notes]);

  useEffect(() => {
    if (!routeStart || !routeDestination) return;
    if (aiAvailable === false) {
      setPlan(null);
      setAiInsight(null);
      setPlanErr("AI not configured. Add Gemini or Grok key to generate a roadmap.");
      return;
    }

    // 1) Use cached roadmap immediately if valid.
    if (trip?.ai_roadmap) {
      try {
        const cached = JSON.parse(trip.ai_roadmap);
        const sig = roadmapSignature(trip, routeStart, routeDestination);
        const sigMatch = !cached.signature || cached.signature === sig;
        if (cached.plan && cached.insight && cached.start === routeStart && cached.destination === routeDestination && sigMatch) {
          setPlan(cached.plan);
          setAiInsight(cached.insight);
          planFetchedRef.current = `${routeStart}||${routeDestination}`;
          return;
        }
      } catch (e) { }
    }

    // 2) Wait for backend warmup DB cache instead of heavy local generation.
    let dead = false;
    let pollId = null;

    pollId = setInterval(async () => {
      if (dead) return;
      try {
        const freshTrip = await tripsApi.get(tripId);
        if (!freshTrip?.ai_roadmap) return;
        const cached = JSON.parse(freshTrip.ai_roadmap);
        const sig = roadmapSignature(freshTrip, routeStart, routeDestination);
        const sigMatch = !cached.signature || cached.signature === sig;
        if (cached?.plan && cached?.insight && cached.start === routeStart && cached.destination === routeDestination && sigMatch) {
          dead = true;
          clearInterval(pollId);
          setPlan(cached.plan);
          setAiInsight(cached.insight);
          setTrips(prev => prev.map(tr => String(tr.id) === String(freshTrip.id) ? freshTrip : tr));
          planFetchedRef.current = `${routeStart}||${routeDestination}`;
        }
      } catch { }
    }, 3000);

    return () => {
      dead = true;
      if (pollId) clearInterval(pollId);
    };
  }, [routeStart, routeDestination, trip?.ai_roadmap, tripId, aiAvailable]);

  useEffect(() => {
    if (!tripId) return;
    if (tab !== "route") return;
    let dead = false;
    const loadStatus = async () => {
      setWarmStatusLoading(true);
      try {
        const data = await aiApi.roadmapStatus();
        if (dead) return;
        if (typeof data?.ai_available === "boolean") setAiAvailable(data.ai_available);
        const item = (data?.items || []).find(x => String(x.trip_id) === String(tripId)) || null;
        setWarmItem(item);
      } catch {
      } finally {
        if (!dead) setWarmStatusLoading(false);
      }
    };
    loadStatus();
    const tid = setInterval(loadStatus, 15000);
    return () => {
      dead = true;
      clearInterval(tid);
    };
  }, [tripId, tab]);

  useEffect(() => {
    if (aiAvailable === true && planErr?.includes("AI not configured")) {
      setPlanErr("");
    }
  }, [aiAvailable, planErr]);

  // â”€â”€ Bulk add plan â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  const addPlanToTrip = async () => {
    if (!plan || !tripId) return;
    setAdding(true);
    try {
      const autoPlaces = places.filter(p => p.notes?.includes("km from start") || p.notes?.includes("km)"));
      for (const p of autoPlaces) { try { await placesApi.delete(tripId, p.id); } catch { } }
      const autoDays = days.filter(d => d.notes?.includes("Route Day"));
      for (const d of autoDays) { try { await itineraryApi.delete(tripId, d.id); } catch { } }

      for (const m of plan.milestones) {
        await placesApi.create(tripId, { name: m.name, place_type: m.placeType, address: m.addr || "", latitude: m.lat, longitude: m.lng, status: "planned", notes: m.note });
      }

      const existingDayNums = days.map(d => d.day_number);
      let nextDay = (existingDayNums.length ? Math.max(...existingDayNums) : 0) + 1;
      for (const dg of plan.days) {
        const placeNames = dg.items.map(i => i.name).join(", ");
        const stayItem = dg.items.find(i => i.category === "stay");
        const aiDay = aiInsight?.days?.find(d => d.day === dg.day);
        await itineraryApi.create(tripId, {
          day_number: nextDay++,
          date_label: `Day ${dg.day}`,
          title: aiDay?.title || (stayItem ? `${plan?.multiModal ? "Arrive at" : "Drive to"} ${stayItem.name}` : `Day ${dg.day}${plan?.multiModal ? "" : ` - Route Day`}`),
          notes: aiDay ? `${aiDay.theme || ""}${aiDay.morningTip ? "  -  " + aiDay.morningTip : ""}` : (plan?.multiModal ? `Multi-modal Day ${dg.day}` : `Route Day - ${Math.round((dg.distEnd - dg.distStart) / 1000)}km`),
          place_names: placeNames,
        });
      }
      await reload();
      setTab("places");
    } catch (e) {
      alert("Error adding plan: " + e.message);
    } finally {
      setAdding(false);
    }
  };

  const filtered = useMemo(
    () => filterStatus === "all" ? places : places.filter(p => p.status === filterStatus),
    [places, filterStatus]
  );
  const planCategoryCounts = useMemo(() => {
    if (!plan?.milestones?.length) return {};
    return plan.milestones.reduce((acc, m) => {
      acc[m.category] = (acc[m.category] || 0) + 1;
      return acc;
    }, {});
  }, [plan]);

  const roadmapCacheBadge = useMemo(() => {
    if (aiAvailable === false) return null;
    if (!trip?.ai_roadmap) return null;
    try {
      const cached = JSON.parse(trip.ai_roadmap);
      const fresh = cached?.signature ? cached.signature === roadmapSignature(trip, routeStart, routeDestination) : true;
      if (!cached?.plan || !cached?.insight || !fresh) return null;
      return cached?.generated_at ? `Precomputed  -  ${new Date(cached.generated_at).toLocaleString()}` : "Precomputed roadmap ready";
    } catch {
      return null;
    }
  }, [trip, aiAvailable]);

  const warmupBadge = useMemo(() => {
    if (!warmItem) return null;
    const base = warmItem.state === "fresh"
      ? { text: "Warmup Fresh", color: t.green, bg: t.greenSoft || t.accentSoft, border: `${t.green}44` }
      : warmItem.state === "stale"
        ? { text: "Warmup Pending", color: t.amber, bg: `${t.amber}22`, border: `${t.amber}44` }
        : { text: "Warmup Invalid", color: t.red, bg: t.redSoft, border: `${t.red}44` };
    const flags = `${warmItem.ai_ready ? "AI ok" : "AI..."}  -  ${warmItem.livemap_ready ? "Map ok" : "Map..."}`;
    return { ...base, text: `${base.text} (${flags})` };
  }, [warmItem, t]);

  const aiUsageBadge = useMemo(() => {
    const insight = aiInsight || cachedRoadmap?.insight;
    if (!insight) return null;
    if (insight.__ai_used === true) {
      const c = t.cyan || t.accent;
      return { text: `AI Used${insight.__ai_provider ? `  -  ${insight.__ai_provider}` : ""}`, color: c, bg: `${c}22`, border: `${c}55` };
    }
    if (insight.__ai_used === false) {
      return { text: "AI Fallback", color: t.amber, bg: `${t.amber}22`, border: `${t.amber}55` };
    }
    return null;
  }, [aiInsight, cachedRoadmap, t]);

  const aiConfigBadge = useMemo(() => {
    if (aiAvailable !== false) return null;
    return { text: "AI Not Configured", color: t.red, bg: t.redSoft, border: `${t.red}55` };
  }, [aiAvailable, t]);

  // â”€â”€ Render â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
  return (
    <>
      <div className="fade-up">

        {/* Header */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20, flexWrap: "wrap", gap: 10 }}>
          <div>
            <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>Planner</div>
            <div style={{ color: t.textSub, fontSize: 13, marginTop: 3 }}>
              {trip ? `${routeDestination || trip.destination || "No destination"}  -  ${places.length} places  -  ${days.length} days` : "Select a trip"}
            </div>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <select value={tripId} onChange={setTripId}
              style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 9, padding: "8px 12px", color: t.text, fontSize: 13, fontFamily: "inherit", outline: "none" }}>
              {trips.map(tr => <option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name}</option>)}
            </select>
            {tripId && tab !== "route" && (
              <Btn dark={dark} onClick={() => tab === "places" ? openAdd() : openAddDay()}>
                + Add {tab === "places" ? "Place" : "Day"}
              </Btn>
            )}
          </div>
        </div>

        {/* Tab bar */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16, flexWrap: "wrap", gap: 10 }}>
          <Tabs dark={dark} tabs={[{ value: "places", label: "Places" }, { value: "itinerary", label: "Itinerary" }, { value: "route", label: "✨ AI Roadmap" }]} active={tab} onChange={setTab} />
          {tab === "places" && places.length > 0 && (
            <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
              {["all", "planned", "upcoming", "visited", "skipped"].map(s => (
                <button key={s} onClick={() => setFilterStatus(s)}
                  style={{ padding: "5px 11px", borderRadius: 6, fontSize: 11, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", textTransform: "capitalize", background: filterStatus === s ? t.accent : t.surface, color: filterStatus === s ? "#fff" : t.textSub, border: `1px solid ${filterStatus === s ? t.accent : t.border}`, transition: "all .15s" }}>
                  {s}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Content */}
        {!tripId ? (
          <Empty icon="🗺️" text="Select a trip to start planning" />
        ) : loading ? (
          <div style={{ display: "flex", justifyContent: "center", padding: 60 }}><Spinner dark={dark} /></div>

        ) : tab === "places" ? (
          filtered.length === 0 ? (
            <Empty icon="📍" text="No Places Yet" sub="Click '+ Add Place' or use the AI Roadmap tab" />
          ) : (
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(270px,1fr))", gap: 14 }}>
              {filtered.map(p => (
                <Card key={p.id} dark={dark} className="fade-in" style={{ position: "relative", padding: "22px 16px 16px" }}>
                  <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 3, background: SC(p.status, t), borderRadius: "16px 16px 0 0" }} />
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                    <div style={{ flex: 1, marginRight: 8 }}>
                      <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 2, color: t.text }}>{p.name}</div>
                      <div style={{ fontSize: 11, color: t.textSub }}>{p.place_type}</div>
                    </div>
                    <Badge dark={dark} color={SC(p.status, t)}>{p.status}</Badge>
                  </div>
                  {p.address && <div style={{ fontSize: 12, color: t.textSub, marginBottom: 2 }}>{p.address}</div>}
                  {p.visit_time && <div style={{ fontSize: 12, color: t.textSub, marginBottom: 2 }}>Time: {p.visit_time}</div>}
                  {p.rating && <div style={{ fontSize: 13, color: t.amber, marginBottom: 4 }}>{"*".repeat(Math.round(p.rating))}{".".repeat(5 - Math.round(p.rating))} <span style={{ color: t.textSub, fontSize: 11 }}>{p.rating}</span></div>}
                  {p.notes && <div style={{ fontSize: 12, color: t.textSub, marginBottom: 6, fontStyle: "italic" }}>"{p.notes}"</div>}
                  {(p.latitude && p.longitude) && (
                    <div style={{ fontSize: 10, color: t.accent, background: t.accentSoft, padding: "2px 8px", borderRadius: 5, display: "inline-block", marginBottom: 6 }}>
                      {parseFloat(p.latitude).toFixed(4)}, {parseFloat(p.longitude).toFixed(4)}
                    </div>
                  )}
                  <div style={{ display: "flex", gap: 6, marginTop: 8 }}>
                    <button onClick={() => markVisited(p)} disabled={togglingPlaceId === p.id}
                      style={{ flex: 1, padding: "7px 4px", borderRadius: 7, border: `1px solid ${p.status === "visited" ? t.green + "44" : t.border}`, background: p.status === "visited" ? t.greenSoft : "transparent", color: p.status === "visited" ? t.green : t.textSub, cursor: togglingPlaceId === p.id ? "wait" : "pointer", fontSize: 11, fontFamily: "inherit", fontWeight: 600, transition: "all .15s", opacity: togglingPlaceId === p.id ? 0.7 : 1 }}>
                      {togglingPlaceId === p.id ? <span style={{display:"inline-flex",alignItems:"center",gap:6}}><span style={{width:12,height:12,border:`2px solid ${t.border}`,borderTopColor:t.accent,borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite"}}/>Updating</span> : (p.status === "visited" ? "ok Visited" : "Mark Visited")}
                    </button>
                    <button onClick={() => openEdit(p)} disabled={deletingPlaceId === p.id}
                      style={{ padding: "7px 10px", borderRadius: 7, border: `1px solid ${t.border}`, background: "none", color: t.textSub, cursor: deletingPlaceId === p.id ? "not-allowed" : "pointer", fontSize: 13, transition: "all .15s", opacity: deletingPlaceId === p.id ? 0.5 : 1 }}
                      onMouseEnter={e => { if (deletingPlaceId !== p.id) { e.currentTarget.style.borderColor = t.accent; e.currentTarget.style.color = t.accent; } }}
                      onMouseLeave={e => { e.currentTarget.style.borderColor = t.border; e.currentTarget.style.color = t.textSub; }}>
                      Edit
                    </button>
                    <button onClick={() => rmPlace(p.id)} disabled={deletingPlaceId === p.id}
                      style={{ padding: "7px 10px", borderRadius: 7, border: `1px solid ${t.red}33`, background: t.redSoft, color: t.red, cursor: deletingPlaceId === p.id ? "wait" : "pointer", fontSize: 13, opacity: deletingPlaceId === p.id ? 0.7 : 1, minWidth: 42 }}>
                      {deletingPlaceId === p.id ? <span style={{width:12,height:12,border:`2px solid ${t.red}55`,borderTopColor:t.red,borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite"}}/> : "Del"}
                    </button>
                  </div>
                </Card>
              ))}
            </div>
          )

        ) : tab === "itinerary" ? (
          days.length === 0 ? (
            <Empty icon="📅" text="No Itinerary Yet" sub="Generate an AI Roadmap to auto-fill your itinerary" />
          ) : (
            <div className="itinerary-list">
              {days.map(d => (
                <Card key={d.id} dark={dark} className="itinerary-card" style={{ position: "relative", padding: 16 }}>
                  <div className="itinerary-bar" style={{ background: `linear-gradient(90deg,${t.accent}88,${(t.cyan || t.accent)}55)` }} />
                  <div className="itinerary-head">
                    <div className="itinerary-day" style={{ background: t.accentSoft, border: `1px solid ${t.accent}44` }}>
                      <div className="itinerary-day-label" style={{ color: t.accent }}>Day</div>
                      <div className="itinerary-day-num" style={{ color: t.text }}>{d.day_number}</div>
                      {d.date_label && <div className="itinerary-day-date" style={{ color: t.textSub }}>{d.date_label}</div>}
                    </div>
                    <div className="itinerary-main">
                      <div className="itinerary-title" style={{ color: t.text }}>{d.title}</div>
                      {d.notes && <div className="itinerary-notes" style={{ color: t.textSub }}>{d.notes}</div>}
                    </div>
                    <div className="itinerary-actions">
                      <button onClick={() => openEditDay(d)} className="itinerary-btn"
                        disabled={deletingDayId === d.id}
                        style={{ border: `1px solid ${t.border}`, color: t.textSub, opacity: deletingDayId === d.id ? 0.5 : 1 }}>
                        Edit
                      </button>
                      <button onClick={() => rmDay(d.id)} className="itinerary-btn danger"
                        disabled={deletingDayId === d.id}
                        style={{ border: `1px solid ${t.red}33`, background: t.redSoft, color: t.red, opacity: deletingDayId === d.id ? 0.7 : 1 }}>
                        {deletingDayId === d.id ? <span style={{width:12,height:12,border:`2px solid ${t.red}55`,borderTopColor:t.red,borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite"}}/> : "Del"}
                      </button>
                    </div>
                  </div>
                  {d.places_list && d.places_list.length > 0 && (
                    <div className="itinerary-places">
                      {d.places_list.map((pl, i) => (
                        <span key={i} className="itinerary-place"
                          style={{ background: t.accentSoft, border: `1px solid ${t.accent}33`, color: t.accent }}>
                          {pl}
                        </span>
                      ))}
                    </div>
                  )}
                </Card>
              ))}
            </div>
          )

        ) : tab === "route" ? (
          <div>
            {(!routeStart || !routeDestination) ? (
              <div style={{ textAlign: "center", padding: "60px 20px" }}>
                <div style={{ fontSize: 52, marginBottom: 16 }}>Map</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: t.text, marginBottom: 8 }}>No Route Set</div>
                <div style={{ fontSize: 13, color: t.textSub, maxWidth: 340, margin: "0 auto", lineHeight: 1.7 }}>
                  Edit your trip and set both a <strong style={{ color: t.accent }}>Start Location</strong> and <strong style={{ color: t.accent }}>Destination</strong> to unlock your AI-powered road plan.
                </div>
              </div>
            ) : (
              <>
                {/* Route header */}
                <div style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: 14, padding: "16px 20px", marginBottom: 18, display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                  <div style={{ flex: 1, minWidth: 200 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 8, flexWrap: "wrap" }}>
                      <div style={{ fontSize: 11, color: t.textSub, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".06em" }}>AI Roadmap</div>
                      {roadmapCacheBadge && (
                        <div style={{ fontSize: 10, color: t.green, background: t.greenSoft || t.accentSoft, border: `1px solid ${t.green}44`, borderRadius: 99, padding: "2px 8px", fontWeight: 700 }}>
                          {roadmapCacheBadge}
                        </div>
                      )}
                      {warmupBadge && (
                        <div style={{ fontSize: 10, color: warmupBadge.color, background: warmupBadge.bg, border: `1px solid ${warmupBadge.border}`, borderRadius: 99, padding: "2px 8px", fontWeight: 700 }}>
                          {warmupBadge.text}
                        </div>
                      )}
                      {aiConfigBadge && (
                        <div style={{ fontSize: 10, color: aiConfigBadge.color, background: aiConfigBadge.bg, border: `1px solid ${aiConfigBadge.border}`, borderRadius: 99, padding: "2px 8px", fontWeight: 700 }}>
                          {aiConfigBadge.text}
                        </div>
                      )}
                      {aiUsageBadge && (
                        <div style={{ fontSize: 10, color: aiUsageBadge.color, background: aiUsageBadge.bg, border: `1px solid ${aiUsageBadge.border}`, borderRadius: 99, padding: "2px 8px", fontWeight: 700 }}>
                          {aiUsageBadge.text}
                        </div>
                      )}
                      {warmStatusLoading && (
                        <div style={{ fontSize: 10, color: t.textSub }}>
                          Checking warmup...
                        </div>
                      )}
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", marginBottom: 6 }}>
                      <span style={{ background: t.accentSoft, color: t.accent, padding: "4px 12px", borderRadius: 20, fontSize: 12, fontWeight: 600 }}>From: {routeStart}</span>
                      <span style={{ color: t.textSub, fontSize: 20 }}>{"->"}</span>
                      <span style={{ background: t.greenSoft || t.accentSoft, color: t.green || t.accent, padding: "4px 12px", borderRadius: 20, fontSize: 12, fontWeight: 600 }}>To: {routeDestination}</span>
                    </div>
                    {plan && (
                      <div style={{ fontSize: 12, color: t.textSub, display: "flex", gap: 14, flexWrap: "wrap" }}>
                        <span>Distance: {plan.distKm} km</span>
                        <span>Time: ~{Math.floor(plan.durH)}h {Math.round((plan.durH % 1) * 60)}m driving</span>
                        <span>Plan Items: {plan.milestones.length}</span>
                      </div>
                    )}
                  </div>
                  <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
                    <button
                      onClick={() => { planFetchedRef.current = ""; generatePlan(routeStart, routeDestination, true); }}
                      disabled={planLoading || aiAvailable === false}
                      style={{ padding: "8px 16px", borderRadius: 9, border: `1px solid ${t.border}`, background: t.surface, color: t.text, cursor: (planLoading || aiAvailable === false) ? "default" : "pointer", fontSize: 12, fontWeight: 600, fontFamily: "inherit", transition: "all .15s" }}>
                      {aiAvailable === false ? "AI Not Configured" : (planLoading ? "Generating..." : plan ? "Regenerate" : "Generate Plan")}
                    </button>
                    {plan && plan.milestones.length > 0 && (
                      <button onClick={addPlanToTrip} disabled={adding}
                        style={{ padding: "8px 18px", borderRadius: 9, border: "none", background: `linear-gradient(135deg,${t.accent},${t.accentDeep})`, color: "#fff", cursor: adding ? "default" : "pointer", fontSize: 12, fontWeight: 700, fontFamily: "inherit" }}>
                        {adding ? "Adding..." : "+ Add All to Trip"}
                      </button>
                    )}
                  </div>
                </div>

                {/* Loading */}
                {planLoading && (
                  <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 16, padding: "50px 20px" }}>
                    <div style={{ position: "relative", width: 56, height: 56 }}>
                      <div style={{ position: "absolute", inset: 0, border: `3px solid ${t.border}`, borderTopColor: t.accent, borderRadius: "50%", animation: "spin .7s linear infinite" }} />
                      <div style={{ position: "absolute", inset: 8, border: `2px solid ${t.border}`, borderBottomColor: t.cyan || t.accent, borderRadius: "50%", animation: "spin 1.2s linear infinite reverse" }} />
                    </div>
                    <div style={{ fontSize: 14, color: t.text, fontWeight: 600 }}>{planProgress || "Generating AI roadmap..."}</div>
                    <div style={{ fontSize: 12, color: t.textSub, textAlign: "center", maxWidth: 280, lineHeight: 1.65 }}>
                      Building route context, then asking AI to generate the full plan with stays, food, visits, and travel guidance.
                    </div>
                  </div>
                )}

                {/* Error */}
                {planErr && !planLoading && (
                  <div style={{ background: t.redSoft, border: `1px solid ${t.red}33`, borderRadius: 10, padding: "14px 18px", color: t.red, fontSize: 13 }}>{planErr}</div>
                )}
                {!plan && !planLoading && !planErr && (
                  <div style={{ textAlign: "center", padding: "28px 16px", color: t.textSub, fontSize: 13, lineHeight: 1.7 }}>
                    Roadmap is being prepared in background and saved to cloud cache. You can wait here or tap <strong style={{ color: t.accent }}>Generate Plan</strong> to fetch immediately.
                  </div>
                )}

                {/* AI Insight Banner */}
                {plan && !planLoading && aiInsight && (
                  <div style={{ background: `linear-gradient(135deg,${t.accent}12,${t.cyan || t.accent}08)`, border: `1px solid ${t.accent}35`, borderRadius: 16, padding: "18px 20px", marginBottom: 20 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 10 }}>
                      <span style={{ fontSize: 20 }}>AI</span>
                      <span style={{ fontSize: 12, fontWeight: 700, color: t.accent, textTransform: "uppercase", letterSpacing: ".06em" }}>AI Travel Analysis</span>
                    </div>
                    <div style={{ fontSize: 13, color: t.text, lineHeight: 1.8, marginBottom: 14 }}>{typeof aiInsight.tripInsight === "string" ? aiInsight.tripInsight : JSON.stringify(aiInsight.tripInsight)}</div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(180px,1fr))", gap: 10, marginBottom: 14 }}>
                      {[
                        { icon: "🕐", label: "Best Departure", value: aiInsight.bestTimeToLeave },
                        { icon: "⛽", label: "Fuel Estimate", value: aiInsight.estimatedFuelCost },
                        { icon: "🌤", label: "Weather", value: aiInsight.weatherNote },
                        { icon: "✈️", label: "Transit Options", value: aiInsight.smartTravelOptions },
                        { icon: "🏨", label: "Fuel & Stay", value: aiInsight.fuelAndStayTips },
                        { icon: "💰", label: "Budget Alert", value: aiInsight.budgetAlert },
                        { icon: "🎒", label: "Packing Reminder", value: aiInsight.packingReminder },
                      ].filter(x => x.value).map(({ icon, label, value }) => (
                        <div key={label} style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: 10, padding: "10px 14px" }}>
                          <div style={{ fontSize: 11, color: t.textSub, marginBottom: 3 }}>{icon} {label}</div>
                          <div style={{ fontSize: 12, color: t.text, fontWeight: 600, lineHeight: 1.4 }}>{typeof value === "string" ? value : value?.name || value?.text || JSON.stringify(value)}</div>
                        </div>
                      ))}
                    </div>
                    {aiInsight.travelTips?.length > 0 && (
                      <div>
                        <div style={{ fontSize: 11, color: t.textSub, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".05em", marginBottom: 8 }}>Pro Tips</div>
                        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
                          {aiInsight.travelTips.map((tip, i) => (
                            <div key={i} style={{ display: "flex", gap: 8, fontSize: 12, color: t.text, lineHeight: 1.55 }}>
                              <span style={{ color: t.accent, flexShrink: 0, marginTop: 1 }}>{"->"}</span>
                              <span>{typeof tip === "string" ? tip : tip?.name || tip?.text || JSON.stringify(tip)}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Day-by-day roadmap */}
                {plan && !planLoading && plan.days.length > 0 && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
                    {plan.days.map((dg, di) => {
                      const aiDay = aiInsight?.days?.find(d => d.day === dg.day);
                      return (
                        <div key={di}>
                          {/* Day header */}
                          <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 12 }}>
                            <div style={{ background: `linear-gradient(135deg,${t.accent},${t.accentDeep})`, borderRadius: 10, padding: "7px 18px", fontSize: 13, fontWeight: 800, color: "#fff", flexShrink: 0, letterSpacing: ".02em" }}>
                              Day {dg.day}
                            </div>
                            <div style={{ flex: 1 }}>
                              {aiDay ? (
                                <>
                                  <div style={{ fontWeight: 700, fontSize: 14, color: t.text, lineHeight: 1.2 }}>{aiDay.title}</div>
                                  <div style={{ fontSize: 11, color: t.accent, fontWeight: 600, marginTop: 2 }}>{aiDay.theme}</div>
                                </>
                              ) : (
                                <div style={{ fontSize: 12, color: t.textSub, fontStyle: "italic" }}>Details not returned by AI — tap <strong style={{ color: t.accent }}>Regenerate</strong> to get the full plan.</div>
                              )}
                            </div>
                            <div style={{ fontSize: 11, color: t.textSub, flexShrink: 0, background: t.surface, border: `1px solid ${t.border}`, borderRadius: 6, padding: "3px 9px" }}>
                              {plan?.multiModal
                                ? (aiDay?.journeyMode
                                    ? ({"flight":"✈️ Flight","train":"🚆 Train","ferry":"🛳️ Ferry","driving":"🚗 Drive","mixed":"🔀 Multi"}[aiDay.journeyMode.toLowerCase()] || ("🗺️ " + aiDay.journeyMode))
                                    : "🗺️ Multi-modal")
                                : `~${Math.round((dg.distEnd - dg.distStart) / 1000)} km`}
                            </div>
                          </div>

                          {/* AI tips row */}
                          {aiDay && (
                            <div style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: 12, padding: "12px 16px", marginBottom: 12 }}>
                              {/* Morning / Evening / Stay row */}
                              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(150px,1fr))", gap: 12, marginBottom: (aiDay.highlights?.length || aiDay.meals?.length) ? 12 : 0 }}>
                                {aiDay.morningTip && (
                                  <div>
                                    <div style={{ fontSize: 10, color: t.amber, fontWeight: 700, marginBottom: 3, textTransform: "uppercase", letterSpacing: ".04em" }}>🌅 Morning</div>
                                    <div style={{ fontSize: 12, color: t.text, lineHeight: 1.5 }}>{aiDay.morningTip}</div>
                                  </div>
                                )}
                                {aiDay.eveningTip && (
                                  <div>
                                    <div style={{ fontSize: 10, color: t.violet || t.accent, fontWeight: 700, marginBottom: 3, textTransform: "uppercase", letterSpacing: ".04em" }}>🌆 Evening</div>
                                    <div style={{ fontSize: 12, color: t.text, lineHeight: 1.5 }}>{aiDay.eveningTip}</div>
                                  </div>
                                )}
                                {aiDay.stayRecommendation && (
                                  <div>
                                    <div style={{ fontSize: 10, color: "#34D399", fontWeight: 700, marginBottom: 3, textTransform: "uppercase", letterSpacing: ".04em" }}>🏨 Stay</div>
                                    <div style={{ fontSize: 12, color: t.text, lineHeight: 1.5 }}>{typeof aiDay.stayRecommendation === "string" ? aiDay.stayRecommendation : aiDay.stayRecommendation?.name || String(aiDay.stayRecommendation)}</div>
                                  </div>
                                )}
                              </div>
                              {/* Highlights */}
                              {aiDay.highlights?.length > 0 && (
                                <div style={{ marginBottom: aiDay.meals?.length ? 10 : 0 }}>
                                  <div style={{ fontSize: 10, color: t.accent, fontWeight: 700, marginBottom: 6, textTransform: "uppercase", letterSpacing: ".04em" }}>🏛️ Must-See</div>
                                  <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
                                    {aiDay.highlights.map((h, hi) => (
                                      <div key={hi} style={{ fontSize: 11, color: t.text, background: t.card, border: `1px solid ${t.border}`, borderRadius: 7, padding: "4px 10px", lineHeight: 1.4 }}>
                                        {typeof h === "string" ? h : h?.name || h?.location || h?.text || JSON.stringify(h)}
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              )}
                              {/* Meals */}
                              {aiDay.meals?.length > 0 && (
                                <div>
                                  <div style={{ fontSize: 10, color: "#FCD34D", fontWeight: 700, marginBottom: 6, textTransform: "uppercase", letterSpacing: ".04em" }}>🍽️ Meals</div>
                                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                                    {["🌄 Breakfast", "☀️ Lunch", "🌙 Dinner"].map((label, mi) => aiDay.meals[mi] ? (
                                      <div key={mi} style={{ fontSize: 11, background: t.card, border: `1px solid ${t.border}`, borderRadius: 7, padding: "4px 10px" }}>
                                        <span style={{ color: t.textSub }}>{label}: </span>
                                        <span style={{ color: t.text, fontWeight: 600 }}>{typeof aiDay.meals[mi] === "string" ? aiDay.meals[mi] : aiDay.meals[mi]?.name || aiDay.meals[mi]?.location || JSON.stringify(aiDay.meals[mi])}</span>
                                      </div>
                                    ) : null)}
                                  </div>
                                </div>
                              )}
                            </div>
                          )}

                          {/* Milestone timeline */}
                          <div style={{ display: "flex", flexDirection: "column", gap: 8, paddingLeft: 18, borderLeft: `2px solid ${t.border}` }}>
                            {dg.items.length === 0 && (
                              <div style={{ padding: "14px 16px", borderRadius: 10, background: t.surface, border: `1px solid ${t.border}`, fontSize: 12, color: t.textSub, fontStyle: "italic" }}>
                                No stops generated for this day — tap <strong style={{ color: t.accent }}>Regenerate</strong> to get a full itinerary for all days.
                              </div>
                            )}
                            {dg.items.map((m, mi) => {
                              const cs = getCatStyle(m.category, dark);
                              return (
                                <div key={mi}
                                  style={{ display: "flex", alignItems: "flex-start", gap: 12, background: t.card, border: `1px solid ${cs.border}`, borderRadius: 12, padding: "12px 14px", position: "relative", transition: "transform .18s, box-shadow .18s" }}
                                  onMouseEnter={e => { e.currentTarget.style.transform = "translateX(5px)"; e.currentTarget.style.boxShadow = `0 6px 24px ${cs.color}20`; }}
                                  onMouseLeave={e => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}>
                                  {/* Timeline dot */}
                                  <div style={{ position: "absolute", left: -25, top: 14, width: 12, height: 12, borderRadius: "50%", background: cs.color, border: `2px solid ${t.bg}`, boxShadow: `0 0 8px ${cs.color}70` }} />
                                  {/* Category badge */}
                                  <div style={{ flexShrink: 0, textAlign: "center", minWidth: 54 }}>
                                    <div style={{ fontSize: 20, marginBottom: 2 }}>{CAT_ICONS[m.category]}</div>
                                    <div style={{ fontSize: 9, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".04em", color: cs.color, background: cs.bg, border: `1px solid ${cs.border}`, borderRadius: 5, padding: "1px 5px" }}>
                                      {CAT_LABEL[m.category]}
                                    </div>
                                    <div style={{ fontSize: 10, color: t.textSub, marginTop: 4 }}>{Math.round(m.distM / 1000)} km</div>
                                  </div>
                                  {/* Details */}
                                  <div style={{ flex: 1, minWidth: 0 }}>
                                    <div style={{ fontWeight: 700, fontSize: 13, color: t.text, marginBottom: 3, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.name}</div>
                                    {m.addr && <div style={{ fontSize: 11, color: t.textSub, marginBottom: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>📍 {m.addr}</div>}
                                    {m.note && <div style={{ fontSize: 11, color: t.textDim || t.textSub, marginBottom: 2, lineHeight: 1.4 }}>💡 {m.note}</div>}
                                    {m.hours && <div style={{ fontSize: 11, color: t.textSub, marginBottom: 2 }}>🕐 {m.hours}</div>}
                                    {m.phone && <div style={{ fontSize: 11, color: t.textSub }}>📞 {m.phone}</div>}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}

                    {/* Return journey card */}
                    <div style={{ background: `linear-gradient(135deg,${t.green || t.accent}12,${t.accent}08)`, border: `1px solid ${t.green || t.accent}35`, borderRadius: 14, padding: "18px 20px" }}>
                      <div style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
                        <div style={{ fontSize: 12, fontWeight: 700, color: t.textSub }}>Return</div>
                        <div>
                          <div style={{ fontWeight: 700, fontSize: 14, color: t.text, marginBottom: 5 }}>Return Journey</div>
                          <div style={{ fontSize: 13, color: t.textSub, lineHeight: 1.7 }}>
                            {plan?.multiModal
                              ? <>Your return from <strong style={{ color: t.accent }}>{routeDestination}</strong> to <strong style={{ color: t.accent }}>{routeStart}</strong>. {aiInsight?.smartTravelOptions || "Book return flights or transport in advance for best fares."}</>
                              : <>Your return from <strong style={{ color: t.accent }}>{routeDestination}</strong> to <strong style={{ color: t.accent }}>{routeStart}</strong> is {plan.distKm} km (~{Math.floor(plan.durH)}h driving). {aiInsight?.travelTips?.[0] ? aiInsight.travelTips[0] : "Use the same stops in reverse  -  pre-book hotels for a smooth return."}</>
                            }
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Summary */}
                    <div style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: 14, padding: "16px 20px" }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: t.text, marginBottom: 12 }}>Plan Summary</div>
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 14 }}>
                        {Object.entries(planCategoryCounts).map(([cat, count]) => {
                          const cs = getCatStyle(cat, dark);
                          return (
                            <div key={cat} style={{ display: "flex", alignItems: "center", gap: 6, background: t.card, border: `1px solid ${cs.border}`, borderRadius: 8, padding: "6px 12px" }}>
                              <span>{CAT_ICONS[cat]}</span>
                              <span style={{ fontSize: 12, color: t.text, fontWeight: 600 }}>{count} {CAT_LABEL[cat]}{count > 1 ? "s" : ""}</span>
                            </div>
                          );
                        })}
                      </div>
                      <div style={{ fontSize: 12, color: t.textSub, lineHeight: 1.6 }}>
                        Click <strong style={{ color: t.accent }}>Add All to Trip</strong> to save all {plan.milestones.length} AI plan items to your Places and auto-build your itinerary.
                      </div>
                    </div>
                  </div>
                )}

                {plan && plan.milestones.length === 0 && !planLoading && (
                  <div style={{ textAlign: "center", padding: "40px 20px" }}>
                    <div style={{ fontSize: 36, marginBottom: 12 }}>Done</div>
                    <div style={{ fontSize: 13, color: t.textSub }}>AI returned a minimal plan for this route. Regenerate to get more suggestions.</div>
                  </div>
                )}
              </>
            )}
          </div>
        ) : null}

        {/* Add/Edit Place modal */}
        {showPlace && (
          <Modal dark={dark} title={editingPlace ? "Edit Place" : "Add Place"} onClose={() => setShowPlace(false)}>
            <form onSubmit={savePlace} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div>
                <div style={{ fontSize: 11, fontWeight: 600, color: t.textSub, display: "block", marginBottom: 5, textTransform: "uppercase", letterSpacing: ".06em" }}>Place Name *</div>
                <PlaceSearchInput value={pf.name} onChange={v => setPf(f => ({ ...f, name: v }))}
                  onSelect={place => {
                    if (!place) { setPlaceVerified(false); return; }
                    setPf(f => ({ ...f, name: place.name, address: place.address || f.address, latitude: place.lat || f.latitude, longitude: place.lng || f.longitude, place_type: place.type || f.place_type }));
                    setPlaceVerified(true);
                  }}
                  contextCity={trip?.destination || ""} placeholder="Search e.g. Eiffel Tower, Taj Mahal..." dark={dark} required />
              </div>
              <Select dark={dark} label="Type" value={pf.place_type} onChange={sp("place_type")} options={PLACE_TYPES} />
              <LocationInput dark={dark} label="Address" value={pf.address} onChange={v => setPf(f => ({ ...f, address: v }))} onSelect={s => setPf(f => ({ ...f, address: s.label, latitude: String(s.lat), longitude: String(s.lng) }))} placeholder="Optional full address" zIndex={5000} />
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))", gap: 12 }}>
                <Input dark={dark} label="Visit Time" value={pf.visit_time} onChange={sp("visit_time")} placeholder="09:30 AM" />
                <Input dark={dark} label="Rating (0-5)" type="number" value={pf.rating} onChange={sp("rating")} placeholder="4.8" />
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))", gap: 12 }}>
                <Input dark={dark} label="Latitude" type="number" value={pf.latitude} onChange={sp("latitude")} placeholder="26.9157" />
                <Input dark={dark} label="Longitude" type="number" value={pf.longitude} onChange={sp("longitude")} placeholder="70.9083" />
              </div>
              <Select dark={dark} label="Status" value={pf.status} onChange={sp("status")} options={STATUSES} />
              <Input dark={dark} label="Notes" value={pf.notes} onChange={sp("notes")} placeholder="Any tips or notes" />
              <ErrorMsg msg={err} />
              <Btn dark={dark} type="submit" size="lg" loading={saving} style={{ justifyContent: "center" }}>
                {editingPlace ? "Save Changes" : "Add Place"}
              </Btn>
            </form>
          </Modal>
        )}

        {/* Add/Edit Day modal */}
        {showDay && (
          <Modal dark={dark} title={editingDay ? "Edit Day" : "Add Itinerary Day"} onClose={() => setShowDay(false)}>
            <form onSubmit={saveDay} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(160px,1fr))", gap: 12 }}>
                <Input dark={dark} label="Day Number" type="number" value={df.day_number} onChange={sd("day_number")} required />
                <Input dark={dark} label="Date / Label" value={df.date_label} onChange={sd("date_label")} placeholder="Dec 18" />
              </div>
              <Input dark={dark} label="Day Title" value={df.title} onChange={sd("title")} placeholder="Heritage Walk through Old City" required />
              <Input dark={dark} label="Places (comma-separated)" value={df.place_names} onChange={sd("place_names")} placeholder="Jaisalmer Fort, Patwon Ki Haveli" />
              <Input dark={dark} label="Notes / Tips" value={df.notes} onChange={sd("notes")} placeholder="Start early to beat the heat." />
              <ErrorMsg msg={err} />
              <Btn dark={dark} type="submit" size="lg" loading={saving} style={{ justifyContent: "center" }}>
                {editingDay ? "Save Changes" : "Add Day"}
              </Btn>
            </form>
          </Modal>
        )}
      </div>
    </>
  );
}
