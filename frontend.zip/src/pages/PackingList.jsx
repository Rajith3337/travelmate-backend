import { useState, useEffect, useRef } from "react";
import { tripsApi, checklistApi } from "../api/client";
import { Btn, Empty, ProgressBar, Modal } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";
import useActiveTrip from "../hooks/useActiveTrip";

const TEMPLATES = {
  beach:      ["👙 Swimwear","🕶️ Sunglasses","☀️ Sunscreen SPF 50+","🩴 Flip flops","🏖️ Beach towel","🎣 Snorkel gear","👒 Sun hat","💊 Sea-sickness tablets"],
  mountain:   ["🥾 Trekking boots","🧥 Thermal layers","🧤 Gloves","🎿 Ski jacket","🔦 Headlamp","🏕️ First aid kit","🧴 Altitude meds","🗺️ Physical map"],
  city:       ["🎒 Day backpack","📷 Camera","🚇 Metro card","🔌 Universal adapter","💳 Travel card","👟 Comfortable shoes","☂️ Umbrella","📱 Phone charger"],
  business:   ["👔 Formal shirts","💼 Laptop bag","📁 Documents folder","👞 Dress shoes","🪥 Grooming kit","⌚ Watch","🪪 Business cards","🔋 Power bank"],
  essentials: ["🛂 Passport","✈️ Flight tickets","🏨 Hotel booking","💊 Medications","💳 Cards","📱 Smartphone","🔌 Chargers","🧳 Luggage lock","📋 Travel insurance","💵 Emergency cash"],
};
const CATEGORIES = ["Essentials","Clothing","Toiletries","Electronics","Health","Entertainment","Snacks","Other"];
const CAT_ICONS  = { Essentials:"🌍", Clothing:"👕", Toiletries:"🧴", Electronics:"🔌", Health:"💊", Entertainment:"🎮", Snacks:"🍫", Other:"📦" };

function Confetti() {
  const ref = useRef();
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const colors = ["#38BDF8","#34D399","#FBBF24","#F43F5E","#818CF8","#FB923C"];
    for (let i = 0; i < 70; i++) {
      const p = document.createElement("div");
      const size = Math.random() * 9 + 4;
      p.style.cssText = `position:absolute;width:${size}px;height:${size}px;background:${colors[Math.floor(Math.random()*colors.length)]};border-radius:${Math.random()>.5?"50%":"3px"};left:${Math.random()*100}%;top:-10px;pointer-events:none;`;
      el.appendChild(p);
      const anim = p.animate([
        { transform:`translateY(0) rotate(0deg)`, opacity:1 },
        { transform:`translateY(${350+Math.random()*200}px) rotate(${Math.random()*720}deg)`, opacity:0 }
      ], { duration:1600+Math.random()*1000, easing:"ease-in", delay:Math.random()*600 });
      anim.onfinish = () => p.remove();
    }
  }, []);
  return <div ref={ref} style={{position:"fixed",inset:0,pointerEvents:"none",zIndex:9999,overflow:"hidden"}}/>;
}

export default function PackingList({ dark = true }) {
  const t = dark ? DARK : LIGHT;
  const [trips, setTrips]               = useState([]);
  const [tripId, setTripId]             = useActiveTrip();
  const [items, setItems]               = useState([]);
  const [loading, setLoading]           = useState(false);
  const [saving, setSaving]             = useState(false);
  const [togglingId, setTogglingId]     = useState(null);
  const [deletingId, setDeletingId]     = useState(null);
  const [clearingDone, setClearingDone] = useState(false);
  const [showAdd, setShowAdd]           = useState(false);
  const [form, setForm]                 = useState({ text:"", category:"Essentials" });
  const [filter, setFilter]             = useState("all");
  const [search, setSearch]             = useState("");
  const [showTemplate, setShowTemplate] = useState(false);
  const [showImport, setShowImport]     = useState(false);
  const [confetti, setConfetti]         = useState(false);
  const prevAllPacked                   = useRef(false);

  useEffect(() => {
    tripsApi.list().then(d => { setTrips(d); if (!localStorage.getItem("tm_active_trip") && d.length) setTripId(String(d[0].id)); });
  }, []);

  useEffect(() => {
    if (!tripId) return;
    setLoading(true);
    checklistApi.list(tripId).then(setItems).finally(() => setLoading(false));
  }, [tripId]);

  useEffect(() => {
    const handler = e => {
      const d = e?.detail || {};
      if (d.type === "checklist" && String(d.tripId) === String(tripId)) {
        checklistApi.list(tripId).then(setItems).catch(() => {});
      }
      if (d.type === "trips") {
        tripsApi.list().then(setTrips).catch(() => {});
      }
    };
    window.addEventListener("tm_data_updated", handler);
    return () => window.removeEventListener("tm_data_updated", handler);
  }, [tripId]);

  const checkAllPacked = (newItems) => {
    const allPacked = newItems.length > 0 && newItems.every(i => i.done);
    if (allPacked && !prevAllPacked.current) { setConfetti(true); setTimeout(() => setConfetti(false), 2600); }
    prevAllPacked.current = allPacked;
  };

  const addItem = async () => {
    if (!form.text.trim() || !tripId) return;
    setSaving(true);
    try {
      const created = await checklistApi.create(tripId, { text: form.text.trim(), category: form.category, order_idx: items.length });
      const newItems = [...items, created];
      setItems(newItems); checkAllPacked(newItems);
      setForm({ text:"", category:"Essentials" }); setShowAdd(false);
    } finally { setSaving(false); }
  };

  const toggle = async (item) => {
    setTogglingId(item.id);
    try {
      const updated = await checklistApi.update(tripId, item.id, { done: !item.done });
      const newItems = items.map(i => i.id === updated.id ? updated : i);
      setItems(newItems); checkAllPacked(newItems);
    } finally {
      setTogglingId(null);
    }
  };

  const remove = async (id) => {
    setDeletingId(id);
    try {
      await checklistApi.delete(tripId, id);
      setItems(items.filter(i => i.id !== id));
    } finally {
      setDeletingId(null);
    }
  };

  const clearDone = async () => {
    if (!confirm("Remove all checked items?")) return;
    setClearingDone(true);
    try {
      const done = items.filter(i => i.done);
      await Promise.all(done.map(i => checklistApi.delete(tripId, i.id)));
      setItems(items.filter(i => !i.done));
    } finally {
      setClearingDone(false);
    }
  };

  const addTemplate = async (tplKey) => {
    setSaving(true);
    try {
      const tpl = TEMPLATES[tplKey];
      const existing = new Set(items.map(i => i.text));
      const created = await Promise.all(
        tpl.filter(t => !existing.has(t)).map((text, idx) =>
          checklistApi.create(tripId, { text, category:"Essentials", order_idx: items.length + idx })
        )
      );
      setItems([...items, ...created]);
    } finally { setSaving(false); setShowTemplate(false); }
  };

  const importFromTrip = async (srcId) => {
    const src = await checklistApi.list(srcId);
    if (!src.length) return alert("That trip has no checklist items.");
    const existing = new Set(items.map(i => i.text));
    setSaving(true);
    try {
      const created = await Promise.all(
        src.filter(i => !existing.has(i.text)).map((item, idx) =>
          checklistApi.create(tripId, { text: item.text, category: item.category, order_idx: items.length + idx })
        )
      );
      setItems([...items, ...created]);
    } finally { setSaving(false); setShowImport(false); }
  };

  const exportList = () => {
    const trip = trips.find(tr => String(tr.id) === tripId);
    const lines = CATEGORIES.map(cat => {
      const ci = items.filter(i => i.category === cat);
      if (!ci.length) return null;
      return `${CAT_ICONS[cat]} ${cat}\n` + ci.map(i => `  [${i.done?"x":" "}] ${i.text}`).join("\n");
    }).filter(Boolean).join("\n\n");
    const blob = new Blob([`${trip?.name || "Packing List"}\n${"=".repeat(30)}\n\n${lines}`], { type:"text/plain" });
    const a = document.createElement("a"); a.href = URL.createObjectURL(blob); a.download = "packing-list.txt"; a.click();
  };

  const packed   = items.filter(i => i.done).length;
  const progress = items.length ? (packed / items.length) * 100 : 0;
  let displayed  = [...items];
  if (search)  displayed = displayed.filter(i => i.text.toLowerCase().includes(search.toLowerCase()));
  if (filter === "packed")   displayed = displayed.filter(i => i.done);
  if (filter === "unpacked") displayed = displayed.filter(i => !i.done);
  const byCat = CATEGORIES.reduce((a, c) => { a[c] = displayed.filter(i => i.category === c); return a; }, {});

  const cardSt = { background:t.card, border:`1px solid ${t.border}`, borderRadius:14, padding:"16px 18px" };
  const inpSt  = { background:t.surface, border:`1px solid ${t.border}`, borderRadius:9, padding:"8px 11px", color:t.text, fontSize:13, outline:"none", fontFamily:"inherit", width:"100%", boxSizing:"border-box" };

  return (
    <>
      {confetti && <Confetti />}
      <div className="fade-up">
        {/* Header */}
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:20,flexWrap:"wrap",gap:10}}>
          <div>
            <div style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>🧳 Packing List</div>
            <div style={{color:t.textSub,fontSize:13,marginTop:3}}>
              {packed}/{items.length} packed
              {progress === 100 && items.length > 0 && <span style={{color:t.green,marginLeft:8}}>🎉 All packed!</span>}
            </div>
          </div>
          <div style={{display:"flex",gap:8,flexWrap:"wrap",alignItems:"center"}}>
            <select value={tripId} onChange={e => setTripId(e.target.value)}
              style={{background:t.card,border:`1px solid ${t.border}`,borderRadius:9,padding:"8px 12px",color:t.text,fontSize:13,fontFamily:"inherit",outline:"none"}}>
              {trips.map(tr => <option key={tr.id} value={tr.id}>{tr.cover_emoji} {tr.name}</option>)}
            </select>
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="🔍 Search…"
              style={{...inpSt,width:130,padding:"8px 10px"}}/>
            {items.some(i => i.done) && <Btn size="sm" variant="ghost" onClick={clearDone} loading={clearingDone} dark={dark}>🗑️ Clear Done</Btn>}
            {items.length > 0 && <Btn size="sm" variant="ghost" onClick={exportList} dark={dark}>📤 Export</Btn>}
            <Btn size="sm" variant="ghost" onClick={() => setShowImport(true)} dark={dark}>📥 Import</Btn>
            <Btn size="sm" variant="ghost" onClick={() => setShowTemplate(true)} dark={dark}>📋 Templates</Btn>
            <Btn size="sm" onClick={() => setShowAdd(true)} dark={dark}>+ Add Item</Btn>
          </div>
        </div>

        {/* Progress bar */}
        {items.length > 0 && (
          <div style={{...cardSt, marginBottom:16}}>
            <div style={{display:"flex",justifyContent:"space-between",marginBottom:10,alignItems:"center"}}>
              <div style={{fontWeight:600,color:t.text}}>Packing Progress</div>
              <span style={{fontWeight:700,color:progress===100?t.green:t.accent}}>{Math.round(progress)}%</span>
            </div>
            <ProgressBar value={progress} color={progress===100?t.green:t.accent} height={10} dark={dark}/>
            <div style={{display:"flex",gap:16,marginTop:10,fontSize:12,color:t.textSub,flexWrap:"wrap",alignItems:"center"}}>
              <span>✅ {packed} packed</span><span>📦 {items.length - packed} remaining</span>
              <span style={{flex:1}}/>
              <div style={{display:"flex",gap:5}}>
                {["all","unpacked","packed"].map(f => (
                  <button key={f} onClick={() => setFilter(f)}
                    style={{padding:"4px 11px",borderRadius:6,fontSize:11,fontWeight:600,cursor:"pointer",fontFamily:"inherit",textTransform:"capitalize",
                      background:filter===f?t.accent:"transparent",color:filter===f?"#fff":t.textSub,
                      border:`1px solid ${filter===f?t.accent:t.border}`,transition:"all .15s"}}>
                    {f}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Category stats pills */}
        {items.length > 0 && (
          <div style={{display:"flex",gap:8,marginBottom:16,overflowX:"auto",paddingBottom:4}}>
            {CATEGORIES.filter(cat => items.filter(i=>i.category===cat).length > 0).map(cat => {
              const total = items.filter(i => i.category === cat).length;
              const done  = items.filter(i => i.category === cat && i.done).length;
              const allDone = done === total;
              return (
                <div key={cat} style={{display:"flex",alignItems:"center",gap:5,padding:"4px 12px",borderRadius:99,
                  background:allDone?`${t.green}15`:t.card,border:`1px solid ${allDone?t.green+"44":t.border}`,
                  whiteSpace:"nowrap",flexShrink:0}}>
                  <span style={{fontSize:13}}>{CAT_ICONS[cat]}</span>
                  <span style={{fontSize:11,fontWeight:600,color:allDone?t.green:t.textSub}}>{cat}</span>
                  <span style={{fontSize:10,color:allDone?t.green:t.accent,fontWeight:700}}>{done}/{total}</span>
                </div>
              );
            })}
          </div>
        )}

        {/* Items list */}
        {loading ? (
          <div style={{display:"flex",justifyContent:"center",padding:60}}>
            <div style={{width:32,height:32,border:`3px solid ${t.border}`,borderTopColor:t.accent,borderRadius:"50%",animation:"spin 1s linear infinite"}}/>
          </div>
        ) : items.length === 0 ? (
          <Empty icon="🧳" text="Empty packing list" sub="Add items manually or load a template" dark={dark}
            action={<Btn onClick={() => setShowTemplate(true)} dark={dark}>📋 Use Template</Btn>}/>
        ) : (
          <div style={{display:"flex",flexDirection:"column",gap:16}}>
            {CATEGORIES.map(cat => {
              const catItems = byCat[cat];
              if (!catItems?.length) return null;
              const catPacked = catItems.filter(i => i.done).length;
              return (
                <div key={cat}>
                  <div style={{fontSize:12,fontWeight:700,color:t.textSub,textTransform:"uppercase",letterSpacing:".08em",marginBottom:8,display:"flex",gap:8,alignItems:"center"}}>
                    <span>{CAT_ICONS[cat]}</span>
                    <span style={{flex:1}}>{cat}</span>
                    <span style={{color:catPacked===catItems.length?t.green:t.accent}}>{catPacked}/{catItems.length}</span>
                  </div>
                  <div style={{display:"flex",flexDirection:"column",gap:5}}>
                    {catItems.map(item => (
                      <div key={item.id} className="fade-in"
                        style={{display:"flex",alignItems:"center",gap:12,padding:"10px 14px",
                          background:item.done?`${t.green}08`:t.card,
                          border:`1px solid ${item.done?t.green+"33":t.border}`,
                          borderRadius:10,transition:"all .22s"}}>
                        <button onClick={() => toggle(item)} disabled={togglingId === item.id}
                          style={{width:24,height:24,borderRadius:7,border:`2px solid ${item.done?t.green:t.border}`,
                            background:item.done?t.green:"transparent",color:"#fff",cursor:"pointer",fontSize:13,
                            display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,
                            transition:"all .2s",boxShadow:item.done?`0 0 10px ${t.green}44`:"none",opacity:togglingId === item.id ? 0.6 : 1}}>
                          {togglingId === item.id ? <span style={{width:10,height:10,border:`2px solid ${t.border}`,borderTopColor:t.accent,borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite"}}/> : (item.done && "✓")}
                        </button>
                        <div style={{flex:1,minWidth:0,wordBreak:"break-word",fontSize:14,fontWeight:item.done?400:500,color:item.done?t.textSub:t.text,textDecoration:item.done?"line-through":"none",transition:"all .2s"}}>{item.text}</div>
                        <button onClick={() => remove(item.id)} disabled={deletingId === item.id}
                          style={{padding:"4px 8px",borderRadius:6,border:`1px solid ${t.red}33`,background:"transparent",color:t.red,cursor:deletingId === item.id ? "wait" : "pointer",fontSize:12,opacity:deletingId === item.id ? 0.8 : .5,transition:"opacity .15s",minWidth:30,display:"flex",alignItems:"center",justifyContent:"center"}}
                          onMouseEnter={e=>{ if (deletingId !== item.id) e.currentTarget.style.opacity="1"; }} onMouseLeave={e=>{ if (deletingId !== item.id) e.currentTarget.style.opacity=".5"; }}>
                          {deletingId === item.id ? <span style={{width:10,height:10,border:`2px solid ${t.red}55`,borderTopColor:t.red,borderRadius:"50%",display:"inline-block",animation:"spin .7s linear infinite"}}/> : "🗑️"}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {/* Add Item Modal */}
        {showAdd && (
          <Modal title="➕ Add Packing Item" width={400} dark={dark} onClose={()=>setShowAdd(false)}>
            <div style={{display:"flex",flexDirection:"column",gap:12}}>
              <div>
                <label style={{fontSize:11,fontWeight:600,color:t.textSub,display:"block",marginBottom:4}}>ITEM *</label>
                <input value={form.text} onChange={e=>setForm(f=>({...f,text:e.target.value}))}
                  onKeyDown={e=>e.key==="Enter"&&addItem()} placeholder="e.g. Passport" autoFocus style={inpSt}/>
              </div>
              <div>
                <label style={{fontSize:11,fontWeight:600,color:t.textSub,display:"block",marginBottom:4}}>CATEGORY</label>
                <select value={form.category} onChange={e=>setForm(f=>({...f,category:e.target.value}))} style={inpSt}>
                  {CATEGORIES.map(c=><option key={c} value={c}>{CAT_ICONS[c]} {c}</option>)}
                </select>
              </div>
              <div style={{display:"flex",gap:8,marginTop:6}}>
                <button onClick={()=>setShowAdd(false)} style={{flex:1,padding:"10px",borderRadius:10,border:`1px solid ${t.border}`,background:"transparent",color:t.textSub,cursor:"pointer",fontFamily:"inherit",fontSize:13}}>Cancel</button>
                <Btn onClick={addItem} loading={saving} dark={dark} style={{flex:2,justifyContent:"center"}}>Add Item</Btn>
              </div>
            </div>
          </Modal>
        )}

        {/* Template Modal */}
        {showTemplate && (
          <Modal title="📋 Load Template" width={420} dark={dark} onClose={()=>setShowTemplate(false)}>
            <div style={{display:"flex",flexDirection:"column",gap:10}}>
              {Object.entries(TEMPLATES).map(([key,tpl])=>(
                <div key={key} onClick={()=>addTemplate(key)}
                  style={{background:t.surface,border:`1px solid ${t.border}`,borderRadius:12,padding:"13px 15px",cursor:"pointer",transition:"all .15s",display:"flex",justifyContent:"space-between",alignItems:"center"}}
                  onMouseEnter={e=>{e.currentTarget.style.borderColor=t.accent;e.currentTarget.style.background=`${t.accent}0D`;}}
                  onMouseLeave={e=>{e.currentTarget.style.borderColor=t.border;e.currentTarget.style.background=t.surface;}}>
                  <div>
                    <div style={{fontWeight:700,fontSize:13,marginBottom:4,textTransform:"capitalize",color:t.text}}>
                      {key==="beach"?"🏖️":key==="mountain"?"🏔️":key==="city"?"🏙️":key==="business"?"💼":"🌍"} {key} Trip
                    </div>
                    <div style={{fontSize:11,color:t.textSub}}>{tpl.slice(0,3).join(" · ")}…</div>
                  </div>
                  <span style={{fontSize:11,color:t.accent,fontWeight:700,whiteSpace:"nowrap"}}>{tpl.length} items</span>
                </div>
              ))}
            </div>
          </Modal>
        )}

        {/* Import from Trip Modal */}
        {showImport && (
          <Modal title="📥 Import from Another Trip" width={380} dark={dark} onClose={()=>setShowImport(false)}>
            <div style={{fontSize:12,color:t.textSub,marginBottom:14}}>Copy checklist items from another trip (synced to backend)</div>
            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              {trips.filter(tr=>String(tr.id)!==tripId).map(tr=>(
                <div key={tr.id} onClick={()=>importFromTrip(tr.id)}
                  style={{background:t.surface,border:`1px solid ${t.border}`,borderRadius:10,padding:"11px 14px",cursor:"pointer",display:"flex",alignItems:"center",gap:10,transition:"all .15s"}}
                  onMouseEnter={e=>e.currentTarget.style.borderColor=t.accent}
                  onMouseLeave={e=>e.currentTarget.style.borderColor=t.border}>
                  <span style={{fontSize:20}}>{tr.cover_emoji}</span>
                  <div><div style={{fontWeight:600,fontSize:13,color:t.text}}>{tr.name}</div><div style={{fontSize:11,color:t.textSub}}>{tr.destination}</div></div>
                </div>
              ))}
              {trips.filter(tr=>String(tr.id)!==tripId).length===0&&<div style={{textAlign:"center",color:t.textSub,fontSize:13,padding:20}}>No other trips found</div>}
            </div>
          </Modal>
        )}
      </div>
    </>
  );
}
