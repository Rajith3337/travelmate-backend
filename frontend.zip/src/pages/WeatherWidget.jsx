import { useState, useEffect, useRef, useCallback } from "react";
import { tripsApi } from "../api/client";
import { Spinner } from "../components/UI";
import { DARK, LIGHT } from "../styles/theme";
import useActiveTrip from "../hooks/useActiveTrip";

/* ── WMO weather code maps ── */
const WMO_DESC = {
  0:"Clear sky",1:"Mainly clear",2:"Partly cloudy",3:"Overcast",
  45:"Fog",48:"Icy fog",51:"Light drizzle",53:"Drizzle",55:"Heavy drizzle",
  61:"Slight rain",63:"Rain",65:"Heavy rain",71:"Slight snow",73:"Snow",
  75:"Heavy snow",77:"Snow grains",80:"Slight showers",81:"Showers",
  82:"Heavy showers",85:"Slight snow showers",86:"Heavy snow showers",
  95:"Thunderstorm",96:"Thunderstorm + hail",99:"Thunderstorm + heavy hail",
};
const WMO_ICON = {
  0:"☀️",1:"🌤️",2:"⛅",3:"☁️",45:"🌫️",48:"🌫️",
  51:"🌦️",53:"🌦️",55:"🌧️",61:"🌧️",63:"🌧️",65:"🌧️",
  71:"❄️",73:"❄️",75:"❄️",77:"🌨️",80:"🌦️",81:"🌧️",82:"⛈️",
  85:"🌨️",86:"🌨️",95:"⛈️",96:"⛈️",99:"⛈️",
};

// Night variants — replace sun with moon for codes 0/1/2 (clear/mainly-clear/partly-cloudy)
const WMO_ICON_NIGHT = { ...WMO_ICON, 0:"🌙", 1:"🌙", 2:"🌙" };

function getWeatherIcon(code, sunriseIso, sunsetIso) {
  const now  = Date.now();
  const rise = sunriseIso ? new Date(sunriseIso).getTime() : null;
  const set  = sunsetIso  ? new Date(sunsetIso).getTime()  : null;
  const isNight = (rise && set) ? (now < rise || now > set) : new Date().getHours() < 6 || new Date().getHours() >= 19;
  return (isNight ? WMO_ICON_NIGHT : WMO_ICON)[code] || "🌡️";
}

const PACK_TIPS = {
  hot:  ["🧴 Sunscreen SPF50+","🩴 Sandals","🕶️ Sunglasses","💧 Extra water","🧢 Wide hat","👕 Light breathable clothing"],
  warm: ["👕 Light clothing","🌂 Umbrella","☀️ Sunscreen","🕶️ Sunglasses"],
  mild: ["🧥 Light jacket","☂️ Umbrella","👟 Comfortable shoes","👕 Layering clothes"],
  cool: ["🧥 Warm jacket","🧤 Gloves","🥾 Boots","🧣 Scarf"],
  cold: ["🧥 Heavy coat","🧣 Scarf","🧤 Gloves","🥾 Insulated boots","🧦 Thermal socks","❄️ Hand warmers"],
};

function timeoutSignal(ms) {
  if (typeof AbortSignal !== "undefined" && typeof AbortSignal.timeout === "function") {
    return { signal: AbortSignal.timeout(ms), cleanup: () => {} };
  }
  const ctrl = new AbortController();
  const id = setTimeout(() => ctrl.abort(), ms);
  return { signal: ctrl.signal, cleanup: () => clearTimeout(id) };
}

async function fetchJson(url, { timeoutMs = 20000, headers, retries = 1 } = {}) {
  let lastError = null;
  for (let attempt = 0; attempt <= retries; attempt++) {
    const { signal, cleanup } = timeoutSignal(timeoutMs);
    try {
      const r = await fetch(url, { headers, signal });
      if (!r.ok) {
        let errText = `Request failed (${r.status})`;
        try {
          const d = await r.json();
          if (d.reason) errText += `: ${d.reason}`;
        } catch (e) {
          /* ignore */
        }
        const e = new Error(errText);
        e.status = r.status;
        throw e;
      }
      return await r.json();
    } catch (ex) {
      lastError = ex;
      const status = Number(ex?.status || 0);
      const msg = (ex?.message || "").toString();
      const timeoutish = ex?.name === "AbortError" || ex?.name === "TimeoutError" || /timed out/i.test(msg);
      const retryableHttp = status === 429 || status >= 500;
      const retryableNet = /Failed to fetch/i.test(msg) || /NetworkError/i.test(msg);
      if (attempt < retries && (timeoutish || retryableHttp || retryableNet)) {
        await new Promise(res => setTimeout(res, 600 * (attempt + 1)));
        continue;
      }
      throw ex;
    } finally {
      cleanup();
    }
  }
  throw lastError || new Error("Request failed");
}

function normalizeFetchError(ex) {
  const msg = (ex?.message || "").toString();
  const name = (ex?.name || "").toString();
  if (name === "AbortError" || name === "TimeoutError" || /timed out/i.test(msg)) {
    return "Request timed out — check your internet and tap “Get Weather” again.";
  }
  if (/Request failed \(429\)/.test(msg)) {
    return "Weather service rate-limited — please wait a moment and try again.";
  }
  if (/Request failed \(5\d\d\)/.test(msg)) {
    return "Weather service is temporarily unavailable — try again in a bit.";
  }
  if (/Failed to fetch/i.test(msg) || /NetworkError/i.test(msg)) {
    return "Network error — check your internet and try again.";
  }
  return msg || "Something went wrong.";
}

/* ── Geocoding via backend proxy (avoids CORS) ── */
async function geocode(city) {
  if (!city || !city.trim()) throw new Error("No city name provided.");
  const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";
  const url = `${BASE}/api/v1/weather/geocode?city=${encodeURIComponent(city.trim())}`;
  const d = await fetchJson(url, { timeoutMs: 18000, retries: 1 });
  const results = d?.results;
  if (!Array.isArray(results) || results.length === 0) {
    throw new Error(`"${city}" not found — try a different spelling or nearby city.`);
  }
  const r = results[0];
  const lat = r?.latitude ?? r?.lat;
  const lng = r?.longitude ?? r?.lon ?? r?.lng;
  if (lat == null || lng == null || !Number.isFinite(Number(lat)) || !Number.isFinite(Number(lng))) {
    throw new Error(`Could not get coordinates for "${city}". Try a more specific name.`);
  }
  return {
    lat: Number(lat),
    lng: Number(lng),
    name: r.name || city,
    country: r.country || "",
  };
}

/* ── Autocomplete suggestions via backend proxy ── */
async function searchCities(query) {
  if (query.length < 2) return [];
  const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";
  const url = `${BASE}/api/v1/weather/geocode?city=${encodeURIComponent(query)}`;
  const d = await fetchJson(url, { timeoutMs: 12000, retries: 0 });
  return (d?.results || []).map(x => ({
    label: [x.name, x.admin1, x.country].filter(Boolean).join(", "),
    lat: x.latitude ?? x.lat,
    lng: x.longitude ?? x.lon ?? x.lng,
    country: x.country || "",
  }));
}

/* ── Live weather from backend proxy (avoids CORS) ── */
async function fetchWeather(lat, lng) {
  if (lat == null || lng == null || !Number.isFinite(Number(lat)) || !Number.isFinite(Number(lng))) {
    throw new Error(`Invalid coordinates: lat=${lat}, lng=${lng}`);
  }
  const BASE = import.meta.env.VITE_API_URL || "http://localhost:8000";
  const url = `${BASE}/api/v1/weather/forecast?lat=${Number(lat)}&lng=${Number(lng)}`;
  return fetchJson(url, { timeoutMs: 22000, retries: 1 });
}

/* ── Helper: format wind direction ── */
function windDir(deg) {
  const dirs = ["N","NE","E","SE","S","SW","W","NW"];
  return dirs[Math.round(deg / 45) % 8];
}

/* ── UV color + label ── */
function uvInfo(uv) {
  if (uv < 3)  return { label: "Low",       color: "#10B981" };
  if (uv < 6)  return { label: "Moderate",  color: "#F59E0B" };
  if (uv < 8)  return { label: "High",      color: "#F97316" };
  if (uv < 11) return { label: "Very High", color: "#EF4444" };
  return         { label: "Extreme",   color: "#8B5CF6" };
}

/* ── Rain probability bar ── */
function RainBars({ hourly, t }) {
  // Show next 24 hours only, 3-hour buckets
  const now = new Date();
  const times = (hourly?.time || []).map((iso, i) => ({ iso, i }))
    .filter(({ iso }) => {
      const h = new Date(iso);
      return h >= now && h <= new Date(now.getTime() + 24 * 3600000);
    })
    .filter((_, idx) => idx % 3 === 0)
    .slice(0, 8);

  if (!times.length) return null;
  const max = 100;

  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: t.textSub, textTransform: "uppercase", letterSpacing: ".07em", marginBottom: 8 }}>
        Rain probability — next 24 h
      </div>
      <div style={{ display: "flex", gap: 6, alignItems: "flex-end", height: 72 }}>
        {times.map(({ iso, i }) => {
          const prob = hourly.precipitation_probability[i] ?? 0;
          const h = new Date(iso);
          const label = h.toLocaleTimeString("en-IN", { hour: "2-digit", hour12: true });
          const barColor = prob > 70 ? "#3B82F6" : prob > 40 ? "#60A5FA" : t.border;
          return (
            <div key={iso} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
              <div style={{ fontSize: 9, color: t.textSub, whiteSpace: "nowrap" }}>{prob}%</div>
              <div style={{ width: "100%", height: 48, display: "flex", alignItems: "flex-end", borderRadius: 4, overflow: "hidden", background: `${t.border}55` }}>
                <div style={{ width: "100%", height: `${Math.max(prob, 4)}%`, background: barColor, borderRadius: "4px 4px 0 0", transition: "height .5s cubic-bezier(.22,.68,0,1.2)", minHeight: prob > 0 ? 3 : 0 }} />
              </div>
              <div style={{ fontSize: 9, color: t.textSub, whiteSpace: "nowrap" }}>{label}</div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ── Hourly temperature mini-chart ── */
function TempLine({ hourly, color, t }) {
  const now = new Date();
  const pts = (hourly?.time || []).map((iso, i) => ({
    iso, i, temp: hourly.temperature_2m[i],
    h: new Date(iso),
  })).filter(p => p.h >= now && p.h <= new Date(now.getTime() + 24 * 3600000)).slice(0, 24);

  if (pts.length < 2) return null;
  const temps = pts.map(p => p.temp);
  const min = Math.min(...temps), max = Math.max(...temps);
  const range = max - min || 1;
  const W = 280, H = 50;
  const x = i => (i / (pts.length - 1)) * W;
  const y = v => H - ((v - min) / range) * (H - 10) - 4;
  const pathD = pts.map((p, i) => `${i === 0 ? "M" : "L"}${x(i).toFixed(1)},${y(p.temp).toFixed(1)}`).join(" ");

  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: t.textSub, textTransform: "uppercase", letterSpacing: ".07em", marginBottom: 8 }}>
        Hourly temperature — next 24 h
      </div>
      <svg width="100%" viewBox={`0 0 ${W} ${H + 20}`} style={{ overflow: "visible" }}>
        <path d={pathD} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
        {pts.filter((_, i) => i % 6 === 0).map((p, i, arr) => (
          <g key={p.iso}>
            <circle cx={x(pts.indexOf(p))} cy={y(p.temp)} r="3" fill={color} />
            <text x={x(pts.indexOf(p))} y={y(p.temp) - 8} textAnchor="middle" fontSize="9" fill={t.textSub} fontFamily="inherit">
              {Math.round(p.temp)}°
            </text>
            <text x={x(pts.indexOf(p))} y={H + 16} textAnchor="middle" fontSize="9" fill={t.textSub} fontFamily="inherit">
              {p.h.toLocaleTimeString("en-IN", { hour: "2-digit", hour12: true })}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

/* ── City autocomplete input ── */
function CityInput({ value, onChange, onSelect, placeholder, icon, t }) {
  const [suggestions, setSuggestions] = useState([]);
  const [open, setOpen] = useState(false);
  const [searching, setSearching] = useState(false);
  const debounceRef = useRef(null);
  const wrapRef = useRef(null);

  const handleChange = e => {
    const v = e.target.value;
    onChange(v);
    clearTimeout(debounceRef.current);
    if (v.length < 2) { setSuggestions([]); setOpen(false); return; }
    debounceRef.current = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await searchCities(v);
        setSuggestions(res);
        setOpen(res.length > 0);
      } catch {}
      setSearching(false);
    }, 400);
  };

  // Close on outside click
  useEffect(() => {
    const h = e => { if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", h);
    return () => document.removeEventListener("mousedown", h);
  }, []);

  return (
    <div ref={wrapRef} style={{ position: "relative", flex: 1, minWidth: 180 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, background: t.surface, border: `1px solid ${t.border}`, borderRadius: 10, padding: "8px 12px" }}>
        <span style={{ fontSize: 16, flexShrink: 0 }}>{icon}</span>
        <input value={value} onChange={handleChange} onFocus={() => suggestions.length && setOpen(true)}
          placeholder={placeholder}
          style={{ background: "transparent", border: "none", outline: "none", color: t.text, fontSize: 13, fontFamily: "inherit", width: "100%" }} />
        {searching && <span style={{ fontSize: 11, color: t.textSub }}>…</span>}
      </div>
      {open && suggestions.length > 0 && (
        <div style={{ position: "absolute", top: "calc(100% + 4px)", left: 0, right: 0, background: t.card, border: `1px solid ${t.border}`, borderRadius: 10, zIndex: 100, boxShadow: "0 8px 24px rgba(0,0,0,.25)", overflow: "hidden" }}>
          {suggestions.map((s, i) => (
            <div key={i} onClick={() => { onSelect(s); onChange(s.label.split(",")[0]); setOpen(false); }}
              style={{ padding: "10px 14px", cursor: "pointer", fontSize: 13, color: t.text, borderBottom: i < suggestions.length - 1 ? `1px solid ${t.border}` : "none", transition: "background .12s" }}
              onMouseEnter={e => e.currentTarget.style.background = t.cardHover}
              onMouseLeave={e => e.currentTarget.style.background = ""}>
              📍 {s.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ── Main WeatherCard component ── */
function WeatherCard({ city, country, data, label, color, dark, showHourly }) {
  const t = dark ? DARK : LIGHT;
  const c = data.current;
  const h = data.hourly;
  const daily = data.daily;

  // Approximate current hour values if missing from `current`
  const getHourlyVal = key => {
    if (!h?.time || !h?.[key]) return null;
    const now = Date.now();
    let bestIdx = 0, minDiff = Infinity;
    for (let i = 0; i < h.time.length; i++) {
      const diff = Math.abs(new Date(h.time[i]).getTime() - now);
      if (diff < minDiff) { minDiff = diff; bestIdx = i; }
    }
    return h[key][bestIdx];
  };

  const code = c.weather_code ?? c.weathercode;
  const temp = c.temperature_2m;
  const cUv = c.uv_index ?? getHourlyVal("uv_index") ?? daily?.uv_index_max?.[0] ?? 0;
  const cVis = c.visibility ?? getHourlyVal("visibility");
  const uv = uvInfo(cUv);
  const packType = temp > 35 ? "hot" : temp > 28 ? "warm" : temp > 20 ? "mild" : temp > 12 ? "cool" : "cold";
  const rain0 = daily?.precipitation_probability_max?.[0] || 0;
  const sunriseRaw = daily?.sunrise?.[0] || null;
  const sunsetRaw  = daily?.sunset?.[0]  || null;
  const sunrise = sunriseRaw ? new Date(sunriseRaw).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true }) : "—";
  const sunset  = sunsetRaw  ? new Date(sunsetRaw).toLocaleTimeString("en-IN",  { hour: "2-digit", minute: "2-digit", hour12: true }) : "—";
  const currentIcon = getWeatherIcon(code ?? 0, sunriseRaw, sunsetRaw);

  return (
    <div style={{ background: t.card, border: `1px solid ${color}33`, borderRadius: 18, overflow: "hidden", boxShadow: dark ? "0 4px 20px rgba(0,0,0,.3)" : "0 2px 10px rgba(0,0,0,.08)" }}>

      {/* Hero */}
      <div style={{ background: `${color}15`, padding: "18px 20px", borderBottom: `1px solid ${color}22` }}>
        <div style={{ fontSize: 10, color: color, fontWeight: 700, textTransform: "uppercase", letterSpacing: ".08em", marginBottom: 3 }}>{label}</div>
        <div style={{ fontWeight: 700, fontSize: 15, color: t.text, marginBottom: 10 }}>
          📍 {city}{country ? `, ${country}` : ""}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <span style={{ fontSize: 52, lineHeight: 1 }}>{currentIcon}</span>
          <div>
            <div style={{ fontSize: 42, fontWeight: 800, color: t.text, lineHeight: 1 }}>{Math.round(temp)}°C</div>
            <div style={{ fontSize: 12, color: t.textSub, marginTop: 3 }}>Feels like {Math.round(c.apparent_temperature)}°C</div>
            <div style={{ fontSize: 13, color: t.textSub, marginTop: 1 }}>{WMO_DESC[code] || "—"}</div>
          </div>
        </div>
      </div>

      {/* Stats grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(80px,1fr))", borderBottom: `1px solid ${t.border}` }}>
        {[
          ["💧", "Humidity",  `${c.relative_humidity_2m}%`],
          ["💨", "Wind",      `${Math.round((c.wind_speed_10m ?? c.windspeed_10m) || 0)} km/h ${windDir((c.wind_direction_10m ?? c.winddirection_10m) || 0)}`],
          ["🌧️", "Rain",      `${rain0}%`],
          ["☀️", "UV",        `${cUv.toFixed(0)} · ${uv.label}`],
        ].map(([icon, lbl, val], i) => (
          <div key={i} style={{ padding: "10px 6px", textAlign: "center", borderRight: i < 3 ? `1px solid ${t.border}` : "none" }}>
            <div style={{ fontSize: 14 }}>{icon}</div>
            <div style={{ fontSize: 10, color: t.textSub, marginTop: 2 }}>{lbl}</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: i === 3 ? uv.color : t.text, marginTop: 1 }}>{val}</div>
          </div>
        ))}
      </div>

      {/* Sunrise/Sunset + pressure/visibility */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill,minmax(80px,1fr))", borderBottom: `1px solid ${t.border}` }}>
        {[
          ["🌅", "Sunrise", sunrise],
          ["🌇", "Sunset",  sunset],
          ["🔽", "Pressure", `${Math.round(c.pressure_msl || 0)} hPa`],
          ["👁️", "Visibility", cVis != null ? `${(cVis / 1000).toFixed(0)} km` : "—"],
        ].map(([icon, lbl, val], i) => (
          <div key={i} style={{ padding: "9px 6px", textAlign: "center", borderRight: i < 3 ? `1px solid ${t.border}` : "none" }}>
            <div style={{ fontSize: 13 }}>{icon}</div>
            <div style={{ fontSize: 10, color: t.textSub, marginTop: 2 }}>{lbl}</div>
            <div style={{ fontSize: 11, fontWeight: 600, color: t.text, marginTop: 1 }}>{val}</div>
          </div>
        ))}
      </div>

      {/* 7-day forecast */}
      <div style={{ padding: "12px 16px", borderBottom: `1px solid ${t.border}` }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: t.textSub, textTransform: "uppercase", letterSpacing: ".07em", marginBottom: 8 }}>7-day forecast</div>
        <div style={{ display: "flex", gap: 5, overflowX: "auto", paddingBottom: 4 }}>
          {(daily?.time || []).map((day, i) => {
            const isToday = i === 0;
            return (
              <div key={i} style={{ flex: "0 0 58px", textAlign: "center", background: isToday ? `${color}18` : t.surface, borderRadius: 10, padding: "8px 4px", border: `1px solid ${isToday ? color + "44" : t.border}` }}>
                <div style={{ fontSize: 10, color: isToday ? color : t.textSub, fontWeight: isToday ? 700 : 400, marginBottom: 3 }}>
                  {isToday ? "Today" : new Date(day).toLocaleDateString("en-IN", { weekday: "short" })}
                </div>
                <div style={{ fontSize: 18, marginBottom: 3 }}>{WMO_ICON[(daily.weather_code || daily.weathercode || [])[i]] || "🌡️"}</div>
                <div style={{ fontSize: 11, fontWeight: 700, color: t.text }}>{Math.round(daily.temperature_2m_max[i])}°</div>
                <div style={{ fontSize: 10, color: t.textSub }}>{Math.round(daily.temperature_2m_min[i])}°</div>
                {(daily.precipitation_probability_max[i] || 0) > 20 && (
                  <div style={{ fontSize: 9, color: "#60A5FA", marginTop: 2 }}>{daily.precipitation_probability_max[i]}%</div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Hourly charts */}
      {showHourly && data.hourly && (
        <div style={{ padding: "14px 16px", borderBottom: `1px solid ${t.border}`, display: "flex", flexDirection: "column", gap: 18 }}>
          <TempLine hourly={data.hourly} color={color} t={t} />
          <RainBars hourly={data.hourly} t={t} />
        </div>
      )}

      {/* Packing tips */}
      <div style={{ padding: "12px 16px" }}>
        <div style={{ fontSize: 11, fontWeight: 700, color: t.textSub, textTransform: "uppercase", letterSpacing: ".07em", marginBottom: 7 }}>
          🎒 Pack for {packType} weather
        </div>
        <div style={{ display: "flex", gap: 5, flexWrap: "wrap" }}>
          {PACK_TIPS[packType].map(tip => (
            <span key={tip} style={{ fontSize: 11, padding: "3px 10px", borderRadius: 20, background: t.surface, border: `1px solid ${t.border}`, color: t.textSub }}>{tip}</span>
          ))}
          {rain0 > 40 && <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 20, background: `${color}10`, border: `1px solid ${color}44`, color: color }}>🌧️ Rain expected</span>}
        </div>
      </div>
    </div>
  );
}

/* ══════════════════════════════════════════
   Main page
══════════════════════════════════════════ */
export default function WeatherWidget({ destination, dark = true }) {
  const t = dark ? DARK : LIGHT;
  const [trips,      setTrips]      = useState([]);
  const [tripId,     setTripId]     = useActiveTrip();
  const [depCity,    setDepCity]    = useState("");
  const [arrCity,    setArrCity]    = useState(destination || "");
  const [depCoords,  setDepCoords]  = useState(null);
  const [arrCoords,  setArrCoords]  = useState(null);
  const [depWeather, setDepWeather] = useState(null);
  const [arrWeather, setArrWeather] = useState(null);
  const [depResolved,setDepResolved]= useState("");
  const [arrResolved,setArrResolved]= useState("");
  const [depCountry, setDepCountry] = useState("");
  const [arrCountry, setArrCountry] = useState("");
  const [loading,    setLoading]    = useState(false);
  const [err,        setErr]        = useState("");
  const [tab,        setTab]        = useState("forecast");
  const [showHourly, setShowHourly] = useState(false);
  const [lastFetch,  setLastFetch]  = useState(null);

  // Load trips and auto-set departure + destination from active trip
  useEffect(() => {
    tripsApi.list().then(d => {
      setTrips(d);
      const active = d.find(tr => tr.status === "active") || d[0];
      if (active) {
        setTripId(String(active.id));
        if (active.start_location) setDepCity(active.start_location);
        if (active.destination)    setArrCity(active.destination);
      }
    });
  }, []);

  // Auto-fetch when cities arrive from trip selection — use refs to avoid stale closure
  const depCityRef  = useRef(depCity);
  const arrCityRef  = useRef(arrCity);
  const depCoordsRef2 = useRef(depCoords);
  const arrCoordsRef2 = useRef(arrCoords);
  useEffect(() => { depCityRef.current  = depCity;  }, [depCity]);
  useEffect(() => { arrCityRef.current  = arrCity;  }, [arrCity]);
  useEffect(() => { depCoordsRef2.current = depCoords; }, [depCoords]);
  useEffect(() => { arrCoordsRef2.current = arrCoords; }, [arrCoords]);

  const prevArrCity = useRef("");
  useEffect(() => {
    if (arrCity && arrCity.length > 2 && arrCity !== prevArrCity.current) {
      prevArrCity.current = arrCity;
      // Use current ref values to avoid stale closure
      fetchBoth(depCityRef.current, arrCity, depCoordsRef2.current, null);
    }
  }, [arrCity]);

  const fetchBoth = useCallback(async (dep = depCity, arr = arrCity, dCoords = depCoords, aCoords = arrCoords) => {
    if (!arr.trim() && !dep.trim()) { setErr("Enter at least one city."); return; }
    setLoading(true); setErr("");
    let gotDep = false, gotArr = false;
    try {
      const tasks = [
        dep.trim() && (async () => {
          const g = dCoords || await geocode(dep);
          setDepCoords(g);
          const w = await fetchWeather(g.lat, g.lng);
          setDepWeather(w); gotDep = true;
          setDepResolved(g.name);
          setDepCountry(g.country);
        })(),
        arr.trim() && (async () => {
          const g = aCoords || await geocode(arr);
          setArrCoords(g);
          const w = await fetchWeather(g.lat, g.lng);
          setArrWeather(w); gotArr = true;
          setArrResolved(g.name);
          setArrCountry(g.country);
        })(),
      ].filter(Boolean);
      const settled = await Promise.allSettled(tasks);
      const hadError = settled.some(s => s.status === "rejected");
      if (hadError && !gotDep && !gotArr) {
        throw settled.find(s => s.status === "rejected")?.reason || new Error("Weather fetch failed");
      }
      if (hadError) {
        setErr("Some weather data could not be fetched. Showing available results.");
      }
      setLastFetch(new Date());
    } catch (ex) {
      setErr(normalizeFetchError(ex));
    } finally {
      setLoading(false);
    }
  }, [depCity, arrCity, depCoords, arrCoords]);

  const handleTripChange = e => {
    const id = e.target.value;
    setTripId(id);
    const tr = trips.find(x => String(x.id) === id);
    // Reset prevArrCity so the auto-fetch effect fires for the new trip's destination
    prevArrCity.current = "";
    setDepWeather(null); setArrWeather(null);
    if (tr?.start_location) { setDepCity(tr.start_location); setDepCoords(null); }
    if (tr?.destination)    { setArrCity(tr.destination);    setArrCoords(null); }
  };

  const handleDepSelect = s => { setDepCoords({ lat: s.lat, lng: s.lng, name: s.label.split(",")[0], country: s.country || "" }); };
  const handleArrSelect = s => { setArrCoords({ lat: s.lat, lng: s.lng, name: s.label.split(",")[0], country: s.country || "" }); };

  const tabBtn = id => ({
    padding: "7px 16px", borderRadius: 8, fontSize: 12,
    fontWeight: tab === id ? 600 : 400, cursor: "pointer", fontFamily: "inherit",
    background: tab === id ? t.card : "transparent",
    color: tab === id ? t.accent : t.textSub,
    border: tab === id ? `1px solid ${t.accent}33` : "1px solid transparent",
    transition: "all .14s",
  });

  const hasData = depWeather || arrWeather;

  return (
    <div className="page-enter" style={{}}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 20, flexWrap: "wrap", gap: 12 }}>
        <div>
          <h1 style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}>🌤️ Weather</h1>
          <div style={{ fontSize: 13, color: t.textSub }}>
            Live data · Open-Meteo API · 7-day · Hourly · UV
            {lastFetch && <span style={{ marginLeft: 10, color: t.textDim }}>· Updated {lastFetch.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true })}</span>}
          </div>
        </div>
        <select value={tripId} onChange={handleTripChange}
          style={{ background: t.surface, border: `1px solid ${t.border}`, borderRadius: 9, padding: "8px 12px", color: t.text, fontSize: 13, fontFamily: "inherit", outline: "none", cursor: "pointer" }}>
          <option value="">Select trip…</option>
          {trips.map(tr => <option key={tr.id} value={String(tr.id)}>{tr.cover_emoji} {tr.name}</option>)}
        </select>
      </div>

      {/* City inputs */}
      <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 16, padding: "16px 20px", marginBottom: 18 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <CityInput
            value={depCity} onChange={v => { setDepCity(v); setDepCoords(null); }}
            onSelect={handleDepSelect}
            placeholder="Departure city (optional)"
            icon="🛫" t={t}
          />
          <span style={{ color: t.textSub, fontSize: 20, flexShrink: 0 }}>→</span>
          <CityInput
            value={arrCity} onChange={v => { setArrCity(v); setArrCoords(null); }}
            onSelect={handleArrSelect}
            placeholder="Destination city *"
            icon="🛬" t={t}
          />
          <button onClick={() => fetchBoth()} disabled={loading}
            style={{ padding: "9px 20px", borderRadius: 10, background: `linear-gradient(135deg,${t.accent},${t.violet || "#7C3AED"})`, border: "none", color: "#fff", fontWeight: 700, fontSize: 13, cursor: loading ? "wait" : "pointer", fontFamily: "inherit", opacity: loading ? .7 : 1, flexShrink: 0 }}>
            {loading ? "Loading…" : "🔍 Get Weather"}
          </button>
        </div>
        {err && <div style={{ marginTop: 10, color: t.red, fontSize: 12, display: "flex", alignItems: "center", gap: 6 }}>⚠️ {err}</div>}
      </div>

      {/* Tab bar */}
      {hasData && !loading && (
        <div style={{ display: "flex", gap: 8, marginBottom: 18, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ display: "flex", gap: 3, background: t.surface, borderRadius: 10, padding: 3, border: `1px solid ${t.border}` }}>
            {[["forecast","📅 Forecast"], ...(depWeather && arrWeather ? [["compare","⚖️ Compare"]] : []), ["tips","🎒 Tips"]].map(([id, label]) => (
              <button key={id} onClick={() => setTab(id)} style={tabBtn(id)}>{label}</button>
            ))}
          </div>
          <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, color: t.textSub, cursor: "pointer", marginLeft: 6 }}>
            <input type="checkbox" checked={showHourly} onChange={e => setShowHourly(e.target.checked)} />
            Show hourly charts
          </label>
          <button onClick={() => fetchBoth(depCity, arrCity, null, null)}
            style={{ marginLeft: "auto", padding: "5px 12px", borderRadius: 8, background: "transparent", border: `1px solid ${t.border}`, color: t.textSub, cursor: "pointer", fontSize: 11, fontFamily: "inherit" }}>
            🔄 Refresh
          </button>
        </div>
      )}

      {/* Loading */}
      {loading && (
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 60, gap: 16 }}>
          <Spinner size={40} dark={dark} />
          <div style={{ color: t.textSub, fontSize: 13 }}>Fetching live weather data…</div>
        </div>
      )}

      {/* Forecast */}
      {!loading && tab === "forecast" && (
        <div style={{ display: "grid", gridTemplateColumns: depWeather && arrWeather ? "1fr 1fr" : "1fr", gap: 16 }}>
          {depWeather && <WeatherCard city={depResolved || depCity} country={depCountry} data={depWeather} label="Departure" color={t.accent} dark={dark} showHourly={showHourly} />}
          {arrWeather && <WeatherCard city={arrResolved || arrCity} country={arrCountry} data={arrWeather} label="Destination" color={t.green || "#10b981"} dark={dark} showHourly={showHourly} />}
        </div>
      )}

      {/* Compare */}
      {!loading && tab === "compare" && depWeather && arrWeather && (() => {
        const dc = depWeather.current, ac = arrWeather.current;
        const rows = [
          ["🌡️ Temperature",   `${Math.round(dc.temperature_2m)}°C`,          `${Math.round(ac.temperature_2m)}°C`],
          ["🤔 Feels like",    `${Math.round(dc.apparent_temperature)}°C`,     `${Math.round(ac.apparent_temperature)}°C`],
          ["💧 Humidity",      `${dc.relative_humidity_2m}%`,                  `${ac.relative_humidity_2m}%`],
          ["💨 Wind",          `${Math.round((dc.wind_speed_10m ?? dc.windspeed_10m) || 0)} km/h`,         `${Math.round((ac.wind_speed_10m ?? ac.windspeed_10m) || 0)} km/h`],
          ["☀️ UV Index",      `${(dc.uv_index ?? depWeather.hourly?.uv_index?.[0] ?? 0).toFixed(0)} — ${uvInfo(dc.uv_index ?? depWeather.hourly?.uv_index?.[0] ?? 0).label}`, `${(ac.uv_index ?? arrWeather.hourly?.uv_index?.[0] ?? 0).toFixed(0)} — ${uvInfo(ac.uv_index ?? arrWeather.hourly?.uv_index?.[0] ?? 0).label}`],
          ["🌧️ Rain today",    `${depWeather.daily?.precipitation_probability_max?.[0]||0}%`,       `${arrWeather.daily?.precipitation_probability_max?.[0]||0}%`],
          ["🔽 Pressure",      `${Math.round(dc.pressure_msl||0)} hPa`,        `${Math.round(ac.pressure_msl||0)} hPa`],
          ["📅 High / Low",    `${Math.round(depWeather.daily?.temperature_2m_max?.[0]||0)}° / ${Math.round(depWeather.daily?.temperature_2m_min?.[0]||0)}°`, `${Math.round(arrWeather.daily?.temperature_2m_max?.[0]||0)}° / ${Math.round(arrWeather.daily?.temperature_2m_min?.[0]||0)}°`],
        ];
        return (
          <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 18, overflow: "hidden" }}>
            <div style={{ display: "grid", gridTemplateColumns: "minmax(100px,160px) 1fr 1fr", background: t.surface, borderBottom: `1px solid ${t.border}` }}>
              <div style={{ padding: "12px 18px" }} />
              <div style={{ padding: "12px 18px", textAlign: "center", fontSize: 13, fontWeight: 700, color: t.accent }}>🛫 {depResolved || depCity}</div>
              <div style={{ padding: "12px 18px", textAlign: "center", fontSize: 13, fontWeight: 700, color: t.green || "#10b981" }}>🛬 {arrResolved || arrCity}</div>
            </div>
            {rows.map(([label, d, a], i) => (
              <div key={label} style={{ display: "grid", gridTemplateColumns: "minmax(100px,160px) 1fr 1fr", borderBottom: i < rows.length - 1 ? `1px solid ${t.border}` : "none" }}>
                <div style={{ padding: "11px 18px", fontSize: 12, color: t.textSub, fontWeight: 600 }}>{label}</div>
                <div style={{ padding: "11px 18px", textAlign: "center", fontSize: 13, fontWeight: 700, color: t.text }}>{d}</div>
                <div style={{ padding: "11px 18px", textAlign: "center", fontSize: 13, fontWeight: 700, color: t.text }}>{a}</div>
              </div>
            ))}
          </div>
        );
      })()}

      {/* Tips */}
      {!loading && tab === "tips" && arrWeather && (() => {
        const temp = arrWeather.current.temperature_2m;
        const packType = temp > 35 ? "hot" : temp > 28 ? "warm" : temp > 20 ? "mild" : temp > 12 ? "cool" : "cold";
        const uv = arrWeather.current.uv_index ?? arrWeather.hourly?.uv_index?.[0] ?? 0;
        const rain = (arrWeather.daily?.precipitation_probability_max?.[0] || 0) > 40;
        const uvI = uvInfo(uv);
        return (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 16, padding: "18px 20px" }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: t.text, marginBottom: 12 }}>🎒 Packing for {arrResolved || arrCity}</div>
              {PACK_TIPS[packType].map(tip => (
                <div key={tip} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 0", borderBottom: `1px solid ${t.border}`, fontSize: 13, color: t.text }}>{tip}</div>
              ))}
              {rain && (
                <div style={{ marginTop: 10, padding: "8px 12px", background: `${t.accent}10`, borderRadius: 10, fontSize: 13, color: t.accent }}>
                  🌧️ Rain expected — pack an umbrella!
                </div>
              )}
              {uv > 7 && (
                <div style={{ marginTop: 8, padding: "8px 12px", background: `${uvI.color}15`, borderRadius: 10, fontSize: 13, color: uvI.color }}>
                  ☀️ {uvI.label} UV ({uv.toFixed(0)}) — sunscreen essential!
                </div>
              )}
            </div>
            <div style={{ background: t.card, border: `1px solid ${t.border}`, borderRadius: 16, padding: "18px 20px" }}>
              <div style={{ fontWeight: 700, fontSize: 14, color: t.text, marginBottom: 12 }}>📅 Week ahead</div>
              {(arrWeather.daily?.time || []).map((day, i) => (
                <div key={day} style={{ display: "flex", alignItems: "center", gap: 10, padding: "7px 0", borderBottom: i < 6 ? `1px solid ${t.border}` : "none" }}>
                  <div style={{ fontSize: 12, color: t.textSub, width: 38, flexShrink: 0 }}>{i === 0 ? "Today" : new Date(day).toLocaleDateString("en-IN", { weekday: "short" })}</div>
                  <span style={{ fontSize: 18, flexShrink: 0 }}>{WMO_ICON[((arrWeather.daily.weather_code || arrWeather.daily.weathercode || [])[i])] || "🌡️"}</span>
                  <div style={{ flex: 1, fontSize: 11, color: t.textSub }}>{WMO_DESC[((arrWeather.daily.weather_code || arrWeather.daily.weathercode || [])[i])] || ""}</div>
                  <div style={{ fontSize: 12, fontWeight: 700, color: t.text, flexShrink: 0 }}>
                    {Math.round(arrWeather.daily.temperature_2m_max[i])}° / {Math.round(arrWeather.daily.temperature_2m_min[i])}°
                  </div>
                  {(arrWeather.daily.precipitation_probability_max[i] || 0) > 20 && (
                    <div style={{ fontSize: 11, color: "#60A5FA", width: 28, textAlign: "right" }}>{arrWeather.daily.precipitation_probability_max[i]}%</div>
                  )}
                </div>
              ))}
            </div>
          </div>
        );
      })()}

      {/* Empty state */}
      {!loading && !hasData && (
        <div style={{ textAlign: "center", padding: "60px 40px", color: t.textSub }}>
          <div style={{ fontSize: 64, marginBottom: 16 }}>🌍</div>
          <div style={{ fontSize: 16, fontWeight: 600, marginBottom: 8, color: t.text }}>Enter a city to get live weather</div>
          <div style={{ fontSize: 13, marginBottom: 6 }}>Type any city name above — autocomplete will help</div>
          <div style={{ fontSize: 12, color: t.textDim }}>Powered by Open-Meteo (free, no API key) · Updates on every fetch</div>
        </div>
      )}
    </div>
  );
}