import { useState, useEffect, useRef } from "react";
import { useAuth } from "../context/AuthContext";
import { DARK } from "../styles/theme";
import { isNativePlatform } from "../utils/offline";

// ── Particle canvas ────────────────────────────────────────────────────────────
function ParticleCanvas() {
  return null;
}

// ── Glitch logo text ───────────────────────────────────────────────────────────
function GlitchLogo() {
  return (
    <div className="auth-logo-text" style={{position:"relative",display:"inline-block",fontFamily:"'Syne',sans-serif",fontWeight:800,letterSpacing:"-.02em",lineHeight:1}}>
      <span style={{color:"transparent",WebkitTextStroke:"1px rgba(144,96,240,0.15)"}} aria-hidden="true"
        className="neon-flick">TRAVELMATE</span>
      <span style={{position:"absolute",inset:0,background:"linear-gradient(90deg,#9060F0,#C8A0FF,#00E5FF)",WebkitBackgroundClip:"text",WebkitTextFillColor:"transparent",backgroundClip:"text"}}>TRAVELMATE</span>
    </div>
  );
}

// ── Aurora submit button ───────────────────────────────────────────────────────
function AuroraBtn({ loading, label, type="submit" }) {
  return (
    <div className="ab-wrap" style={{width:"100%",height:52,borderRadius:10}}>
      <button type={type} disabled={loading} style={{
        position:"absolute",inset:0,zIndex:10,opacity:0,
        cursor:loading?"not-allowed":"pointer",border:"none",borderRadius:10,
      }}/>
      <div className="ab-spin ab-blur" style={{borderRadius:10}}/>
      <div className="ab-spin ab-glow" style={{borderRadius:10,inset:"-1px"}}/>
      <div style={{
        position:"absolute",inset:0,borderRadius:10,
        background:"linear-gradient(135deg,#0C0E14,#10131C)",
        border:"1px solid rgba(144,96,240,0.4)",
        display:"flex",alignItems:"center",justifyContent:"center",gap:10,
        overflow:"hidden",
        minHeight: 48,
        boxShadow:"inset 0 1px 0 rgba(144,96,240,0.12),0 2px 24px rgba(0,0,0,.5)",
      }}>
        <div style={{position:"absolute",top:0,left:0,right:0,height:1,background:"linear-gradient(90deg,transparent,rgba(144,96,240,0.7),rgba(200,160,255,0.5),transparent)"}}/>
        {loading
          ? <div className="spin" style={{width:18,height:18,border:"2px solid rgba(144,96,240,.2)",borderTopColor:"#9060F0",borderRadius:"50%"}}/>
          : <span style={{fontSize:13}}>{"\u26A1"}</span>
        }
        <span style={{fontSize:13,fontWeight:800,letterSpacing:".1em",color:"#EDF0F7",textTransform:"uppercase"}}>{label}</span>
        {!loading && <div style={{position:"absolute",right:16,fontSize:12,color:"rgba(200,160,255,0.6)"}}>{"\u203A"}</div>}
      </div>
    </div>
  );
}

// ── Animated destination ticker ────────────────────────────────────────────────
const DESTS = ["Tokyo \u26E9\uFE0F","Paris \u{1F5FC}","Bali \u{1F33A}","New York \u{1F5FD}","Dubai \u{1F306}","Santorini \u{1F3DD}\uFE0F","Kyoto \u{1F341}","Maldives \u{1F3DD}\uFE0F"];
function DestTicker() {
  const [idx,setIdx] = useState(0);
  const [vis,setVis] = useState(true);
  useEffect(()=>{
    const id=setInterval(()=>{
      setVis(false);
      setTimeout(()=>{setIdx(i=>(i+1)%DESTS.length);setVis(true);},300);
    },2200);
    return()=>clearInterval(id);
  },[]);
  return (
    <span style={{
      display:"inline-block",
      color:"#9060F0",fontWeight:800,letterSpacing:".02em",
      opacity:vis?1:0,transform:vis?"translateY(0)":"translateY(-6px)",
      transition:"opacity .28s ease,transform .28s ease",
      minWidth:100,textAlign:"left",
    }}>{DESTS[idx]}</span>
  );
}

export default function AuthPage() {
  const t = DARK;
  const isNative = isNativePlatform();
  const { login, register } = useAuth();
  const [mode,        setMode]        = useState("login");
  const [loginEmail,  setLoginEmail]  = useState("");
  const [loginPass,   setLoginPass]   = useState("");
  const [regUsername, setRegUsername] = useState("");
  const [regEmail,    setRegEmail]    = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regFullName, setRegFullName] = useState("");
  const [err,         setErr]         = useState("");
  const [loading,     setLoading]     = useState(false);
  const [showPass,    setShowPass]    = useState(false);
  const [ready,       setReady]       = useState(false);
  const [foc,         setFoc]         = useState({});
  const [strength,    setStrength]    = useState(0);

  useEffect(()=>{
    if (isNative) {
      setReady(true);
      return undefined;
    }
    const id=setTimeout(()=>setReady(true),100);
    return()=>clearTimeout(id);
  },[isNative]);

  const focus=k=>()=>setFoc(f=>({...f,[k]:true}));
  const blur =k=>()=>setFoc(f=>({...f,[k]:false}));

  const calcStrength=p=>{let s=0;if(p.length>=8)s++;if(/[A-Z]/.test(p))s++;if(/[0-9]/.test(p))s++;if(/[^A-Za-z0-9]/.test(p))s++;return s;};
  const strCol=["#FF1744","#FF6D00","#FFD600","#00E676"][strength-1]||"#1C2030";
  const strLbl=["Weak","Fair","Good","Strong"][strength-1]||"";

  const submit=async e=>{
    e.preventDefault(); setErr(""); setLoading(true);
    try {
      if(mode==="login") await login(loginEmail,loginPass);
      else {
        if(strength<2){setErr("Password too weak \u2014 add uppercase and numbers");setLoading(false);return;}
        await register({email:regEmail,username:regUsername,full_name:regFullName||regUsername,password:regPassword});
      }
    } catch(ex){setErr(ex.message||"Something went wrong");}
    finally{setLoading(false);}
  };

  const inp=k=>({
    width:"100%",
    background:foc[k]?"rgba(144,96,240,0.06)":"rgba(255,255,255,0.03)",
    border:`1px solid ${foc[k]?"rgba(144,96,240,0.6)":"rgba(255,255,255,0.08)"}`,
    borderRadius:8,padding:"12px 14px",
    color:"#EDF0F7",fontSize:15,outline:"none",
    transition:"border-color .2s,box-shadow .2s,background .2s",
    fontFamily:"inherit",letterSpacing:".01em",
    boxShadow:foc[k]?"0 0 0 3px rgba(144,96,240,0.1)":"none",
  });

  const label={fontSize:10,fontWeight:800,textTransform:"uppercase",letterSpacing:".12em",color:"rgba(144,96,240,0.7)",display:"block",marginBottom:7};

  return (
    <div className={`auth-page-container${isNative ? " native-auth" : ""}`} style={isNative ? { position: "fixed", height: "var(--vp-height)", minHeight: "var(--vp-height)" } : undefined}>

      {/* SVG filters */}
      <svg style={{position:"absolute",width:0,height:0}}>
        <filter id="unopaq"><feColorMatrix values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 9 0"/></filter>
        <filter id="unopaq2"><feColorMatrix values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 3 0"/></filter>
      </svg>

      {/* Particle network */}
      <ParticleCanvas/>

      {/* Scan line */}
      <div style={{position:"absolute",left:0,right:0,height:1.5,background:"linear-gradient(90deg,transparent,#9060F088,#00E5FF66,transparent)",animation:isNative?"none":"scanMove 10s linear infinite",pointerEvents:"none"}}/>

      {/* Grid */}
      <div style={{position:"absolute",inset:0,backgroundImage:"linear-gradient(rgba(144,96,240,0.04) 1px,transparent 1px),linear-gradient(90deg,rgba(144,96,240,0.04) 1px,transparent 1px)",backgroundSize:"50px 50px",maskImage:"radial-gradient(ellipse 80% 80% at 50% 50%,black,transparent)",WebkitMaskImage:"radial-gradient(ellipse 80% 80% at 50% 50%,black,transparent)",pointerEvents:"none"}}/>

      {/* Orbs */}
      {[[600,500,"top:-20%","left:-15%","#9060F0","24s"],[400,400,"bottom:-15%","right:-10%","#C8A0FF","32s","6s"],[300,300,"top:45%","left:48%","#D500F9","18s","3s"]].map(([w,h,top,left,c,dur,delay="0s"],i)=>(
        <div key={i} style={{position:"absolute",width:w,height:h,top,left,borderRadius:"50%",background:`radial-gradient(circle,${c}12,transparent 65%)`,filter:"blur(80px)",pointerEvents:"none",animation:isNative?"none":`orbFloat ${dur} ease-in-out ${delay} infinite`}}/>
      ))}

      {/* Main card */}
      <div 
        className="auth-card-wrapper"
        style={{
          opacity:(isNative || ready)?1:0,
          transform:(isNative || ready)?"none":"translateY(28px) scale(.96)",
          transition:isNative?"none":undefined
        }}
      >
        {/* Outer glow border */}
        <div style={{position:"absolute",inset:-1,borderRadius:18,background:"linear-gradient(135deg,rgba(144,96,240,0.5),rgba(200,160,255,0.2),rgba(213,0,249,0.3),rgba(144,96,240,0.4))",backgroundSize:"300% 300%",animation:isNative?"none":"gradShift 5s linear infinite",filter:"blur(1px)"}}/>

        <div className="auth-card">

          {/* Top scan */}
          <div style={{position:"absolute",top:0,left:"5%",right:"5%",height:1,background:"linear-gradient(90deg,transparent,#9060F0AA,#00E5FF77,transparent)"}}/>

          {/* Logo area */}
          <div style={{textAlign:"center",marginBottom:26}}>
            <div style={{
              width:58,height:58,borderRadius:16,margin:"0 auto 14px",
              background:"linear-gradient(135deg,rgba(144,96,240,0.15),rgba(200,160,255,0.05))",
              border:"1px solid rgba(144,96,240,0.3)",
              display:"flex",alignItems:"center",justifyContent:"center",
              boxShadow:"0 0 30px rgba(144,96,240,0.2),inset 0 1px 0 rgba(144,96,240,0.1)",
            }} className="ember">
              <svg width="44" height="44" viewBox="0 0 100 100">
                <defs>
                  <linearGradient id="cg" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#9060F0"/>
                    <stop offset="100%" stopColor="#C8A0FF"/>
                  </linearGradient>
                </defs>
                <circle cx="50" cy="50" r="46" fill="none" stroke="url(#cg)" strokeWidth="2.5" opacity="0.4"/>
                <g>
                  <animateTransform attributeName="transform" type="rotate" from="0 50 50" to="360 50 50" dur="8s" repeatCount="indefinite"/>
                  <circle cx="50" cy="50" r="36" fill="none" stroke="url(#cg)" strokeWidth="1" strokeDasharray="4 6" opacity="0.5"/>
                  <polygon points="50,16 45,38 50,33 55,38" fill="url(#cg)"/>
                  <polygon points="50,84 45,62 50,67 55,62" fill="url(#cg)" opacity="0.35"/>
                  <circle cx="82" cy="50" r="3" fill="url(#cg)" opacity="0.5"/>
                  <circle cx="18" cy="50" r="3" fill="url(#cg)" opacity="0.5"/>
                </g>
                <circle cx="50" cy="50" r="7" fill="url(#cg)"/>
                <circle cx="50" cy="50" r="3.5" fill="#080510"/>
              </svg>
            </div>
            <GlitchLogo/>
            <div style={{fontSize:12,color:"rgba(122,134,158,0.8)",marginTop:7,letterSpacing:".08em"}}>
              NEXT DESTINATION: <DestTicker/>
            </div>
          </div>

          {/* Tabs */}
          <div style={{display:"flex",background:"rgba(255,255,255,0.03)",borderRadius:9,padding:3,marginBottom:22,border:"1px solid rgba(255,255,255,0.07)",gap:3}}>
            {[["login","SIGN IN"],["register","REGISTER"]].map(([m,l])=>(
              <button key={m} onClick={()=>{setMode(m);setErr("");}}
                style={{
                  flex:1,padding:"9px",borderRadius:7,fontSize:11,
                  fontWeight:800,cursor:"pointer",fontFamily:"inherit",
                  letterSpacing:".1em",
                  background:mode===m?`${t.accent}1F`:"transparent",
                  color:mode===m?t.accent:t.textSub,
                  border:mode===m?`1px solid ${t.accent}59`:"1px solid transparent",
                  transition:"all .2s",
                  boxShadow:mode===m?`0 0 16px ${t.accent}1A`:"none",
                }}>{l}</button>
            ))}
          </div>

          <form onSubmit={submit} style={{display:"flex",flexDirection:"column",gap:15}}>
            {mode==="login" ? (
              <>
                <div><label style={label}>Email or Username</label>
                  <input type="text" value={loginEmail} onChange={e=>setLoginEmail(e.target.value)} placeholder="you@email.com or explorer42" required autoComplete="username" onFocus={focus("le")} onBlur={blur("le")} style={inp("le")}/></div>
                <div style={{position:"relative"}}><label style={label}>Password</label>
                  <input type={showPass?"text":"password"} value={loginPass} onChange={e=>setLoginPass(e.target.value)} placeholder="Enter your password" required autoComplete="current-password" onFocus={focus("lp")} onBlur={blur("lp")} style={inp("lp")}/>
                  <button type="button" onClick={()=>setShowPass(s=>!s)} style={{position:"absolute",right:12,bottom:13,background:"none",border:"none",color:"rgba(122,134,158,0.5)",cursor:"pointer",fontSize:14}}>{showPass?"\u{1F648}":"\u{1F441}\uFE0F"}</button>
                </div>
              </>
            ) : (
              <>
                <div className="auth-reg-grid">
                  <div><label style={label}>Full Name</label>
                    <input value={regFullName} onChange={e=>setRegFullName(e.target.value)} placeholder="Your name" autoComplete="name" onFocus={focus("rn")} onBlur={blur("rn")} style={inp("rn")}/></div>
                  <div><label style={label}>Username</label>
                    <input value={regUsername} onChange={e=>setRegUsername(e.target.value)} placeholder="explorer42" required autoComplete="username" onFocus={focus("ru")} onBlur={blur("ru")} style={inp("ru")}/></div>
                </div>
                <div><label style={label}>Email</label>
                  <input type="email" value={regEmail} onChange={e=>setRegEmail(e.target.value)} placeholder="you@email.com" required autoComplete="email" onFocus={focus("re")} onBlur={blur("re")} style={inp("re")}/></div>
                <div style={{position:"relative"}}>
                  <div style={{display:"flex",justifyContent:"space-between",marginBottom:7}}>
                    <label style={{...label,marginBottom:0}}>Password</label>
                    {strength>0&&<span style={{fontSize:9,fontWeight:800,color:strCol,letterSpacing:".08em",textTransform:"uppercase"}}>{strLbl}</span>}
                  </div>
                  <input type={showPass?"text":"password"} value={regPassword} onChange={e=>{setRegPassword(e.target.value);setStrength(calcStrength(e.target.value));}} placeholder="Min 8 chars, uppercase, number" required autoComplete="new-password" onFocus={focus("rp")} onBlur={blur("rp")} style={inp("rp")}/>
                  <button type="button" onClick={()=>setShowPass(s=>!s)} style={{position:"absolute",right:12,bottom:13,background:"none",border:"none",color:"rgba(122,134,158,0.5)",cursor:"pointer",fontSize:14}}>{showPass?"\u{1F648}":"\u{1F441}\uFE0F"}</button>
                  {regPassword&&<div style={{display:"flex",gap:3,marginTop:7}}>{[1,2,3,4].map(i=><div key={i} style={{flex:1,height:2,borderRadius:99,background:i<=strength?strCol:"rgba(255,255,255,0.06)",transition:"background .3s"}}/>)}</div>}
                </div>
              </>
            )}

            {err&&<div style={{background:"rgba(255,23,68,0.08)",border:"1px solid rgba(255,23,68,0.25)",borderRadius:8,padding:"10px 13px",fontSize:12,color:"#FF6B6B",display:"flex",gap:8,alignItems:"flex-start"}}>{"\u26A0"} {err}</div>}

            <AuroraBtn loading={loading} label={mode==="login"?"Sign In":"Create Account"}/>
          </form>

          <div style={{marginTop:18,textAlign:"center",fontSize:11,color:"rgba(122,134,158,0.45)"}}>
            {mode==="login"?"No account? ":"Already exploring? "}
            <button onClick={()=>{setMode(mode==="login"?"register":"login");setErr("");}} style={{background:"none",border:"none",color:"#9060F0",cursor:"pointer",fontSize:11,fontWeight:800,letterSpacing:".04em"}}>
              {mode==="login"?"Register \u2192":"Sign in \u2192"}
            </button>
          </div>

          <div style={{marginTop:20,paddingTop:16,borderTop:"1px solid rgba(144,96,240,0.08)",display:"flex",justifyContent:"center",gap:16}}>
            {["\u{1F512} Secure","\u26A1 Fast","\u{1F30D} Global"].map(s=><span key={s} style={{fontSize:9,color:"rgba(122,134,158,0.3)",letterSpacing:".1em",textTransform:"uppercase"}}>{s}</span>)}
          </div>
        </div>
      </div>
    </div>
  );
}
