/**
 * TravelMate Global Data Store
 * A lightweight in-memory cache + prefetch system.
 * Shared across all components so the data is fetched once and reused everywhere.
 */
import { tripsApi, expensesApi, notesApi, checklistApi } from "../api/client";

const CACHE = {
  trips: null,
  summaries: {},       // tripId -> expense summary
  notes: {},           // tripId -> notes[]
  checklist: {},       // tripId -> checklist[]
  lastFetch: {},       // key -> timestamp
  listeners: new Set(),
};

const TTL = 60 * 1000; // 1 minute cache TTL

function notify() {
  CACHE.listeners.forEach(fn => fn());
}

export function subscribeToStore(fn) {
  CACHE.listeners.add(fn);
  return () => CACHE.listeners.delete(fn);
}

function isFresh(key) {
  return CACHE.lastFetch[key] && Date.now() - CACHE.lastFetch[key] < TTL;
}

/** Get cached trips synchronously (may be null if not loaded yet) */
export function getCachedTrips() {
  return CACHE.trips;
}

/** Get cached expense summary synchronously */
export function getCachedSummary(tripId) {
  return CACHE.summaries[String(tripId)] ?? null;
}

/** Get cached notes synchronously */
export function getCachedNotes(tripId) {
  return CACHE.notes[String(tripId)] ?? null;
}

/** Get cached checklist synchronously */
export function getCachedChecklist(tripId) {
  return CACHE.checklist[String(tripId)] ?? null;
}

/** Invalidate a specific key so it will be refetched */
export function invalidate(key) {
  delete CACHE.lastFetch[key];
  if (key === "trips") CACHE.trips = null;
}

/** Fetch trips (with cache) and return the result */
export async function fetchTrips(force = false) {
  if (!force && isFresh("trips") && CACHE.trips) return CACHE.trips;
  try {
    const trips = await tripsApi.list();
    CACHE.trips = trips;
    CACHE.lastFetch["trips"] = Date.now();
    notify();
    return trips;
  } catch (e) {
    return CACHE.trips || [];
  }
}

/** Fetch expense summary for one trip (with cache) */
export async function fetchSummary(tripId, force = false) {
  const key = `summary_${tripId}`;
  if (!force && isFresh(key) && CACHE.summaries[tripId]) return CACHE.summaries[tripId];
  try {
    const s = await expensesApi.summary(tripId);
    CACHE.summaries[String(tripId)] = s;
    CACHE.lastFetch[key] = Date.now();
    notify();
    return s;
  } catch {
    return CACHE.summaries[tripId] || null;
  }
}

/** Fetch notes for one trip (with cache) */
export async function fetchNotes(tripId, force = false) {
  const key = `notes_${tripId}`;
  if (!force && isFresh(key) && CACHE.notes[tripId]) return CACHE.notes[tripId];
  try {
    const notes = await notesApi.list(tripId);
    CACHE.notes[String(tripId)] = notes;
    CACHE.lastFetch[key] = Date.now();
    notify();
    return notes;
  } catch {
    return CACHE.notes[tripId] || [];
  }
}

/** Fetch checklist for one trip (with cache) */
export async function fetchChecklist(tripId, force = false) {
  const key = `checklist_${tripId}`;
  if (!force && isFresh(key) && CACHE.checklist[tripId]) return CACHE.checklist[tripId];
  try {
    const items = await checklistApi.list(tripId);
    CACHE.checklist[String(tripId)] = items;
    CACHE.lastFetch[key] = Date.now();
    notify();
    return items;
  } catch {
    return CACHE.checklist[tripId] || [];
  }
}

/**
 * Prefetch ALL data in the background.
 * Called once at app start (from AppDataContext).
 * Uses concurrency limiting so we don't hammer the backend.
 */
export async function prefetchAll() {
  const token = localStorage.getItem("tm_token");
  if (!token) return;

  // 1. Fetch trips first — everything depends on them
  const trips = await fetchTrips();
  if (!trips?.length) return;

  // Wait briefly so the dashboard can render its immediate priority data first
  await new Promise(r => setTimeout(r, 1500));

  // 2. Prefetch summaries serially with staggering to prevent connection exhaust timeouts
  for (const tr of trips) {
    await fetchSummary(tr.id);
    await new Promise(r => setTimeout(r, 250));
  }

  // 3. Prefetch notes + checklist for first 5 trips 
  const top5 = trips.slice(0, 5);
  for (const tr of top5) {
    await fetchNotes(tr.id);
    await fetchChecklist(tr.id);
    await new Promise(r => setTimeout(r, 350));
  }
}
