import os
import re

PAGE_DIR = r"c:\Users\acer\Desktop\RAJITH\travelmate\fe\src\pages"

def process_file(filepath):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    # If already using PageHeader, skip
    if "PageHeader" in content:
        # Just in case it was imported but not used, or already standardized
        pass

    # We want to find standard header blocks and replace them.
    # Because they vary, let's just do a regex replace on the title styles directly!
    # Instead of injecting the PageHeader component, let's just standardize the inline style attribute of the title!
    # The user asked: "make the text style size and positions consistent across tabs"
    # The title div usually looks like:
    # <div style={{fontFamily:"'Playfair Display',serif",fontSize:28,fontWeight:800,color:t.text}}>My Trips</div>
    # <h1 style={{fontFamily:"'Playfair Display',serif",fontSize:26,fontWeight:900,marginBottom:2,color:t.text}}>🤖 AI Travel Assistant</h1>
    
    # We will replace `fontFamily:.*Playfair Display.*}` with a standardized style object.
    # E.g. style={{ fontFamily: "'Playfair Display',serif", fontSize: 28, fontWeight: 900, margin: 0, color: t.text, lineHeight: 1.2, display: "flex", alignItems: "center" }}
    
    # It might be an h1 or h2 or div.
    
    pattern = r'style=\{\{\s*fontFamily:\s*["\']\'?Playfair Display\'?,serif["\']\s*,\s*fontSize:\s*\d+[^}]*\}\}'
    standard_style = 'style={{ fontFamily: "\'Playfair Display\',serif", fontSize: 28, fontWeight: 900, color: t.text, lineHeight: 1.2, margin: 0, display: "flex", alignItems: "center", gap: 8 }}'
    
    new_content = re.sub(pattern, standard_style, content)
    
    if new_content != content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(new_content)
        print(f"Updated {os.path.basename(filepath)}")

for filename in os.listdir(PAGE_DIR):
    if filename.endswith(".jsx"):
        process_file(os.path.join(PAGE_DIR, filename))
