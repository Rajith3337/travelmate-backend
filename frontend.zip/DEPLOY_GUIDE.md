# TravelMate — Full Deployment Guide
### Backend → Render · Frontend → Capacitor Android APK

---

## PART 1 — BACKEND ON RENDER

### Step 1 · Prepare your backend repo

1. Open your `be/` folder and create a file called `render.yaml` at the root:

```yaml
services:
  - type: web
    name: travelmate-api
    runtime: python
    buildCommand: pip install -r requirements.txt
    startCommand: uvicorn main:app --host 0.0.0.0 --port $PORT
    envVars:
      - key: SECRET_KEY
        generateValue: true
      - key: GEMINI_API_KEY
        sync: false
      - key: GROK_API_KEY
        sync: false
      - key: DATABASE_URL
        value: sqlite+aiosqlite:///./travelmate.db
      - key: ACCESS_TOKEN_EXPIRE_MINUTES
        value: "1440"
      - key: UPLOAD_DIR
        value: uploads
```

2. Push the `be/` folder to a **GitHub repository** (e.g. `github.com/you/travelmate-backend`).

---

### Step 2 · Deploy on Render

1. Go to **https://render.com** → Sign up / Log in
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub account → select your `travelmate-backend` repo
4. Fill in:
   | Field | Value |
   |---|---|
   | Name | `travelmate-api` |
   | Region | Singapore (closest to India) |
   | Branch | `main` |
   | Runtime | **Python 3** |
   | Build Command | `pip install -r requirements.txt` |
   | Start Command | `uvicorn main:app --host 0.0.0.0 --port $PORT` |
   | Instance Type | **Free** (or Starter $7/mo for always-on) |

5. Scroll to **Environment Variables** → Add:
   | Key | Value |
   |---|---|
   | `SECRET_KEY` | *(click "Generate")* |
   | `GEMINI_API_KEY` | `your-actual-gemini-key` |
   | `GROK_API_KEY` | `your-actual-grok-key` |
   | `DATABASE_URL` | `sqlite+aiosqlite:///./travelmate.db` |

6. Click **"Create Web Service"** — Render will build and deploy.

7. Once deployed, copy your URL: `https://travelmate-api.onrender.com`

> ⚠️ **Free tier sleeps after 15 min inactivity** — first request takes ~30s to wake. Upgrade to Starter ($7/mo) for always-on.

---

### Step 3 · Test your backend

```bash
curl https://travelmate-api.onrender.com/
# Should return: {"status":"TravelMate API v5 running","docs":"/docs"}
```

---

## PART 2 — FRONTEND AS ANDROID APK (TravelMate)

### Prerequisites (install once)

```bash
# 1. Node.js 18+ — https://nodejs.org
node --version   # must be 18+

# 2. Android Studio — https://developer.android.com/studio
# During install, make sure these are checked:
#   - Android SDK
#   - Android SDK Platform
#   - Android Virtual Device

# 3. Java 17 (bundled with Android Studio, or install separately)
java --version   # must be 17+
```

---

### Step 4 · Point frontend at your Render backend

Open `fe/.env.production` and set:
```
VITE_API_URL=https://travelmate-api.onrender.com
```

Open `fe/src/api/client.js` and change line 3:
```js
// FROM:
const RENDER_BACKEND = "http://localhost:8000";

// TO:
const RENDER_BACKEND = import.meta.env.VITE_API_URL || "https://travelmate-api.onrender.com";
```

---

### Step 5 · Build the web app

```bash
cd fe
npm install
npm run build
# This creates fe/dist/
```

---

### Step 6 · Install Capacitor

```bash
cd fe
npm install @capacitor/core @capacitor/cli @capacitor/android
npx cap init
```

When prompted:
- **App name:** `TravelMate`
- **App ID:** `com.travelmate.app`
- **Web asset directory:** `dist`

---

### Step 7 · Add Android platform

```bash
npx cap add android
npx cap sync android
```

This copies your `dist/` into the Android project.

---

### Step 8 · Set app name to "TravelMate"

Open `fe/android/app/src/main/res/values/strings.xml`:
```xml
<resources>
    <string name="app_name">TravelMate</string>
    <string name="title_activity_main">TravelMate</string>
    <string name="package_name">com.travelmate.app</string>
    <string name="custom_url_scheme">com.travelmate.app</string>
</resources>
```

---

### Step 9 · Set app icon

Replace these files with your icon (use a 1024×1024 PNG):
```
android/app/src/main/res/mipmap-hdpi/ic_launcher.png       (72×72)
android/app/src/main/res/mipmap-mdpi/ic_launcher.png       (48×48)
android/app/src/main/res/mipmap-xhdpi/ic_launcher.png      (96×96)
android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png     (144×144)
android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png    (192×192)
```
Or use Android Studio: right-click `res/` → **New → Image Asset** → upload your icon.

---

### Step 10 · Allow HTTP + mixed content (for dev/testing)

Open `fe/android/app/src/main/AndroidManifest.xml` and add inside `<application`:
```xml
android:usesCleartextTraffic="true"
android:networkSecurityConfig="@xml/network_security_config"
```

Create `fe/android/app/src/main/res/xml/network_security_config.xml`:
```xml
<?xml version="1.0" encoding="utf-8"?>
<network-security-config>
    <base-config cleartextTrafficPermitted="true">
        <trust-anchors>
            <certificates src="system"/>
        </trust-anchors>
    </base-config>
</network-security-config>
```

---

### Step 11 · Open in Android Studio and build APK

```bash
cd fe
npx cap open android
```

Android Studio opens. Then:

1. Wait for Gradle sync to finish (bottom status bar)
2. Menu → **Build → Build Bundle(s) / APK(s) → Build APK(s)**
3. Click **"locate"** in the popup → find your APK at:
   ```
   android/app/build/outputs/apk/debug/app-debug.apk
   ```

---

### Step 12 · Install on your phone

**Option A — USB:**
```bash
adb install android/app/build/outputs/apk/debug/app-debug.apk
```

**Option B — File transfer:**
Copy the `.apk` to your phone → open it → tap Install
(You may need to enable "Install from unknown sources" in Settings → Security)

---

### Step 13 · Build a RELEASE APK (for Play Store / sharing)

1. In Android Studio: **Build → Generate Signed Bundle / APK**
2. Choose **APK** → **Create new keystore**
3. Fill in keystore details → remember the password!
4. Select **release** build variant → Finish
5. APK is at: `android/app/build/outputs/apk/release/app-release.apk`

---

## PART 3 — QUICK RE-DEPLOY WORKFLOW

Every time you update the frontend:
```bash
cd fe
npm run build          # rebuild web app
npx cap sync android   # copy to Android project
# Then in Android Studio: Build → Build APK(s)
```

Every time you update the backend:
```bash
git add . && git commit -m "update" && git push
# Render auto-deploys on push
```

---

## SUMMARY

| What | Where | URL |
|---|---|---|
| Backend API | Render | `https://travelmate-api.onrender.com` |
| API Docs | Render | `https://travelmate-api.onrender.com/docs` |
| Android APK | Android Studio | `android/app/build/outputs/apk/debug/` |

---

## AI KEYS REFERENCE

| Provider | Get key at | Used for |
|---|---|---|
| Gemini | https://aistudio.google.com/app/apikey | Primary AI (free tier) |
| Grok | https://console.x.ai/ | Fallback AI (when Gemini fails) |

The backend tries Gemini first. If Gemini fails or is unconfigured, it automatically falls back to Grok. Both keys are optional — but at least one must be set.
